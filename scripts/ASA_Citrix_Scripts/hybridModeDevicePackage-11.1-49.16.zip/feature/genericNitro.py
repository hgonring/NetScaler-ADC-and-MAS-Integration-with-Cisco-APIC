#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import json
import requests
import syslog
import urllib

from util import scriptConst as const

from urllib import urlencode 

class NitroMapper(object):
    """
    This is to configure and update NetScaler's configurable object using NITRO
    """
    def __init__(self, logName):
	self.logger = logName

#
# This is to add Nitro object in the NetScaler
#
    def addNitroObject(self, objectName, vser, url, deviceIp, sessionId):
      self.logger.debug( "++++++++++++++++ This is to add NITRO Object ++++++++++++++++++")
      #self.logger.debug( " Params for this methods = %s"% (vser))
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      #url = "http://10.102.201.42/nitro/v1/config/"
      #url = "http://" + deviceIp + "/nitro/v1/config/"
      #payload = {"sessionid":sessionId, "lbvserver" : vser}
      payload = {"sessionid":sessionId, objectName : vser}
      payload = json.dumps(payload)
      payload = urllib.quote_plus(payload, ':{},=')
      payload = "object=" + payload
      self.logger.debug( "----------add Nitro Object ------ payload = %s"% payload)
      retCol = {}
      try:
          response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
          self.logger.debug( "------ add Nitro object ------------- Response  = %s "% response.text)
          retCol = response.json()
          retCol[const.STATUS_CODE] = response.status_code
          retCol[const.OPR_NAME] = const.ADD_OP

          return retCol
      except Exception as exMsg:
          self.logger.error( "Add Nitro  exception = " % str(exMsg))
          retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
          retCol[const.OPR_NAME] = const.ADD_OP
	  retCol[const.ERRORCODE] = 1001
	  retCol[const.MESSAGE] = str(exMsg)
	  retCol[const.STATE] = const.PERMANENT
	  retCol[const.SEVERITY] = "ERROR"
	  return retCol
#
# This is add Binding for the Nitro Object
#

    def addNitroBinding(self, objName, bindCol, url, devIp, sesId):
        self.logger.debug("+++++++ This is to create Bind  ++++++++ objName = %s, payload = %s" % (objName, bindCol))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        # this is to convert object value to double encoded value
        payload = {"sessionid":sesId, objName : bindCol}
        payload = json.dumps(payload)
        payload = urllib.quote_plus(payload, ':{},=')
        payload = "object=" + payload
        
        self.logger.debug(" JSON Payload = %s" %payload)
        retCol = {}
        try :
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug("+++++++++++++  Create Bind Response = %s" %response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.BIND_OP

            return retCol
        except Exception as exMsg:
            self.logger.error( "Create Bind exception = " % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.BIND_OP
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol
#
# This is to modify or set operations for the object
#
        
    def setNitroParams(self, objName, paramCol, url, deviceIp, sessionId):
        """
        This is to set parameters 
        """
        self.logger.debug('This is to set Nitro Params Name = %s, Collection = %s' % (objName, paramCol))
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        
        #url = "http://" + deviceIp + "/nitro/v1/config/"

        payload = {"sessionid":sessionId, "params":{"skipinvalidarg":"yes"}, objName : paramCol }   
        payload = json.dumps(payload)
        #payload = urllib.quote_plus(payload, ':{},=')
        self.logger.debug(' set Nitro JSON payload = %s' % (payload))
        retCol = {}
        try:
            
            response = requests.put(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('++++++++ set NITRO response details = %s' % (response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.MOD_OP
     
            return retCol
        except Exception as exMsg:
            self.logger.error( "++++++++ Set NITRO exception = " % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.MOD_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

#
# This is to unset or delete attribute  operations for the object
#
        
    def unsetNitroParams(self, objName, paramCol, url, deviceIp, sessionId):
        """
        This is to unset parameters 
        """
        self.logger.debug('This is to UNSET Nitro Params Name = %s, Collection = %s' % (objName, paramCol))
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params" : { "action" : "unset" }, "sessionid":sessionId, objName : paramCol } 
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug(' unset Nitro JSON payload = %s' % (payload))
        retCol = {}
        try:
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('+++++++ UNSET NITRO response details = %s' % (response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.MOD_OP
            return retCol

        except Exception as exMsg:
            self.logger.error( "++++++++ UnSet NITRO exception = " % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.MOD_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol
        
#
# This is to unbind or delete the existing the bind 
#
    def removeNitroObject(self, objName, objVal, args, devUrl, devIp, sesId):
        """
        This is delete object from the NetScaler, this should work for the unbind also
        """
        self.logger.debug('+++++++ Remove Nitro Object name = %s, collection = %s' % (objName, objVal))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        # this is for precautionary measure 
        if (objVal):
            objVal = str(objVal)
        else: 
            objVal = None
        # this is to convert object value to double encoded value
        if objName.find('6') > 0 and args is not None:  # this is to check for IPv6 specific values 
            tmp1 = {'id' : args}
            tmpEncode = urlencode(tmp1)
            tmp1 = tmpEncode[3:]
            tmp1 = {'id' : tmp1}
            tmpEncode = urlencode(tmp1)
            args = tmpEncode[3:]
        if (args):
            if (objVal):
                #url = "http://" + devIp + "/nitro/v1/config/" + objName + "/" + objVal + "?" + args
                url = devUrl + objName + "/" + objVal + "?" + args
            else:
                #url = "http://" + devIp + "/nitro/v1/config/" + objName +  "?" + args
                url = devUrl + objName +  "?" + args
        else:
            if (objVal):
                #url = "http://" + devIp + "/nitro/v1/config/" + objName + "/" + objVal
            	# this is to convert object value to double encoded value
                if objName.find('6') > 0 and objVal is not None:  # this is to check for IPv6 specific values 
                    tmp1 = {'id' : objVal}
                    tmpEncode = urlencode(tmp1)
                    tmp1 = tmpEncode[3:]
                    tmp1 = {'id' : tmp1}
                    tmpEncode = urlencode(tmp1)
                    objVal = tmpEncode[3:]

	    	self.logger.debug('IPv6 val double encoded = %s' % (objVal))
                url = devUrl + objName + "/" + objVal
            else:
                 #url = "http://" + devIp + "/nitro/v1/config/" + objName
                 url = devUrl + objName

        self.logger.debug('+++  Remove Nitro JSON URL = %s' % (url))
        retCol = {}
        try:
            response = requests.delete(url, headers=headers, timeout=const.TIMEOUT, verify=False)
            self.logger.debug('+++ Remvoe  NITRO response details = %s' % (response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.DELETE_OP
            return retCol

        except Exception as exMsg:
            self.logger.error( "++++++++ Remove NITRO exception = " % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.DELETE_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

        
#
# This is to get stat from NetScaler
#

    def getNitroStat(self, objName, objVal, devUrl, devIp, sesId):
        self.logger.debug("+++++++ This is to get stat ++++++++ for  objName = %s, instance Name  = %s" % (objName, objVal))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
	# this is to support both calls where objVal may or may not be present
	tmpUrl = devUrl.replace('config', 'stat')
        if (objVal):
            #url = "http://" + devIp + "/nitro/v1/stat/" + objName + '/' + objVal
	    # here remove config with stat for monitoring data collection
            url = tmpUrl + objName + '/' + objVal
            #url = "http://" + devIp + "/nitro/v1/stat/" + 'Interface?args=id:1%2F1'
	    self.logger.debug('URL = %s' % (url))
        else:
            url = tmpUrl + objName 
        retCol = {}
        try :
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug(" Get Nitro Stat Response = %s" %response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.MONITOR_OP
            return retCol
	    
        except Exception as exMsg:
            self.logger.error( "Get Nitro STAT exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.MONITOR_OP
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol

#
# This is to get member stat from NetScaler
#

    def getNitroMemberStat(self, objName, objVal, devUrl, devIp, sesId):
        self.logger.debug("+++++++ This is to get member stat ++++++++ for  objName = %s, param details = %s" % (objName, objVal))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
	# this is to support both calls where objVal may or may not be present
	tmpUrl = devUrl.replace('config', 'stat')
        if (objVal):
            #url = "http://" + devIp + "/nitro/v1/stat/" + objName + '?' + objVal
            url = tmpUrl +  objName + '?' + objVal
            #url = "http://" + devIp + "/nitro/v1/stat/" + 'Interface?args=id:1%2F1'
	    self.logger.debug('URL = %s' % (url))
        else:
            #url = "http://" + devIp + "/nitro/v1/stat/" + objName 
            url = tmpUrl + objName 
        retCol = {}
        try :
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug(" Get Nitro Member Stat Response = %s" %response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.MONITOR_OP
            return retCol
	    
        except Exception as exMsg:
            self.logger.error( "Get Nitro Member STAT exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.MONITOR_OP
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol

#
# This is to get configuration from the device
#
    def getNitroObjectsConfigFromDevice(self, objName, devUrl, devIp, sesId):
        """
        This is to get configuration objects details from device
        """
        self.logger.debug('++++++++ This is to get config object details for = %s ++++++++' % (objName))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        retCol = {}
        try:
            #url = "http://" + devIp + "/nitro/v1/config/" + objName
            url = devUrl + objName
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('+++++++++ getConfigObject URL = %s and Response = %s' % (url, response.text))
            #self.logger.debug('+++++++++  Response = %s' % (response.json()))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.GET_OP            
            return retCol
        except Exception as exMsg:
            self.logger.debug('++ Exception from getConfigObject =%s'% str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.GET_OP 
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol

#
# This is to get object instance from the device configuration 
#
    def getNitroInstanceFromDevice(self, objName, instName, devUrl, devIp, sesId):
        """
        This is to get object instance from device configuration 
        """
        self.logger.debug('++++++++ This is to get object instance from device config object details for = %s ++++++++' % (objName))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        retCol = {}
        try:
            #url = "http://" + devIp + "/nitro/v1/config/" + objName + "/" + instName
            if objName == const.SNMPTRAP:
                url = devUrl + objName + "?" + instName
            else:
                url = devUrl + objName + "/" + instName
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('+++++++++ getObjectConfigObject URL = %s and Response = %s' % (url, response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.GET_OP            
            return retCol
        except Exception as exMsg:
            self.logger.error('++ Exception from getConfigObject =%s'% str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.GET_OP 
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol

#
# This is to get bindings from NetScaler for each object
#
    def getNitroBindingsForObject(self, objName, objVal, devUrl, devIp, sesId):
        """
        This is to get bindings for each object
        """
        self.logger.debug('++++++++ This is to get bindings for object = %s Value = %s' % (objName, objVal))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        retCol = {}
        try:
            #url = "http://" + devIp + "/nitro/v1/config/" + objName + '/' + objVal
            url = devUrl + objName + '/' + objVal
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('+++++++++ getNitroBindings For Object  URL = %s and Response = %s' % (url, response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.GET_OP
            return retCol
            
        except Exception as exMsg:
            self.logger.error('++ Exception from getNitroBindingsForObject =%s'% str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.GET_OP 
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol


#
# This is to get stat from NetScaler
#

    def getInterfaceStat(self, objName, objVal, devUrl, devIp, sesId):
        self.logger.debug("+++++++ This is to get Interface stat ++++++++ for  objName = %s, instance Name  = %s" % (objName, objVal))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
	# this is to support both calls where objVal may or may not be present
	payload = None
        if (objVal):
            # this is to convert object value to double encoded value
            tmp1 = {'id' : objVal}
            tmpEncode = urlencode(tmp1)
            tmp1 = tmpEncode[3:]
            tmp1 = {'id' : tmp1}
            tmpEncode = urlencode(tmp1)
            objVal = tmpEncode[3:]

	    self.logger.debug('Interface val double encoded = %s' % (objVal))
        retCol = {}
        try :
	    tmpUrl = devUrl.replace('config', 'stat')
            #url = "http://" + devIp + "/nitro/v1/stat/Interface/" + objVal 
            url = tmpUrl + "Interface/" + objVal 
	    #self.logger.debug('URL = %s' % (url))
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
	    #self.logger.debug('URL = %s' % (response.url))
            #self.logger.debug(" Get Interface  Stat Response = %s" %response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.MONITOR_OP
            return retCol
	    
        except Exception as exMsg:
            self.logger.error( "Get Interface  STAT exception = %s" % str(exMsg))
	    retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.MONITOR_OP 
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol
	
#
# This is to set LB VServer's Param
#

    def setLBVServerParams(self, lbvParams, sessionId, url, deviceIp):
        """
        This is to set LB vserver's parameters 
        """
        syslog.syslog(syslog.LOG_ALERT, "This is to set LB VServer Params  ++++++++++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"sessionid":sessionId, "lbvserver": {
                        "name" : vser["name"],
                        "servicetype":vser["serviceType"],
                        "ipv46" : vser["ipAddress"],
                        "port" : vser["port"],
                        "state" : vser["state"],
                        "lbmethod" : vser["lbmethod"]
                        }
                 }
        payload = json.dumps(payload)
        syslog.syslog(syslog.LOG_ALERT," LB VServer JSON payload = %s"%payload)
        response = requests.put(url, timeout=const.TIMEOUT, data=payload, headers=headers, verify=False)
        syslog.syslog(syslog.LOG_ALERT," LB VServer response details = %s"%response.text)
     
        return response.json()
#
# This is for clear config from NetScaler device
#
    def doClearConfigFromNetScaler(self, url, devIp, cfgLevel, sesId):
        """
        This is to clear device configuration from the NetScaler device
        """
        self.logger.debug("+++++++ This is to clear configuration from  NetScaler IP = %s" % (devIp))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        retCol = {}
        try :
            #url = "http://" + devIp + "/nitro/v1/config/"
            payload = None
            if cfgLevel == 'extended':
                payload = { "params" : { 'action': 'clear'},
                        'sessionid' : sesId,
                         'nsconfig' : {'level' : 'extended%2B' } } # %2B is encoded value for +
            else:
                payload = { "params" : { 'action': 'clear'},
                        'sessionid' : sesId,
                         'nsconfig' : {'level' : 'basic' } }  
                         #'nsconfig' : {'level' : extStr } }
            payload = json.dumps(payload)
            payload = 'object=' + payload
            self.logger.debug('+++++++ Clear Config Payload = %s' % (payload))

            response = requests.post(url, timeout=const.TIMEOUT, data=payload, headers=headers, verify=False)
            self.logger.debug(" Clear config  Response = %s" %response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.DELETE_OP
            return retCol
            
        except Exception as exMsg:
            self.logger.error( "do Clear Config  exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.DELETE_OP 
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

#
# This is to add LB Service Group Binding 
#

    def addLBServiceGroupBinding(self, vserName, svrGrpName, sessionId, url, deviceIp):
        syslog.syslog(syslog.LOG_ALERT, "+++++++ This is to Bind service Group with LBVServer ++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"sessionid":sessionId, "lbvserver_servicegroup_binding": { 
        	"name":vserName,
		"servicegroupname": svrGrpName}
		}
	
        syslog.syslog(syslog.LOG_ALERT, " Payload = %s" %payload)
      	payload = json.dumps(payload)
        payload = "object=" + payload
        syslog.syslog(syslog.LOG_ALERT, " JSON Payload = %s" %payload)
	try :
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            syslog.syslog(syslog.LOG_ALERT, " Response = %s" %response.text)

            return response.json()
	except Exception as exMsg:
	    retCol = {}
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol
            syslog.syslog(syslog.LOG_ERR, str(exMsg))

    def addLBVServerObj(self, sessionId, url, deviceIp):
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      #url = "http://" + deviceIp + "/nitro/v1/config/"
      payload = {"sessionid":sessionId, "lbvserver": { 
			"name" : self.name, 
			"servicetype":self.serviceType,
		 	"ipv46" : self.ipAddress,
		 	"port" : self.port,
			"lbmethod" : self.lbMethod } }
      payload = json.dumps(payload)
      payload = "object=" + payload
      response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
      return response.json()

    def setLBVServerObj(self, lbDetail, sessionId, devUrl, deviceIp):
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      url = devUrl + "/lbvserver/" + self.name + "/"
      payload = {"sessionid":sessionId, "lbvserver": {
                        "name" : lbDetail["name"],
		       "backupvserver" : lbDetail["backupvserver"] } }
      payload = json.dumps(payload)
      response = requests.put(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
      return response.json()

    def renLBVServerObj(self, oldName, sessionId, devUrl, deviceIp):
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      url = devUrl + "/lbvserver/" + oldName + "/"
      payload = {"params": { "action" : "rename"}, "sessionid":sessionId, "lbvserver": {
                        "name" : oldName ,
                        "newname" : self.name } }
                       # "servicetype":self.serviceType, This can not changed
                       #"ipv46" : self.ipAddress,
                       # "port" : self.port,  Same as serviceType This can not changed              
                       # "lbmethod" : self.lbMethod } }
      payload = json.dumps(payload)
      payload = "object=" + payload
      response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
      return response.json()
    
    def enableLBVServer(self, serverName, sessionId, url, deviceIp):
        """                     
        This is enable LB server  from NetScaler   
        """
        syslog.syslog(syslog.LOG_ALERT, "++++++++ This is enable LB Server on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"enable"},
                       "sessionid":sessionId,
                       "lbvserver": { "name": serverName}
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        syslog.syslog(syslog.LOG_ALERT, " LB ENABLE Server Payload = %s"%payload)
        response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
        syslog.syslog(syslog.LOG_ALERT, " LB ENABLE Server Response = %s"%response)

        return response.json()

#
# This is to send arp to all or specific IP
#
    def sendArp(self, ipAdr, allBoolVal, url, devIp, sesId):
        """
        This is to send ARP to all or given IP address
        """
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        tmp1 = {'id' : ipAdr}
        tmpEncode = urlencode(tmp1)
        ipAdr = tmpEncode[3:]
        #tmp1 = {'id' : tmp1}
        #tmpEncode = urlencode(tmp1)
        #ipAdr = tmpEncode[3:]
        payload = { "params" : { 'action': 'send'},
                    'sessionid' : sesId,
                     'arp' : { 'ipaddress' : ipAdr , 'all' : allBoolVal } }
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug('++++++++ Send ARP payload = %s' % (payload))
        #payload = urllib.quote_plus(payload, ':{},=')
        #self.logger.debug('++++++++ Encoded ARP payload = %s' % (payload))
        retCol = {}
        try :
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug(" Send ARP Nitro  Response = %s" %response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.ARP_OP
            return retCol
        except Exception as exMsg:
            self.logger.error( "SEND  ARP Nitro  exception = %s" % str(exMsg))
	    retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.ARP_OP 
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol


#
# This is to send arp to all or specific IP
#
    def executeCLI(self, payload, url, devIp, sesId):
        """ 
        This is to execute CLIs kind of command i.e. link certs 
        """
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug('++++++++ add execute CLI payload = %s' % (payload))
        #payload = urllib.quote_plus(payload, ':{},=')                                                                                                                           
        #self.logger.debug('++++++++ Encoded ARP payload = %s' % (payload))                                                                                                      
        retCol = {}
        try :
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug("execute CLI Nitro  Response = %s" %response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.ADD_OP
            return retCol
        except Exception as exMsg:
            self.logger.error( "execute CLI Nitro  exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.ADD_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

#
# This is for save config
#
    def saveConfig(self, url, devIp, sesId):
        """
        This is for save config at NetScaler
        """
        self.logger.debug('+++++++++ Call for Save Config for device = %s' % (devIp))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        payload = { "params" : { 'action': 'save'},
                    'sessionid' : sesId,
                     'nsconfig' : { } }
        payload = json.dumps(payload)
        payload = 'object=' + payload
        self.logger.debug('+++++++ Save Config Payload = %s' % (payload))
        retCol = {}
        try:
            response = requests.post(url, data=payload, headers=headers, verify=False)
            self.logger.debug(" Save config  Response = %s" % response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.ADD_OP
            return retCol
            
        except Exception as exMsg:
            self.logger.error( "Save Config  exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.ADD_OP 
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

#
# This is for apply ns acls
#
    def applyAcls(self, url, devIp, sesId):
        """
        This is for apply ns acls at NetScaler
        """
        self.logger.debug('+++++++++ Call for apply ns acls for device = %s' % (devIp))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        payload = { "params" : { 'action': 'apply'},
                    'sessionid' : sesId,
                     'nsacls' : { } }
        payload = json.dumps(payload)
        payload = 'object=' + payload
        self.logger.debug('+++++++ apply ns acls Payload = %s' % (payload))
        retCol = {}
        try:
            response = requests.post(url, data=payload, headers=headers, verify=False)
            self.logger.debug(" apply ns acls  Response = %s" % response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.ADD_OP
            return retCol
            
        except Exception as exMsg:
            self.logger.error( "apply ns acls  exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.ADD_OP 
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol


#
# This is for apply ns acls6
#
    def applyAcls6(self, url, devIp, sesId):
        """
        This is for apply ns acls at NetScaler
        """
        self.logger.debug('+++++++++ Call for apply ns acls6 for device = %s' % (devIp))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        payload = { "params" : { 'action': 'apply'},
                    'sessionid' : sesId,
                     'nsacls6' : { } }
        payload = json.dumps(payload)
        payload = 'object=' + payload
        self.logger.debug('+++++++ apply ns acls6 Payload = %s' % (payload))
        retCol = {}
        try:
            response = requests.post(url, data=payload, headers=headers, verify=False)
            self.logger.debug(" apply ns acls6  Response = %s" % response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.ADD_OP
            return retCol
            
        except Exception as exMsg:
            self.logger.error( "apply ns acls6  exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.ADD_OP 
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol
    
#
# This is to disable LBVServer 
#
    def disableLBVServer(self, serverName, sessionId, url, deviceIp):
        """                                                                                       
        This is disable LB server  from NetScaler                                                               
        """
        syslog.syslog(syslog.LOG_ALERT, "++++++++ This is disable LB Server on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"disable"},
                       "sessionid":sessionId,
                       "lbvserver": { "name": serverName}
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload

        syslog.syslog(syslog.LOG_ALERT, " LB DISABLE Server Payload = %s"%payload)
        response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
        syslog.syslog(syslog.LOG_ALERT, " LB DISABLE Server Response = %s"%response)

        return response.json()


#
# This is to clear all VLANs from NetScaler
#
    def removeAllVLANs(self, devUrl, devIp, sesId):
        """
        This is to remove all the VLANs from NetScaler
        """

        self.logger.debug('+++++++++ Call for remove VLANs for device = %s' % (devIp))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/vlan"
        url =  devUrl + "vlan"

        retCol = {}
        try:
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug(" get VLAN  Response = %s" %response.text)
            retCol = response.json()
            tmpErrorCode = 0
            tmpVlanList = []
            for i1, j1 in retCol.iteritems():
                if i1 == const.ERRORCODE:
                    tmpErrorCode = j1
                elif i1 == const.VLAN_BIND:  # VLAN_BIND is eq 'vlan'
                    tmpVlanList = j1
            if tmpErrorCode == 0:
                for tmpCol in tmpVlanList:
                    for a1, b1 in tmpCol.iteritems():
                        if a1 == const.ID:
                            # ignore the VLAN id 1 since this is default
                            if int(b1) == 1:
                                continue
                            # remove this from NetScaler
                            tmpUrl = url + '/' + b1
                            tmpResp = requests.delete(tmpUrl, timeout=const.TIMEOUT, headers=headers, verify=False)
                            self.logger.debug('+++++++ remove All Vlan response for tmpURL = %s response = %s' % (tmpUrl, tmpResp))
 
            return

        except Exception as exMsg:
            self.logger.error( " remove All VLANs from NetScaler exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.DELETE_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

#
# This is to clear all IPs from NetScaler Except the one which has mgmt access
#
    def removeIPsWithoutMgmtAc(self, devUrl, devIp, sesId):
        """
        This is to remove all the IPs from NetScaler which doesn't have mgmt access 
        """

        self.logger.debug('+++++++++ Call for remove NSIPs for device = %s' % (devIp))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/vlan"
        url =  devUrl + "vlan"

        retCol = {}
        try:
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug(" get VLAN  Response = %s" %response.text)
            retCol = response.json()
            tmpErrorCode = 0
            tmpVlanList = []
            for i1, j1 in retCol.iteritems():
                if i1 == const.ERRORCODE:
                    tmpErrorCode = j1
                elif i1 == const.NSIP:  # NSIP is eq 'nsip'
                    tmpVlanList = j1
            if tmpErrorCode == 0:
                for tmpCol in tmpVlanList:
                    for a1, b1 in tmpCol.iteritems():
                        if a1 == const.MGMTACCESS:
                            # ignore the IPs which has mgmtAccess
                            if b1.strip().lower() == const.ENABLED:
                                continue
                            # remove this from NetScaler
                            tmpUrl = url + '/' + b1
                            tmpResp = requests.delete(tmpUrl, timeout=const.TIMEOUT, headers=headers, verify=False)
                            self.logger.debug('+++++++ remove All IPs Without mgmt access response for tmpURL = %s response = %s' % (tmpUrl, tmpResp))
 
            return

        except Exception as exMsg:
            self.logger.error( " remove All IPs from NetScaler exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.DELETE_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol
#
# This is for adding HA node
#
    def addHANode(self, nodeCol, sesId, url, devIp):
        """
        This is to add Node for HA config
        """
        self.logger.debug( "++++++++++++++++ This is to add HA Node  ++++++++++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"sessionid":sessionId, 'hanode' : nodeCol}
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug( "----------add HA Node  ------ payload = %s"% payload)
        retCol = {}
        try:
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug( "------ add HA Node ------------- Response  = %s "% response.text)
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.ADD_OP

            return retCol
        except Exception as exMsg:
            self.logger.error( "Add HA Node  exception = %s" % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.ADD_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

    def __eq__(self, other):
        return self.__dict__ == other.__dict__

    def diffOps(self, other):
        if (self.name != other.name) and (self.serviceType == other.serviceType) and (self.ipAddress == other.ipAddress) and (self.port == other.port) and (self.lbMethod == other.lbMethod):
            return "renOps"
        elif self.name == other.name: 
              return "setOps"
        else: 
           return "newOps"

#
# This is to get object instance using filter mechanism from the device configuration 
#
    def getNitroInstanceByFilterFromDevice(self, objName, paramName, paramVal, devUrl, devIp, sesId):
        """
        This is to get object instance from device configuration using filter mechanism 
        """
        self.logger.debug('++++++++ This is to get object instance from device config object details for = %s ++++++++' % (objName))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        retCol = {}
        try:
            #url = "http://" + devIp + "/nitro/v1/config/" + objName + "/" + instName
            url = devUrl + objName + "?filter=" + paramName + ':' + paramVal
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('+++++++++ getObjectConfigObject URL = %s and Response = %s' % (url, response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.GET_OP            
            return retCol
        except Exception as exMsg:
            self.logger.debug('++ Exception from getConfigObject =%s'% str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.GET_OP 
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol

	    
	    
#
# This is to switch operations for the object
#
        
    def switchNitroParams(self, objName, paramCol, url, deviceIp, sessionId):
        """
        This is to switch parameters 
        """
        self.logger.debug('This is to switch Nitro Params Name = %s, Collection = %s' % (objName, paramCol))
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params" : { "action" : "switch" }, "sessionid":sessionId, objName : paramCol } 
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug(' switch Nitro JSON payload = %s' % (payload))
        retCol = {}
        try:
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('+++++++ switch NITRO response details = %s' % (response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.MOD_OP
            return retCol

        except Exception as exMsg:
            self.logger.error( "++++++++ switch NITRO exception = " % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.MOD_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

#
# This is to set ZebOS routing related parameters
#
        
    def setZebosNitroParams(self, cmdstr, url, sessionId):
        """
        This is to set parameters 
        """
        self.logger.debug('This is to setZebosNitroParams,  cmdstr = %s' % (cmdstr))
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        config = {"commandstring":cmdstr}
        self.logger.debug(' setZebosNitroParams config= %s' % (config))

        payload = {"sessionid":sessionId, "params":{"action":"apply"}, const.ROUTING:config} 
        #payload = {"params":{"action":"apply"}, const.ROUTING:config}   
        self.logger.debug(' setZebosNitroParams payload1= %s' % (payload))
        payload = json.dumps(payload)
        #payload = urllib.quote_plus(payload, ':{},=')
        payload = "object=" + payload 
        self.logger.debug(' setZebosNitroParams = %s' % (payload))
        retCol = {}
        try:
            
            response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('++++++++ setZebosNitroParams = %s' % (response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.MOD_OP
     
            return retCol
        except Exception as exMsg:
            self.logger.error( "++++++++ setZebosNitroParams exception = " % str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.MOD_OP
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = str(exMsg)
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            return retCol

#
# This is to get object instance from the device configuration 
#
    def getZebosNitroFromDevice(self, cmdstr, devUrl, sesId):
        """
        This is to get Zebos configuration from device
        """
        self.logger.debug('++++++++ This is to get Zebos configuration from device cmdstr = %s ++++++++' % (cmdstr))
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        retCol = {}
        try:
            url = devUrl + const.ROUTING + "?args=commandstring:" + cmdstr
            response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
            self.logger.debug('+++++++++ getObjectConfigObject URL = %s and Response = %s' % (url, response.text))
            retCol = response.json()
            retCol[const.STATUS_CODE] = response.status_code
            retCol[const.OPR_NAME] = const.GET_OP            
            return retCol
        except Exception as exMsg:
            self.logger.error('++ Exception from getConfigObject =%s'% str(exMsg))
            retCol[const.STATUS_CODE] = const.EXCEPTION_CODE
            retCol[const.OPR_NAME] = const.GET_OP 
	    retCol[const.ERRORCODE] = 1001
	    retCol[const.MESSAGE] = str(exMsg)
	    retCol[const.STATE] = const.PERMANENT
	    retCol[const.SEVERITY] = "ERROR"
	    return retCol
