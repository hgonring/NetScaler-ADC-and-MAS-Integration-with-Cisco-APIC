#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import json
import requests
import syslog

class LBVServer(object):
    """
    This is to configure and update LBVServer
    """
    def __init__(self, logName, uname=None, userviceType=None, uipAddress=None, uport= None, ulbmethod=None):
        self.name = uname
        self.serviceType = userviceType
        self.ipAddress = uipAddress
        self.port = uport
        self.lbMethod = ulbmethod
	self.logger = logName

    def addLBVServer(self, vser, deviceIp, sessionId):
      self.logger.debug( "++++++++++++++++ This is to add LB VServer ++++++++++++++++++")
      self.logger.debug( " Params for this methods = ", vser)
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      #url = "http://10.102.201.42/nitro/v1/config/"
      url = "http://" + deviceIp + "/nitro/v1/config/"
      payload = {"sessionid":sessionId, "lbvserver" : vser}
      payload = json.dumps(payload)
      payload = "object=" + payload
      self.logger.debug( "add LB VServer payload = %s"% payload)
 
      response = requests.post(url, data=payload, timeout=2, headers=headers)
      self.logger.debug( "add LB VServer Response  = %s "% response.text)

      return response

    def setLBVServerParams(self, lbvParams, sessionId, deviceIp):
        """
        This is to set LB vserver's parameters 
        """
        syslog.syslog(syslog.LOG_ALERT, "This is to set LB VServer Params  ++++++++++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        
        url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"sessionid":sessionId, "lbvserver": {
                        "name" : vser["name"],
                        "servicetype":vser["serviceType"],
                        "ipv46" : vser["ipAddress"],
                        "port" : vser["port"],
                        "state" : vser["state"],
                        "lbmethod" : vser["lbmethod"]
                        }
                 }
        payload = json.dumps(payload)
        syslog.syslog(syslog.LOG_ALERT," LB VServer JSON payload = %s"%payload)
        response = requests.put(url, data=payload, timeout=2, headers=headers)
        syslog.syslog(syslog.LOG_ALERT," LB VServer response details = %s"%response.text)
     
        return response


    def addLBServiceGroupBinding(self, vserName, svrGrpName, sessionId, deviceIp):
        syslog.syslog(syslog.LOG_ALERT, "+++++++ This is to Bind service Group with LBVServer ++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"sessionid":sessionId, "lbvserver_servicegroup_binding": { 
        	"name":vserName,
		"servicegroupname": svrGrpName}
		}
	
        syslog.syslog(syslog.LOG_ALERT, " Payload = %s" %payload)
      	payload = json.dumps(payload)
        payload = "object=" + payload
        syslog.syslog(syslog.LOG_ALERT, " JSON Payload = %s" %payload)
	try :
            response = requests.post(url, data=payload, timeout=2, headers=headers)
	except Exception, err:
            syslog.syslog(syslog.LOG_ERR, traceback.format_exc())
        syslog.syslog(syslog.LOG_ALERT, " Response = %s" %response.text)

        return response

    def addLBVServerObj(self, sessionId, deviceIp):
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      url = "http://" + deviceIp + "/nitro/v1/config/"
      payload = {"sessionid":sessionId, "lbvserver": { 
			"name" : self.name, 
			"servicetype":self.serviceType,
		 	"ipv46" : self.ipAddress,
		 	"port" : self.port,
			"lbmethod" : self.lbMethod } }
      payload = json.dumps(payload)
      payload = "object=" + payload
      response = requests.post(url, data=payload, timeout=2, headers=headers)
      return response

    def setLBVServerObj(self, lbDetail, sessionId, deviceIp):
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      url = "http://" + deviceIp + "/nitro/v1/config/lbvserver/" + self.name + "/"
      payload = {"sessionid":sessionId, "lbvserver": {
                        "name" : lbDetail["name"],
		       "backupvserver" : lbDetail["backupvserver"] } }
      payload = json.dumps(payload)
      response = requests.put(url, data=payload, timeout=2, headers=headers)
      return response

    def renLBVServerObj(self, oldName, sessionId, deviceIp):
      headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      url = "http://" + deviceIp + "/nitro/v1/config/lbvserver/" + oldName + "/"
      payload = {"params": { "action" : "rename"}, "sessionid":sessionId, "lbvserver": {
                        "name" : oldName ,
                        "newname" : self.name } }
                       # "servicetype":self.serviceType, This can not changed
                       #"ipv46" : self.ipAddress,
                       # "port" : self.port,  Same as serviceType This can not changed              
                       # "lbmethod" : self.lbMethod } }
      payload = json.dumps(payload)
      payload = "object=" + payload
      response = requests.post(url, data=payload, timeout=2, headers=headers)
      return response
    
    def enableLBVServer(self, serverName, sessionId, deviceIp):
        """                     
        This is enable LB server  from NetScaler   
        """
        syslog.syslog(syslog.LOG_ALERT, "++++++++ This is enable LB Server on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"enable"},
                       "sessionid":sessionId,
                       "lbvserver": { "name": serverName}
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        syslog.syslog(syslog.LOG_ALERT, " LB ENABLE Server Payload = %s"%payload)
        response = requests.post(url, data=payload, timeout=2, headers=headers)
        syslog.syslog(syslog.LOG_ALERT, " LB ENABLE Server Response = %s"%response)

        return response

    def disableLBVServer(self, serverName, sessionId, deviceIp):
        """                                                                                       
        This is disable LB server  from NetScaler                                                               
        """
        syslog.syslog(syslog.LOG_ALERT, "++++++++ This is disable LB Server on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"disable"},
                       "sessionid":sessionId,
                       "lbvserver": { "name": serverName}
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        syslog.syslog(syslog.LOG_ALERT, " LB DISABLE Server Payload = %s"%payload)
        response = requests.post(url, data=payload, timeout=2, headers=headers)
        syslog.syslog(syslog.LOG_ALERT, " LB DISABLE Server Response = %s"%response)

        return response


    def __eq__(self, other):
        return self.__dict__ == other.__dict__

    def diffOps(self, other):
        if (self.name != other.name) and (self.serviceType == other.serviceType) and (self.ipAddress == other.ipAddress) and (self.port == other.port) and (self.lbMethod == other.lbMethod):
            return "renOps"
        elif self.name == other.name: 
              return "setOps"
        else: 
           return "newOps"

