# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import logging
import logging.config
import Insieme.Logger as Logger
import inspect


class LogService(object):
    """
    This is to get logging service for the device script
    """
    
    def __init__(self):
        pass


    def get_frame(self):
        cf = inspect.currentframe()
        caller_frame = inspect.getouterframes(cf,3)
        return caller_frame
    
    def getLogger(self, logName='deviceScript'):
        return self

    def debug (self, args):
        Logger.log(Logger.DEBUG, args)

    def debug2 (self, args):
        Logger.log(Logger.DEBUG2, args)
    
    def debug3 (self, args):
        Logger.log(Logger.DEBUG3, args)
    
    def debug4 (self, args):
        Logger.log(Logger.DEBUG4, args)
    
    def crit (self, args):
        Logger.log(Logger.CRIT, args)
    
    def info (self, args):
        Logger.log(Logger.INFO, args)

    def warn (self, args):
        Logger.log(Logger.WARN, args)

    def error (self, args):
        Logger.log(Logger.ERROR, args)
    
if __name__ == "__main__":
   lgObj = LogService()
   log1 = lgObj.getLogger() 
   log1.debug("this is test")
   log1.error("this is test")
   log1.warn("this is test")
   log1.info("this is test")
