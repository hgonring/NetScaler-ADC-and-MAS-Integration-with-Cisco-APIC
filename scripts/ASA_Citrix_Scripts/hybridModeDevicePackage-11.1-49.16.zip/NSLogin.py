#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import requests
import json
import logging
import logging.config

import LogService

from util import scriptConst as const

class NSLogin(object):
    """
        This is Login class for NS to login at NetScaler
    """

    def __init__(self, credential, logName):
      self.url = credential["url"]
      self.userName = credential["userName"]
      self.userPassword = credential["password"]
      self.logger = logName

    def login(self):
      headers = {'Content-Type': "application/x-www-form-urlencoded"}
      payload = {"login":{"username":self.userName, "password":self.userPassword} }
      payload =  json.dumps(payload)
      payload = "object= " + payload
      response = None
      try:
          response = requests.post(self.url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
          self.logger.debug("RESPONSE from NSLOGIN = %s"% response.text)
      except requests.exceptions.ConnectionError as exMsg:
          self.logger.error('Connection error from login requests = %s' % str(exMsg))
          raise 
      except requests.exceptions.RequestException as exMsg:
          self.logger.error('Exception in NSLogin =%s' % str(exMsg))
          raise Exception(exMsg)
      
      loginResp = response.json()
      if loginResp['errorcode'] == 0:
          sessionId = loginResp["sessionid"]
      else:
          raise Exception(loginResp)

      return sessionId

    def logout(self, sessionId):
      headers = { 'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
      payload = {"logout": {} }
      payload =  json.dumps(payload)
      payload = "object= " + payload
      response = None
      try: 
          response = requests.post(self.url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
          dict = response.json()
          errCode = dict["errorcode"]
      except requests.exceptions.RequestException as exMsg:
          self.logger.error('Exception in NSLogin =%s' % str(exMsg))
          raise Exception(exMsg)
      self.logger.debug("RESPONSE from NSLOGOUT = %s, sessionId = %s"% (response.text, sessionId))
     
      if errCode != 0:
          raise Exception(response)

      return errCode


if __name__ == "__main__":
   lgObj = LogService.LogService()
   logEr = lgObj.getLogger()
   url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
   cred = {"userName":"nsroot", "password":"nsroot", "url": url}
   nsLgObj = NSLogin(cred, logEr)
   sesId = nsLgObj.login()
   print sesId
   nsLgObj.logout(sesId)
