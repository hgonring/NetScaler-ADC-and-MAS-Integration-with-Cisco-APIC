#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import sys

"""
This is to define all the constants in the script
"""

MAS_ERROR_CODE = 1001
MAS_ERROR_MSG = 'serviceUnavailable'
MAS_ERROR_MSG_APIC = 'device manager error. Please check device manager log'
MAS_POLLING_ERROR_MSG = 'Error'
JOB_ID = 'job_id'
POLLING_URL = '/admin/v1/journalcontexts/'
MAX_POLLING_TIME = 72
POLLING_INTERVAL = 10
STYLEBOOK = 'Stylebook'
FUNC_STYLEBOOK = 'mFCngStylebook'
AdminPartitionSupport = True
DefaultPartition = True
PARTITION = 'nspartition'
PARTITION_NAME = 'partitionname'
PARTITION_VLAN_BIND = 'nspartition_vlan_binding'
CONTEXT = 'ctxName'
TENANT = 'tenant'
VDEV = 'vdev'
CONTEXTAWARE = 'contextaware'
CSVSERVER = 'csvserver'
VSERVER = 'vserver'
GSLBVSERVER = 'gslbvserver'
CRVSERVER = 'crvserver'
VALUE = 'value'
EXTENDED = 'extended'
BASIC = 'basic'
STATE = 'state'
UP = 'up'
ENABLED = 'enabled'
ENABLE = 'enable'
DISABLE = 'disable'
DOWN = 'down'
PARAMOBJ = 'param'
HEALTH = 'health'
POLICY = 'policy'
FAULTS = 'faults'
GLOBAL = 'global'
COUNTERS = 'counters'
VERSION = 'version'
SUCCESS, TRANSIENT, PERMANENT, AUDIT = range(4)
NOCHANGE, CREATE, MODIFY, DELETE = range(4)
#DEVICE, GROUP, CONNECTION, FUNCTION, FOLDER, PARAM, MREL, VIF, VLAN, VENCAPASS = range(10)
DEVICE, FUNCTIONGROUP, CONNECTION, FUNCTION, FOLDER, PARAM, MREL, IFCTAG, VENCAPASS, ENCAPREL, VIF, INFTYPE, TEMP1, OSPFDEV, TEMP2, TEMP3, OSPFVENCAPASC, BGPDEV = range(18)
ATTACHIP = 22 # this is for FCS+9 changes for attach & detach events
REFOBJECT = 'refObject'
ERRORCODE = 'errorcode'
MESSAGE = 'message'
SEVERITY = 'severity'
DNSMXREC = 'dnsmxrec'
MX = 'mx'
DNSNSREC='dnsnsrec'
NAMESERVER = 'nameserver'
ERROR_VAL = 1001
# monitoring constants 
RESCPUUSAGEPCNT = 'rescpuusagepcnt'
MEMUSAGEPCNT  = 'memusagepcnt'
DISK_0_PERUSAGE  = 'disk0perusage'
DISK_1_PERUSAGE  = 'disk1perusage'
VLAN_NSIP_BINDING = 'vlan_nsip_binding'
VLAN_NSIP6_BINDING = 'vlan_nsip6_binding'
CSVSERVER_CSPOLICY_BINDING = 'csvserver_cspolicy_binding'
BINDING = 'binding'
NAME = 'name'
NSIP = 'nsip'
IPTYPE = 'iptype'
MGMTACCESS = 'mgmtaccess'
TRUE = 'true'
FALSE = 'false'
TAG = 'tag'
USNIP = 'USNIP'
HOST = 'host'
CREDS = 'creds'
USERNAME = 'username'
PASSWORD = 'password'
SYSTEM = 'system'
VIRTUAL = 'virtual'
SERVER = 'server'
NAME = 'name'
APIC_ADDR = 'addr'
APIC_CONN = 'conn'
CIFS = 'cifs'
DEVS = 'devs'
TYPE  = 'type'
EXTERNAL  = 'external'
INTERNAL  = 'internal'
INTERFACE  = 'interface'
BINDCOL = 'bindCol'
NETWORK = 'network'
CONNECTOR = 'connector'
OUTSIDE = 'outside'
PORT = 'port'
SERVICE = 'service'
SERVICEGROUP = 'servicegroup'
MFCNGSERVICEGROUP = 'mFCngservicegroup'
SERVICEGROUPNAME = 'servicegroupname'
SSLSERVICEGROUP = 'sslservicegroup'
VENCAPREL = 'vEncapRel'
ENCAP = 'encap'
BACKUPVSERVER = 'backupvserver'
LBVSERVER = 'lbvserver'
TARGET_LBVSERVER = 'targetlbvserver'
VSERVERNAME = 'vservername'
SERVICETYPE = 'servicetype'
IPV46 = 'ipv46'
IP = 'ip'
IPADDRESS = 'ipaddress'
IPV6ADDRESS = 'ipv6address'
NETMASK = 'netmask'
GATEWAY = 'gateway'
VLAN_BIND = 'vlan'
SNIP = 'snip'
VLAN_INTERFACE_BIND_NAME = 'vlan_interface_binding'
VIF_NAME = 'vif'
TAGGED = 'tagged'
IFNUM = 'ifnum'
SSL_CERT_BIND = 'sslvserver_sslcertkey_binding'
CERTKEYNAME = 'certkeyname'
LINKCERTKEYNAME = 'linkcertkeyname'
CERTKEY = 'certkey'
SERVICE_BIND_KEY = 'servicename'
SERVICE_BINDING = 'service_binding'
SERVICEGROUP_BINDING = 'servicegroup_binding'
LBVSERVER_SERVICE_BINDING = 'lbvserver_service_binding'
LBVSERVER_SERVICEGROUP_BINDING = 'lbvserver_servicegroup_binding'
SVCGROUP_SGMEM_BIND = 'servicegroup_servicegroupmember_binding'
SERVICEGROUP_MEMBER = 'servicegroupmember'
UNSET = 'unset'
ARGS = 'args'
FILENAME = 'util/objectList.txt'
ID = 'id'
HANODE = 'hanode'
HAPEER = 'HAPeer'
HIGHAVAILABILITY = 'HighAvailability'
PRIMARY = 'primary'
ROUTE = 'route'
NSPBRS = 'nspbrs'
TARGET = 'target'
LBMONITOR = 'lbmonitor'
DNSSRVREC = 'dnssrvrec'
SSLVSERVER = 'sslvserver'
SSLCERTKEY = 'sslcertkey'
DEVICE_VALIDATE = 'deviceValidate'
DEVICE = 'device'
CONFIG = 'config'
METHOD = 'method'
SERVICE_MODIFY = 'serviceModify'
DEVICE_HEALTH = 'deviceHealth'
SERVICE_HEALTH = 'deviceHealth'
SERVICE_COUNTER = 'serviceCounters'
DEVICE_COUNTER = 'deviceCounters'
STATUS_CODE = 'status_code'
OPR_NAME = 'operation_name'
ADD_OP = 'add_op'
GET_OP = 'get_op'
ARP_OP = 'arp_op'
MOD_OP = 'mod_op'
DELETE_OP = 'del_op'
BIND_OP = 'bind_op'
AUTHENTICATION_SERVER='authenticationvserver'
AAA_TOKEN='aaa_'
AAA_REPLACE_TOKEN='authenticationvserver_authentication'
UNBIND_OP = 'unbind_op'
NSRPCNODE = 'nsrpcnode'
MONITOR_OP = 'monitor_op'
EXCEPTION_CODE = 599
ENABLE_FEATURE = 'enableFeature'
ENABLE_MODE = 'enableMode'
OSPF = 'OSPF'
NTP_SERVER = 'ntpserver'
SNMPALARM = 'snmpalarm'
SNMPTRAP = 'snmptrap'
MFCNG_PREFIX = 'mFCng'
POLICY_HTTP_CALLOUT = 'policyhttpcallout'
TIMEOUT = 100
ISDEFAULT = 'isdefault'
ROUTING = 'routerdynamicrouting'
ROUTINGSHOWOUTPUT = 'output'
OSPFINTERFACE = 'OspfVIfCfg'
OSPFADDRFAMILY = 'addressFamily'
OSPFINTFAUTHTYPE = 'authType'
OSPFINTFAUTHKEY = 'authKey'
OSPFINTFAUTHKEYID = 'authKeyId'
OSPFINTFMD5KEY = 'md5Key'
OSPFINTFAUTHTYPENONE = 'none'
OSPFINTFAUTHTYPEMD5 = 'message-digest'
OSPFINTFAUTHTYPEPLAIN = 'plain'
OSPFINTFIPV6 = 'ipv6 ospf '
OSPFINTFIPV4 = 'ip ospf '
OSPFINTFROUTERCMDLIST = ['area']
OSPFINTFCMDAPICTOCLILIST = [('area','ipv6 router ospf area'),
                        ('authKey', 'authentication-key'), 
                        ('authKeyId', 'message-digest-key'), 
                        ('authType', 'authentication'),
                        ('cost', 'cost'),
                        ('deadIntvl', 'dead-interval'), 
                        ('helloIntvl', 'hello-interval'), 
                        ('prio','priority'),
                        ('rexmitIntvl', 'retransmit-interval'),
                        ('xmitDelay', 'transmit-delay ')]
OSPF_DEL_IGNORE_ERROR = ["Parameter is not configured", 
                         "No such interface", 
                         "There isn't active OSPF instance with such ID", 
                         "There isn't active OSPFv3 instance with such ID", 
                         "The redistribution does not exist", 
                         "Can't find specified network statement",
                         "Unknown object, configure first",
                         "Protocol daemon is not running", 
                         "Specified area is not configured"]
OSPF_PROCESS_ID = 'processid'
OSPF_AREA_ID = 'area'
OSPF_AREA_TYPE = 'areatype'
OSPF_AREA_CTRL = 'areactrl'
OSPF_RTR_ID = 'rtrid'
OSPF_REDISTRI = 'redistribute'
OSPF_CONTEXT = 'context'
BGP_LOCAL_AS = 'localAS'
BGP_RTR_ID = 'rtrId'
BGP_TIMERS = 'timers'
BGP_TIMERS_KEEPALIVE = 'keepalive'
BGP_TIMERS_HOLD = 'hold'
BGP_TIMERS_KEEPALIVE_DEFAULT = 30
BGP_TIMERS_HOLD_DEFAULT = 90
BGP_CONTEXT = 'context'
BGP_CONTEXT_IPV4 = 'ipv4'
BGP_CONTEXT_IPV6 = 'ipv6'
DEVICE_MGR = 'manager'
HOSTS = 'hosts'
BGP_CONTEXT_IP_NEIGHBOR = 'neighbor'
BGP_CONTEXT_IP_NEIGHBOR_REMOTE_AS = 'remoteAS'
BGP_CONTEXT_IP_NEIGHBOR_ADMIN_STATUS = 'adminStatus'
BGP_CONTEXT_IP_NEIGHBOR_STATE = 'state'
BGP_CONTEXT_IP_NETWORKS = 'networks'
BGP_CONTEXT_IP_REDIS = 'redistribute'
METHOD_LIST = ['serviceModify', 'serviceAudit']
ENABLE_OPTIONS = ('ENABLE', 'YES', 'ON', 'enable', 'yes', 'on')
DISABLE_OPTIONS = ('DISABLE', 'NO', 'OFF', 'disable', 'no', 'off')
IGNORE_OPTIONS = ('Interface is already bound to this VLAN', 'Operation not permitted','Subnet already bound to this vlan')
FOLDER_IN_FOLDER = ('Network', 'Policy', 'Global', 'Param')
IGNORE_OBJECTS_LIST = ['nsversion', 'nsconfig', 'nsfeature', 'nsmode', 'nslicense', 'ntpserver', 'snmpcommunity', 'snmpmanager','snmpalarm','snmptrap', 'systemparameter', 'systemuser', 'systemgroup', 'clusterinstance', 'clusternode', 'rsskeytype', 'ci', 'snmpmib', 'snmpoption', 'appflowparam', 'appflowglobal', 'gslbparameter', 'locationparameter', 'locationfile', 'cmpparameter', 'aaaradiusparams', 'aaaldapparams', 'aaatacacsparams', 'aaacertparams', 'cmpglobal', 'coglobal', 'lbparameter', 'csparameter', 'cacheparameter', 'aaaparameter', 'rewriteglobal', 'rewriteparam', 'responderglobal', 'responderparam', 'scparameter', 'cacheglobal', 'appfwsettings', 'appfwglobal', 'transformglobal', 'nsdhcpparams', 'nsspparams', 'nsweblogparam', 'nsdiameter', 'nsratecontrol', 'nstcpparam', 'nshttpparam', 'protocolhttpband', 'nstcpbufparam', 'arpparam', 'dnsglobal', 'dnsparameter', 'pqbinding', 'sslparameter', 'sslcertlink', 'hafailover', 'hasync', 'vpnparameter', 'tmsessionparameter', 'auditsyslogparams', 'auditnslogparams', 'filterglobal', 'tunnelglobal', 'systemglobal', 'aaaglobal', 'vpnglobal', 'tmglobal', 'nsacls', 'nsacls6', 'nspbrs', 'rnat', 'lbsipparameters', 'bridgetable', 'sslglobal', 'filterprebodyinjection', 'filterpostbodyinjection', 'nstimeout', 'rnatparam', 'l2param', 'l3param', 'lbpersistentsessions', 'filterhtmlinjectionparameter', 'nsencryptionparams', 'wipackage', 'l4param', 'vpathparam', 'vridparam', 'ipsecparameter', 'iptunnelparam', 'Interface', 'policypatset', 'policyexpression', 'server', 'lacp','nshostname', 'snmpengineid', 'nstcpprofile', 'route6', 'sslservice', 'hanode', 'sslservicegroup', 'authenticationldappolicy', 'authenticationldapaction', 'authenticationradiuspolicy','authenticationradiusaction', 'authenticationlocalpolicy', 'authenticationtacacspolicy', 'authenticationtacacsaction', 'policyexpression','systemcmdpolicy', ]

CLUSTER_OBJECTS_LIST = ['ntpserver', 'snmpcommunity', 'snmpmanager', 'snmpalarm', 'snmptrap',]


class AdminDelete(Exception):
   """Raised when admin partition is needed in service modify"""
   pass
