#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import sys
import json
import math

import scriptConst as const
import nitroUtil

import configUtil as util

#
# get the device health using various device stat
#
def getDeviceHealth(url, devIp, sesId, interface, cnfg, logger):
    """
    This is to collect the system stat from the device and calculate deviceHealth based on the state value
    """
    logger.debug('++++++++ get device health for = %s' % (devIp))
    retCol = {}
    statVal = None
    linkScore = 0
    respCol = nitroUtil.getStats(const.SYSTEM, None, url, devIp, sesId, logger)
    logger.debug('------ Device Health  response = %s' % (respCol))
    devHealthPcnt = -1 # this is negative to indicate the error
    if respCol[const.ERRORCODE] == 0:
        sysParams = respCol[const.SYSTEM]
        cpuUsage = sysParams[const.RESCPUUSAGEPCNT]
        memUsage = sysParams[const.MEMUSAGEPCNT]
        disk_0_Usage = sysParams[const.DISK_0_PERUSAGE]
        disk_1_Usage = sysParams[const.DISK_1_PERUSAGE]
        
        # add the weights on each attribute to caculate the device health
        # sum of the weight must be 1 e.g. 0.6 (this is for CPU)  + 0.2 (memory) + 0.2 (disk)
        #linkScore = processNodeLinkHealth(url, devIp, sesId, interface, cnfg, logger)
        if interface is not None:
            linkScore = processNodeLinkHealth(url, devIp, sesId, interface, cnfg, logger)
        # convert link score 
        linkScore = 100 - linkScore # this is to convert values in negative form e.g. 100 will be 0 means all the links are up
        diskUsage = ((disk_0_Usage + disk_1_Usage) / 2)  * 0.2
        devHealthPcnt = float(cpuUsage * 0.4) + float(memUsage * 0.2) + float(diskUsage * 0.1) + float(linkScore * 0.3)
        logger.debug('++++++ device health percent = %s cpu = %s, mem = %s, disk=%s, link = %s' % (devHealthPcnt, cpuUsage, memUsage, diskUsage, linkScore))
        # convert the percent value upto 2 decimal values
        devHealthPcnt = math.ceil(float(devHealthPcnt * 100)/100)
        # subtract by 100 to since 0 is poor and 100 is good health
	devHealthPcnt = 100 - devHealthPcnt
        logger.debug('------ Device Stat response = %s' % (devHealthPcnt))
        statVal = 0
    else:
        logger.error('++++++++++ device health error = %s' % (respCol))
        statVal = const.PERMANENT 
    tmpList = []
    emptyList = []
    tmpTuple = (emptyList,int(devHealthPcnt))
    tmpList.append(tmpTuple)
    retCol[const.STATE] = statVal
    retCol[const.HEALTH] = tmpList
    retCol[const.FAULTS] = []
    return retCol 
#
# This is to calculate linkstate from Node
#
def processNodeLinkHealth(url, devIp, sesId, interface, cnfg, logger):
    """
    This is to calculate node link health from device collection
    """
    nodeCol = {}
    nodeName = None
    nodeHealth = {}
    infCol = []
    logger.debug('+++++ interface details = %s' % (interface))
    #infCol = util.getInterfaceAttrFromCol(interface, logger)
    # length of the interface collection
    infCount = len(interface)
    upCount = 0
    downCount = 0
    #logger.debug('+++++ interface collection = %s' % (interface))
    for i in interface.keys():
        # interface collection is of this type {(11, '', '1_1'): {'state': 0, 'label': ''}
        tmpCol = {}
        # replace '_' with '/'
        infNum = None
        infNum = i[2]
        if infNum is None:
            continue
        infNum = infNum.replace('_', '/')
        #logger.debug('+++++ interface from collection  = %s' % (infNum))
        tmpCol[i] = nitroUtil.getInterfaceStat(const.INTERFACE, infNum, url, devIp, sesId, logger)
        tmpStat = getInterfaceStatus(tmpCol, logger)
        #logger.debug('+++++ Link status = %s' % (tmpStat))
        if (tmpStat):
            if tmpStat.strip().lower() == 'up':
                upCount += 1
            else:
                downCount +=1
        else:
            downCount +=1
        # node level link status
    if infCount > 0:
        nodeHealth[nodeName] = (((infCount - downCount) * 100 ) / infCount)
    else:
        nodeHealth[nodeName] = 0 # this is to make link score 0 since there no interface in the config
    #logger.debug('+++ Interface node = %s, healthscore = %s' % (nodeName, nodeHealth[nodeName]))
    # overall health of the links from all the nodes
    nodeCount = len(nodeHealth)
    healthScore = 0
    linkScore = 0
    for i1, j1 in nodeHealth.iteritems():
        # get health of each node 
        healthScore += j1
    # return overall health score 
    if nodeCount > 0:
        linkScore = (float(healthScore) / float(nodeCount * 100)) * 100
    else:
        linkScore = 0 # this is avoid accidental division by 0
    logger.debug('+++ link score  = %s' % (linkScore))
    return linkScore


#
# This is to process JSON response for servcie health
#
def processStateJsonResp(respCol, logger, prFlag=False):
    """
    This is to calculate service health for each service
    """
    retCol = {}
    healthScore = 0
    #logger.debug('+++++++ Resp Col = %s' % (respCol))
    for a1, b1 in respCol.iteritems():
        entName = a1
        # inside this there is a list
        for tmpVal in b1:
            # inside there is dictionary of key value 
            hlthScore = 0
            for a2, b2 in tmpVal.iteritems():
                if a2.strip().lower() == const.STATE:
                    if (b2.strip().lower() == const.UP or b2.strip().lower() == const.ENABLED):
                        healthScore = 100
                    else:
                        heallthScore = 0
                    if prFlag:
                        return healthScore
                    break

    logger.debug('Health score = %s' % (healthScore))

    return healthScore

#
# This is to calculate health score
#
def calServiceHealth(retCol, logger):
    """
    This is to calculate health score 
    """

    # now calculate health score 
    upCount = 0
    downCount = 0
    totalCount = len(retCol)
    #logger.debug('Health score collection = %s ' % (retCol))
    for k1, v1 in retCol.iteritems():
        if v1 == 0:
            downCount += 1
        else:
            upCount += 1
  #      logger.debug('Count details Total = %s Up = %s Down = %s ' % (totalCount, upCount, downCount))
    # now calculate score based on up & down count
    logger.debug('Count details Total = %s Up = %s Down = %s ' % (totalCount, upCount, downCount))
    if upCount == 0:
        healthScore = 0
    elif downCount == 0:
        healthScore = 100
        #logger.debug('Health Score details Up = %s ' % (healthScore))
    else:
        #healthScore = ((upCount - downCount) * 100) / totalCount
        healthScore = ((totalCount - downCount) * 100) / totalCount
        # this is to reverse the score since in APIC 100 is good 0 is bad
        #healthScore = 100 - healthScore

    logger.debug('Health Score details Up = %s ' % (healthScore))
    
    return healthScore

#
# This is to process JSON response and get the health score 
#
def processServiceHealth(servName, servCol, logger, prFlag = False):
    """
    This is to process service health based on JSON response
    """
    logger.debug('Service health details = %s collection length = %s' % (servCol, len(servCol)))
    resCol = {}
    faultList = []
    for a1, b1 in servCol.iteritems():
        erVal = None
        severVal = None
        msgStr = None
        respCol = {}
        serviceCol = {}
        for a2, b2 in b1.iteritems():
            if a2.strip().lower() == const.ERRORCODE:
                erVal = b2
            elif a2.strip().lower() == const.MESSAGE:
                msgStr = b2
            elif a2.strip().lower() == const.SEVERITY:
                severVal = b2
            elif a2.strip().lower().find(const.VSERVER) != -1: # this should cover all types of vserver
                respCol[a2] = b2
            elif a2.strip().lower().find(const.SERVICE) != -1:  # this should cover service & servicegroup
                 respCol[a2] = b2
        # if errorcode is 0 then check for state and calculate heath
        if erVal == 0:
            tmpVal = processStateJsonResp(respCol, logger, prFlag)
            if prFlag:
                return tmpVal
            resCol[a1] = tmpVal
        else:
            # if there is exception and prFlag is True then 0 as vServer health
            if prFlag:
                return 0
            tmpTuple = (msgStr, severVal)
            tmpTuple_2 = (a1,erVal, tmpTuple)
            faultList.append(tmpTuple_2)

    retCol = {}
    healthFlag = True
    
    healthScore = calServiceHealth(resCol, logger)

    retCol[const.STATE] = const.SUCCESS
    
    retCol[const.FAULTS] = faultList
    tmpList = []
    
    for i in servName:
        #logger.debug('++++++++++ ServName Values = %s' % (str(i)))
        if type(i) is tuple:
            tmpList.append(i)
    #logger.debug('+++++++ SERVNAME Tuple = %s' % (str(servName)))
    retCol[const.HEALTH] = (tmpList, healthScore)

    return retCol
#
# Get Service Health
#
def getServiceHealth(cnfg, devObj, sesId, logger):
    """
    This is to get service health from device
    """
    healthCol = {}
    #logger.debug('++++++ Service Health Device = %s' % (devObj))
    devsCol = devObj[const.DEVS]
    devList = []
    funCol = {}
    for t1 in devsCol.keys():
	devList.append(t1)
    devIp = devObj[const.HOST]
    url = util.getURL(devObj[const.PORT], devObj[const.HOST], logger)
    funCol = util.getFunctionsFromConfig(cnfg, logger)
    #logger.debug('++++++++++ Function collection --- = %s' % (funCol))
    for i1, j1 in funCol.iteritems(): # this to start for each function
        # get vServer from the function collection
        vSerCol = util.getVserverFromFunctionCol(j1, logger)
        tmpCol = {}
        tmpFunSerList = []
        healthServiceCol = {}
        for i2, j2 in vSerCol.iteritems(): # <----- this is per vServer within the function
            instVal = util.getKeyAttrValForObjectFromConfig(j2, cnfg, logger)
	    tmpCol= {}
            # this is to remvoe 'mFCnfg' from the config objects
            instName = i2[1]
            instName = instName[len(const.MFCNG_PREFIX):]
            tmpCol[i2] = nitroUtil.getStats(instName, instVal, url, devIp, sesId, logger)
            
            for i3, j3 in tmpCol.iteritems(): # <-------- this is to get bind service or service group for given vServer
                tmpVScore = 0
                tmpVScore = processServiceHealth(i1, tmpCol, logger, True)
                #if tmpVScore == 100: # this means vServer is UP
                healthServiceCol[i3] = j3
                tmpSerCol = {}
                    # the vServer refrence to device config must be unique even for multiple graphs 
                tmpSerCol = util.getServiceNServiceGroupForVServer(i2, cnfg, logger)
                for i4, j4 in tmpSerCol.iteritems():
                    tmpFunSerList.append(j4)
                    if tmpVScore == 100: # this means vServer is UP
                        tmpSerStCol = {}
                        tmpInstName = i4
                        # here j4 is the instance of the service/serviceGroup object
                        servInstVal = util.getKeyAttrValForObjectFromConfig(j4, cnfg, logger)
                        # extract object Name from the key i.e. service from lbvserver_service_binding
                        #{((0, '', 4272), (4, 'lbvserver', 'lbvserver'), (4, 'lbvserver_service_binding', 'lbService1'), (6, 'servicename', 'webservice1')): 'service1'}
                        tmpTup = i4
                        tmpTup = tmpTup[2]
                        tmpObjName = tmpTup[1]
                        tmpName = tmpObjName[tmpObjName.find('_')+1:tmpObjName.rfind('_')]
                        #logger.debug('+++++++++++++ Service key = %s Instance value = %s' % (tmpName, servInstVal))
                        #-- check if the binding is serviceGroup ---
                        if tmpName.strip().lower() == const.SERVICEGROUP:
                            tmpSgStatCol = {}
                            tmpSgStatCol[tmpName] = nitroUtil.getStats(tmpName, servInstVal, url, devIp, sesId, logger)
                            tmpSGScore = processServiceHealth(i4, tmpSgStatCol, logger, True)
                            # process serviceGroup and get all its members
                            if tmpSGScore == 100:
                                # get members and its stat collection
                                tmpSerMemCol = {}
                                tmpSerMemCol = util.getServiceGroupMemCol(j4, cnfg, logger)
                                # get stat for each member 
                                for c1, d1 in tmpSerMemCol.iteritems():
                                    tmpArgStr = 'args=' + const.SERVICEGROUPNAME + ':' + servInstVal
                                    # construct payload in the form of 
                                    for c2, d2 in d1.iteritems():
                                        if c2 == const.IP:
                                            tmpArgStr = tmpArgStr + ',' + const.IP + ':' + d2
                                        elif c2 == const.PORT:
                                            tmpArgStr = tmpArgStr + ',' + const.PORT + ':' + d2
                                    # get stat
                                    #logger.debug('++++++++++ service group member stat string = %s' % (tmpArgStr))
                                    healthServiceCol[c1] = nitroUtil.getMemberStats(const.SERVICEGROUP_MEMBER, tmpArgStr, url, devIp, sesId, logger)
                        else:
                            healthServiceCol[i4] = nitroUtil.getStats(tmpName, servInstVal, url, devIp, sesId, logger)
                        #logger.debug('+++++++++++++++ Health service Collection = %s' % (healthServiceCol))
                else:
                    healthServiceCol[i3] = j3
               
        # just check if there are any services or service group present in this function which may or may not bind to any vServer
        funSerCol = util.getServiceNServiceGroupFromFunctionCol(j1, logger)
        tmpUnSerCol = {}
        for r1, s1 in funSerCol.iteritems():
            if s1 in tmpFunSerList:
                continue
            else:
                tmpUnSerCol[r1] = s1
        #logger.debug('+++++++++++ Unbind service or serviceGroup collection for Function - %s' % (tmpUnSerCol))
       # now process the health of the unbind service collection
        for x1, y1 in tmpUnSerCol.iteritems():
            servInstVal = util.getKeyAttrValForObjectFromConfig(y1, cnfg, logger)
            tmpName = x1[1]
            # this is to remvoe 'mFCnfg' from the config objects    
            tmpName = tmpName[len(const.MFCNG_PREFIX):]
            #logger.debug('+++++++++++++ Service key = %s Instance value = %s' % (tmpName, servInstVal))
            healthServiceCol[x1] = nitroUtil.getStats(tmpName, servInstVal, url, devIp, sesId, logger)
        #logger.debug('+++++++++++++++ Final Health service Collection = %s' %(healthServiceCol))
        
        healthCol[i1] = processServiceHealth(i1, healthServiceCol, logger)
            
        # this is the end of function loop
                    

    logger.debug('Service HEALTH final collection  = %s' % (healthCol))

    retCol = {}
    faultList = []
    healthList = []
    healthTuple = ()
    healthFlag = False
    for a1, b1 in healthCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2.strip().lower() == const.FAULTS:
                if b2:
                    for q1 in b2:
                        faultList.append(q1)
                #logger.debug('Fault List = %s'%(faultList))
            elif a2.strip().lower() == const.HEALTH:
                # loop over list items and append it to HealthList
                if (b2) :
	            tmpTuple = b2
		    healthList.append(b2)
                    #logger.debug('HEalth Tuple = %s' %(str(healthList)))
            elif a2.strip().lower() == const.STATE:
                if b2 != 0:
                    healthFlag = True
    #if (healthFlag):
    #    retCol[const.STATE] = const.TRANSIENT
    #else:
    #    retCol[const.STATE] = const.SUCCESS
    
    #for t1 in healthTuple:
    #    logger.debug('+++++++ Health Tuple Entry --- = %s' % (t1))
    #    if type(t1) is tuple:
    #        healthList.append(t1)
    retCol[const.STATE] = const.SUCCESS
    #healthList.append(healthTuple) 
    #logger.debug('HEalth List = %s' %(healthList))
    logger.debug('++++++getServiceHealth Fault List = %s' %(faultList))
    retCol[const.FAULTS] = []
    retCol[const.HEALTH] = healthList
    for t1 in devList:
        retCol[const.DEVS] = t1

    # now convert health and faults in list
    logger.debug('Service HEALTH final response  = %s' % (retCol))
    
    return retCol
#
# This is to get deviceCounters for each interfaces
#
def getDeviceCounters(infCol, config, url, devIp, sesId, logger):
    """
    This is to get the device counters for each interface passed as infCol parameter
    """

    # get the interface list 
    infList = util.getInterfaceAttrFromCol(infCol, logger)
    logger.error('getDeviceCounters infList = %s' % (infList))
    retList = [] 
    retCol = {}
    statVal = 0
    for inf in infList:
	tmpCol = {}
        tmpCol[inf] = nitroUtil.getInterfaceStat(const.INTERFACE, inf[3], url, devIp, sesId, logger)
        tmpResp = processCounterResponse(tmpCol, logger)
        for k1, l1 in tmpResp.iteritems():
            if k1 == 0:
 		tmpList = []
	        tmpKeyTuple = (inf[0], inf[1], inf[2])
		tmpList.append(tmpKeyTuple)
                tmpTuple = (tmpList, l1)
                retList.append(tmpTuple)
                statVal = 0
            else:
                statVal = const.PERMANENT
		logger.error('Error in getDeviceCounters errorCode = %s errorMessage =%s' % (k1, l1))
                #retCol[inf] = l1
        
        #retCol = dict(tmpCol.items() + retCol.items())

    #processCounterResponse(retCol, logger)
    retCol[const.STATE] = statVal
    retCol[const.COUNTERS] = retList
    logger.debug('++++++ Stat for interface collection = %s' % (retCol))
    #logger.debug('++++++ Error Details = %s' % (errCol))
    return retCol

#
# This is to get service counters for each connector connected with a vserver
#
def getServiceCounters(cnfg, url, devIp, sesId, logger):
    """
    This is to get service counters based on connectors 
    """
    retCol = {}
    retList = []
    transFlag = False
    cnCol = util.getVserverNConnectorsFromConfig(cnfg, logger)
    # loop over to get target vserver's instance name
    for i1, j1 in cnCol.iteritems():
        keyName = i1[4]
        # this is to remvoe 'mFCnfg' from the config objects
        keyName = keyName[len(const.MFCNG_PREFIX):]
        for i2, j2 in j1.iteritems():
            # now get the target vserver's instance name
            conName = i2[2]
            instVal = util.getKeyAttrValForObjectFromConfig(j2, cnfg, logger)
            tmpCol = {}
            # now get the stat 
            tmpCol[conName] = nitroUtil.getStats(keyName, instVal, url, devIp, sesId, logger)
            tmpResp = processServiceCounterResponse(tmpCol, logger)
            for k1, l1 in tmpResp.iteritems():
                if k1 != 0:
                    # set the trans flag to TRANSIENT
                    transFlag = True
                    logger.error('Error in getDeviceCounters errorCode = %s errorMessage =%s' % (k1, l1))
                else:
	            tmpList = []
		    #tmpKeyTuple = i1[0]+ i1[1]+ i1[2]+ i1[3]
		    tmpList.append(i1[0])
                    tmpList.append(i1[1])
                    tmpList.append(i1[2])
                    tmpList.append(i1[3])
                    tmpTuple = (tmpList, l1)
                    retList.append(tmpTuple)
    
    if(transFlag):
        retCol[const.STATE] = const.PERMANENT
    else:
        retCol[const.STATE] = 0
    retCol[const.COUNTERS] = retList
    
    logger.debug('+++++++ Service Counters stats = %s' % (retCol))

    return retCol
#
# This is to get interface status from Nitro response
#
def getInterfaceStatus(respCol, logger):
    """
    This is to get interface status from the Nitro response
    """
    for a1, b1 in respCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2.strip() == 'Interface':
                infList = b2
                for i in infList:
                    for a3, b3 in i.iteritems():
                        if a3.strip().lower() == 'curintfstate':
                            # return the status
                            return b3
    # if code reaches here then return None
    return None                
#
# This is to process counter response
#
def processCounterResponse(prCol, logger):
    """
    This is to process response and return apporipriate result set
    """
    erVal = None
    retList = []
    errMsg = None
    svrty = None
    resCol = {}
    for i1, j1 in prCol.iteritems():
        for i2, j2 in j1.iteritems():
            #logger.debug('++++++++ Response details key = %s Value = %s' % (i2,j2))
            if i2.strip() == 'errorcode':
                erVal = j2
            elif i2.strip() == 'Interface':
                retList = j2
                #logger.debug('Stat Col type = %s' % (type(retList))) 
            elif i2.strip() == 'message':
                errMsg = j2
            elif i2.strip() == 'severity':
                svrty = j2
        if erVal == 0:
            resCol[erVal] = parseRespList(retList, logger)
        elif erVal != 0:
            #logger.debug('++++++++ Error details message = %s sevrity = %s' % (errMsg,svrty))
            tmpTuple = (errMsg, svrty)
            resCol[erVal] =  tmpTuple
        #tmpCol = json.dumps(j1)
        #logger.debug('TmpCol type = %s' % (type(j1)))
        #logger.debug('++++++++ Response details key = %s Value = %s' % (i1,j1))
        #logger.debug('++++++++ JSON Response  Value = %s' % (tmpCol))

    return resCol
#
# This is to process Service counter response
#
def processServiceCounterResponse(prCol, logger):
    """
    This is to process service counter response and return apporipriate result set
    """
    erVal = None
    retList = []
    errMsg = None
    svrty = None
    resCol = {}
    conName = None
    for i1, j1 in prCol.iteritems():
        conName = i1
        for i2, j2 in j1.iteritems():
            logger.debug('++++++++ Service Response details key = %s Value = %s' % (i2,j2))
            if i2.strip() == 'errorcode':
                erVal = j2
            elif i2.strip().find(const.VSERVER) != -1: # this is to get any vservers
                retList = j2
                #logger.debug('Stat Serivce Col type = %s' % (type(retList))) 
            elif i2.strip() == 'message':
                errMsg = j2
            elif i2.strip() == 'severity':
                svrty = j2
        if erVal == 0:
            resCol[erVal] = parseServiceRespList(retList, logger)
            #logger.debug('++++++++ Service Counters  Response  Value = %s' % (resCol))
        elif erVal != 0:
            logger.debug('++++++++ Error details message from Service Counters  = %s sevrity = %s' % (errMsg,svrty))
            tmpTuple = (errMsg, svrty)
            resCol[erVal] =  tmpTuple
        #tmpCol = json.dumps(j1)
        #logger.debug('TmpCol type = %s' % (type(j1)))
        #logger.debug('++++++++ Response details key = %s Value = %s' % (i1,j1))
        #logger.debug('++++++++ JSON Response  Value = %s' % (tmpCol))

    return resCol
#
# This is to parse service counters result set
#
def parseServiceRespList(rsList, logger):
    """
    This is to filter appropriate values from the response for service counters 
    """
    retCol = {}
    #logger.debug('Type of collecton = %s' % (type(rsCol)))
    for i in rsList:
        valCol = i
        # since the return type is dict loop over
        tmpCol = {}
        for a1, b1 in valCol.iteritems():
            #logger.debug(' Ret  collecton Elements a1 = %s b1 = %s' % (a1,b1))
            if a1.strip() == 'totalpktsrecvd':
                tmpCol['rxpackets'] = int(b1)
            elif a1.strip() == 'totalpktssent':
                tmpCol['txpackets'] = int(b1)
            tmpCol['rxerrors'] = 0
            tmpCol['txerrors'] = 0
            tmpCol['rxdrops'] = 0
            tmpCol['txdrops'] = 0
        retCol = dict(tmpCol.items() + retCol.items())
        #logger.debug(' Ret  collecton = %s' % (retCol))

    return retCol
#
# This is to parse result set
#
def parseRespList(rsList, logger):
    """
    This is to filter appropriate values from the response
    """
    retCol = {}
    #logger.debug('Type of collecton = %s' % (type(rsCol)))
    for i in rsList:
	valCol = {}
        valCol = i
        # since the return type is dict loop over
        tmpCol = {}
        for a1, b1 in valCol.iteritems():
            #logger.debug(' Ret  collecton Elements a1 = %s b1 = %s' % (a1,b1))
            if a1.strip() == 'totrxpkts':
                tmpCol['rxpackets'] = int(b1)
            elif a1.strip() == 'errpktrx':
                tmpCol['rxerrors'] = int(b1)
            elif a1.strip() == 'errdroppedrxpkts':
                tmpCol['rxdrops'] = int(b1)
            elif a1.strip() == 'tottxpkts':
                tmpCol['txpackets'] = int(b1)
            elif a1.strip() == 'errpkttx':
                tmpCol['txerrors'] = int(b1)
            elif a1.strip() == 'errdroppedtxpkts':
                tmpCol['txdrops'] = int(b1)
        retCol = dict(tmpCol.items() + retCol.items())
        #logger.debug(' Ret  collecton = %s' % (retCol))

    return retCol
