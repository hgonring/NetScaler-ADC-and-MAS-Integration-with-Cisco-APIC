# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.

# (resource_type, settable_args_array, metadata_dict)
# metadata_dict has following 'keys' - 
	# ADDOP, SETOP, REMOP, UNSETOP, SETONLY_args, SETUID_REQD_args

setArgs = [
('nslicenseproxyserver', (), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':False, }, ),
('vpath', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('route6', ('weight', 'distance', 'cost', 'advertise', 'msr', 'monitor', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('vrid', ('priority', 'preemption', 'sharing', 'tracking', 'ownernode', 'trackifnumpriority', 'preemptiondelaytimer', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nstcpprofile', ('ws', 'sack', 'wsval', 'nagle', 'ackonpush', 'mss', 'maxburst', 'initialcwnd', 'delayedack', 'oooqsize', 'maxpktpermss', 'pktperretx', 'minrto', 'slowstartincr', 'buffersize', 'syncookie', 'kaprobeupdatelastactivity', 'flavor', 'dynamicreceivebuffering', 'ka', 'kaconnidletime', 'kamaxprobes', 'kaprobeinterval', 'sendbuffsize', 'mptcp', 'establishclientconn', 'tcpsegoffload', 'rstwindowattenuate', 'rstmaxack', 'spoofsyndrop', 'ecn', 'mptcpdropdataonpreestsf', 'mptcpfastopen', 'mptcpsessiontimeout', 'timestamp', 'dsack', 'ackaggregation', 'frto', 'maxcwnd', 'fack', 'tcpmode', 'tcpfastopen', 'hystart', 'dupackthresh', 'burstratecontrol', 'tcprate', 'rateqmax', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nspbr', ('srcip', 'srcipop', 'srcipval', 'srcport', 'srcportop', 'srcportval', 'destip', 'destipop', 'destipval', 'destport', 'destportop', 'destportval', 'nexthop', 'nexthopval', 'iptunnel', 'iptunnelname', 'vxlanvlanmap', 'srcmac', 'srcmacmask', 'protocol', 'protocolnumber', 'vlan', 'vxlan', 'Interface', 'priority', 'msr', 'monitor', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nstimeout', ('zombie', 'client', 'server', 'httpclient', 'httpserver', 'tcpclient', 'tcpserver', 'anyclient', 'anyserver', 'anytcpclient', 'anytcpserver', 'halfclose', 'nontcpzombie', 'reducedfintimeout', 'reducedrsttimeout', 'newconnidletimeout', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('inat', ('mode', 'tcpproxy', 'ftp', 'tftp', 'usip', 'usnip', 'proxyip', 'useproxyport', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsxmlnamespace', ('description', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('rsskeytype', (), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':False, }, ),
('forwardingsession', ('connfailover', 'sourceroutecache', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':False, }, ),
('nshostname', (), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':False, }, ),
('nsacl', ('srcip', 'srcipop', 'srcipval', 'srcport', 'srcportop', 'srcportval', 'destip', 'destipop', 'destipval', 'destport', 'destportop', 'destportval', 'srcmac', 'srcmacmask', 'protocol', 'protocolnumber', 'vlan', 'vxlan', 'Interface', 'established', 'icmptype', 'icmpcode', 'priority', 'logstate', 'ratelimit', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('route', ('distance', 'cost1', 'weight', 'advertise', 'protocol', 'msr', 'monitor', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nspartition', ('maxbandwidth', 'minbandwidth', 'maxconn', 'maxmemlimit', 'partitionmac', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nstrafficdomain', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('nsacls6', (), {'ADDOP':False, 'SETOP':False, 'REMOP':False, 'UNSETOP':False, }, ),
('onlinkipv6prefix', ('onlinkprefix', 'autonomusprefix', 'depricateprefix', 'decrementprefixlifetimes', 'prefixvalidelifetime', 'prefixpreferredlifetime', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsip6', ('nd', 'icmp', 'vserver', 'telnet', 'ftp', 'gui', 'ssh', 'snmp', 'mgmtaccess', 'restrictaccess', 'dynamicrouting', 'hostroute', 'ip6hostrtgw', 'metric', 'vserverrhilevel', 'ospf6lsatype', 'ospfarea', 'state', 'map', 'vrid6', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('ip6tunnel', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('nstimer', ('unit', 'comment', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsconsoleloginprompt', ('promptstring', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('vxlan', ('vlan', 'port', 'dynamicrouting', 'ipv6dynamicrouting', 'innervlantagging', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsvariable', ('iffull', 'ifvaluetoobig', 'ifnovalue', 'init', 'expires', 'comment', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('lacp', (), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':False, }, ),
('rnat6', ('redirectport', 'srcippersistency', 'ownergroup', ), {'ADDOP':True, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('nsappflowcollector', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('netbridge', ('vxlanvlanmap', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsservicepath', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('nspbr6', ('srcipv6', 'srcipop', 'srcipv6val', 'srcport', 'srcportop', 'srcportval', 'destipv6', 'destipop', 'destipv6val', 'destport', 'destportop', 'destportval', 'srcmac', 'srcmacmask', 'protocol', 'protocolnumber', 'vlan', 'vxlan', 'Interface', 'priority', 'msr', 'monitor', 'nexthop', 'nexthopval', 'iptunnel', 'vxlanvlanmap', 'nexthopvlan', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsdhcpip', (), {'ADDOP':False, 'SETOP':False, 'REMOP':False, 'UNSETOP':False, }, ),
('nsextension', ('comment', 'trace', 'tracefunctions', 'tracevariables', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, 'SETONLY_args':('trace', 'tracefunctions', 'tracevariables', ), 'SETUID_REQD_args':('name', ), }, ),
('nscapacity', ('bandwidth', 'edition', 'unit', 'platform', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('nsratecontrol', ('tcpthreshold', 'udpthreshold', 'icmpthreshold', 'tcprstthreshold', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('netprofile', ('srcip', 'srcippersistency', 'overridelsn', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsassignment', ('set', 'Add', 'sub', 'append', 'clear', 'comment', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nslicenseserver', ('port', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':False, }, ),
('nsacl6', ('srcipv6', 'srcipop', 'srcipv6val', 'srcport', 'srcportop', 'srcportval', 'destipv6', 'destipop', 'destipv6val', 'destport', 'destportop', 'destportval', 'srcmac', 'srcmacmask', 'protocol', 'protocolnumber', 'vlan', 'vxlan', 'Interface', 'established', 'icmptype', 'icmpcode', 'priority', 'aclaction', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, 'SETONLY_args':('aclaction', ), 'SETUID_REQD_args':('acl6name', ), }, ),
('rnat', ('network', 'netmask', 'aclname', 'redirectport', 'natip', 'td', 'ownergroup', 'natip2', 'srcippersistency', 'useproxyport', 'connfailover', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('nssimpleacl6', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('nspbrs', (), {'ADDOP':False, 'SETOP':False, 'REMOP':False, 'UNSETOP':False, }, ),
('arp', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('iptunnel', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('nsip', ('arp', 'icmp', 'vserver', 'telnet', 'ftp', 'gui', 'ssh', 'snmp', 'mgmtaccess', 'restrictaccess', 'dynamicrouting', 'ospf', 'bgp', 'rip', 'hostroute', 'hostrtgw', 'metric', 'vserverrhilevel', 'vserverrhimode', 'ospflsatype', 'ospfarea', 'vrid', 'icmpresponse', 'arpresponse', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('ptp', (), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':False, }, ),
('ipv6', ('ralearning', 'routerredirection', 'ndbasereachtime', 'ndretransmissiontime', 'natprefix', 'dodad', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('vlan', ('aliasname', 'dynamicrouting', 'ipv6dynamicrouting', 'mtu', 'sharing', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsrpcnode', ('password', 'srcip', 'secure', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('nslimitidentifier', ('threshold', 'timeslice', 'mode', 'limittype', 'selectorname', 'maxbandwidth', 'trapsintimeslice', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nssimpleacl', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('interfacepair', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('bridgegroup', ('dynamicrouting', 'ipv6dynamicrouting', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('fis', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('channel', ('state', 'mode', 'conndistr', 'macdistr', 'lamac', 'speed', 'flowctl', 'hamonitor', 'haheartbeat', 'tagall', 'trunk', 'ifalias', 'throughput', 'bandwidthhigh', 'bandwidthnormal', 'mtu', 'lrminthroughput', 'linkredundancy', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, 'SETONLY_args':('mtu', 'lrminthroughput', 'linkredundancy', ), 'SETUID_REQD_args':('id', ), }, ),
('nslimitselector', (), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('vrid6', ('priority', 'preemption', 'sharing', 'preemptiondelaytimer', 'trackifnumpriority', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nd6', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('linkset', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('nshttpprofile', ('dropinvalreqs', 'markhttp09inval', 'markconnreqinval', 'cmponpush', 'conmultiplex', 'maxreusepool', 'dropextracrlf', 'incomphdrdelay', 'websocket', 'rtsptunnel', 'reqtimeout', 'adpttimeout', 'reqtimeoutaction', 'dropextradata', 'weblog', 'clientiphdrexpr', 'maxreq', 'persistentetag', 'spdy', 'http2', 'reusepooltimeout', 'maxheaderlen', 'minreusepool', 'http2maxheaderlistsize', 'http2maxframesize', 'http2maxconcurrentstreams', 'http2initialwindowsize', 'http2headertablesize', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('nsservicefunction', (), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':False, }, ),
('Interface', ('speed', 'duplex', 'flowctl', 'autoneg', 'hamonitor', 'haheartbeat', 'mtu', 'tagall', 'trunk', 'trunkmode', 'trunkallowedvlan', 'lacpmode', 'lacpkey', 'lagtype', 'lacppriority', 'lacptimeout', 'ifalias', 'throughput', 'linkredundancy', 'bandwidthhigh', 'bandwidthnormal', 'lldpmode', 'lrsetpriority', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('bridgetable', ('bridgeage', ), {'ADDOP':False, 'SETOP':True, 'REMOP':False, 'UNSETOP':True, }, ),
('ipset', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('vxlanvlanmap', (), {'ADDOP':True, 'SETOP':False, 'REMOP':True, 'UNSETOP':False, }, ),
('nsacls', (), {'ADDOP':False, 'SETOP':False, 'REMOP':False, 'UNSETOP':False, }, ),
('nat64', ('netprofile', ), {'ADDOP':True, 'SETOP':True, 'REMOP':True, 'UNSETOP':True, }, ),
('rnatglobal', (), {'ADDOP':False, 'SETOP':False, 'REMOP':False, 'UNSETOP':False, }, ),
]