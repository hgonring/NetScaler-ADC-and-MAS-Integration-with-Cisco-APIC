#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import unittest
import ScriptUtil
import scriptConst as const
import LogService
import vServerUtil
import NSDeviceScript
import configUtil
import yaml
import NSLogin


class TestvServerUtil(unittest.TestCase):

    def setup(self):
        self.tmpParam = {"name" : "Test1", "ip" : "1.1.1.1", "port" : 80, "lbmethod" : "RoundRobin"}
        self.LBData = range(10)
        self.scrObj = ScriptUtil.ScriptUtil()

    def test_a_ProcessCreateDataSet(self):
	print 'Process Create Dataset +++ ' 
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        #url = "http://" + ipAdr + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        #csvFile = open('test/modifyCsvServer.yaml', "r")
        #csvFile = open('test/deviceConfigEPAttach.yaml', "r")
        csvFile = open('test/QA-Test_1.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/SSLData.yaml', "r")
        #cnfgFile = open('test/ifc_ICTestData.yaml', "r")
        #cnfgFile = open('test/CSLBTestData.yaml', "r")
        #cnfgFile = open('test/vlanTestData.yaml', "r")
        #cnfgFile = open('test/garpTestData.yaml', "r")
        #cnfgFile = open('test/faultTestData.yaml', "r")
        #cnfgFile = open('test/lbMonitorModifyTestData.yaml', "r")
        #cnfgFile = open('test/vlanTestData.yaml', "r")
        #cnfgFile = open('test/vlanKiranTestData.yaml', "r")
        #cnfgFile = open('test/amitTestData.yaml', "r")
        cnfgFile = open('test/raviVlanTestData.yaml', "r")
	# get the device data 
        deviceFile = open('test/deviceBLRData.yaml', "r")
        #deviceFile = open('test/deviceVData.yaml', "r")
        #deviceFile = open('test/deviceData_2.yaml', "r")
	deviceData = yaml.load_all(deviceFile)
	deviceCol = {}
	for m in deviceData:
            deviceCol = m

        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        #cnfgFile = open('test/QA-Test_1.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.102.51'
	#devIp = '172.23.50.132'
    	vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processCreateDataSet(cnfgCol, devIp, sesId)
	#print 'Process Create Dataset Response = ', respCol
        devurl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
	#respCol = vservObj.processCreateNetworkDataSet(deviceCol, cnfgCol, devurl, devIp, deviceCol['virtual'], sesId)
	#print 'Process Network Dataset Response = ', respCol
	#respCol = vservObj.processVEncapassDataSet(cnfgCol, devIp, sesId)
	#respCol = configUtil.getFaults(respCol, logger)
	#print 'Faults Create Dataset Response = ', respCol
	#print 'Process Network Dataset Response = ', respCol
        #nsLgObj.logout(sesId)

    def test_x_ProcessCreateDataSet(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
	# get the device data 
        #deviceFile = open('test/clusterHAConfig.yaml', "r")
        deviceFile = open('test/deviceData_2.yaml', "r")
	deviceData = yaml.load_all(deviceFile)
	deviceCol = {}
	for m in deviceData:
            deviceCol = m

        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        cnfgFile = open('test/lbMonitorModifyTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	#devIp = '10.102.102.51'
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processDeviceModify(deviceCol, cnfgCol)
	#print 'Process deviceModify  Response = ', respCol
	return 

    def test_x_ProcessClusterModify(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
	# get the device data 
        #deviceFile = open('test/clusterHAConfig.yaml', "r")
        deviceFile = open('test/deviceBLRData.yaml', "r")
	deviceData = yaml.load_all(deviceFile)
	deviceCol = {}
	for m in deviceData:
            deviceCol = m

        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        #cnfgFile = open('test/snmpTestData.yaml', "r")
        cnfgFile = open('test/kiranClusterModifyTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.102.51'
    	vservObj  = vServerUtil.VServerUtil(logger)
        deurl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
	#respCol = vservObj.processClusterModify(deurl, deviceCol, None, cnfgCol, sesId)
	#print 'Process cluster Modify  Response = ', respCol
        #nsLgObj.logout(sesId)
	return 

    def test_c_ProcessModifyDataSet(self):
        csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol

	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        #url = "http://" + ipAdr + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/lbMonitorModifyTestData.yaml', "r")
        #cnfgFile = open('test/amitTestData.yaml', "r")
        #cnfgFile = open('test/modTestData.yaml', "r")
        #cnfgFile = open('test/vipulServiceModifyTestData.yaml', "r")
        cnfgFile = open('test/pariModTestData.yaml', "r")
        #cnfgFile = open('test/modifyTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	#devIp = '10.102.201.141'
	devIp = '10.102.102.51'
	#devIp = '172.23.50.132'
        ipurl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
    	vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processModifyDataSet(cnfgCol, ipurl, devIp, sesId)
	#respCol = vservObj.processModifyBindDataSet(cnfgCol, ipurl, devIp, sesId)
	#print 'Process Modify  Bind Dataset Response = ', respCol
        #nsLgObj.logout(sesId)
	return 

    def test_e_ProcessDeleteDataset(self):
        csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i

	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        #deviceFile = open('test/deviceData.yaml', "r")
        #deviceFile = open('test/deviceData_2.yaml', "r")
        #deviceFile = open('test/deviceVData.yaml', "r")
        deviceFile = open('test/deviceVDataCisco.yaml', "r")
	deviceData = yaml.load_all(deviceFile)
	deviceCol = {}
	for m in deviceData:
            deviceCol = m

	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
    	#cnfgFile = open('test/ifc_ICTestData.yaml', 'r')
    	#cnfgFile = open('test/routeData.yaml', 'r')
    	#cnfgFile = open('test/appFWTestData.yaml', 'r')
        #cnfgFile = open('test/CSLBTestData.yaml', "r")
        #cnfgFile = open('test/DNSTestData.yaml', "r")
        #cnfgFile = open('test/vlanTestData.yaml', "r")
        #cnfgFile = open('test/deleteVlanTestData.yaml', "r")
        cnfgFile = open('test/vlanTestData.yaml', "r")
        #cnfgFile = open('test/lbMonitorTestData.yaml', "r")
        #cnfgFile = open('test/deleteServiceTestData.yaml', "r")
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	#devIp = '10.102.102.51'
	devIp = '172.23.50.132'
	#devIp = '10.102.201.141'

	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
    	vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processDeleteDataSet(cnfgCol, devIp, sesId)
	#respCol = vservObj.processDeleteNetworkDataSet(deviceCol, cnfgCol, devIp, deviceCol['virtual'], sesId)
	#respCol = vservObj.processDeleteNetworkDataSet(deviceCol, cnfgCol, devIp, deviceCol['virtual'], sesId)
	#print 'Process Delete  Network Dataset Response = ', respCol
	#savRespCol = vservObj.saveConfig(devIp, sesId)
	#print 'Save Config Response =', savRespCol
        #nsLgObj.logout(sesId)
	return	
    def test_b_ProcessCreateBindDatSet(self):
        #csvFile = open('test/ApicTestData.yaml', "r")
        #csvFile = open('test/modifyCsvServer.yaml', "r")
        #csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	#csvData = yaml.load_all(csvFile)
  	#csvCol = {}
	#respCol = {}
	#for i in csvData:
        #    csvCol = i
	#print 'csvCol = ', csvCol

	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
    	#cnfgFile = open('test/ApicTestData.yaml', 'r')
    	#cnfgFile = open('test/ifc_ICTestData.yaml', 'r')
    	cnfgFile = open('test/serviceGroupTestData.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/SSLData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.201.141'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processCreateBindDataSet(cnfgCol, devIp, sesId)
	#print 'Process Create BIND  Dataset Response = ', respCol
        #nsLgObj.logout(sesId)
	return	

    def test_d_ProcessUnbindDataSet(self):
        #csvFile = open('test/modifyCsvServer.yaml', "r")
        #csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	#csvData = yaml.load_all(csvFile)
  	#csvCol = {}
	#respCol = {}
	#for i in csvData:
        #    csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
    	cnfgFile = open('test/CSLBTestData.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")

	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.201.141'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processUnbindDataSet(cnfgCol, devIp, sesId)
	#print 'Process UnBIND  Dataset Response = ', respCol
        #nsLgObj.logout(sesId)
	return	

    def test_f_ProcessAttachEndpoint(self):
        csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol
        deviceCol = {}	
        deviceFile = open('test/deviceVData.yaml', "r")
	deviceData = yaml.load_all(deviceFile)
	for m in deviceData:
            deviceCol = m

	tmpData = open('test/conn_1.yaml', "r")
        cData = yaml.load_all(tmpData)
        for conData in cData:
            conn = conData

	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        cnfgFile = open('test/attachTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
 	ep = '10.10.1.1'	
	conName = 'conn_1'
	devIp = '10.102.201.141'
        endPoints = [   {   'addr': '10.10.10.102',   'conn': 'inside' } ]
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
    	vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processAttachEndpoint(endPoints, cnfgCol, devIp, sesId)
	#respCol = NSDeviceScript.attachEndpoint(deviceCol, cnfgCol, endPoints)
	#respCol = vservObj.processDetachEndpoint(endPoints, cnfgCol, devIp, sesId)
	#print 'Process Attach Endpoint Dataset Response = ', respCol
	#respCol = NSDeviceScript.detachEndpoint(deviceCol, cnfgCol, endPoints)
	#print 'Process Detach Endpoint Dataset Response = ', respCol
        #nsLgObj.logout(sesId)
	return	

    def test_g_processFunctionSpecificIPVLANBinding(self):
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
    	#cnfgFile = open('test/ifcLoadBalancingData.yaml', 'r')
    	#cnfgFile = open('test/garpTestData.yaml', 'r')
    	#cnfgFile = open('test/sameConnTestData.yaml', 'r')
    	cnfgFile = open('test/vipul100Graphs.yaml', 'r')
    	#cnfgFile = open('test/monitorTestData.yaml', 'r')
    	#cnfgFile = open('test/twoGraphTestData.yaml', 'r')
        #csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
	#devIp = '10.102.201.141'
	devIp = '172.23.50.132'
    	vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processFunctionSpecificIPVLANBinding(cnfgCol, devIp, sesId, True)
	#respCol = vservObj.processFunctionSpecificIPVLANBinding(cnfgCol, devIp, sesId)
	#print 'Response from Function Specific IPVALN Binding = ', respCol
        #nsLgObj.logout(sesId)

 	return 

    def test_removeNodeOfDevice(self):
        #cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
        logSerObj = LogService.LogService()
        #devIp = '10.102.201.141'
        devIp = '172.23.50.132'
        logger = logSerObj.getLogger()
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
    	#vservObj  = vServerUtil.VServerUtil(logger)
        #tmpCol = vservObj.removeHAPeerFromDevice(devIp, sesId)
        #nsLgObj.logout(sesId)
        #print 'Device HA Node  = ', tmpCol

        return

    def test_processDeviceModify(self):
        #cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
        logSerObj = LogService.LogService()
        #devIp = '10.102.201.141'
        devIp = '172.23.50.132'
        haFile = open('test/haConfigTestData.yaml', "r")
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	cnfgData = yaml.load_all(haFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
    	vservObj  = vServerUtil.VServerUtil(logger)
	tmpCol = {}
        #try:
        #   tmpCol = vservObj.processDeviceModify(devIp, False, None, cnfgCol,  sesId)
	#except Exception as ex:
	#   print ex
        #nsLgObj.logout(sesId)
        #print 'DeviceModify response   = ', tmpCol

        return

    def test_r_getAuditFlag(self):
	print 'Process Check for Need to raise Audit  +++ ' 
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        #url = "http://" + ipAdr + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        sesId = nsLgObj.login()

    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/SSLData.yaml', "r")
        #cnfgFile = open('test/ifc_ICTestData.yaml', "r")
        #cnfgFile = open('test/CSLBTestData.yaml', "r")
        #cnfgFile = open('test/vlanTestData.yaml', "r")
        #cnfgFile = open('test/garpTestData.yaml', "r")
        #cnfgFile = open('test/faultTestData.yaml', "r")
        #cnfgFile = open('test/lbMonitorModifyTestData.yaml', "r")
        #cnfgFile = open('test/vlanTestData.yaml', "r")
        #cnfgFile = open('test/vlanKiranTestData.yaml', "r")
        #cnfgFile = open('test/amitTestData.yaml', "r")
        #cnfgFile = open('test/raviVlanTestData.yaml', "r")
        cnfgFile = open('test/interfaceModifyTestData.yaml', "r")
	# get the device data 
        deviceFile = open('test/deviceBLRData.yaml', "r")
        #deviceFile = open('test/deviceVData.yaml', "r")
        #deviceFile = open('test/deviceData_2.yaml', "r")
	deviceData = yaml.load_all(deviceFile)
	deviceCol = {}
	for m in deviceData:
            deviceCol = m

        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        #cnfgFile = open('test/QA-Test_1.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.102.51'
	#devIp = '172.23.50.132'
    	vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = vservObj.processCreateDataSet(cnfgCol, devIp, sesId)
	#print 'Process Create Dataset Response = ', respCol
        devurl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
	respCol = vservObj.getAuditFlagBasedOnInterface(deviceCol, cnfgCol, devurl, devIp, deviceCol['virtual'], sesId)
	print 'get Audit Flag Based on Interface Response = ', respCol
        nsLgObj.logout(sesId)
	return 
if __name__ == '__main__':
    unittest.main()
