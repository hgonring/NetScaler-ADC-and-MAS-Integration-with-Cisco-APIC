#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import requests
import json

import scriptConst as const
import configUtil as util
import nitroUtil as nitro
import setArgs as setargs
import auditConfig
import clusterAudit
import NSServer
from urllib import urlencode

from rhi import rhiConfig as rhconf

class VServerUtil(object):

    """
    This is handle all the CSVServer related details from create, modify to delete methods
    """

#
# This is just initialization method
#
    def __init__(self, logName):
        self.logger = logName

#
# Delete config objects
#
    def deleteConfigObjects(objCol, devCfg, url, devIp, sesId):
        """
        This is to delete config objects from NetScaler
        """
        for a1, b1 in objCol.iteritems():
            objKey = a1
            for a2, b2 in b1.iteritems():
                if a2 == const.STATE:
                    objState = b2
                if a2 == const.VALUE:
                    objCol = b2
            if objState == cons.DELETE:
                objAtrCol = util.getAttributeCollectionForObject(objCol, devCfg, self.logger)
                remObjCol = util.getObjectIdentifierNValue(objAtrCol)
                for k1, l1 in remObjCol.iteritems():
                    # here k1 is the object key
                    for k2, l2 in l1.iteritems():
                        args = None
                        #self.logger.debug('++++++++++++++ Removing Object details key = %s, val = %s' % (k1, l2))
                        respCode = nitro.removeNitroObject(k1, l2, args, url, devIp, sesId, self.logger)

        return respCode

#
# Process the LBVServer since this requires special handling of the backup server
#
    def processLBVServerDataSet(self, keyVal, instVal, lbCol, url, devIp, sesId):
        """
        This is to handle the LBVServer by removing backup server entry and later set the backup value
        """
        lbObjName = None
        backupServer = None
	servType = None
	ipvVal = None
  	portVal = None
	objAtrCol = {}
	respCode = {}
	setTmpCol = {}
        # get the backupserver from the collection which we can create later
        #self.logger.debug('+++++++++ Process LBV Server collection for Backup = %s' % (lbCol))
        for u1, v1 in lbCol.iteritems():
            # lbVServer object name
            lbObjName = u1[2]
            for u2, v2 in v1.iteritems():
                if u2.lower().strip() == const.BACKUPVSERVER:
                    backupServer = v2
                elif u2.lower().strip() == const.NAME:
                    instVal = v2
            #self.logger.debug('+++++++++++++ BACKUP VServer for LBVServer = %s ' % (backupServer))
            # now remove from the collection
            objAtrCol = self.removeBackupserverFromObjCol(lbCol)
            #self.logger.debug('+++++++++++ Object Attribute collection for LBVServer = %s'% (objAtrCol))

            # create the first level objects
            if len(objAtrCol) > 0:
                for i1, j1 in objAtrCol.iteritems():
                    respCode[i1] = nitro.createConfigObjects(i1, j1, url, devIp, sesId, self.logger)
                    # check the backup server must not be empty
                    #if (backupServer and backupServer is not None):
                    #    setTmpCol[const.NAME] = instVal
                    #    setTmpCol[const.BACKUPVSERVER] = backupServer

                    #    self.logger.debug('++++++++++++++ Setting the BACKUP server ++++++++++++++')
                    #    respCode[keyVal] = nitro.setConfigObjects(keyVal, setTmpCol, devIp, sesId, self.logger)

        return respCode

#
# Process backup for lbvservers
#
    def processBackupLBVServer(self, keyVal, instVal, lbCol, url, devIp, sesId):
        """
        This is to set the backupvserver for created lbvserver
        """
        respCode = {}
        self.logger.debug('+++++++++ Process Backup LBV Server collection for Backup = %s' % (lbCol))
        for u1, v1 in lbCol.iteritems():
            # lbVServer object name
            backupServer = None
            instVal = None
            setTmpCol = {}
            lbObjName = u1[2]
            for u2, v2 in v1.iteritems():
                if u2.lower().strip() == const.BACKUPVSERVER:
                    backupServer = v2
                elif u2.lower().strip() == const.NAME:
                    instVal = v2
            #self.logger.debug('+++++++++++++ BACKUP VServer for LBVServer = %s ' % (backupServer))

            if (backupServer and backupServer is not None):
                setTmpCol[const.NAME] = instVal
                setTmpCol[const.BACKUPVSERVER] = backupServer

                #self.logger.debug('++++++++++++++ Setting the BACKUP server ++++++++++++++')
                respCode = nitro.setConfigObjects(keyVal, setTmpCol, url, devIp, sesId, self.logger)

        return respCode

#
# Process the CSVServer since this requires special handling of the backup server
#
    def processCSVServerDataSet(self, keyVal, instVal, csvCol, url, devIp, sesId):
        """
        This is to handle the CSVServer by removing backup server entry and later set the backup value
        """
        csvObjName = None
        backupServer = None
	servType = None
	ipvVal = None
  	portVal = None
	objAtrCol = {}
	respCode = {}
	setTmpCol = {}
        # get the backupserver from the collection which we can create later
        self.logger.debug('+++++++++ Process CSV Server collection = %s' % (csvCol))
        for u1, v1 in csvCol.iteritems():
            # csvServer object name
            csvObjName = u1[2]
            for u2, v2 in v1.iteritems():
                if u2.lower().strip() == const.BACKUPVSERVER:
                    backupServer = v2
                # get the service type also since this is required
                elif u2.lower().strip() == const.SERVICETYPE:
                    servType = v2
                elif u2.lower().strip() == const.IPV46:
                    ipvVal = v2
                elif u2.lower().strip() == const.PORT:
                    portVal = v2
                elif u2.lower().strip() == const.NAME:
                    instVal = v2
            #self.logger.debug('+++++++++++++ BACKUP VServer = %s ' % (backupServer))
            # now remove from the collection
            objAtrCol = self.removeBackupserverFromObjCol(csvCol)
            #self.logger.debug('+++++++++++ Object Attribute collection = %s'% (objAtrCol))

            # create the first level objects
            if len(objAtrCol) > 0:
                for i1, j1 in objAtrCol.iteritems():
                    respCode[i1] = nitro.createConfigObjects(i1, j1, url, devIp, sesId, self.logger)
                    # check the backup server must not be empty
                    if (backupServer and backupServer is not None):
                        setTmpCol[const.NAME] = instVal
                        setTmpCol[const.BACKUPVSERVER] = backupServer
                        #setTmpCol[const.SERVICETYPE] = servType
                        setTmpCol[const.IPV46] = ipvVal
                        #setTmpCol[const.PORT] = portVal

                        #self.logger.debug('++++++++++++++ Setting the BACKUP server ++++++++++++++')
                        respCode[keyVal] = nitro.setConfigObjects(keyVal, setTmpCol, url, devIp, sesId, self.logger)

        return respCode

#
# process device level config objects based on its state
#
    def processCreateDataSet(self, devCfg, url, devIp, sesId, deviceAuditFlag=False):
        """
        This is to handle all the device level objects
        """
        createObjCol = {}
        respCode = {}
        configOrderCol = {}
        respCode = {}
        keyVal = None
        instVal = None
	orderObjList = []
	tmpObjCol = {}
        backupLBVCol = {}
        #self.logger.debug('++++++++ Process Create Data Set ++++++++++')
        # first get the create object data Set
        createObjCol = util.getStateSpecificObjectsFromConfig(const.CREATE, devCfg, self.logger, deviceAuditFlag)

        #self.logger.debug('++++++++ Create config object collection = %s' % (createObjCol))
        # get order list
        #orderObjList = util.loadObjectListFromFile(const.FILENAME)
	orderObjList = util.getObjectOrderList(self.logger)  #const.OBJECTLIST
	#self.logger.debug('++++ order list length = %s' % (orderObjList))
        # get the array index for each config object
        for a1, b1 in createObjCol.iteritems():
	    tmpTuple = a1[1]
	    tmpName = tmpTuple[1]
	    # remove _cfg from the key
	    #tmpName = tmpName[:tmpName.find('_cfg')]
	    #self.logger.debug('+++++++++ Searching for  object details = %s' % (tmpName.upper()))
	    for i in orderObjList:
                if i.strip().lower() == tmpName.strip().lower():
                    # this will store only one value since others will get overwritten
                    configOrderCol[orderObjList.index(i)] = tmpName.strip().lower()
                    #self.logger.debug('+++++++++ Create object details = %s' % (tmpName.upper()))
                    break

        # now configure this object based on config order

        #self.logger.debug('++++++++ Create config object order collection length = %s' % len(configOrderCol))
        for k1 in sorted(configOrderCol.iterkeys()):
            objkey = configOrderCol[k1]
	    tmpObjCol = {}
            for p1 in createObjCol.keys():
	        tmpTuple_2 = p1[1]
		keyStr = tmpTuple_2[1]
		#keyStr = keyStr[:keyStr.find('_cfg')]
                # check for SSLVSERVER in CREATE state if it is present then  skip the SSLVServer
                #if keyStr.strip().lower() == const.SSLVSERVER:
                    # skip this since this is mistake
                #    self.logger.debug('+++++++++ SSLVSERVER can not be in Create state skipping this object = %s' % (keyStr))
                #    continue

                #self.logger.debug('++++++++++ KEYs from create object key = %s, object collection key = %s' % (objkey, str(tmpTuple_2)))
                # here key is config object name i.e. lbvserver
                if objkey == keyStr.strip().lower():
                    tmpObjCol = {}
                    tmpObjCol[tmpTuple_2] = createObjCol[p1]
                    #self.logger.debug('+++++++++++ Objkey = %s , object val = %s' % (objkey, tmpObjCol))
                    keyVal = keyStr #p1[1]
                    #instVal = p1[2]
                    instVal = tmpTuple_2[2]
		    #instVal = instVal[:instVal.find('_cfg')]
                    # get the attribute list for this object
                    tmpAtrCol = util.getAttributeCollectionForObject(tmpObjCol, devCfg, self.logger)
		    #self.logger.debug('++++++++++ Attribute collection = %s' % (tmpAtrCol))
                    # now create this object
                    if keyStr == const.CSVSERVER:
                        tmpResCode = self.processCSVServerDataSet(keyVal, instVal, tmpAtrCol,url, devIp, sesId)
	                for x1, y1 in tmpResCode.iteritems():
                            respCode[(p1, x1)] = y1
                    elif keyStr == const.LBVSERVER or keyStr == const.GSLBVSERVER or keyStr == const.CRVSERVER or keyStr == const.VSERVER:
                        tmpBkVal = (const.FOLDER, keyVal,instVal)
                        backupLBVCol[(p1, tmpBkVal)] = tmpAtrCol
                        tmpResCode = self.processLBVServerDataSet(keyVal, instVal, tmpAtrCol,url, devIp, sesId)
	                for x1, y1 in tmpResCode.iteritems():
                            respCode[(p1, x1)] = y1
                    elif keyStr == const.POLICY_HTTP_CALLOUT:
                        # http callout policy can be added with only name and rest should be set
                        htPolCol = {}
                        htPolCol[keyVal] = instVal
                        tmpResp = {}
                        respCode[(p1, keyStr)] = nitro.createConfigObjects(keyStr, htPolCol, url, devIp, sesId, self.logger)
                        # now set rest of the values
                        respCode[p1] = nitro.setConfigObjects(keyStr, tmpAtrCol[keyStr], url, devIp, sesId, self.logger)
                    elif  keyStr == const.NSPBRS: # if the nspbrs is present in the payload then just apply
                        payload = {}
                        payload = { 'params' : { 'action' : 'apply' },
                                   'sessionid' : sesId, const.NSPBRS : {}}
                        respCode[p1] = nitro.postCLIRequest(payload, url, devIp, sesId, self.logger)
                    elif keyStr == const.SSLCERTKEY:
                        # This is to handle linking certificate
                        self.logger.debug('+++++ SSLCERT Key payload = %s' % (tmpAtrCol))
                        for l1, m1 in tmpAtrCol.iteritems():
                            tmpObjName = l1 # this is the object name i.e. sslcertkey
                            tmpLinkVal = None
                            tmpCertKeyVal = None
                            for l2, m2 in m1.iteritems():
                                if l2.strip().lower() == const.LINKCERTKEYNAME:
                                    tmpLinkVal = m2
                                elif l2.strip().lower() == const.CERTKEY:
                                    tmpCertKeyVal = m2
                            if tmpLinkVal is not None:
                                rmLinkCol = m1
                                # remove this entry from the payload
                                del rmLinkCol[const.LINKCERTKEYNAME]
                                respCode[p1] = nitro.createConfigObjects(l1, rmLinkCol, url, devIp, sesId, self.logger)
                            else:
                                # first add sslcertkey
                                respCode[p1] = nitro.createConfigObjects(l1, m1, url, devIp, sesId, self.logger)
                            # now check if the linkcert key value is present then link them
                            if tmpLinkVal is not None and tmpCertKeyVal is not None:
                                tmpPayload = {}
                                tmpPayload = { 'params' : { 'action' : 'link' },
                                               'sessionid' : sesId, const.SSLCERTKEY : {
                                        const.CERTKEY : tmpCertKeyVal,
                                        const.LINKCERTKEYNAME : tmpLinkVal, } }
                                # execute this as
                                respCode[p1] = nitro.postCLIRequest(tmpPayload, url, devIp, sesId, self.logger)
                    else:
                        for s1, o1 in tmpAtrCol.iteritems():
                            # handle the backupvserver for CSVServer
        		    #self.logger.debug('++++++++ Create config object data key = %s  value = %s' % (s1, o1))
                            if s1 == const.SSLVSERVER:
                                respCode[p1] = nitro.setConfigObjects(s1, o1, url, devIp,sesId, self.logger)
                            elif s1 == const.NSRPCNODE:
                                respCode[p1] = nitro.setConfigObjects(s1, o1, url, devIp,sesId, self.logger)
                            else:
                                respCode[p1] = nitro.createConfigObjects(s1, o1, url, devIp, sesId, self.logger)
        # now set the backup lbvservers if it is present in the config
        for x1, y1 in backupLBVCol.iteritems():
            tmpKey = x1[1]
            keyStr = tmpKey[1]
            instStr = tmpKey[2]
            respCode[x1[0]] = self.processBackupLBVServer(keyStr, instStr, y1, url, devIp, sesId)

	return respCode
#
# get key value from object collection
#
    def getKeyValFromCollection(self, keyName, objCol):
        """
        This is to get key's value from object key value pair collection
        """
        for i1, j1 in objCol.iteritems():
            if i1 == const.VALUE:
                for i2, j2 in j1.iteritems():
                    #self.logger.debug('OBJECT VALUE = %s, KEY VALUE = %s' % (i2[1], keyName))
                    if i2[1].strip().lower() == keyName.strip().lower():
                        for i3, j3 in j2.iteritems():
                            if i3 == const.VALUE:
                                return j3
        # if the execution comes here then it is not found
        return None
#
# get key from modify cluster attribute collection
#
    def getKeyFromClusterModCol(self, keyName, objCol):
        """
        This is to get key from modify cluster call
        """
        for a1, b1 in objCol.iteritems():
            if a1 == keyName:
                return b1[1] # since value is tuple of state and value
        # if execution reaches here then no value found
        return None

#
# get key value state from object collection
#
    def getKeyValueStateFromObjCollection(self, keyName, objCol):
        """
        This is to get key attribute's state from the object
        """
        for i1, j1 in objCol.iteritems():
            if i1 == const.VALUE:
                for i2, j2 in j1.iteritems():
                    #self.logger.debug('OBJECT VALUE = %s, KEY VALUE = %s' % (i2[1], keyName))
                    if i2[1].strip().lower() == keyName.strip().lower():
                        for i3, j3 in j2.iteritems():
                            if i3 == const.STATE:
                                return j3
        # if the execution comes here then it is not found
        return None

#
# This is to Process Modify dataset
#
    def processModifyDataSet(self, devCfg, url, devIp, sesId, deviceAuditFlag=False):
        """
        This is to handle all the config objects which has modify state
        """
        self.logger.debug('++++++++++ Proces Modify Data set from the config+++++++++++++++')
        modObjOrdCol = {}
        tmpSetCol = {}
        tmpUnSetCol = {}
        respCode = {}
        objVal = None
        objKey = None
        createObjCol = {}
        # get all the config objects which has modify state
        modObjCol = util.getStateSpecificObjectsFromConfig(const.MODIFY, devCfg, self.logger, deviceAuditFlag)
        #modObjCol = util.getModifyStateSpecificAtrColFromConfig(devCfg, self.logger)
        self.logger.debug('+++++++++ Mod object Col = %s ' % (modObjCol))
        # get the order list
        for a1, b1 in modObjCol.iteritems():
            #self.logger.debug('+++++++++ Mod Key  Col = %s, VAL = %s ' % (a1,b1))
            atrKeyName = None
            instVal = None
	    tmpTuple_1 = a1[1]
            objKey = tmpTuple_1[1]
            objVal = tmpTuple_1[2]
            atrName = util.getObjectKey(objKey,self.logger)
            # get the first element of the tuple
            atrKeyName = atrName[0]
            #self.logger.debug('+++++++++ Set Attr Name  = %s collection = %s' % (atrName, b1))
            instVal = self.getKeyValFromCollection(atrKeyName, b1)
            tmpSetCol = {}
            tmpUnSetCol = {}
            # create set and unset collections based on the object collection and its state
            tmpObjCol = {}
            tmpObjCol[a1] = b1
            tmpSetCol = {}
            tmpUnSetCol = {}
            tmpSetCol = util.getSetAttrCol(tmpObjCol, const.MODIFY, devCfg, self.logger)
            # this is to raise exception for non-modifiable attributes
            #if objKey == const.LBVSERVER or objKey == const.SERVICE:
            #   for k1 in tmpSetCol.keys():
            #       if k1 == const.SERVICETYPE or k1 == const.PORT:
            #           # raise exception
            #           raise Exception("ServiceType or Port can not be modified")
            # first check if the object exist in NetScaler or not
	    insResCol = {}
            insResCol = nitro.getInstanceConfigFromDevice(objKey, instVal, url, devIp, sesId, self.logger)
	    instObjCol = {}
            instObjCol = util.getObjectInstanceFromResponse(objKey, insResCol, self.logger)
            # if the object is not found in NetScaler then check for object's key attribute state
            if len(instObjCol) == 0:
                # make sure this is no just the RE-NAME incident
                keyState = None
                keyState = self.getKeyValueStateFromObjCollection(atrKeyName, b1)
                # if the keyState for this object is no change then add this
                #self.logger.debug('+++++ Object keyState = %s Object = %s' % (keyState, type(keyState)))
                if keyState == const.NOCHANGE:
                    # add this object in Object collection since this object doesn't exist in NetScaler
                    #self.logger.debug('+++++ Adding Object for create = %s Object = %s' % (keyState, b1))
                    createObjCol[a1] = b1
                    continue
            else:
                tmpCmpFlag = False
                tmpDAtrCol = {}
                tmpDAtrCol[a1[1]] = b1
                tmpDAtrCol = util.getAttributeCollectionForObject(tmpDAtrCol, devCfg, self.logger)
                # if object found in the NetScaler then compare its values from APIC
                tmpCmpFlag = util.compareAPICNDeviceObjects(tmpDAtrCol[objKey], instObjCol[objKey], self.logger)
                if tmpCmpFlag:
                    #self.logger.debug('+++++ Ignore same objects APIC object = %s, NetScaler Object = %s' % (tmpDAtrCol, instObjCol))
                    continue
            # check for unmodifiable attribute from setArgs
            # get the object's modifiable attribute from the modObjList
            modTup = util.getModObjTup(objKey, self.logger)
            # check all the columns in the modified attributes
            #self.logger.debug('++++++ Set column details = %s' % (tmpSetCol))
            for x1, y1 in tmpSetCol.iteritems():
                if x1 not in modTup:
                    path = util.getTupleList(a1, self.logger)
                    erCode = 2001
                    msg = 'Object ' + objKey + ' Attributes ' + x1 + ' can not be changed'
                    self.logger.error('+++++ RAISING VALUEERROR Fault object = %s attribute = %s'% (a1,b1))
                    errTuple = (path, erCode, msg)
                    raise ValueError(errTuple)

            tmpUnSetCol = util.getSetAttrCol(tmpObjCol, const.DELETE, devCfg, self.logger)
            for x1, y1 in tmpUnSetCol.iteritems():
                if x1 not in modTup:
                    path = util.getTupleList(a1, self.logger)
                    erCode = 2001
                    msg = 'Object ' + objKey + ' Attributes ' + x1 + ' can not be changed'
                    self.logger.error('+++++ RAISING VALUEERROR Fault object = %s attribute = %s' % (a1,b1))
                    errTuple = (path, erCode, msg)
                    raise ValueError(errTuple)

            #self.logger.debug('Tmp Set collection from Modify object = %s' % (tmpSetCol))
            #self.logger.debug('Tmp UNSET collection from Modify object = %s' % (tmpUnSetCol))
            if len(tmpSetCol) > 0:
                # get all the attribute collection from the object this is to avoid some corner cases
                tmpSetCol = util.getSetAttrCol(tmpObjCol, const.MODIFY, devCfg, self.logger, True) # this is to get all attributes from object
                tmpSetCol[atrKeyName] = instVal # this is to add object's key and its value
                #self.logger.debug('Tmp Set NITRO col  = %s, ObjKey = %s' % (tmpSetCol, objKey))
                respCode[a1] = nitro.setConfigObjects(objKey, tmpSetCol, url, devIp, sesId, self.logger)
                # for some reason if the object doesn't exist then add them
                erCode = util.getErrorCodeFromRespCol(respCode, self.logger)
                #self.logger.debug('Response code from MODIFY object = %s error code = %s' % (respCode[a1], erCode))
                #if erCode == 258:  # here errorcode 258 is for resource does not exist
                #    respCode[a1] = nitro.createConfigObjects(objKey, tmpSetCol, url, devIp, sesId, self.logger)

            if len(tmpUnSetCol) > 0:
               tmpUnSetCol[atrKeyName] = instVal
               respCode[a1] = nitro.unsetConfigObjects(objKey, tmpUnSetCol, url, devIp, sesId, self.logger)
        if len(createObjCol) > 0:
            # Add these objects in order in NetScaler
            #self.logger.debug('Creating object from Modify object = %s' % (createObjCol))
            tmpResp = {}
            tmpResp = auditConfig.createObjectInDevice(createObjCol, url, devIp, sesId, devCfg, self.logger)
            respCode = dict(tmpResp.items() + respCode.items())

        return respCode


#
# This is to handle all the delete object dataset
#
    def processDeleteDataSet(self, devCfg, url, devIp, sesId):
        """
        This is to handle all the delete state config objects
        """
        self.logger.debug('++++++++++++ process Delete specific DataSet +++++++++++++')
        configOrderCol = {}
        keyVal = None
        instVal = None
        objKey = None
        respCode = {}
	tmpName = None
	delObjCol = {}
	orderObjList = []
	tmpObjCol = {}

        delObjCol =  util.getStateSpecificObjectsFromConfig(const.DELETE, devCfg, self.logger)

        self.logger.debug('++++++++++++ Delete object = %s' % (delObjCol))
        # get order list so for config obects
        #orderObjList = util.loadObjectListFromFile(const.FILENAME)
	orderObjList = util.getObjectOrderList(self.logger)  #const.OBJECTLIST
        #self.logger.debug('++++++++++++ Order object length = %s' % (len(orderObjList)))

        # get the array index for each delete objects
        for a1, b1 in delObjCol.iteritems():
	    tmpTuple_1 = a1[1]
	    tmpName = tmpTuple_1[1]
            #self.logger.debug('++++++++++++ TEMP Name = %s' % (tmpName))
            for k1 in orderObjList:
                if k1.strip().lower() == tmpName.strip().lower():
                    configOrderCol[orderObjList.index(k1)] = tmpTuple_1[1] # just store the key value such as lbvserver'
                    break
        	#self.logger.debug('++++++++++++ config order  object = %s' % (configOrderCol))
        #self.logger.debug('++++++++++++ config order  object length = %s' % (len(configOrderCol)))
        # now delete the object in descending order
        for k1 in sorted(configOrderCol.iterkeys(), reverse=True):
            objKey = configOrderCol[k1]
            #self.logger.debug('++++++++++++ objKey   object = %s' % (objKey))
            for p1, p2 in delObjCol.iteritems():
                # match the key values and if they are same then proceed to delete
		#self.logger.debug('+++++++++ P1 = %s p2 = %s ' % (p1, p2))
		#self.logger.debug('+++++++++ Delete Key = %s Value = %s' % (objKey, p1))
	        tmpTuple_2 = p1[1]
		#self.logger.debug('+++++++++ TMP Tuple 2 = %s  p1 = %s' % (tmpTuple_2, objKey ))
                if tmpTuple_2[1].strip().lower() == objKey.strip().lower():
                    keyVal = tmpTuple_2[1]
		    #self.logger.debug('+++++++++ key Val   = %s' % (keyVal))
                    #if objKey.strip().lower() == const.SERVICEGROUP.strip().lower():
                    #    instVal = util.getParamAttributeValueFromCollection(const.SERVICEGROUPNAME, p2, self.logger)
                    #elif objKey.strip().lower() == const.NSIP.strip().lower():
                    #    instVal = util.getParamAttributeValueFromCollection(const.IPADDRESS, p2, self.logger)
                    #else:
                    atrName = None
	            # return type of getObject key is tuple
                    atrName = util.getObjectKey(tmpTuple_2[1],self.logger)
	            if len(atrName) == 0: # this is to handle such object where key is empty ('sslfips', ()),
		       self.logger.debug('+++++++++ iKey Atr Name is empty ifor object name = %s' % (objKey))
                       atrName = (objKey,)
	            else:
		       self.logger.debug('+++++++++ Key Atr Name  = %s for object = %s' % (str(atrName), objKey))
                        # get the first element of the tuple
                       atrName = atrName[0]
	               #instVal = util.getKeyAttrValForObjectFromConfig(tmpTuple_2[2],devCfg, self.logger)

                    instVal = util.getParamAttributeValueFromCollection(atrName, p2, self.logger)
                    if objKey.strip().lower() == const.ROUTE.strip().lower():
                        gatewayVal = util.getParamAttributeValueFromCollection(const.GATEWAY, p2, self.logger)
                        netmskVal = util.getParamAttributeValueFromCollection(const.NETMASK, p2, self.logger)
                        args = 'args='+const.NETMASK + ':' + netmskVal + ',' + const.GATEWAY+':'+gatewayVal
                        #self.logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyVal, instVal))
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, args, url, devIp, sesId, self.logger)
                    elif objKey.strip().lower() == const.DNSSRVREC:
                        tgVal = util.getParamAttributeValueFromCollection(const.TARGET, p2, self.logger)
                        argStr = 'args='+ const.TARGET + ':' + tgVal
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, argStr, url, devIp, sesId, self.logger)
                    elif objKey.strip().lower() == const.DNSMXREC:
                        mxVal = util.getParamAttributeValueFromCollection(const.MX, p2, self.logger)
                        argStr = 'args='+ const.MX + ':' + mxVal
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, argStr, url, devIp, sesId, self.logger)
                    elif objKey.strip().lower() == const.DNSNSREC:
                        nsVal = util.getParamAttributeValueFromCollection(const.NAMESERVER, p2, self.logger)
                        argStr = 'args='+ const.NAMESERVER + ':' + nsVal
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, argStr, url, devIp, sesId, self.logger)
                    elif objKey.strip().lower() == const.LBMONITOR:
                        tyVal = util.getParamAttributeValueFromCollection(const.TYPE, p2, self.logger)
                        argStr = 'args='+ const.TYPE + ':' + tyVal
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, argStr, url, devIp, sesId, self.logger)
                    elif objKey.strip().lower() == const.SERVICE:
                        # delete the service and server also since server doesn't get deleted from the config
                        #self.logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyVal, instVal))
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, None, url, devIp, sesId, self.logger)
                        # now exclusive delete the server based on the services IP value
                        tmpIpVal = util.getParamAttributeValueFromCollection(const.IP, p2, self.logger)
                        if tmpIpVal: # this is just to make sure value is not NULL
                            tmpTup = (p1, (const.FOLDER, const.SERVER, tmpIpVal))
                            respCode[tmpTup] = nitro.removeNitroObject(const.SERVER, tmpIpVal, None, url, devIp, sesId, self.logger)
                    elif objKey.strip().lower() == const.NSPBRS:
                        # execute clear nspbrs CLI
                        payload = {}
                        payload = { 'params' : { 'action' : 'clear' }, 'sessionid' : sesId, const.NSPBRS : {}}
                        respCode[p1] = nitro.postCLIRequest(payload, url, devIp, sesId, self.logger)
                    else:
                        #self.logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyVal, instVal))
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, None, url, devIp, sesId, self.logger)

        return respCode
#
# This is get all the binding object from the config
#
    def processCreateBindDataSet(self, devCfg, url, devIp, sesId, deviceAuditFlag=False):
        """
        This is to process all the bindings from the config for a Create state
        """
        #self.logger.debug('+++++++++ processeing Bind objects ++++++++++++')
        respCode = {}
        # first get all the binding objects
        bindObjCol = util.getStateSpecificBindObjectsFromConfig(const.CREATE, devCfg, self.logger, deviceAuditFlag)
        tmpObjCol = {}
        for x1 in bindObjCol.keys():
            tmpObjCol[(x1[2], x1[3])] = x1[3]
	bindOrderObjCol = util.getConfigOrderCol(tmpObjCol, self.logger)
        # now configure the bindings
        for k1 in sorted(bindOrderObjCol.iterkeys()):
            objkey = bindOrderObjCol[k1]
	    tmpObjCol = {}
            for a1, b1 in bindObjCol.iteritems():
		keyStr = a1[3]
                if objkey == keyStr.strip().lower():
                    #for a1, b1 in bindObjCol.iteritems():
                    respCode[a1] = nitro.createBindObject(a1[1], b1, url, devIp, sesId, self.logger)

        return respCode

#
# Process Modify Bind dataset
#
    def processModifyBindDataSet(self, devCfg, url, devIp, sesId):
        """
        This is to find any object which has modify state for bind object
        if that is the case then generate Fault saying that bindings can not be modified, in order to change the binding
        delete unbind and and create new bind with changed values
        """
        #self.logger.debug('++++++++ process Modify bind ++++++++')
        modBnCol = {}
        # first get all the binding objects
        modBnCol = util.getStateSpecificBindObjectsFromConfig(const.MODIFY, devCfg, self.logger)
        if len(modBnCol) > 0:
            for x1 in modBnCol.keys():
                path = util.getTupleList(x1[0], self.logger)
                erCode = 2001
                msg = 'Bind Object ' + str(path) + 'can not be changed, please delete/unbind and create/bind with changed values'
                self.logger.error('+++++ RAISING VALUEERROR for Modify Fault object = %s'% (str(x1)))
                errTuple = (path, erCode, msg)
                raise ValueError(errTuple)
        # if execution reaches here then reurn None
        return None
#
# This for unbinding objects from the config
#
    def processUnbindDataSet(self, devCfg, url, devIp, sesId):
        """
        This is for all the unbind or all the bind object which has delete state
        """
        #self.logger.debug('++++++++++++ Process UNBIND dataset +++++++++++')
        respCode = {}
        objKey = None
        objVal = None
        argStr = None

        # get all the binding objects with DELETE state
        bindObjCol = util.getStateSpecificBindObjectsFromConfig(const.DELETE, devCfg, self.logger)

        for a1, b1 in bindObjCol.iteritems():
            objKey = a1[1]
            tmpStr = None
            argStr = None
            objVal = None
            for a2, b2 in b1.iteritems():

                if a2 == const.NAME or a2 == const.ID:
                    objVal = b2
                else:
                    # skip the targetlbvserver from the arg string since unbind doesn't take this
		    if objKey == const.CSVSERVER_CSPOLICY_BINDING and a2 == const.TARGET_LBVSERVER:
                        continue
                    if tmpStr is not None :
                        tmpStr = tmpStr + ',' + a2 + ':' + b2
                    else:
                        tmpStr = a2 + ':' + b2
            #construct the args string
            if (tmpStr):
                argStr = const.ARGS + '=' + tmpStr
	    # here a1 contains both object and instance value
            respCode[a1] = nitro.removeNitroObject(objKey, objVal, argStr, url, devIp, sesId, self.logger)

        return respCode

#
# Process attachEndpoint request
#
    def processAttachEndpoint(self, endpoints, cfg, url, devIp, sesId):
        """
        This is to handle attach end point requests
        """
        respCol = {}
        self.logger.debug('+++++++++ This is to handle attach endpoint request ++++++++++')
	#endpoints is a list of dictionary
        epCol = {}
        for tmpListVal in endpoints:
            epCol = tmpListVal
            tmpAddr = None
            tmpConName = None
            for a1, b1 in epCol.iteritems():
                if a1.strip().lower() == const.APIC_ADDR:
                    tmpAddr = b1
		    # this is to remove masking from the IP
                    if tmpAddr.find('/') > 0:
                        tmpAddr = tmpAddr[:tmpAddr.find('/')]
                elif a1.strip().lower() == const.APIC_CONN:
                    tmpConName = b1
            # now get the servicegroup object based on tmpConName
            sgObjCol = util.getObjectForConnector(tmpConName, const.MFCNGSERVICEGROUP, cfg, self.logger)
            for i1, j1 in sgObjCol.iteritems():
                sgKeyPortCol = {}
                tmpCol = {}
                # get key and port collection
                sgKeyPortCol = util.getServiceGroupKeyPortCollection(j1, cfg, self.logger)
                tmpCol[i1] = nitro.bindSGPortIPForEpAttach(sgKeyPortCol, tmpAddr, url, devIp, sesId, self.logger)
                respCol = dict(respCol.items() + tmpCol.items())


        return respCol

#
# Process detachEndpoint request
#
    def processDetachEndpoint(self, endpoints, cfg, url, devIp, sesId):
        """
        This is to handle detach end point requests
        """
        respCol = {}
        epCol = {}
        self.logger.debug('+++++++++ This is to handle detach endpoint request ++++++++++')
        for tmpListVal in endpoints:
            epCol = tmpListVal
            tmpConName = None
            tmpAddr = None
            for a1, b1 in epCol.iteritems():
                if a1.strip().lower() == const.APIC_ADDR:
                    tmpAddr = b1
		    # this is to remove masking from the IP
                    if tmpAddr.find('/') > 0:
                        tmpAddr = tmpAddr[:tmpAddr.find('/')]
                elif a1.strip().lower() == const.APIC_CONN:
                    tmpConName = b1
            sgObjCol = util.getObjectForConnector(tmpConName, const.MFCNGSERVICEGROUP, cfg,self.logger)
            for i1, j1 in sgObjCol.iteritems():
                sgKeyPortCol = {}
                tmpCol = {}
                # get key and port collection
                sgKeyPortCol = util.getServiceGroupKeyPortCollection(j1, cfg, self.logger)
                tmpCol = nitro.unbindSGPortIPForEpDetach(sgKeyPortCol, tmpAddr, url, devIp, sesId, self.logger)
                respCol = dict(respCol.items() + tmpCol.items())

            # just in case if detachment happens due to service EPG
            serObjCol = util.getObjectForConnector(tmpConName, const.SERVICE, cfg, self.logger)
            for l1, m1 in serObjCol.iteritems():
                lbCol = {}
                tmpCol = {}
            # get the lbvservers for these services
                lbCol = util.getLBVServerBasedOnObject(const.LBVSERVER_SERVICE_BINDING, m1, cfg, logger)
                if length(lbCol) > 0:
                    for p1, q1 in lbCol.iteritems():
                        argStr = 'args =' + 'servicename:' + q1
                        tmpCol[l1] = nitro.removeNitroObject(const.LBVSERVER_SERVICE_BINDING, p1, argStr, url, devIp, sesId, self.logger)
                        respCol = dict(respCol.items() + tmpCol.items())

        return respCol

#
# Modify VServer's helper method to handle modify objects
#
    def modifyVServer(self, objCol, devCfg, url, devIp, sesId):
        """
        This is for modify vServers
        """
        objState = -1

#
# Modify VServer's helper method to handle modify objects
#
    def modifyVServer(self, objCol, devCfg, url, devIp, sesId):
        """
        This is for modify vServers
        """
        objState = -1
        respCode = {}

        # get the state of the object
        for i1, j1 in objCol.iteritems():
            objKey = i1
            for i2, j2 in j1.iteritems():
                if i2 == const.VALUE:
                    tmpCol = j2
                if i2 == const.STATE:
                    objState = j2
        #print ' ++++++++ Object State = ', objState
        # check the state of the object
        if objState == const.MODIFY:
            # get all the modify attributes
            objAtrCol = util.getModifyAttributeCollectionForObject(objCol)
            #self.logger.debug('+++++++++++++ MODIFIED Attribute collection = %s' % (objAtrCol))
            #print '++++++MODIFIED Attribute collection = ', objAtrCol
            # now set the modified attributes
            for a1, b1 in objAtrCol.iteritems():
                respCode[a1] = nitro.setConfigObjects(a1, b1, url, devIp, sesId, self.logger)
            # now get the deleted attributes
            delObjAtrCol = util.getDeleteAttributeCollectionForObject(objCol)
            #self.logger.debug('++++++++++ DELETE Attribute collection = %s' % (delObjAtrCol))
            # now run the unset on this collection
            for a2, b2 in delObjAtrCol.iteritems():
                respCode[a2] = nitro.unsetConfigObjects(a2, b2, url, devIp, sesId, self.logger)
                #print '+++++++++++ SET MODIFY Response = ', respCode[a1]
        #handle DELETE state
        if objState == const.DELETE:
            objAtrCol = util.getAttributeCollectionForObject(objCol, devCfg, self.logger)
            remObjCol = util.getObjectIdentifierNValue(objAtrCol)
            for k1, l1 in remObjCol.iteritems():
                # here k1 is the object key
                for k2, l2 in l1.iteritems():
                    args = None
                    #self.logger.debug('++++++++++++++ Removing Object details key = %s, val = %s' % (k1, l2))
                    respCode = nitro.removeNitroObject(k1, l2, args, url, devIp, sesId, self.logger)

        # check if there is any bind attribute to be handled
        objBindCol = util.getBindObjectsForObject(objCol)
	if len(objBindCol) > 0:
            # handle bind object details
            respCode[const.BINDING] = self.handleModifyBindReferenceObjects(objBindCol, devCfg, url, devIp, sesId)
            # now handle second level of bind objects
            for c1, d1 in objBindCol.iteritems():
                tmpObjCol = util.getCompleteObjectFromConfig(d1, devCfg)
                tmpBindObjCol = util.getBindObjectsForObject(tmpObjCol)
                respCode[c1] = self.handleModifyBindReferenceObjects(tmpBindObjCol, devCfg, url, devIp, sesId)

        return respCode
#
# create VServer's helper method
#
    def createVServer(self, objCol, devCfg, url, devIp, sesId):
        """
        This is to create csvserver util since csvserver requires special handling for backupvserver
        """
        #self.logger.debug('-------- This is createCSVServer with objCol = %s' % (objCol))
        objSate = -1
        respCode = {}
        tmpCol = {}
        for i1, j1 in objCol.iteritems():
            objKey = i1
            for i2, j2 in j1.iteritems():
                if i2 == const.VALUE:
                    tmpCol = j2
                if i2 == const.STATE:
                    objState = j2
        if objState == const.CREATE:
            objAtrCol = util.getAttributeCollectionForObject(objCol, devCfg, self.logger)
            # check if the collection has the backupvserver
            for u1, v1 in objAtrCol.iteritems():
                for u2, v2 in v1.iteritems():
                    if u2.lower().strip() == const.BACKUPVSERVER:
                        backupServer = v2
                    # get the service type also since this is required
                    elif u2.lower().strip() == const.SERVICETYPE:
                            servType = v2
                    elif u2.lower().strip() == const.IPV46:
                            ipvVal = v2
                    elif u2.lower().strip() == const.PORT:
                            portVal = v2
            #self.logger.debug('+++++++++++++ BACKUP VServer = %s ' % (backupServer))
            # now remove from the collection
            objAtrCol = self.removeBackupserverFromObjCol(objAtrCol)

            if len(objAtrCol) > 0:
                for i1, j1 in objAtrCol.iteritems():
                    respCode[i1] = nitro.createConfigObjects(i1, j1, url, devIp, sesId, self.logger)
        # get all the related bindings for this object
        bindObjCol = util.getBindObjectsForObject(objCol)
       # now get the second level objects
        for i2, j2 in bindObjCol.iteritems():
            # check for the state
            if i2[0] == const.CREATE:
                # get the objects from config
                objCol = util.getCompleteObjectFromConfig(j2, devCfg)
                # check if the objCol has any objects in it or not
                if len(objCol) > 0:
                    objState = util.getStateForObject(objCol)
                    if objState == const.CREATE:
                        # handle all the MRELs if there is any for second level objects i.e. responderpolicy
                        respCode[const.MREL] = self.processMRELObjects(objCol, devCfg, url, devIp, sesId)
                        # get the attribute collection
                        objAtrCol = util.getAttributeCollectionForObject(objCol, devCfg, self.logger)
                        if len(objAtrCol) > 0:
                            # now create this objects
                            # since object attribute collection's first attribute is object key and value is the collection
                            for i3, j3 in objAtrCol.iteritems():
                                respCode[i3] = nitro.createConfigObjects(i3, j3, url, devIp, sesId, self.logger)

        # now get the reference objects for second level objects
        for i4, j4 in bindObjCol.iteritems():
            objCol = util.getCompleteObjectFromConfig(j4, devCfg)
            bindObjCol = util.getBindObjectsForObject(objCol)

            # check if there is any bindObjCol
            if len(bindObjCol) > 0:
                for i5, j5 in bindObjCol.iteritems():
                    # check the state
                    if i5[0] == const.CREATE:
                        # get the objects from config
                        tmpCol = util.getCompleteObjectFromConfig(j5, devCfg)
                        objState = util.getStateForObject(tmpCol)
                        if objState == const.CREATE:
                            tmpAtrCol = util.getAttributeCollectionForObject(tmpCol, devCfg, self.logger)
                            if len(tmpAtrCol) > 0:
                                for i6, j6 in tmpAtrCol.iteritems():
                                    respCode[i6] = nitro.createConfigObjects(i6, j6, url, devIp, sesId, self.logger)

        # now create the backup server and its binding server
        #self.logger.debug('+++++++++ CREATING BACKUP SERVER = %s' % (backupServer))
        if backupServer:
            bckObj = util.getCompleteObjectFromConfig(backupServer, devCfg)
            # get the object attribute
            bckAttrCol = util.getAttributeCollectionForObject(bckObj, devCfg, self.logger)
            bckBindCol = util.getBindObjectsForObject(bckObj)

            if len (bckAttrCol) > 0:
                for x1, y1 in bckAttrCol.iteritems():
                    respCode[x1] = nitro.createConfigObjects(x1, y1, url, devIp, sesId, self.logger)

            # now get the backup bind objects and create them
            for e1, f1 in bckBindCol.iteritems():
                bckObjCol = util.getCompleteObjectFromConfig(f1, devCfg)
                bckAttrCol = util.getAttributeCollectionForObject(bckObjCol, devCfg, self.logger)
                # check the length
                if len(bckAttrCol) > 0:
                    for e2, f2 in bckAttrCol.iteritems():
                        respCode[e2] = nitro.createConfigObjects(e2, f2, url, devIp, sesId, self.logger)
            setTmpCol = {}
            # now set the backup server this is only for CSVServer
            if objKey == const.CSVSERVER:
                setTmpCol[const.NAME] = objVal
                setTmpCol[const.BACKUPVSERVER] = backupServer
                #setTmpCol[const.SERVICETYPE] = servType
                setTmpCol[const.IPV46] = ipvVal
                #setTmpCol[const.PORT] = portVal

                #self.logger.debug('++++++++++++++ Setting the BACKUP server ++++++++++++++')
                respCode[objKey] = nitro.setConfigObjects(objKey, setTmpCol, url, devIp, sesId, self.logger)


        return respCode

#
# Bind object handler
#
    def handleModifyBindReferenceObjects(self, objBindCol, devCfg, url, devIp, sesId):
        """
        This is to handle all the reference/binding objects of a particular objects
        """
        #self.logger.debug('+++++++++ Handle Modify Bind Reference objects for = %s' % (objCol))
	respCode = {}
        for a1, b1 in objBindCol.iteritems():
            if a1[0] != const.NOCHANGE:
                # bind objects will have either CREATE or DELETE state, CREATE will create Delete will unbind
                if a1[0] == const.CREATE:
                    tmpObj = util.getCompleteObjectFromConfig(b2, devCfg)
                    objState = util.getStateForObject(tmpObj)
                    # This is to handle object's state
                    if objState == const.CREATE:
                        respCode[const.MREL] = self.processMRELObjects(tmpObj, devCfg, url, devIp, sesId)
                        # get attribute collection
                        objAtrCol = util.getAttributeCollectionForObject(tmpObj, devCfg, self.logger)
                        for a3, b3 in objAtrCol.iteritems():
                            respCode[a3] = nitro.createConfigObjects(a3, b3, url, devIp, sesId, self.logger)
                    if objState == const.MODIFY:
                        objAtrCol = util.getModifyAttributeCollectionForObject(tmpObj)
                        # now set modified attributes
                        for a5, b5 in objAtrCol.iteritems():
                            respCode[a5] = nitro.setConfigObjects(a5, b5, url, devIp, sesId, self.logger)
                        # check for any delete attributes from the oject collection
                        delObjAtrCol = util.getDeleteAttributeCollectionForObject(tmpObj)
                        # now unset the attribute
                        for a6, b6 in delObjAtrCol.iteritems():
                            respCode[a6] = nitro.unsetConfigObjects(a6, b6, url, devIp, sesId, self.logger)
                    if objState == const.DELETE:
                        # get the object key and its value
                        tmpAtrObj = util.getAttributeCollectionForObject(tmpObj, devCfg, self.logger)
                        tmpCol = util.getObjectIdentifierNValue(tmpAtrObj)
                        # remove this object from NetScaler
                        for a7, b7 in tmpCol.iteritems():
                            # here a7 is object key, b7 is id and value
                            for a8, b8 in b7.iteritems():
                                #self.logger.debug('++++++++++ Removing object key = %s, value = %s' % (a7, b8))
                                args = None
                                respCode[a7] = nitro.removeNitroObject(a7, b8, args, url, devIp, sesId, self.logger)

        return respCode

#
# remove backup server from CSV collection since add fails withour backupserver
# we will add it later
#
    def removeBackupserverFromObjCol(self, csvCol):
        #self.logger.debug('++++++++++ remove backupserver if it is present in the CSV Col ++++++++')
        atrCol = {}
        for i1, j1 in csvCol.iteritems():
            tmpCol = {}
            for i2, j2 in j1.iteritems():
                if i2.lower().strip() != const.BACKUPVSERVER:
                    tmpCol[i2] = j2
            atrCol[i1] = tmpCol
        #self.logger.debug('++++++++++++ returning collections = %s' % (atrCol))
        return atrCol

#
# Process all MRELs for an object
#
    def processMRELObjects(self, objCol, devCfg, url, devIp, sesId):
        """
        This is to handle all the MRELs which is not binding object rather it is reference objects
        such as responderpolicy's action which is reference objects of type responder action
        """
        #self.logger.debug('++++++++++ Processing MREL Objects for object = %s' % (objCol))
        mrelCol = util.getMRELsForObject(objCol)
        respCode = {}
        tmpAtrCol = {}
        if len (mrelCol) > 0:
            #self.logger.debug('+++ MREL Objects = %s' %(mrelCol))
            for a1, b1 in mrelCol.iteritems():
                for a2, b2 in b1.iteritems():
                    if a2 == const.VALUE:
                        tmpVal = b2
                        # get the value from absolute path
                        b1Val = tmpVal[tmpVal.rfind('/')+1:]
                        # get the complete value from config and configure it
                        tmpObjVal = util.getCompleteObjectFromConfig(b1Val, devCfg)
                        objState = util.getStateForObject(tmpObjVal)
                        if objState == const.CREATE:
                            tmpAtrCol = util.getAttributeCollectionForObject(tmpObjVal, devCfg, self.logger)
                            #self.logger.debug('+++++++ MREL/Reference object creation = %s' % (tmpAtrCol))
                            for c1, d1 in tmpAtrCol.iteritems():
                                respCode[a1] = nitro.createConfigObjects(c1, d1, url, devIp, sesId, self.logger)

        return respCode

#
# Create bindings based on bind collection
#
    def processBindCollection(self, bindObjCol, url, devIp, sesId):
        #self.logger.debug('++++++++ process bind collections = %s'  % (bindObjCol))
        bindCol = {}
        tmpVal = None
        respCode = {}
        bndState = -1
        if len(bindObjCol) > 0:
                for a1, b1 in bindObjCol.iteritems():
                # create the next level of bindings
                    tmpVal = a1[1]
                bindCol = {}
                for a2, b2 in b1.iteritems():
                    # handle the CREATE state
                    if a2[0] == const.CREATE:
                        tmpCol = {}
                        tmpKey = a2[1]
                        for a3, b3 in b2.iteritems():
                            tmpCol[a3[0]] = b3
                        tmpCol[self.NAME] = tmpVal
                        bindCol[tmpKey] = tmpCol
                        #self.logger.debug('+++++++++ SECOND LEVEL BINDINGS COLLECTIONS = %s' % (bindCol))
                        if len(bindCol) > 0:
                            for a4, b4 in bindCol.iteritems():
                                respCode[a4] = nitro.createBindObject(a4, b4, url, devIp, sesId, self.logger)
                    # handle delete state
                    if a2[0] == const.DELETE:
                        args = None
                        tmpKey = a2[1]
                        for a7, b7 in b2.iteritems():
                            if (args):
                                args += ','
                                args += a7[0] + ':' + b7
                            else:
                                args += a7[0] + ':' + b7
                        # remove the bind or Unbind this from NetScaler
                        tmpArg = const.ARGS + '=' + args
                        respCode[tmpVal] = nitro.removeNitroObject(tmpKey, tmpVal, tempArg, url, devIp, sesId, self.logger)
        return respCode

#
# This is to handle bind operations for given object
#
    def handleBindForFunctionDef(self, objKey, objVal, devCfg, url, devIp, sesId):
        #self.logger.debug('++++++++++ This is handle all the BINDINGS for a give Function +++++ ')
        respCode = {}
        # first get the complete and look for all bindings
        objCol = util.getCompleteObjectFromConfig(objVal, devCfg)

        objBindCol = self.getBindAttributeCollectionForObject(objCol)

        #self.logger.debug('+++++++ Bind collections for Object = %s collections = %s' %(objVal, objBindCol))
        bindCol = {}
        tmpKey = None
        # create the first level of bindings
        respCode = self.processBindCollection(objBindCol, url, devIp, sesId)

        # second level bindings
        bindObjCol = util.getBindObjectsForObject(objCol)
        tmpVal = None
        if len(bindObjCol) > 0:
            for a1, b1 in bindObjCol.iteritems():
                tmpObj1 = util.getCompleteObjectFromConfig(b1, devCfg)
                tmpBndObjCol = self.getBindAttributeCollectionForObject(tmpObj1)
                #self.logger.debug('++++++++++ Second level bindings collection = %s' % (tmpBndObjCol))
                # create the next level of bindings
                if len (tmpBndObjCol) > 0:
                    respCode = self.processBindCollection(tmpBndObjCol, url, devIp, sesId)
        # if objkey is csvserver then handle the backup server's bindings
        if objKey == const.CSVSERVER:
            backupVal = None
            # get the value of the backupserver from the objectAttribute collection
            objAttrCol = util.getAttributeCollectionForObject(objCol, devCfg, self.logger)
            for i1, j1 in objAttrCol.iteritems():
                for i2, j2 in j1.iteritems():
                    if i2.lower().strip() == const.BACKUPVSERVER:
                        backupVal = j2
            if backupVal:
                # get this object from config
                bckObjCol = util.getCompleteObjectFromConfig(backupVal, devCfg)
                bckBindCol = self.getBindAttributeCollectionForObject(bckObjCol)
                #self.logger.debug('++++++++++ Bindings for BACKUPVSERVER = %s' % (bckBindCol))
                respCode = self.processBindCollection(bckBindCol, url, devIp, sesId)

        return respCode
#
# get bind object collection from the object
#
    def getBindAttributeCollectionForObject(self, objCol):
        #self.logger.debug('++++++++++ get Bind attribute collection for object = %s' % (objCol))
        objBindCol = {}
        bndState = -1
        for i1, j1 in objCol.iteritems():
            for i2, j2 in j1.iteritems():
                tmpCol2 = {}
                t1Col = {}
                if i2 == const.VALUE:
                    for i3, j3 in j2.iteritems():
                        if i3[0] == const.FOLDER and i3[1].find(const.BINDING) != -1:
                            tmpCol = {}
                            i3BindName = i3[1]
                            i3BindInstName = i3[2]
                            for i4, j4 in j3.iteritems():
                                if i4 == const.STATE:
                                    bndState = j4
                                if i4 == const.VALUE:
                                    t1Col = j4
                            if bndState != const.NOCHANGE:
                                for i5, j5 in t1Col.iteritems(): # this should be either type 6 MREL or PARAM
                                    for i6, j6 in j5.iteritems():
                                        if i6 == const.VALUE:
                                            tmpCol[(i5[1], i5[2])] = j6
                            tmpCol2[(bndState, i3BindName, i3BindInstName)] = tmpCol
            objBindCol[(i1[1], i1[2])] = tmpCol2
        #self.logger.debug('++++++++++++ Bind attribute collection = %s' % (objBindCol))
        return objBindCol
#
# Get the tag value from the IFC Tag object
#
    def getTagValueFromObject(self, objCol):
        """
        This is to get the tag value of type from the object collection
        """
        tagVal = 0
        typeVal = 0
        for a1, b1 in objCol.iteritems():
            for a2, b2 in b1.iteritems():
                if a2 == const.TAG:
                    tagVal = b2
                elif a2 == const.TYPE:
                    typeVal = b2
        #self.logger.debug('+++++++ Tag = %s and Type =%s' % (tagVal, typeVal))
        if typeVal == 1: # Type 1 is VLAN so create the VLAN ids
            return tagVal
	else:
	    return None
#
# Handle IFC Tags from the config
#
    def handleIFCTagObjects(self, objCol, url, devIp, devCfg, sesId):
        """
        This is to handle network specific objects such as IFCTags and VLAN/VXLAN
        """
        #self.logger.debug('++++++++ handleIFCTag Objects ++++++++++')
        tagVal = 0
        typeVal = 0
        respCol = {}
        vlanCol = {}
        for a1, b1 in objCol.iteritems():
            if a1 == const.TAG:
                tagVal = b1
            elif a1 == const.TYPE:
                typeVal = b1
        #self.logger.debug('+++++++ Tag = %s and Type =%s' % (tagVal, typeVal))
        if typeVal == 1: # Type 1 is VLAN so create the VLAN ids
            vlanCol[const.ID] = tagVal
            # this is to create VLAN and not get confused with VLAN_BIND since it is 'vlan'
            respCol[const.VLAN_BIND] = nitro.createConfigObjects(const.VLAN_BIND, vlanCol, url, devIp, sesId, self.logger)

        return respCol
#
# This is to get the interface number from the object
#
    def getVIFValueFromObject(self, objCol):
        """
        This is to get the VIF or interface number from the VIF object
        """
        cifCol = {}
        respCol = {}
        interCol = {}
	idVal = None
        for a1, b1 in objCol.iteritems():
            for a2, b2 in b1.iteritems():
                if a2.strip().lower() == const.CIFS:
                    cifCol = b2
        # get the interface value from the cifCol
        idVal = cifCol['ADC1']
        # replace '_' with '/'
        idVal = idVal.replace('_', '/')
        return idVal
#
# This is to handle VIF objects from the config
#
    def handleVIFObjects(self, objCol, url, devIp, devCfg, sesId):
        """
        This is to handle the VIF objects
        """

        #self.logger.debug('+++++++ handle VIF Objects +++++++++')
        cifCol = {}
        respCol = {}
        interCol = {}
        for a1, b1 in objCol.iteritems():
            if a1.strip().lower() == const.CIFS:
                cifCol = b1
        # get the interface value from the cifCol
        idVal = cifCol['ADC1']
        # replace '_' with '/'
        idVal = idVal.replace('_', '/')
        interCol[const.ID] = idVal
        respCode = nitro.setConfigObjects('interface', interCol, url, devIp, sesId, self.logger)

#
# process delete network level objects such as VLAN, VIF etc.
#
    def processDeleteNetworkDataSet(self, deviceObj, devCfg, url, devIp, virtualFlag, sesId, deviceAuditFlag=False):
        """
        This is to handle all the network level objects
        """
        createObjCol = {}
        respCode = {}
        configOrderCol = {}
        # first get the cluster node from config
        nodeCol = util.getClusterColFromConfig(deviceObj, self.logger)
	#self.logger.debug('nodeCol = %s ' % (nodeCol))
        # for each node get the ip and credential
        for m1, n1 in nodeCol.iteritems():
            vifObjCol = {}
            vifNum = None
            nodeName = m1
            nodeHostVal = None
            nodePortVal = 0
            nodeCredCol = {}
            nodeUrl = None
            for m2, n2 in n1.iteritems():
                if m2.strip().lower() == const.HOST:
                    nodeHostVal = n2
                elif m2.strip().lower() == const.PORT:
                    nodePortVal = n2
                elif m2.strip().lower() == const.CREDS:
                    nodeCredCol = n2
            nodeUrl = util.getURL(nodePortVal, nodeHostVal, self.logger)
            # get loginObj to create the sesId
            loginObj = util.getLoginObj(nodeUrl, nodeHostVal, nodeCredCol, self.logger)
            nodeSesId = loginObj.login()
            # delete the VLANs
            tagCol = {}
            tmpCode = {}
            tagCol = util.getStateSpecificVLANFromConfig(const.DELETE, devCfg, self.logger, deviceAuditFlag)
            tmpCode = self.deleteTags(tagCol, nodeUrl, nodeHostVal, nodeSesId)
            respCode = dict(tmpCode.items() + respCode.items())
            # now get VIF object for this node
            vifObjCol = util.getNodeVIFsFromConfig(nodeName, devCfg, self.logger, deviceAuditFlag)
            #self.logger.debug('++++++++ VIFs for nodeName = %s, VIFs = %s' % (nodeName, vifObjCol))
            for r1, s1 in vifObjCol.iteritems():
                encapCol = {}
	        keyTuple = r1
                # here s1 is the dict of type VIFs such as {'ADC1': '1_1'}
                vifNum = s1[nodeName]
                vifNum = vifNum.replace('_', '/')
                # here r1 is object name
                encapCol = util.getStateSpecificVIFEncapassFromConfig(const.DELETE, r1[1], devCfg, self.logger, deviceAuditFlag)
                #self.logger.debug('++++++++ ENCAP collection for VIF object = %s, encapass collection = %s' % (r1[1], encapCol))
                for r2, s2 in encapCol.iteritems():
                    for r3, s3 in s2.iteritems():
                        if r3.strip().lower() == const.ENCAP:
                            # now get the IFC tags based on the encap object name
                            tagObjName = s3
                            tagCol = {}
                            tagCol = util.getStateSpecificEncapTagFromConfig(const.DELETE, tagObjName, devCfg, self.logger, deviceAuditFlag)
                            # now first unbind VIFs and Tags if it is of type 1
                            tmpCode = self.deleteVIFTagBind(keyTuple, tagCol, vifNum, nodeUrl, nodeHostVal, virtualFlag, nodeSesId)
	                    respCode = dict(tmpCode.items() + respCode.items())

            # now logout and end the session
            loginObj.logout(nodeSesId)
        return respCode

#
# process network level objects such as VLAN, VIF etc.
#
    def processCreateNetworkDataSet(self, deviceObj, devCfg, url, devIp, virtualFlag, sesId, deviceAuditFlag=False):
        """
        This is to handle all the network level objects
        """
        createObjCol = {}
        respCode = {}
        configOrderCol = {}
        # first get the cluster node from config
        nodeCol = util.getClusterColFromConfig(deviceObj, self.logger)
        # for each node get the ip and credential
        for m1, n1 in nodeCol.iteritems():
            vifObjCol = {}
            vifNum = None
            nodeName = m1
            nodeHostVal = None
            nodePortVal = 0
            nodeCredCol = {}
            nodeUrl = None
            for m2, n2 in n1.iteritems():
                if m2.strip().lower() == const.HOST:
                    nodeHostVal = n2
                elif m2.strip().lower() == const.PORT:
                    nodePortVal = n2
                elif m2.strip().lower() == const.CREDS:
                    nodeCredCol = n2
            # get the Node URL
            nodeUrl = util.getURL(nodePortVal, nodeHostVal, self.logger)
            # get loginObj to create the sesId
            loginObj = util.getLoginObj(nodeUrl, nodeHostVal, nodeCredCol, self.logger)
            nodeSesId = loginObj.login()
            # create the VLANs
            tagCol = {}
            tmpCode = {}
            tagCol = util.getAddModStateVLANFromConfig(devCfg, self.logger, deviceAuditFlag)
            partitionCol = self.getContextTenantName(devCfg)
            if const.AdminPartitionSupport == True and const.TENANT in partitionCol:
                # default partition is created, and we can skip this part)
                if partitionCol[const.TENANT] != 'default':
                    partitionName = partitionCol[const.TENANT] + "_" + partitionCol[const.CONTEXT] + "_" + str(partitionCol[const.VDEV])
                    tmpCode = self.createTagsAdmin(tagCol, nodeUrl, nodeHostVal, nodeSesId)
                    respCode = dict(tmpCode.items() + respCode.items())
                    tmpCode = self.bindVlanPartition(partitionName, tagCol, nodeUrl, nodeHostVal, nodeSesId)
                    respCode = dict(tmpCode.items() + respCode.items())
                else:
                    tmpCode = self.createTags(tagCol, nodeUrl, nodeHostVal, nodeSesId)
                    respCode = dict(tmpCode.items() + respCode.items())
            else:
                tmpCode = self.createTags(tagCol, nodeUrl, nodeHostVal, nodeSesId)
                respCode = dict(tmpCode.items() + respCode.items())


            # now get VIF object for this node
            vifObjCol = util.getStateSpecificNodeVIFsFromConfig(const.CREATE, nodeName, devCfg, self.logger, deviceAuditFlag)
            #self.logger.debug('++++++++ VIFs for nodeName = %s, VIFs = %s' % (nodeName, vifObjCol))
            for r1, s1 in vifObjCol.iteritems():
                encapCol = {}
                # here s1 is the dict of type VIFs such as {'ADC1': '1_1'}
                vifNum = s1[nodeName]
                vifNum = vifNum.replace('_', '/')
                # here r1 is object name
                encapCol = util.getStateSpecificVIFEncapassFromConfig(const.CREATE, r1[1], devCfg, self.logger, deviceAuditFlag)
                #self.logger.debug('++++++++ ENCAP collection for VIF object = %s, encapass collection = %s' % (r1[1], encapCol))
                for r2, s2 in encapCol.iteritems():
	            keyTuple = r2
                    for r3, s3 in s2.iteritems():
                        if r3.strip().lower() == const.ENCAP:
                            # now get the IFC tags based on the encap object name
                            tagObjName = s3
                            tagCol = {}
                            tagCol = util.getStateSpecificEncapTagFromConfig(const.CREATE, tagObjName, devCfg, self.logger, deviceAuditFlag)
                            # now create the binding between VIFs and Tags if it is of type 1
                            tmpCode = self.createVIFTagBind(keyTuple, tagCol, vifNum, nodeUrl, nodeHostVal, virtualFlag, nodeSesId)
	                    respCode = dict(tmpCode.items() + respCode.items())
            # now logout and end the session
            loginObj.logout(nodeSesId)
        return respCode

#
# create the IFC tags in NetScaler
#
    def createTags(self, tagCol, nodeUrl, nodeHostIp, ndSesId):
        """
        This is to create tags in the node based on node Ip
        """
        #self.logger.debug('+++++++++ create Tags based on type in the node Ip = %s' % (nodeHostIp))
        typeVal = 0
        tagVal = 0
        respCol = {}
        vlanCol = {}
        for a1, b1 in tagCol.iteritems():
            vlanCol = {}
            vlanCol[const.ID] = b1
            #self.logger.debug('+++++++++ Request for Create Tag value  = %s ' % (b1))
            respCol[a1] = nitro.createConfigObjects(const.VLAN_BIND, vlanCol, nodeUrl, nodeHostIp, ndSesId, self.logger)

     	return respCol
#
# create VIF and tag binding
#
    def createVIFTagBind(self, keyTuple, tagCol, vifNum, nodeUrl, nodeHostIp, virtualFlag, ndSesId):
        """
        This is to create Vlan binding between tag and an interface i.e. VIF
        """
        #self.logger.debug('+++++++++ VIFTagBind tagCol = %s, IFNUM = %s' % (tagCol, vifNum))
        tagVal = None
        typeVal = None
        vlanCol = {}
        respCode = {}
        for a1, b1 in tagCol.iteritems():
            vlanCol = {}
            tagVal = None
            typeVal = None
	    # the key for the collection is in this format {('7185', 1): 203}
	    typeVal = a1[2]
	    tagVal = b1
            # check the type
            if typeVal == 1: # This is of type VLAN
                vlanCol[const.ID] = tagVal
                vlanCol[const.IFNUM] = vifNum
		        #if virtualFlag is False: # this is no longer applicable from NetScaler 11.1 onwards
                vlanCol[const.TAGGED] = True
                respCode[keyTuple] = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, vlanCol, nodeUrl, nodeHostIp, ndSesId, self.logger)
        return respCode
#
# delete the IFC tags in NetScaler
#
    def deleteTags(self, tagCol, nodeUrl, nodeHostIp, ndSesId):
        """
        This is to delete tags in the node based on node Ip
        """
	respCol = {}
        #self.logger.debug('+++++++++ delete Tags based on type in the node Ip = %s' % (nodeHostIp))

        for a1, b1 in tagCol.iteritems():
            respCol[a1] = nitro.removeNitroObject(const.VLAN_BIND, b1, None, nodeUrl, nodeHostIp, ndSesId, self.logger)

     	return respCol
#
# Delete VIF and tag binding
#
    def deleteVIFTagBind(self, keyTuple, tagCol, vifNum, nodeUrl, nodeHostIp, virtualFlag, ndSesId):
        """
        This is to delete Vlan binding between tag and an interface i.e. VIF
        """
        #self.logger.debug('+++++++++ VIFTag UnBind tagCol = %s, IFNUM = %s' % (tagCol, vifNum))
        tagVal = None
        typeVal = None
        vlanCol = {}
        respCode = {}
	tmp1 = { const.IFNUM : vifNum }
        tmpEncode = urlencode(tmp1)
        tmp1 = tmpEncode[6:]
        #tmp1 = {const.IFNUM : tmp1}
        #tmpEncode = urlencode(tmp1)
        #infVal = tmpEncode[6:]
        
	#if virtualFlag is False: # This is no longer applicable 
        tmpStr = const.IFNUM + ':' + tmp1 + ',' + const.TAGGED + ':' + const.TRUE
        #else:
        #    tmpStr = const.IFNUM + ':' + tmp1 + ',' + const.TAGGED + ':' + const.FALSE
        argStr = const.ARGS + '=' + tmpStr
        for a1, b1 in tagCol.iteritems():
            vlanCol = {}
            tagVal = None
            typeVal = None
	    # the key for the collection is in this format {('7185', 1): 203}
	    typeVal = a1[2]
	    tagVal = b1
            # check the type
            if typeVal == 1: # This is of type VLAN
		tmpTuple = tuple(set(keyTuple[0] + a1[0]))
                #self.logger.debug('+++++++++ tmp Tuple for response = %s' % (str(tmpTuple)))
                respCode[tmpTuple] = nitro.removeNitroObject(const.VLAN_INTERFACE_BIND_NAME, tagVal, argStr, nodeUrl, nodeHostIp, ndSesId, self.logger)
        return respCode
#
# process vlan bind
#
    def processVEncapassDataSet(self, devCfg, url, devIp, sesId):
        """
        This is to handle all the network binding dataset
        """
        createObjCol = {}
        respCode = {}
        configOrderCol = {}
        encapVal = 0
        vifVal = None
        createObjCol = util.getStateSpecificVEncapassObjects(const.CREATE, devCfg, self.logger)
	for a1, b1 in createObjCol.iteritems():
            encapCol = {}
            vlanBindCol = {}
            vifCol = {}
            for a2, b2 in b1.iteritems():
                if a2 == const.ENCAP:
                    encapVal = b2
                elif a2 == const.VIF_NAME:
                    vifVal = b2
            self.logger.debug('++++++++ Encap value = %s, VIF val = %s' % (encapVal, vifVal))
            # now get the ENCAP and VIF object from the config
            encapCol = util.getCompleteObjectFromConfig(encapVal, devCfg)
            vifCol = util.getCompleteObjectFromConfig(vifVal, devCfg)
            self.logger.debug('++++++++ Encapass objects ---- vif = %s, encap = %s' % (encapCol, vifCol))
            # get the tag value of type 1 which mean VLAN IDs
            tagVal = self.getTagValueFromObject(encapCol)
            infVal = self.getVIFValueFromObject(vifCol)
            vlanBindCol[const.ID] = tagVal
            vlanBindCol[const.IFNUM] = infVal

            resPcode[a1] = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, vlanBindCol, url, devIp, sesId, self.logger)
        return respCode

#
# Process Function specific IP and VLAN/VXLAN binding
#

    def processFunctionSpecificIPVLANBinding(self, devCfg, url, devIp, sesId, deviceAuditFlag=False):
        """
        This is to handle function level VLAN/VXLAN and IP binding
        """
        respCode = {}
        # get external network and connector for each function
        extCol = util.getNetworkNConnectorFromConfig(const.EXTERNAL, devCfg, self.logger)
        intCol = util.getNetworkNConnectorFromConfig(const.INTERNAL, devCfg, self.logger)
        tmpCode = self.processIPVlanBind(extCol, devCfg, url, devIp, sesId, deviceAuditFlag)
        self.logger.debug(' External Network Response  = %s' % (tmpCode))
        respCode = dict(tmpCode.items() + respCode.items())
        tmpCode = self.processIPVlanBind(intCol, devCfg, url, devIp, sesId, deviceAuditFlag)
        self.logger.debug(' Internal Network Response  = %s' % (tmpCode))
        respCode =  dict(tmpCode.items() + respCode.items())

        return respCode

#
# This is for save config in NetScaler
#
    def saveConfig(self, url, devIp, sesId):
        """
        This is to save config in NetScaler
        """
        resCode = {}
        resCode[devIp] = nitro.saveNSConfig(url, devIp, sesId, self.logger)
        return resCode

    def applyAcls(self, url, devIp, sesId):
        """
        This is to applyNsAcls in NetScaler
        """
        resCode = {}
        resCode[devIp] = nitro.applyNsAcls(url, devIp, sesId, self.logger)
        return resCode

    def applyAcls6(self, url, devIp, sesId):
        """
        This is to applyNsAcls6 in NetScaler
        """
        resCode = {}
        resCode[devIp] = nitro.applyNsAcls6(url, devIp, sesId, self.logger)
        return resCode

    def getNetworkObjectFromSubFolderConfig(self, subFolderName, objValName, networkName, devCfg, logger):
        """
        This is to get the complete object from folder inside the config
        """
        #self.logger.debug('+++++++++++++ get complete object from config = %s' % objValName)
        tmpCol = {}
        for k1, v1 in devCfg.iteritems(): # iterating over device level
            for k2, v2 in v1.iteritems(): # iterating over device value dict
                if k2 == const.VALUE: # check for 'value':
                    for k3, v3  in v2.iteritems(): # This is for global configuration
                        if k3[0] == const.FOLDER and k3[1].strip().lower() == subFolderName.strip().lower() and k3[2] == networkName :
                            for k4, v4 in v3.iteritems():
                                #logger.debug('++++++ Network object from config k4 = %s v4 = %s' % (k4, v4))
                                if k4 == const.VALUE:
                                    for k5, v5 in v4.iteritems():
                                        #logger.debug('++++++ Network object from config k5 = %s v5 = %s' % (k5, v5))
                                        if k5[2] == objValName:
                                            tmpCol[k5] = v4[k5]
        return tmpCol

#
# This is to bind IPs with VLAN ids
#
    def processIPVlanBind(self, extCol, devCfg, url, devIp, sesId, deviceAuditFlag):
        """
        This is to bind external and internal VLANs with SNIP and VIP
        """

        respCode = {}
        # check for the state and if it is create get the object and bind them
        for i1, j1 in extCol.iteritems():
            netObj = None
            networkName = None
            conObj = None
            netStat = -1
            # key is function name
            #funName = i1
            for i2, j2 in j1.iteritems():
                #self.logger.debug(' i2 = %s, j2 = %s' % (i2,j2))
                # key will be network with state i.e. ('network/snip2', 1)
                netObj = i2[0]
                if netObj == None:
                    erCode = 2001
                    msg = 'connector object has no value set'
                    errTuple = (i1, erCode, msg)
                    raise ValueError(errTuple)
                # remove the '/' from name and just get the value
                if netObj.find('/'):
                    networkName = netObj[:netObj.rfind('/')]
                    netObj = netObj[netObj.rfind('/') + 1:]
                netStat = i2[1]
                conObj = j2
            #self.logger.debug('Details netObj = %s, networkName = %s, conObj = %s, netStat = %s' % (netObj, networkName, conObj, netStat))
            # now get the object from config
            netObjCol = self.getNetworkObjectFromSubFolderConfig(const.NETWORK, netObj, networkName, devCfg, self.logger)
            conObjCol = util.getCompleteObjectFromConfig(conObj, devCfg)
            #self.logger.debug(' Network object = %s  Connector object = %s' % (netObjCol, conObjCol))
	    ipValCol = util.getAttributeCollectionForObject(netObjCol, devCfg, self.logger)
            #self.logger.debug(' Network object Attribute Value = %s' % (ipValCol))
            # get the ipaddress and netmask from the ipValCol
            bindCol = {}
	    argStr = None
            ipv6Flag = False
	    for l1, m1 in ipValCol.iteritems():
                for l2, m2 in m1.iteritems():
		    #self.logger.debug('L2 M2  details - l2 = %s m2 = %s' % (l2,m2))
                    if l2 == const.IPADDRESS:
                        bindCol[const.IPADDRESS] = m2
	                argStr = 'args=' + const.IPADDRESS + ':' + m2
                    elif l2 == const.IPV6ADDRESS:
			#self.logger.debug('IPV6 address details - l2 = %s m2 = %s' % (l2,m2))
                        bindCol[const.IPADDRESS] = m2
                        ipv6Flag = True
	                argStr = 'args=' + const.IPADDRESS + ':' + m2
                    elif l2 == const.NETMASK:
                        bindCol[const.NETMASK] = m2
	    bindCol[const.ID] = conObj
            if (conObj): # this is to make sure the None doesn't get created
                if ((netStat == const.CREATE) or (netStat == const.MODIFY) or deviceAuditFlag):
	            tmpCode = {}
                    #tmpCode[(conObj, bindCol[const.IPADDRESS])] = nitro.createBindObject(const.VLAN_NSIP_BINDING, bindCol, url, devIp, sesId, self.logger)
                    if (ipv6Flag):
                        tmpCode[(i1, l1)] = nitro.createBindObject(const.VLAN_NSIP6_BINDING, bindCol, url, devIp, sesId, self.logger)
                    else:
                        tmpCode[(i1, l1)] = nitro.createBindObject(const.VLAN_NSIP_BINDING, bindCol, url, devIp, sesId, self.logger)
		    respCode = dict(tmpCode.items() + respCode.items())
                    #self.logger.debug(' Bind Response  Value = %s' % (respCode))

		    # send GARP if IP is NOT v6 this is workaround for GARP issue
                    if ipv6Flag is False:
                        for s1, t1 in bindCol.iteritems():
                            if s1 == const.IPADDRESS:
                                tmpCode = {}
                                tmpCode[(conObj, t1)] = nitro.sendArpPostRequest(t1,  False, url, devIp, sesId, self.logger)
		                #respCode = dict(tmpCode.items() + respCode.items())
                                #self.logger.debug(' GARP Response  Value = %s' % (tmpCode))
                elif netStat != const.NOCHANGE:
                # modify or delete will require to unbind
                    if (ipv6Flag):
                        respCode[i1] = nitro.removeNitroObject(const.VLAN_NSIP6_BINDING, conObj, argStr, url, devIp, sesId, self.logger)
                    else:
                        respCode[i1] = nitro.removeNitroObject(const.VLAN_NSIP_BINDING, conObj, argStr, url, devIp, sesId, self.logger)

        return respCode

    def processclusterAudit_NTP(self , url, device, interface, cnfg, sesId):

        respCol = {}

        self.logger.debug('+++++++ cluster-NTP-Audit for %s' % device[const.HOST])

        #peerCol = util.getObjColFromDevModCnfg(cnfg, const.NTP_PARAM, self.logger)
        #if len(peerCol) > 0:
        #    respCol[const.NTP_PARAM] = nitro.setConfigObjects(const.NTP_PARAM, peerCol, url, device[const.HOST], sesId, self.logger)

        device_ntpServObjs = {}
        device_instList = []
        device_ntpServObjs = nitro.getObjectsConfigFromDevice(const.NTP_SERVER, url, device[const.HOST], sesId, self.logger)
        tmp = {}
        tmp  = device_ntpServObjs[const.NTP_SERVER]
        for a,b in tmp.iteritems():
            if a == const.NTP_SERVER:
                device_instList = b

        apic_instList = util.getObjColFromDevModCnfg_list(cnfg, const.NTP_SERVER, self.logger)

        #self.logger.debug('++++++++ APIC NTPServer list = %s' % (apic_instList))
        #self.logger.debug('++++++++ Device NTPServer list = %s' % (device_instList))

        #compare diff
        doneObj = {}
        for a in device_instList:
            uid1 = None
            found = 0
            servername = a.get('servername')
            serverip = a.get('serverip')
            if servername is not None:
                uid1 = servername
            elif serverip is not None:
                uid1 = serverip
            if uid1 is None:
                continue
            for b in apic_instList:
                uid2 = None
                servername1 = b.get('servername')
                serverip1 = b.get('serverip')
                if servername1 is not None:
                    uid2 = servername1
                elif serverip1 is not None:
                    uid2 = serverip1
                if uid2 is None:
                    continue
                if uid1 == uid2:
                    tmpobj = b
                    found = 1
                    break;
                else:
                    continue;
            if found != 1:
                #self.logger.debug('extra ntpserver - delete %s from device' % uid1);
                respCol_tmp = self.removeNTPConfigFromDevice(a, url, device[const.HOST], sesId)
                #self.logger.debug('delete %s ntpserver response = %s' % (uid1, respCol_tmp))
                respCol_tmp = {}
            if found == 1:
                # modObj = {}
                # for a1,b1 in tmpobj:
                #     for a2,b2 in a:
                #         if a1 == a2 and b1 != b2:
                #             modObj[a1] = b1
                doneObj[uid1] = 1
                if len(tmpobj) > 1:
                    # atleast one param is there to set otherwise results in 'too few args' error
                    #self.logger.debug('setting ntpserver %s on device' % uid1)
                    respCol_tmp = {}
                    respCol_tmp = nitro.setConfigObjects(const.NTP_SERVER, tmpobj, url, device[const.HOST], sesId, self.logger)
                    #self.logger.debug('setntpserver %s response = %s' % (uid1, respCol_tmp))
                    respCol_tmp = {}

        # above for loops takes care of removing extra ntpserver in device and setting matching ones
        # below code takes care of creating new servers from apic payload
        for leftObj in apic_instList:
            uid = None
            servername2 = leftObj.get('servername')
            serverip2 = leftObj.get('serverip')
            if servername2 is not None:
                uid = servername2
            if serverip2 is not None:
                uid = serverip2
            if uid is not None:
                if uid not in doneObj.keys():
                    #self.logger.debug('Adding ntpserver %s on device' % uid)
                    respCol_tmp = {}
                    respCol_tmp = nitro.createConfigObjects(const.NTP_SERVER, leftObj, url, device[const.HOST], sesId, self.logger)
                    #self.logger.debug('Addntpserver %s response = %s' % (uid, respCol_tmp))
                    respCol_tmp = {}
            else:
                self.logger.error('****Missing REQD field  = %s', leftObj)
                raise Exception('cluster-NTP-Audit - Missing REQD field %s...' % leftObj)


        self.logger.debug('++++++++ cluster-NTP-Audit response = %s' % (respCol))
        return respCol
#
# This is to handle deviceModify request
#
    def processDeviceAudit(self, device, interface, cnfg, sesId):
        """
        This is to handle the device Modify, this function will handle following tasks:
        - get Login obj & instantiate session for each cluster node
        - create ha node for each cluster
        - find the primary
        - create snips, bind vlan to interface & snip
        """
        respCol = {}
        peerCol = {}
        nodeState = None
	# first get the URL
        url = util.getURL(device[const.PORT], device[const.HOST], self.logger)
        #remove HA from the device (if it exisits)
        tmpRespCol = {}
        #tmpRespCol = self.removeHAPeerFromDevice(device[const.HOST], sesId)
        #respCol = dict(respCol.items() + tmpRespCol.items())
        # first get the cluster node from config
        peerCol = util.getObjColFromDevModCnfg(cnfg, const.HAPEER, self.logger)
        # now add the peer to device
        #self.logger.debug('+++++++ Add HA node for nodeHost Val = %s, node collection = %s' % (device[const.HOST], peerCol))
        if len(peerCol) > 0:
            respCol[const.HAPEER] = nitro.createConfigObjects(const.HANODE, peerCol, url, device[const.HOST], sesId, self.logger)
            # now get the state of the HANode
            #nodeState = util.getStaeOfInstanceObject(const.HANODE, peerCol[const.ID], device[const.HOST], sesId, self.logger)

        tmpRespCol = {}
        #if nodeState is not None and nodeState.strip().lower() == const.PRIMARY:
        # add VLAN, bind VLAN to interface, add SNIP, bind SNIP to VLAN
        haCol = util.getObjColFromDevModCnfg(cnfg, const.HIGHAVAILABILITY, self.logger)
        # create SNIP with mgmt access ENABLED
        #self.logger.debug('+++ HA Collection  = %s' % (haCol))
        if len(haCol) > 0:
            tmpRespCol = {}
            tmpRespCol = self.createHighAvailabilityConfig(haCol, url, device[const.HOST], device[const.VIRTUAL], sesId)

        respCol = dict(tmpRespCol.items() + respCol.items())

        self.logger.debug('++++++++ HA Config response = %s' % (respCol))

        return respCol

#
# create High Availability configuration
#
    def createHighAvailabilityConfig(self, haCol, url, devIp, virtualFlag, sesId):
        """
        This is to create High Availability specific config e.g. SNIP, VLAN, bindings etc.
        """
        #self.logger.debug('+++ HA Collection  = %s' % (haCol))
        tmpCol = {}
        tmpRespCol = {}
        tmpIPAddr = haCol.get(const.SNIP)
        tmpNetMask = haCol.get(const.NETMASK)
        if tmpIPAddr is not None and tmpNetMask is not None:
            tmpCol[const.IPADDRESS] = tmpIPAddr
            tmpCol[const.NETMASK] = tmpNetMask
            tmpCol[const.MGMTACCESS] = const.ENABLED.upper()

            tmpRespCol[const.NSIP] = nitro.createConfigObjects(const.NSIP, tmpCol, url, devIp, sesId, self.logger)
        tmpCol = {}
        tmpVlan = haCol.get(const.VLAN_BIND)
        if tmpVlan is not None:
            tmpCol[const.ID] = haCol[const.VLAN_BIND]
            tmpRespCol[const.VLAN_BIND] = nitro.createConfigObjects(const.VLAN_BIND, tmpCol, url, devIp, sesId, self.logger)

        tmpCol = {}
        tmpInf = haCol.get(const.INTERFACE)
        if tmpVlan is not None and tmpInf is not None:
            tmpCol[const.ID] = tmpVlan
            tmpIfVal = tmpInf
            ifVal = tmpIfVal.replace('_', '/')
            tmpCol[const.IFNUM] = ifVal
            #if virtualFlag is False: # since tagged is only supported on MPX not on VPX
            tmpCol[const.TAGGED] = True
            tmpRespCol[const.VLAN_INTERFACE_BIND_NAME] = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, tmpCol, url, devIp, sesId, self.logger)
        tmpCol = {}
	self.logger.debug('HA collection tmpVlan = %s, tmpInf = %s, tmpIPAddr = %s, tmpNetMask = %s' % (tmpVlan, tmpInf, tmpIPAddr, tmpNetMask))
        if tmpIPAddr is not None and tmpVlan is not None and tmpNetMask is not None:
            tmpCol[const.ID] = tmpVlan
            tmpCol[const.IPADDRESS] = tmpIPAddr
            tmpCol[const.NETMASK] = tmpNetMask

            tmpRespCol[const.VLAN_NSIP_BINDING] = nitro.createBindObject(const.VLAN_NSIP_BINDING, tmpCol, url, devIp, sesId, self.logger)
        return tmpRespCol

#
# remove HighAvailability Configuration from the Device
#
    def removeHighAvailabilityConfigFromDevice(self, haCol, url, devIp, sesId):
        """
        This is to remove high Availability config from device
        """
        respCol = {}
        tmpIPAddr = haCol.get(const.SNIP)
        if tmpIPAddr is not None:
            respCol[tmpIPAddr] = nitro.removeNitroObject(const.NSIP, tmpIPAddr, None, url, devIp, sesId, self.logger)

        tmpVlan = haCol.get(const.VLAN_BIND)
        if tmpVlan is not None:
            respCol[tmpVlan] = nitro.removeNitroObject(const.VLAN_BIND, tmpVlan, None, url, devIp, sesId, self.logger)

        return respCol

#
# remove ntpserver from the Device
# used by clusterModify
#
    def removeNTPConfigFromDevice(self, ntpCol, url, devIp, sesId):
        respCol = {}
        servername = ntpCol.get('servername')
        if servername is not None:
            respCol = nitro.removeNitroObject(const.NTP_SERVER, servername, None, url, devIp, sesId, self.logger)
        else:
            serverip = ntpCol.get('serverip')
            if serverip is not None:
                respCol = nitro.removeNitroObject(const.NTP_SERVER, serverip, None, url, devIp, sesId, self.logger)

        return respCol


#
# remove HA Peer from the Device
#
    def removeHAPeerFromDevice(self, url, devIp, sesId):
        """
        This is to remveo HA peer from device
        """
        respCol = {}
        peerId = util.getPeerHANodeOfDevice(const.HANODE, url, devIp, sesId, self.logger)
        if peerId is not None:
            # remove this HA node from the device
            respCol = nitro.removeNitroObject(const.HANODE, peerId, None, url, devIp, sesId, self.logger)

        return respCol


#
# process clusterModify
#
    def processClusterModify(self, url, device, interface, cnfg, sesId):
        """
        This is to process cluster modify request
        """
        respCol = {}
        devIp = device[const.HOST]
        #self.logger.debug('++++++++ process Cluster modify request for device = %s ' % (devIp))
        # first get all create state data
        crtCol = {}
        crtCol = util.getClusterStateSpecificObjectsFromConfig(const.CREATE, cnfg, self.logger)
	tmpCol = {}
        tmpCol = clusterAudit.createObjectInDevice(crtCol, url, devIp, sesId, cnfg, self.logger)
	respCol = dict(tmpCol.items() + respCol.items())
	delCol = {}
        delCol = util.getClusterStateSpecificObjectsFromConfig(const.DELETE, cnfg, self.logger)
	tmpCol = {}
        tmpCol = self.processClusterDeleteDataSet(delCol, cnfg, url, devIp, sesId)
	respCol = dict(tmpCol.items() + respCol.items())

        modCol = {}
        modCol = util.getClusterModifyObjectAtrsFromConfig(const.MODIFY, cnfg, self.logger)
        tmpCol = {}
        tmpCol = self.processClusterModifyDataSet(modCol, cnfg, url, devIp, sesId)
        respCol = dict(tmpCol.items() + respCol.items())

        return respCol
#
# This is to Process Modify cluster dataset
#
    def processClusterModifyDataSet(self, modObjCol, devCfg, url, devIp, sesId):
        """
        This is to handle cluster modify config objects which has modify state
        """
        self.logger.debug('++++++++++ Proces Cluster Modify Data set from the config+++++++++++++++')

        modObjOrdCol = {}
        tmpSetCol = {}
        tmpUnSetCol = {}
        respCode = {}
        objVal = None
        objKey = None
        createObjCol = {}
        # get all the config objects which has modify state

        #self.logger.debug('+++++++++ Mod object Col = %s ' % (modObjCol))
        # get the order list
        for a1, b1 in modObjCol.iteritems():
            #self.logger.debug('+++++++++ Mod Key  Col = %s, VAL = %s ' % (a1,b1))
            atrKeyName = None
            instVal = None
            atrName = None
            objKey = a1[1]
            objVal = a1[2]
            if objKey in [const.ENABLE_MODE, const.ENABLE_FEATURE]:
                continue # this is to skip processing of enable mode and feature since these are already taken care
            atrName = util.getObjectKey(objKey,self.logger)
            # self.logger.debug('+++++++ object = %s, atrName = %s' % (objKey,atrName))
            # get the first element of the tuple
            atrKeyName = atrName[0]
            #self.logger.debug('+++++++++ Set Attr Name  = %s collection = %s' % (atrName, b1))
            instVal = self.getKeyFromClusterModCol(atrKeyName, b1)
            tmpSetCol = {}
            tmpUnSetCol = {}
            # create set and unset collections based on the object collection and its state
            tmpObjCol = {}
            tmpObjCol[a1] = b1
            tmpSetCol = {}
            tmpUnSetCol = {}
            tmpSetCol = util.getAtrForClusteriModifyObj(const.MODIFY, tmpObjCol, devCfg, self.logger)
            # first check if the object exist in NetScaler or not
	    insResCol = {}
	    if objKey == const.SNMPTRAP:
               instStr = "filter=trapclass:" + instVal
               self.logger.debug('+++++++ SNMP Trap get request val = %s' % (instStr))
               insResCol = nitro.getInstanceConfigFromDevice(objKey, instStr, url, devIp, sesId, self.logger)
            else:
               insResCol = nitro.getInstanceConfigFromDevice(objKey, instVal, url, devIp, sesId, self.logger)
	    instObjCol = {}
            instObjCol = util.getObjectInstanceFromResponse(objKey, insResCol, self.logger)
            # if the object is not found in NetScaler then check for object's key attribute state
            if len(instObjCol) == 0:
                # make sure this is no just the RE-NAME incident
                keyState = None
                keyState = self.getKeyValueStateFromObjCollection(atrKeyName, b1)
                # if the keyState for this object is no change then add this
                #self.logger.debug('+++++ Object keyState = %s Object = %s' % (keyState, type(keyState)))
                if keyState == const.NOCHANGE:
                    # add this object in Object collection since this object doesn't exist in NetScaler
                    #self.logger.debug('+++++ Adding Object for create = %s Object = %s' % (keyState, b1))
                    createObjCol[a1] = b1
                    continue
            else:
                tmpCmpFlag = False
                tmpDAtrCol = {}
                tmpDAtrCol[a1[1]] = b1
                tmpDAtrCol = util.getAtrForClusteriModifyObj(const.MODIFY, tmpDAtrCol, devCfg, self.logger, True)
                # if object found in the NetScaler then compare its values from APIC
                tmpCmpFlag = util.compareAPICNDeviceObjects(tmpDAtrCol[objKey], instObjCol[objKey], self.logger)
                if tmpCmpFlag:
                    self.logger.debug('+++++ Ignore same objects APIC object = %s, NetScaler Object = %s' % (tmpDAtrCol, instObjCol))
                    continue
            # check for unmodifiable attribute from setArgs
            # get the object's modifiable attribute from the modObjList
            modTup = util.getModObjTup(objKey, self.logger)
            # check all the columns in the modified attributes
            #self.logger.debug('++++++ Set column details = %s' % (tmpSetCol))
            for x1, y1 in tmpSetCol.iteritems():
                for x2, y2 in y1.iteritems():
                    if x2 not in modTup:
                        path = util.getTupleList(a1, self.logger)
                        erCode = 2001
                        msg = 'Object ' + objKey + ' Attributes ' + x2 + ' can not be changed'
                        self.logger.error('+++++ RAISING VALUEERROR Fault object = %s attribute = %s'% (a1,b1))
                        errTuple = (path, erCode, msg)
                        raise ValueError(errTuple)

            tmpUnSetCol = util.getAtrForClusteriModifyObj(const.DELETE, tmpObjCol, devCfg, self.logger)
            for x1, y1 in tmpUnSetCol.iteritems():
                for x2, y2 in y1.iteritems():
                    if x2 not in modTup:
                        path = util.getTupleList(a1, self.logger)
                        erCode = 2001
                        msg = 'Object ' + objKey + ' Attributes ' + x2 + ' can not be changed'
                        self.logger.error('+++++ RAISING VALUEERROR Fault object = % attribute = %' % (a1,b1))
                        errTuple = (path, erCode, msg)
                        raise ValueError(errTuple)

            #self.logger.debug('Tmp Set collection from Modify object = %s' % (tmpSetCol))
            #self.logger.debug('Tmp UNSET collection from Modify object = %s' % (tmpUnSetCol))
            if len(tmpSetCol) > 0:
                # get all the attribute collection from the object this is to avoid some corner cases
                tmpSetCol = util.getAtrForClusteriModifyObj(const.MODIFY, tmpObjCol, devCfg, self.logger, True) # this is to get all attributes from object
                tmpSetCol[atrKeyName] = instVal # this is to add object's key and its value
                #self.logger.debug('Tmp Set NITRO col  = %s, ObjKey = %s' % (tmpSetCol, objKey))
                respCode[a1] = nitro.setConfigObjects(objKey, tmpSetCol, url, devIp, sesId, self.logger)
                # for some reason if the object doesn't exist then add them
                erCode = util.getErrorCodeFromRespCol(respCode, self.logger)
                #self.logger.debug('Response code from MODIFY object = %s error code = %s' % (respCode[a1], erCode))
                #if erCode == 258:  # here errorcode 258 is for resource does not exist
                #    respCode[a1] = nitro.createConfigObjects(objKey, tmpSetCol, url, devIp, sesId, self.logger)

            if len(tmpUnSetCol) > 0:
               tmpUnSetCol[atrKeyName] = instVal
               respCode[a1] = nitro.unsetConfigObjects(objKey, tmpUnSetCol, url, devIp, sesId, self.logger)
        if len(createObjCol) > 0:
            # Add these objects in order in NetScaler
            #self.logger.debug('Creating object from Modify object = %s' % (createObjCol))
            tmpResp = {}
            tmpResp = clusterAudit.createObjectInDevice(createObjCol, url, devIp, sesId, devCfg, self.logger)
            respCode = dict(tmpResp.items() + respCode.items())

        return respCode
#
# This is to handle all the delete cluster object dataset
#
    def processClusterDeleteDataSet(self, delCol, devCfg, url, devIp, sesId):
        """
        This is to handle all the delete state cluster  objects
        """
        self.logger.debug('++++++++++++ process cluster Delete specific DataSet +++++++++++++')
        configOrderCol = {}
        keyVal = None
        instVal = None
        objKey = None
        respCode = {}
	tmpName = None
	orderObjList = []
	tmpObjCol = {}

        #self.logger.debug('++++++++++++ Delete object length = %s' % (len(delCol)))
        # get order list so for config obects
	orderObjList = util.getObjectOrderList(self.logger)  #const.OBJECTLIST
        #self.logger.debug('++++++++++++ Order object length = %s' % (len(orderObjList)))

        # get the array index for each delete objects
        for a1, b1 in delCol.iteritems():
	    tmpTuple_1 = a1
	    tmpName = a1[1]
            #self.logger.debug('++++++++++++ TEMP Name = %s' % (tmpName))
            for k1 in orderObjList:
                if k1.strip().lower() == tmpName.strip().lower():
                    configOrderCol[orderObjList.index(k1)] = tmpTuple_1 # just store the key value such as lbvserver'
                    break
        	#self.logger.debug('++++++++++++ config order  object = %s' % (configOrderCol))
        #self.logger.debug('++++++++++++ config order  object length = %s' % (len(configOrderCol)))
        # now delete the object in descending order
        for k1 in sorted(configOrderCol.iterkeys(), reverse=True):
            objKey = configOrderCol[k1]
            for p1, p2 in delCol.iteritems():
                # match the key values and if they are same then proceed to delete
		#self.logger.debug('+++++++++ Delete Key = %s Value = %s Instance Value = %s' % (objKey, p1[1], p1[2]))
	        tmpTuple_2 = p1[1]
                if tmpTuple_2.strip().lower() == objKey[1].strip().lower():
                    keyVal = tmpTuple_2

                    atrName = util.getObjectKey(tmpTuple_2,self.logger)
                        # get the first element of the tuple
                    atrName = atrName[0]
                    #self.logger.debug('+++++++++ cluster delete Key Attr Name  = %s' % (atrName))
                    instVal = p2[atrName] # util.getParamAttributeValueFromCollection(atrName, p2, self.logger)
                    #self.logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyVal, instVal))
                    if keyVal.strip().lower() == const.SNMPALARM.strip().lower():
                        tmpUnCol = {}
                        for j_1 in p2.keys():
                            if j_1 != keyAtr and j_1 not in ('timeout', 'time'): # 'timeout attributes shouldn't get reset
                                tmpUnCol[j_1] = True
                        tmpUnCol[atrName] = instVal
                        respCode[objName] = nitro.unsetConfigObjects(keyVal, tmpUnCol, url, devIp, sesId, self.logger)
                        continue
 	            elif keyVal.strip().lower() == const.SNMPTRAP:
                         self.logger.debug('+++++++++ Delete SNMP TRAP Key = %s' % (keyVal))
                         trapVal = p2['trapdestination']
                         argStr = 'args=trapdestination:' + trapVal
                         respCode[p1] = nitro.removeNitroObject(keyVal, instVal, argStr, url, devIp, sesId, self.logger)
                         continue
                    else:
                        respCode[p1] = nitro.removeNitroObject(keyVal, instVal, None, url, devIp, sesId, self.logger)

        return respCode
#
# process clusterModify
#
    def processClusterModify_NTP(self, url, device, interface, cnfg, sesId):

        devIp = device[const.HOST]

        """
        This is to process clusterModify NTP config
        """
        respCol = {}
        self.logger.debug('+++++++ Processing cluster-NTP-Modify for the device = %s' % (devIp))
        for a1, b1 in cnfg.iteritems():
            #if a1[1] == const.NTP_SERVER or a1[1] == const.NTP_PARAM:
            if a1[1] == const.NTP_SERVER:
                tmpState = None
                tmpVal = None
                rootState = None
                modObjCol = {}
                #self.logger.debug('++++++++ root level values  a1 = %s b1 = %s' % (a1,b1))
                for a2, b2 in b1.iteritems():
                    #self.logger.debug('+++++ Values from the colle a2 = %s b2 = %s' % (a2,b2))
                    if a2 == const.STATE:
                        tmpState = b2
                    elif a2 == const.VALUE:
                        tmpVal = b2

                ntpAdCol = {}
                ntpDelCol = {}
                if a1[1] == const.NTP_SERVER:
                    ntpCol = {}
                    for i3, j3 in tmpVal.iteritems():
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                # ntpserver keys
                                ntpCol[i3[1]] = j4

                    if tmpState == const.CREATE and len(ntpCol) > 0:
                        tmpCol = {}
                        tmpCol[a1] = nitro.createConfigObjects(const.NTP_SERVER, ntpCol, url, device[const.HOST], sesId, self.logger)
                        respCol = dict(respCol.items() + tmpCol.items())
                    elif tmpState == const.DELETE and len(ntpCol) > 0:
                        tmpCol = {}
                        tmpCol[a1] = self.removeNTPConfigFromDevice(ntpCol, url, devIp, sesId)
                        respCol = dict(respCol.items() + tmpCol.items())
                    elif tmpState == const.MODIFY:
                        for a3, b3 in tmpVal.iteritems():
                            #self.logger.debug('+++ a3 = %s, b3 = %s ' % (a3,b3))
                            for a4, b4 in b3.iteritems():
                                if a4 == const.STATE:
                                    atrState = b4
                                elif a4 == const.VALUE:
                                    atrVal = b4
                                    #self.logger.debug('+++ a4 = %s, b4 = %s ' % (atrState,atrVal))
                            if atrState == const.MODIFY:
                                modObjCol[a3[1]]= atrVal
                        # below if shud be at a3 loop level
                        if len(ntpCol) > 0 and len(modObjCol) > 0:
                            modObjCol['servername'] = ntpCol.get('servername')
                            modObjCol['serverip'] = ntpCol.get('serverip')
                            tmpCol = {}
                            tmpCol[a1] = nitro.setConfigObjects(const.NTP_SERVER, modObjCol, url, device[const.HOST], sesId, self.logger)
                            respCol = dict(respCol.items() + tmpCol.items())

                # if a1[1] == const.NTP_PARAM:
                #     ntpCol = {}
                #     ntpCol = util.getObjColFromDevModCnfg(cnfg, const.NTP_PARAM, self.logger)
                #     if tmpState == const.CREATE and len(ntpCol) > 0:
                #         tmpCol = {}
                #         tmpCol[a1] = nitro.setConfigObjects(const.NTP_PARAM, modObjCol, url, device[const.HOST], sesId, self.logger)
                #         respCol = dict(respCol.items() + tmpCol.items())
                #     elif tmpState == const.DELETE and len(ntpCol) > 0:
                #         raise Exception('Cluster ntpparam can\'t be deleted, please use modify.......')
                #     elif tmpState == const.MODIFY:
                #         for a3, b3 in tmpVal.iteritems():
                #             #self.logger.debug('+++ a3 = %s, b3 = %s ' % (a3,b3))
                #             for a4, b4 in b3.iteritems():
                #                 if a4 == const.STATE:
                #                     atrState = b4
                #                 elif a4 == const.VALUE:
                #                     atrVal = b4
                #                     #self.logger.debug('+++ a4 = %s, b4 = %s ' % (atrState,atrVal))
                #             if atrState == const.MODIFY:
                #                 modObjCol[a3[1]]= atrVal
                #         tmpCol = {}
                #         tmpCol[a1] = nitro.setConfigObjects(const.NTP_PARAM, modObjCol, url, device[const.HOST], sesId, self.logger)
                #         respCol = dict(respCol.items() + tmpCol.items())

        self.logger.debug('+++ cluster-NTP-modify Response = %s' % (respCol))

        return respCol


#
# process deviceModify
#
    def processDeviceModify(self, url, devIp, virtualFlag, interface, cnfg, sesId):
        """
        This is to process deviceModify call
        """
        respCol = {}
        self.logger.debug('+++++++ processing deviceModify for the device = %s' % (devIp))
        for a1, b1 in cnfg.iteritems():
            tmpState = None
            tmpVal = None
            rootState = None
            #self.logger.debug('++++++++ root level values  a1 = %s b1 = %s' % (a1,b1))
            for a2, b2 in b1.iteritems():
                if a2 == const.STATE:
                    tmpState = b2
                elif a2 == const.VALUE:
                    tmpVal = b2
                #self.logger.debug('+++++ Values from the colle a2 = %s b2 = %s' % (a2,b2))
                # raise exception if the state is MODIFY
                if tmpState == const.MODIFY:
                    raise Exception('Device Level config e.g. HighAvailability & Peer configuration can not be modified, please remove and add.......')
                haAdCol = {}
                haDelCol = {}
                if a1[1] == const.HIGHAVAILABILITY:
                    haCol = {}
                    haCol = util.getObjColFromDevModCnfg(cnfg, const.HIGHAVAILABILITY, self.logger)
                    if tmpState == const.CREATE and len(haCol) > 0:
                        respCol[a1] = self.createHighAvailabilityConfig(haCol, url, devIp, virtualFlag, sesId)
                    elif tmpState == const.DELETE and len(haCol) > 0:
                        respCol[a1] = self.removeHighAvailabilityConfigFromDevice(haCol, url, devIp, sesId)
                elif a1[1] == const.HAPEER:
                    peerCol = {}
                    peerCol = util.getObjColFromDevModCnfg(cnfg, const.HAPEER, self.logger)
                    if tmpState == const.CREATE and len(peerCol) > 0:
                        respCol[const.HAPEER] = nitro.createConfigObjects(const.HANODE, peerCol, url, devIp, sesId, self.logger)
                    elif tmpState == const.DELETE and len(peerCol) > 0:
                        respCol[const.HAPEER] = self.removeHAPeerFromDevice(url, devIp, sesId)

        self.logger.debug('+++ device Modify response  = %s' % (respCol))

        return respCol
#
# get interface modify state
#
    def getAuditFlagBasedOnInterface(self, deviceObj, devCfg, url, devIp, virtualFlag, sesId, deviceAuditFlag=False):
        """
        This is to handle especial interface modify state
        """
        createObjCol = {}
        respCode = {}
        configOrderCol = {}
        # first get the cluster node from config
        nodeCol = util.getClusterColFromConfig(deviceObj, self.logger)
        # for each node get the ip and credential
        for m1, n1 in nodeCol.iteritems():
            vifObjCol = {}
            vifNum = None
            nodeName = m1
            nodeHostVal = None
            nodePortVal = 0
            nodeCredCol = {}
            nodeUrl = None
            for m2, n2 in n1.iteritems():
                if m2.strip().lower() == const.HOST:
                    nodeHostVal = n2
                elif m2.strip().lower() == const.PORT:
                    nodePortVal = n2
                elif m2.strip().lower() == const.CREDS:
                    nodeCredCol = n2
            # get the Node URL
            nodeUrl = util.getURL(nodePortVal, nodeHostVal, self.logger)
            # get loginObj to create the sesId
            loginObj = util.getLoginObj(nodeUrl, nodeHostVal, nodeCredCol, self.logger)
            nodeSesId = loginObj.login()
            # create the VLANs
            tagCol = {}
            tmpCode = {}
            #tagCol = util.getAddModStateVLANFromConfig(devCfg, self.logger, deviceAuditFlag)
            #tmpCode = self.createTags(tagCol, nodeUrl, nodeHostVal, nodeSesId)
            #respCode = dict(tmpCode.items() + respCode.items())
            modAuditFlag = False
            # first get modify state interface for node
            vifObjCol = util.getNodeVIFsFromConfigForState(const.MODIFY, nodeName, devCfg, self.logger, deviceAuditFlag)
            if len(vifObjCol) > 0:
                modAuditFlag = True
            #self.logger.debug('++++++++ VIFs for nodeName = %s, VIFs = %s' % (nodeName, vifObjCol))
            for r1, s1 in vifObjCol.iteritems():
                encapCol = {}
                # here s1 is the dict of type VIFs such as {'ADC1': '1_1'}
                vifNum = s1[nodeName]
                vifNum = vifNum.replace('_', '/')
                # here r1 is object name
                encapCol = util.getVIFEncapassFromConfigNState(r1[1], devCfg, self.logger, deviceAuditFlag)
                #self.logger.debug('++++++++ ENCAP collection for VIF object = %s, encapass collection = %s' % (r1[1], encapCol))
                for r2, s2 in encapCol.iteritems():
                    encapState = None
	            keyTuple = r2
		    encapVal = s2
                    encapState = keyTuple[1]  # key is this form ((8, '', 'ADCCluster1_inside_2719744_32771'), 0)

                    # now get the IFC tags based on the encap object name
                    tagCol = {}

                    tagCol = util.getEncapTagNStateFromConfig(encapVal, devCfg, self.logger, deviceAuditFlag)
                    for r3, s3 in tagCol.iteritems():
                        tagState = None
                        tagState = r3[3] # tag key is in this form - (((0, '', 5104), (7, '', '2719744_32771')), '2719744_32771', 1, 0)
                        #self.logger.debug('++++ Interface state check values encap State = %s, tagState = %s' %(encapState, tagState))
                        if encapState == const.NOCHANGE and tagState == const.NOCHANGE:
                            continue
                        else:
                            modAuditFlag = False
                            #self.logger.debug('++++ Genuine Modify Interface value = %s encap State = %s, tagState = %s' %(vifNum, encapState, tagState))
                            loginObj.logout(nodeSesId)
                            break
                    else:
                        continue
                    break
                else:
                    continue
                break
            else:
                if modAuditFlag is True:
                    self.logger.debug('++++ Return Audit state since only interface state is in MODIFY++++++++++')
                    loginObj.logout(nodeSesId) # this is to logout from the Node
                    return const.AUDIT
            break
        # this to check if there were interface in modify state however none of the encapAssociation were either in Create or Modify state
        # this change was due to interface in modify state however the same interface was used for multiple tags
        # and if there multiple tags and its association only one of them will have different state rest all will be in NOCHANGE
        # if execution reached here and modAuditFlag is true it means only interface state is in modify state and none of encapassociation
        # and tags are in either create or modify state

        # if execution reaches here then return None
        return None

#
# process OSPF interface configuration
#
    def processOSPFInterface(self, child, url, deviceObj, devCfg, deviceAudit=False):
        """
        This is to handle all the OSPF interface configuration
        """
        createObjCol = {}
        respCode = {}
        configOrderCol = {}
        cmdDict = dict(const.OSPFINTFCMDAPICTOCLILIST)
        state = const.NOCHANGE
        encapAssoState = const.NOCHANGE
        cmdList = []
        cmdRouterList = []
        ipv4 = False
        ipv6 = False
        ospfIntfConfig = False
        errStr = ''
        self.logger.debug('++++++++ processOSPFInterface')
        for r1, s1 in devCfg.iteritems():
            for r2, s2 in s1.iteritems():
                if r2 == const.VALUE:
                    for r3, s3 in s2.iteritems():
                        if r3[0] == const.VENCAPASS:
                           if const.ENCAP in s3:
                               encapVal = s3[const.ENCAP]
                               encapAssoState = s3[const.STATE]
                               tagTuple = (const.IFCTAG, '', encapVal)
                               vlanValTemp = None
                               vlanVal = None
                               if tagTuple in s2:
                                   vlanValTemp = s2[tagTuple]
                                   vlanVal = vlanValTemp[const.TAG]
                               keyTuple = (r1,r3)
                               cmdList = []
                               cmdRouterList = []
                               cmdMd5List = []
                               ospfIntfConfig = False
                               if const.OSPFINTERFACE in s3:
                                   # now get the IFC tags based on the encap object name
                                   ipv4 = False
                                   ipv6 = False
                                   authType = ''
                                   authKey = ''
                                   authKeyId = 0
                                   cmdMd5Str = ''
                                   cmdMd5List = []
                                   cmdList = []
                                   cmdRouterList = []
                                   s3OspfInt = s3[const.OSPFINTERFACE]
                                   for r4, s4 in s3OspfInt.iteritems():
                                       keyTuple = (r1,r3,r4)
                                       cmdList = []
                                       cmdRouterList = []
                                       cmdMd5List = []
                                       for r5, s5 in s4.iteritems():
                                            if r5.strip().lower() == const.STATE:
                                                state = s5
                                            elif r5.strip().lower() == str.lower(const.OSPFADDRFAMILY):
                                                if "ipv4" in s5:
                                                    ipv4 = True
                                                if "ipv6" in s5:
                                                    ipv6 = True
                                            elif r5.strip().lower() == str.lower(const.OSPFINTFAUTHTYPE):
                                                ospfIntfConfig = True
                                                if s5.strip().lower() == str.lower(const.OSPFINTFAUTHTYPENONE):
                                                    cmdVal = 'null'
                                                elif s5.strip().lower() == str.lower(const.OSPFINTFAUTHTYPEMD5):
                                                    cmdVal = 'message-digest'
                                                elif s5.strip().lower() == str.lower(const.OSPFINTFAUTHTYPEPLAIN):
                                                    cmdVal = 'plain'
                                                authType = cmdVal
                                            elif r5.strip().lower() == str.lower(const.OSPFINTFAUTHKEY):
                                                authKey = s5
                                            elif r5.strip().lower() == str.lower(const.OSPFINTFAUTHKEYID):
                                                authKeyId = s5
                                            elif r5.strip().lower() == str.lower(const.OSPFINTFMD5KEY):
                                                for md5key in s5:
                                                    cmdMd5Str = cmdDict[const.OSPFINTFAUTHKEYID] + " " + str(md5key['md5KeyId']) + " md5 " + md5key['md5Password']
                                                    cmdMd5List.append(cmdMd5Str)
                                            else:
                                                cmdVal = s5
                                                try:
                                                    cmdName = cmdDict[r5.strip()]
                                                except KeyError:
                                                    cmdName = None
                                                if ((cmdName is not None) and str(cmdVal)):
                                                    tmpStr = cmdName + " " + str(cmdVal)
                                                    if r5.strip().lower() in const.OSPFINTFROUTERCMDLIST:
                                                        tmpStr = tmpStr + " tag 1"
                                                        cmdRouterList.append(tmpStr)
                                                    else:
                                                        cmdList.append(tmpStr)

                                       #self.logger.debug('++++++++ OSPF INTERFACE r5 = %s, s5 = %s, cmdVal=%s' % (r5, s5, cmdVal))
                                       if authType == 'null':
                                           cmdName = cmdDict[const.OSPFINTFAUTHTYPE]
                                           tmpStr = cmdName + " " + authType
                                           cmdList.append(tmpStr)
                                       elif authType == 'message-digest':
                                           cmdName = cmdDict[const.OSPFINTFAUTHTYPE]
                                           tmpStr = cmdName + " " + authType
                                           cmdList.append(tmpStr)
                                           cmdList= cmdList + cmdMd5List
                                       elif authType == 'plain':
                                           cmdName = cmdDict[const.OSPFINTFAUTHTYPE]
                                           tmpStr = cmdName
                                           cmdList.append(tmpStr)
                                           tmpStr = cmdDict[const.OSPFINTFAUTHKEY]+ " " + str(authKey)
                                           cmdList.append(tmpStr)
                               retCol = {}
                               resp = {}
                               respObj = {}
                               if deviceAudit == True:
                               # in service audit, if ospf interface is not in the current encap vlan association, we will go ahead and delete already existing ospf interface configuraiton
                               # in service audit, if ospf interface is in the current encap vlan association, we will go ahead and apply it to the device
                                   if ospfIntfConfig == False:
                                       if const.DefaultPartition == True:
                                           if rhconf.zebosCheckOSPFIntfNitro(child, url, vlanVal, self.logger):
                                               errStr = rhconf.zebosSendOSPFIntfCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlanVal, self.logger, const.DELETE)
                                       else:
                                           if rhconf.zebosCheckOSPFIntf(child, vlanVal, self.logger):
                                               errStr = rhconf.zebosSendOSPFIntfCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlanVal, self.logger, const.DELETE)
                                   else:
                                       errStr = rhconf.zebosSendOSPFIntfCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlanVal, self.logger, const.CREATE)
                               else:
                                   # In service Modify, if ospfvifcfg state is NOT NOCHANGE(0), we will take osopf vif cfg state to do add/mod/delete
                                   # In service Modify, if ospfvifcfg state is NOCHANGE(0), we will take encapAssoState to do add/mod/delete
                                   if ospfIntfConfig == True:
                                       if state != const.NOCHANGE:
                                           errStr = rhconf.zebosSendOSPFIntfCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlanVal, self.logger, state)
                                       else:
                                           errStr = rhconf.zebosSendOSPFIntfCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlanVal, self.logger, encapAssoState)
                               if const.DefaultPartition == True:
                                   resp[keyTuple] = errStr
                                   respCode = dict(resp.items() + respCode.items())         
                               elif errStr != '':
                                   retCol[const.ERRORCODE] = 1001
                                   retCol[const.MESSAGE] = errStr
                                   retCol[const.STATE] = const.PERMANENT
                                   retCol[const.SEVERITY] = "ERROR"
                                   respObj['ospf_interface'] = retCol
                                   resp[keyTuple] = respObj
                                   respCode = dict(resp.items() + respCode.items())
        self.logger.debug('++++++++ processOSPFInterface respCode = %s' %(respCode))
        return respCode

#
# process OSPF process configuration
#
    def processOSPFProcess(self, child, url, devCfg, deviceAudit=False):
        respCode = {}
        allProcess = []
        noDelProcess = []
        errStr = ''
        retCol = {}
        resp = {}
        respObj = {}
        keyTuple = ()

        if deviceAudit == True:
             errStr = rhconf.zebosDeletOspfProcess(child, url, self.logger)

        for r1, s1 in devCfg.iteritems():
             keyTuple = r1

        for r1, s1 in devCfg.iteritems():
            for r2, s2 in s1.iteritems():
                if r2 == const.VALUE:
                    for r3, s3 in s2.iteritems():
                        processId = None
                        areaID = None
                        areaType = None
                        areaCtrl = None
                        rtrID = None
                        redistribute = None
                        state = None
                        ipv4_contexts = None
                        ipv6_contexts = None
                        cmdList = []
                        cmdListV6 = []
                        cmdListClear = []
                        retCol = {}
                        resp = {}
                        respObj = {}
                        if r3[0] == const.OSPFDEV:
                            keyTuple = (r1, r3)
                            #self.logger.debug('++++++++ r3=%s s3 = %s' %(r3, s3))
                            for r4, s4 in s3.iteritems():
                                #self.logger.debug('++++++++ r4=%s s4 = %s' %(r4, s4))
                                if r4.strip().lower() == const.OSPF_PROCESS_ID:
                                    processId = s4
                                if r4.strip().lower() == const.OSPF_AREA_ID:
                                    areaID = s4
                                if r4.strip().lower() == const.OSPF_AREA_TYPE:
                                    areaType = s4.strip().lower()
                                if r4.strip().lower() == const.OSPF_AREA_CTRL:
                                    areaCtrl = s4
                                if r4.strip().lower() == const.OSPF_RTR_ID:
                                    rtrID = s4
                                if r4.strip().lower() == const.OSPF_REDISTRI:
                                    redistribute = s4
                                if r4.strip().lower() == const.STATE:
                                    state = s4
                                if r4.strip().lower() == const.OSPF_CONTEXT:
                                    for r5, s5 in s4.iteritems():
                                        if r5.strip().lower() == 'ipv4':
                                            for r6, s6 in s5.iteritems():
                                                if r6.strip().lower() == 'networks':
                                                    ipv4_contexts = s6
                                        if r5.strip().lower() == 'ipv6':
                                            for r6, s6 in s5.iteritems():
                                                if r6.strip().lower() == 'networks':
                                                    ipv6_contexts = s6
                            if processId != None :
                                if processId == 0:
                                    tempstr = "router ospf"
                                    tempstrv6 = "router ipv6 ospf"
                                else:
                                    tempstr = "router ospf " + str(processId)
                                    tempstrv6 = "router ipv6 ospf " + str(processId)
                                if processId not in allProcess:
                                    allProcess.append(processId)
                                if state != const.DELETE:
                                    if processId not in noDelProcess:
                                        noDelProcess.append(processId)
                            else :
                                tempstr = "router ospf 1"
                                tempstrv6 = "router ipv6 ospf 1"
                                if 1 not in allProcess:
                                    allProcess.append(1)
                                if state != const.DELETE:
                                    if 1 not in noDelProcess:
                                        noDelProcess.append(1)

                            cmdList.append(tempstr)
                            cmdListClear.append(tempstrv6)
                            cmdListV6.append(tempstrv6)
                            self.logger.debug('++++++++ cmdList=%s ' %(cmdList))
                            self.logger.debug('++++++++ cmdListV6=%s ' %(cmdListV6))
                            if rtrID != None:
                                tempstr = "no ospf router-id"
                                cmdList.append(tempstr)
                                tempstr = "ospf router-id  " + rtrID
                                cmdList.append(tempstr)
                                tempstrv6 = "no router-id"
                                cmdListClear.append(tempstrv6)
                                tempstrv6 = "router-id  " + rtrID
                                cmdListV6.append(tempstrv6)
                                rtrIDConfig = True
                            if redistribute != None:
                                tempstr = "no redistribute connected"
                                cmdList.append(tempstr)
                                cmdListV6.append(tempstr)
                                tempstr = "no redistribute ospf"
                                cmdList.append(tempstr)
                                cmdListV6.append(tempstr)
                                tempstr = "no redistribute static"
                                cmdList.append(tempstr)
                                cmdListV6.append(tempstr)
                                tempstr = "no redistribute bgp"
                                cmdList.append(tempstr)
                                cmdListV6.append(tempstr)
                                tempstr = "redistribute kernel"
                                cmdList.append(tempstr)
                                cmdListV6.append(tempstr)
                                if 'bgp' in redistribute:
                                    tempstr = "redistribute bgp"
                                    cmdList.append(tempstr)
                                    cmdListV6.append(tempstr)
                                if 'connected' in redistribute:
                                    tempstr = "redistribute connected"
                                    cmdList.append(tempstr)
                                    cmdListV6.append(tempstr)
                                if 'ospf' in redistribute:
                                    tempstr = "redistribute ospf"
                                    cmdList.append(tempstr)
                                    cmdListV6.append(tempstr)
                                if 'static' in redistribute:
                                    tempstr = "redistribute static"
                                    cmdList.append(tempstr)
                                    cmdListV6.append(tempstr)
                            if areaID != None:
                                # nssa configuration
                                if areaType == 'nssa':
                                    tempstr = "area " + str(areaID) + " nssa"
                                    if areaCtrl != None:
                                        if 'no-redistribute' in areaCtrl:
                                            tempstr = tempstr + " no-redistribution"
                                        if 'no-summary' in areaCtrl:
                                            tempstr = tempstr + " no-summary"
                                    cmdList.append(tempstr)
                                # stub configuration
                                elif areaType == 'stub':
                                    tempstr = "area " + str(areaID) + " stub"
                                    if areaCtrl != None:
                                        if 'no-summary' in areaCtrl:
                                            tempstr = tempstr + " no-summary"
                                    cmdList.append(tempstr)
                                    cmdListV6.append(tempstr)
                            if ipv4_contexts != None:
                                for ipv4_context_single in ipv4_contexts:
                                    if deviceAudit == True:
                                        tempstr = "network " + ipv4_context_single['ipaddress'] + "/" + str(ipv4_context_single['netmask']) + " area " + str(ipv4_context_single['area'])
                                    elif ipv4_context_single[const.STATE] == const.DELETE :
                                        tempstr = "no network " + ipv4_context_single['ipaddress'] + "/" + str(ipv4_context_single['netmask']) + " area " + str(ipv4_context_single['area'])
                                    else :
                                        tempstr = "network " + ipv4_context_single['ipaddress'] + "/" + str(ipv4_context_single['netmask']) + " area " + str(ipv4_context_single['area'])
                                    cmdList.append(tempstr)
                            if ipv6_contexts != None:
                                for ipv6_context_single in ipv6_contexts:
                                    if deviceAudit == True:
                                        tempstr = "area " + str(ipv6_context_single['area']) + " range " + ipv6_context_single['ipaddress'] + "/" + str(ipv6_context_single['netmask'])
                                    elif ipv6_context_single[const.STATE] == const.DELETE :
                                        tempstr = "no area " + str(ipv6_context_single['area']) + " range " + ipv6_context_single['ipaddress'] + "/" + str(ipv6_context_single['netmask'])
                                    else :
                                        tempstr = "area " + str(ipv6_context_single['area']) + " range " + ipv6_context_single['ipaddress'] + "/" + str(ipv6_context_single['netmask'])
                                    cmdListV6.append(tempstr)
                            if deviceAudit == True:
                                errStr = rhconf.zebosSendOSPFProcessCmd(child, url, cmdList, self.logger, const.CREATE)
                                if const.DefaultPartition == True:
                                    errStr1 = rhconf.zebosSendOSPFProcessCmd(child, url, cmdListV6, self.logger, const.CREATE)
                            else:
                                errStr = rhconf.zebosSendOSPFProcessCmd(child, url, cmdList, self.logger, state)
                                if const.DefaultPartition == True:
                                    if rtrIDConfig == True:
                                        errStr2 = rhconf.zebosSendOSPFProcessCmd(child, url, cmdListClear, self.logger, state)
                                    errStr1 = rhconf.zebosSendOSPFProcessCmd(child, url, cmdListV6, self.logger, state)
                            if const.DefaultPartition == True:
                                resp[keyTuple] = errStr
                                respCode = dict(resp.items() + respCode.items())
                                resp[keyTuple] = errStr1
                                respCode = dict(resp.items() + respCode.items())
                            elif errStr != '':
                                retCol[const.ERRORCODE] = 1001
                                retCol[const.MESSAGE] = errStr
                                retCol[const.STATE] = const.PERMANENT
                                retCol[const.SEVERITY] = "ERROR"
                                respObj['ospf_process'] = retCol
                                resp[keyTuple] = respObj
                                respCode = dict(resp.items() + respCode.items())
        #Now Let's check if the process needs to be deleted
        if deviceAudit != True:
            for processId in allProcess:
                if processId not in noDelProcess:
                    errStr =  rhconf.zebosDeletOspfProcessID(child, url, processId, self.logger)
        if const.DefaultPartition == True:
            resp[keyTuple] = errStr
            respCode = dict(resp.items() + respCode.items())
        elif errStr != '':
            retCol[const.ERRORCODE] = 1001
            retCol[const.MESSAGE] = errStr
            retCol[const.STATE] = const.PERMANENT
            retCol[const.SEVERITY] = "ERROR"
            respObj['ospf_process'] = retCol
            resp[keyTuple] = respObj
            respCode = dict(resp.items() + respCode.items())
        self.logger.debug('++++++++ processOSPFProcess respCode = %s' %(respCode))

        return respCode

#
# process BGP process configuration
#
    def processBGP(self, child, url, devCfg, deviceAudit=False):
        respCode = {}
        errStr = ''
        retCol = {}
        resp = {}
        respObj = {}
        keyTuple = ()

        for r1, s1 in devCfg.iteritems():
             keyTuple = r1


        if deviceAudit == True:
            errStr = rhconf.zebosDeletBGP(child, url, self.logger)

        for r1, s1 in devCfg.iteritems():
            for r2, s2 in s1.iteritems():
                if r2 == const.VALUE:
                    for r3, s3 in s2.iteritems():
                        localAs = None
                        timers = None
                        rtrID = None
                        ipv4_networks = None
                        ipv4_neighbor = None
                        ipv4_redis = None
                        ipv6_networks = None
                        ipv6_redis = None
                        ipv6_neighbor = None
                        state = None
                        cmdList = []
                        retCol = {}
                        resp = {}
                        respObj = {}
                        if r3[0] == const.BGPDEV:
                            keyTuple = (r1, r3)
                            #self.logger.debug('++++++++ r3=%s s3 = %s' %(r3, s3))
                            for r4, s4 in s3.iteritems():
                                #self.logger.debug('++++++++ r4=%s s4 = %s' %(r4, s4))
                                if r4.strip().lower() == const.BGP_LOCAL_AS.strip().lower():
                                    localAs = s4
                                if r4.strip().lower() == const.BGP_TIMERS.strip().lower():
                                    timers = s4
                                if r4.strip().lower() == const.BGP_RTR_ID.strip().lower():
                                    rtrID = s4
                                if r4.strip().lower() == const.STATE.strip().lower():
                                    state = s4
                                if r4.strip().lower() == const.BGP_CONTEXT.strip().lower():
                                    for r5, s5 in s4.iteritems():
                                        if r5.strip().lower() == const.BGP_CONTEXT_IPV4:
                                            for r6, s6 in s5.iteritems():
                                                if r6.strip().lower() == const.BGP_CONTEXT_IP_NETWORKS:
                                                    ipv4_networks = s6
                                                if r6.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR:
                                                    ipv4_neighbor = s6
                                                if r6.strip().lower() == const.BGP_CONTEXT_IP_REDIS:
                                                    ipv4_redis = s6
                                        if r5.strip().lower() == const.BGP_CONTEXT_IPV6:
                                            for r6, s6 in s5.iteritems():
                                                if r6.strip().lower() == const.BGP_CONTEXT_IP_NETWORKS:
                                                    ipv6_networks = s6
                                                if r6.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR:
                                                    ipv6_neighbor = s6
                                                if r6.strip().lower() == const.BGP_CONTEXT_IP_REDIS:
                                                    ipv6_redis = s6
                            if localAs != None :
                                tempstr = "router bgp " + str(localAs)
                            else :
                                tempstr = "router bgp 1"

                            cmdList.append(tempstr)
                            self.logger.debug('++++++++ cmdList=%s ' %(cmdList))
                            if timers != None:
                                if const.BGP_TIMERS_KEEPALIVE in timers:
                                    keepalive = timers[const.BGP_TIMERS_KEEPALIVE]
                                else :
                                    keepalive = const.BGP_TIMERS_KEEPALIVE_DEFAULT
                                if const.BGP_TIMERS_HOLD in timers:
                                    hold = timers[const.BGP_TIMERS_HOLD]
                                else :
                                    hold = const.BGP_TIMERS_HOLD_DEFAULT
                                tempstr = "timers bgp " + str(keepalive) + " " + str(hold)
                                cmdList.append(tempstr)
                            if rtrID != None:
                                tempstr = "bgp router-id  " + rtrID
                                cmdList.append(tempstr)
                            if ipv4_networks != None:
                                for ipv4_networks_single in ipv4_networks:
                                    if deviceAudit == True:
                                        tempstr = "network " + ipv4_networks_single['ipaddress'] + "/" + str(ipv4_networks_single['netmask'])
                                    elif ipv4_networks_single[const.STATE] == const.DELETE :
                                        tempstr = "no network " + ipv4_networks_single['ipaddress'] + "/" + str(ipv4_networks_single['netmask'])
                                    else :
                                        tempstr = "network " + ipv4_networks_single['ipaddress'] + "/" + str(ipv4_networks_single['netmask'])
                                    cmdList.append(tempstr)
                            if ipv4_neighbor != None:
                                for ipv4_neighbor_ip, ipv4_neighbor_config in ipv4_neighbor.iteritems():
                                    remoteAs = None
                                    admin = None
                                    ipv4_neighbor_state = None
                                    for ipv4_neighbor_config_name, ipv4_neighbor_config_val in ipv4_neighbor_config.iteritems():
                                        if ipv4_neighbor_config_name.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR_REMOTE_AS.strip().lower():
                                            remoteAs = ipv4_neighbor_config_val
                                        if ipv4_neighbor_config_name.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR_ADMIN_STATUS.strip().lower():
                                            admin = ipv4_neighbor_config_val
                                        if ipv4_neighbor_config_name.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR_STATE.strip().lower():
                                            ipv4_neighbor_state = ipv4_neighbor_config_val
                                    if deviceAudit == True:
                                        if remoteAs != None:
                                            tempstr = "neighbor " + ipv4_neighbor_ip + " remote-as " + str(remoteAs)
                                            cmdList.append(tempstr)
                                        if admin != None:
                                            if admin.strip().lower() == const.ENABLED:
                                                tempstr = "neighbor " + ipv4_neighbor_ip + " activate"
                                            else:
                                                tempstr = "no neighbor " + ipv4_neighbor_ip + " activate"
                                            cmdList.append(tempstr)
                                    elif ipv4_neighbor_state == const.DELETE :
                                        tempstr = "no neighbor " + ipv4_neighbor_ip
                                        cmdList.append(tempstr)
                                    else :
                                        if remoteAs != None:
                                            tempstr = "neighbor " + ipv4_neighbor_ip + " remote-as " + str(remoteAs)
                                            cmdList.append(tempstr)
                                        if admin != None:
                                            if admin.strip().lower() == const.ENABLED:
                                                tempstr = "neighbor " + ipv4_neighbor_ip + " activate"
                                            else:
                                                tempstr = "no neighbor " + ipv4_neighbor_ip + " activate"
                                            cmdList.append(tempstr)
                            if ipv4_redis != None:
                                tempstr = "no redistribute connected"
                                cmdList.append(tempstr)
                                tempstr = "no redistribute ospf"
                                cmdList.append(tempstr)
                                tempstr = "no redistribute static"
                                cmdList.append(tempstr)
                                tempstr = "redistribute kernel"
                                cmdList.append(tempstr)
                                if 'connected' in ipv4_redis:
                                    tempstr = "redistribute connected"
                                    cmdList.append(tempstr)
                                if 'ospf' in ipv4_redis:
                                    tempstr = "redistribute ospf"
                                    cmdList.append(tempstr)
                                if 'static' in ipv4_redis:
                                    tempstr = "redistribute static"
                                    cmdList.append(tempstr)
                            if ipv6_networks != None:
                                tempstr = "address-family ipv6"
                                cmdList.append(tempstr)
                                for ipv6_networks_single in ipv6_networks:
                                    if deviceAudit == True:
                                        tempstr = "network " + ipv6_networks_single['ipaddress'] + "/" + str(ipv6_networks_single['netmask'])
                                    elif ipv6_networks_single[const.STATE] == const.DELETE :
                                        tempstr = "no network " + ipv6_networks_single['ipaddress'] + "/" + str(ipv6_networks_single['netmask'])
                                    else :
                                        tempstr = "network " + ipv6_networks_single['ipaddress'] + "/" + str(ipv6_networks_single['netmask'])
                                    cmdList.append(tempstr)
                                tempstr = "exit-address-family"
                                cmdList.append(tempstr)
                            if ipv6_neighbor != None:
                                for ipv6_neighbor_ip, ipv6_neighbor_config in ipv6_neighbor.iteritems():
                                    remoteAs = None
                                    admin = None
                                    ipv6_neighbor_state = None
                                    for ipv6_neighbor_config_name, ipv6_neighbor_config_val in ipv6_neighbor_config.iteritems():
                                        if ipv6_neighbor_config_name.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR_REMOTE_AS.strip().lower():
                                            remoteAs = ipv6_neighbor_config_val
                                        if ipv6_neighbor_config_name.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR_ADMIN_STATUS.strip().lower():
                                            admin = ipv6_neighbor_config_val
                                        if ipv6_neighbor_config_name.strip().lower() == const.BGP_CONTEXT_IP_NEIGHBOR_STATE.strip().lower():
                                            ipv6_neighbor_state = ipv6_neighbor_config_val
                                    if deviceAudit == True:
                                        if remoteAs != None:
                                            tempstr = "neighbor " + ipv6_neighbor_ip + " remote-as " + str(remoteAs)
                                            cmdList.append(tempstr)
                                        if admin != None:
                                            tempstr = "address-family ipv6"
                                            cmdList.append(tempstr)
                                            if admin.strip().lower() == const.ENABLED:
                                                tempstr = "neighbor " + ipv6_neighbor_ip + " activate"
                                            else:
                                                tempstr = "no neighbor " + ipv6_neighbor_ip + " activate"
                                            cmdList.append(tempstr)
                                            tempstr = "exit-address-family"
                                            cmdList.append(tempstr)
                                    elif ipv6_neighbor_state == const.DELETE :
                                        tempstr = "no neighbor " + ipv6_neighbor_ip
                                        cmdList.append(tempstr)
                                    else :
                                        if remoteAs != None:
                                            tempstr = "neighbor " + ipv6_neighbor_ip + " remote-as " + str(remoteAs)
                                            cmdList.append(tempstr)
                                        if admin != None:
                                            tempstr = "address-family ipv6"
                                            cmdList.append(tempstr)
                                            if admin.strip().lower() == const.ENABLED:
                                                tempstr = "neighbor " + ipv6_neighbor_ip + " activate"
                                            else:
                                                tempstr = "no neighbor " + ipv6_neighbor_ip + " activate"
                                            cmdList.append(tempstr)
                                            tempstr = "exit-address-family"
                                            cmdList.append(tempstr)
                            if ipv6_redis != None:
                                tempstr = "address-family ipv6"
                                cmdList.append(tempstr)
                                tempstr = "no redistribute connected"
                                cmdList.append(tempstr)
                                tempstr = "no redistribute ospf"
                                cmdList.append(tempstr)
                                tempstr = "no redistribute static"
                                cmdList.append(tempstr)
                                tempstr = "redistribute kernel"
                                cmdList.append(tempstr)
                                if 'connected' in ipv6_redis:
                                    tempstr = "redistribute connected"
                                    cmdList.append(tempstr)
                                if 'ospf' in ipv6_redis:
                                    tempstr = "redistribute ospf"
                                    cmdList.append(tempstr)
                                if 'static' in ipv6_redis:
                                    tempstr = "redistribute static"
                                    cmdList.append(tempstr)
                                tempstr = "exit-address-family"
                                cmdList.append(tempstr)
                            if deviceAudit == True:
                                errStr = rhconf.zebosSendBGPProcessCmd(child, url, cmdList, self.logger, const.CREATE)
                            else:
                                errStr = rhconf.zebosSendBGPProcessCmd(child, url, cmdList, self.logger, state)
                            if const.DefaultPartition == True:
                                resp[keyTuple] = errStr
                                respCode = dict(resp.items() + respCode.items())
                            elif errStr != '':
                                retCol[const.ERRORCODE] = 1001
                                retCol[const.MESSAGE] = errStr
                                retCol[const.STATE] = const.PERMANENT
                                retCol[const.SEVERITY] = "ERROR"
                                respObj['bgp_process'] = retCol
                                resp[keyTuple] = respObj
                                respCode = dict(resp.items() + respCode.items())
        self.logger.debug('++++++++ processBGPProcess respCode = %s' %(respCode))

        return respCode


#
# process Routing Configuration configuration
#
    def saveRoutingConfig(self, child, keyTuple):
       respCode = {}
       retCol = {}
       resp = {}
       respObj = {}

       errStr = rhconf.zebosSaveRoutingConfig(child, self.logger)
       if errStr != '':
           retCol[const.ERRORCODE] = 1001
           retCol[const.MESSAGE] = errStr
           retCol[const.STATE] = const.PERMANENT
           retCol[const.SEVERITY] = "ERROR"
           respObj['routing_save_config'] = retCol
           resp[keyTuple] = respObj
           respCode = dict(resp.items() + respCode.items())
       self.logger.debug('++++++++ processOSPFInterface respCode = %s' %(respCode))
       return respCode

#
# process Routing Configuration configuration
#
    def processRoutingConfig(self, deviceObj, devCfg, deviceAudit, url, sesId):
        errStr = ''
        resCode = {}
        tmpCode = {}
        child = None
        rootKey = None
        routeConfig = False

        try:
            nsObj = NSServer.NSServer(self.logger)
            devFerList = nsObj.getNSEnableFeature(url, sesId)
            self.logger.debug('++++++++ devFerList = %s' %(devFerList))
            rootKey = util.getRootKey(devCfg, self.logger)
            if ("OSPF" in devFerList or "ospf" in devFerList or "BGP" in devFerList or "bgp" in devFerList):
                if const.DefaultPartition == False:
                    child = rhconf.zebosConfigOpenSession(deviceObj[const.HOST], deviceObj[const.CREDS][const.USERNAME], deviceObj[const.CREDS][const.PASSWORD], devCfg, self.logger)
                else:
                    child = sesId
            if ("OSPF" in devFerList or "ospf" in devFerList):
                tmpCode = self.processOSPFInterface(child, url, deviceObj, devCfg, deviceAudit)
                resCode = dict(resCode.items() + tmpCode.items())
                tmpCode = self.processOSPFProcess(child, url, devCfg, deviceAudit)
                resCode = dict(resCode.items() + tmpCode.items())
                routeConfig = True
            #if ("BGP" in devFerList or "bgp" in devFerList):
                tmpCode = self.processBGP(child, url, devCfg, deviceAudit)
                resCode = dict(resCode.items() + tmpCode.items())
                routeConfig = True
            if routeConfig and const.DefaultPartition == False:
                tmpCode = self.saveRoutingConfig(child, rootKey)
                resCode = dict(resCode.items() + tmpCode.items())

            if ("OSPF" in devFerList or "ospf" in devFerList or "BGP" in devFerList or "bgp" in devFerList):
                if const.DefaultPartition == False:
                    rhconf.zebosConfigCloseSession(child, self.logger)
                    child = None

        except Exception as exMsg:
            if const.DefaultPartition == False and child != None:
                rhconf.zebosConfigCloseSession(child, self.logger)
            raise Exception("Exception in processRoutingConfig %s"% str(exMsg))

        return resCode




#
# getContextTenantName
#
    def getContextTenantName(self, devCfg):
        self.logger.debug('+++++ get context tenant name from Config ++++++')
        objCol = {}

        for a1, b1 in devCfg.iteritems():
            objCol[const.VDEV] = a1[2]
            for a2, b2 in b1.iteritems():
                if (a2 == const.CONTEXT) or (a2 == const.TENANT) or(a2 == const.STATE) :
                    objCol[a2] = b2
        self.logger.debug('+++++ getContextTenantName = %s ++++++' %(objCol))
        return objCol

#
# createPartition
#
    def createPartition(self, partitionName, url, devIp, sesId, paramCol):
        partitionCol = {}
        partitionCol[const.PARTITION_NAME] = partitionName
        partitionCol = dict(partitionCol.items() + paramCol.items())
    
        retCol = nitro.createConfigObjects(const.PARTITION, partitionCol, url, devIp, sesId, self.logger)
        

        return retCol

#
# getAllPartition
#
    def getAllPartitionList(self, url, devIp, sesId):
        retParList = []
    
        parAllCol = nitro.getObjectsConfigFromDevice(const.PARTITION, url, devIp, sesId, self.logger)
        
        if const.PARTITION in parAllCol:
            parList = parAllCol[const.PARTITION]
            for item in parList:
                if PARTITION_NAME in item:
                    retParList.append(item[PARTITION_NAME])
        

        return retParList

#
# getEnableFeatureList
#
    def getEnableFeatureList(self, url, devIp, sesId):
        enableFeatureList = []
    
        featureCol = nitro.getObjectsConfigFromDevice("nsfeature", url, devIp, sesId, self.logger)
        
        self.logger.debug('+++++++++ featureColl  %s ' % (featureCol))
        if "nsfeature" in featureCol:
            feaList = dict(featureCol["nsfeature"])
            self.logger.debug('+++++++++ feaList  %s ' % (feaList))

            #for a1, b1 in feaList.iteritems():
                #if a1 == "feature":
            realFeatureList = dict(feaList["nsfeature"])
            self.logger.debug('+++++++++ realFeatureList  %s ' % (realFeatureList))
            if 'feature' in realFeatureList:
                enableFeatureList = list(realFeatureList["feature"])
            self.logger.debug('+++++++++ enableFeatureList  %s ' % (enableFeatureList))
        

        return enableFeatureList
#
# getEnableModeList
#
    def getEnableModeList(self, url, devIp, sesId):
        enableModeList = []
    
        modeCol = nitro.getObjectsConfigFromDevice("nsmode", url, devIp, sesId, self.logger)
        
        self.logger.debug('+++++++++ modeCol  %s ' % (modeCol))
        if "nsmode" in modeCol:
            modeList = dict(modeCol["nsmode"])
            self.logger.debug('+++++++++ modeList  %s ' % (modeList))

            #for a1, b1 in feaList.iteritems():
                #if a1 == "feature":
            realModeList = dict(modeList["nsmode"])
            self.logger.debug('+++++++++ realModeList  %s ' % (realModeList))
            enableModeList = list(realModeList["mode"])
            self.logger.debug('+++++++++ enableModeList  %s ' % (enableModeList))
        

        return enableModeList
#
# deletePartition
#
    def deletePartition(self, partitionName, url, devIp, sesId):
    
        retCol = nitro.removeNitroObject(const.PARTITION, partitionName, None, url, devIp, sesId, self.logger)
        

        return retCol

#
# switchPartition
#
    def switchPartition(self, partitionName, url, devIp, sesId):
        partitionCol = {}
        partitionCol[const.PARTITION_NAME] = partitionName
        tmpCol = {}

        enableFeatureList = self.getEnableFeatureList(url, devIp, sesId)  
        enableModeList = self.getEnableModeList(url, devIp, sesId)  
        
        retCol = nitro.switchConfigObjects(const.PARTITION, partitionCol, url, devIp, sesId, self.logger)

        nsObj = NSServer.NSServer(self. logger)
        
        if len(enableFeatureList) > 0:
            tmpCol['enableFeature'] = nsObj.enableFeatures(enableFeatureList, sesId, url)
            retCol = dict(retCol.items() + tmpCol.items())
            #if const.OSPF in enableFeatureList:
                #tmpCol= {}
                #time.sleep(1)  # sleep for 10 seconds since OSPF agent must be running before rhi config can run
                #tmpCol['RHI'] = configUtil.execRHIConfig(device, sesId, self.logger)
                #retCol = dict(retCol.items() + tmpCol.items())

        if len(enableModeList) > 0:
           tmpCol['enableMode'] = nsObj.enableNSMode(enableModeList, const.ENABLE, sesId, url, devIp)
           retCol = dict(retCol.items() + tmpCol.items())

        return retCol

#
# switchPartition
#
    def checkParExistsFromErrCode(self, retCol):
    
        if const.PARTITION in retCol:
            parRet = dict(retCol[const.PARTITION])

            #for a1, b1 in feaList.iteritems():
                #if a1 == "feature":
            parErrCode = parRet["errorcode"]
            if parErrCode == 0:
                return True
            

        return False

#
# bindVlanPartition
#
    def bindVlanPartition(self, partitionName, vlanCol, url, devIp, sesId):
        """
        This is to bind vlan to partition in the node based on node Ip
        """
        partitionCol = {}
        respCol = {}
        self.logger.debug('+++++++++ bindVlanPartition, vlanCol  %s ' % (vlanCol))
        for a1, b1 in vlanCol.iteritems():
            partitionCol = {}
            partitionCol[const.PARTITION_NAME] = partitionName
            partitionCol[const.VLAN_BIND] = b1
            self.logger.debug('+++++++++ Request for bind vlan %s to partition  %s ' % (b1, partitionName))
            respCol[a1] = nitro.setConfigObjects(const.PARTITION_VLAN_BIND, partitionCol, url, devIp, sesId, self.logger)

     	return respCol
        
        
#
# createAdminPartition
#
    def adminPartitionHandling(self, devCfg, url, devIp, sesId, auditFlag=False):
    
        objCol = self.getContextTenantName(devCfg)
        tmpCol = {}
        retCol = {}
        paramCol = {}
        
        if const.AdminPartitionSupport == True and const.TENANT in objCol:
            # default partition is created, and we can skip this part
            if objCol[const.TENANT] != 'default':
                partitionName = objCol[const.TENANT] + "_" + objCol[const.CONTEXT] + "_" + str(objCol[const.VDEV])
                const.DefaultPartition = False
                if const.STATE in objCol:
                    if objCol[const.STATE]!= const.DELETE or auditFlag == True:
                        paramCol = self.getPartParam(devCfg)
                        tmpCol = self.createPartition(partitionName, url, devIp, sesId, paramCol)
                        retCol = dict(tmpCol.items() + retCol.items())
                        tmpCol = self.switchPartition(partitionName, url, devIp, sesId)
                        retCol = dict(tmpCol.items() + retCol.items())
                    else:
                        tmpCol = self.deletePartition(partitionName, url, devIp, sesId)
                        retCol = dict(tmpCol.items() + retCol.items())
                        tagCol = util.getStateSpecificVLANFromConfig(const.DELETE, devCfg, self.logger)
                        tmpCol = self.deleteTags(tagCol, url, devIp, sesId)
                        retCol = dict(tmpCol.items() + retCol.items())
                        raise const.AdminDelete()
                        
        elif const.AdminPartitionSupport == True and const.TENANT not in objCol:
            if const.CONTEXT not in objCol and auditFlag == True and not devCfg :
                retCol = auditConfig.deleteAllPartition(devCfg, None, url, devIp, sesId, self.logger)
        elif const.AdminPartitionSupport == False:
            if auditFlag == True:
                retCol = auditConfig.deleteAllPartition(devCfg, None, url, devIp, sesId, self.logger)
        
        return retCol

#
# create the IFC tags in NetScaler
#
    def createTagsAdmin(self, tagCol, nodeUrl, nodeHostIp, ndSesId):
        """
        This is to create tags in the node based on node Ip
        """
        self.logger.debug('+++++++++ create Tags based on type in the node Ip = %s' % (nodeHostIp))
        typeVal = 0
        tagVal = 0
        respCol = {}
        vlanCol = {}
        for a1, b1 in tagCol.iteritems():
            vlanCol = {}
            vlanCol[const.ID] = b1
            self.logger.debug('+++++++++ Request for Create Tag value  = %s ' % (b1))
            respCol[a1] = nitro.createConfigObjects(const.VLAN_BIND, vlanCol, nodeUrl, nodeHostIp, ndSesId, self.logger)

     	return respCol


#
# getContextAwareFlag
#
    def getContextAwareFlag(self, device):
		if const.AdminPartitionSupport == True :
			if const.CONTEXTAWARE in device:
				const.AdminPartitionSupport = device[const.CONTEXTAWARE]
				return

		const.AdminPartitionSupport =  False
		return

#
# check if routing configuration exists in the configuration
#
    def checkRouting(self, devCfg):
        for r1, s1 in devCfg.iteritems():
            for r2, s2 in s1.iteritems():
                if r2 == const.VALUE:
                    for r3, s3 in s2.iteritems():
                        if r3[0] == const.BGPDEV or r3[0] == const.OSPFDEV :
                            return True
                        else:
                            if r3[0] == const.VENCAPASS and const.OSPFINTERFACE in s3 :
                                return True
        self.logger.debug('+++++++++ checkRouting returns false ')
        return False                        

#
# get partition related parameters if there are any
#
    def getPartParam(self, devCfg):
        objCol = {}
        for a1, b1 in devCfg.iteritems():
            for a2, b2 in b1.iteritems():
                if a2 == const.VALUE:
                    for a3, b3 in b2.iteritems():
                        # get all the object which has matching state
                        #self.logger.debug('+++++++++ getPartParam returns a3 = %s, b3=%s ' % (a3,b3))
                        if a3[0] == const.FOLDER:
                            if a3[1].strip().lower() == const.PARTITION:
                                #self.logger.debug('+++++++++ getPartParam returns a3 = %s, b3=%s ' % (a3,b3))
                                for a4, b4 in b3.iteritems():
                                    if a4 == const.VALUE:
                                        for a5, b5 in b4.iteritems():
                                            if a5[0] == const.PARAM and a5[1].strip().lower() != 'partitionname':
                                                for a6, b6 in b5.iteritems():
                                                    if a6 == const.VALUE:
                                                        objCol[a5[1]] = b6
        self.logger.debug('+++++++++ getPartParam returns %s ' % objCol )                                                
        return objCol
