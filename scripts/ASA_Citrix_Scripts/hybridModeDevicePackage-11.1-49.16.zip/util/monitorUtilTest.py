#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import unittest
import yaml

import monitorUtil
import NSLogin
import NSDeviceScript
import LogService

#
# This is to unit monitorUtil class
#

class TestMonitorUtil(unittest.TestCase):
    """
    This is to unit test monitorUtil functions 
    """
    def setup(self):
        pass

#
# This is to unit test deviceHealth
#
    def test_a_deviceHealth(self):
        """
        This is to test the device health based on system stats
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        tmpUrl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        devFile = open('test/deviceBLRData.yaml', "r")
        devData = yaml.load_all(devFile)
        devCol = {}
        for j in devData:
            devCol = j
        cnfgFile = open('test/serviceHealthWSGTestData.yaml', "r")
        cnfgData = yaml.load_all(cnfgFile)
        cnfgCol = {}
        for j in cnfgData:
            cnfgCol = j
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        sesId = nsLgObj.login()
	#infCol = infCol = {(11, '', '1_1'): {'state': 0, 'label': ''}, (11, '', '1_2'): {'state': 0, 'label': ''}}
        infCol = infCol = {(11, '', '1_1'): {'state': 0, 'label': ''}, (11, '', '10_2'): {'state': 0, 'label': ''}}

        #devIp = '10.102.201.63'
        #devIp = '10.102.113.195'
        devIp = '10.102.102.51'

        devStatResp = monitorUtil.getDeviceHealth(tmpUrl, devIp, sesId, infCol, cnfgCol, logger)
        nsLgObj.logout(sesId)
        print ' ++++ Device Health response = %s' , devStatResp
        
        return
#
# This is to unit test node link health
#
    def test_a_nodeLinkHealth(self):
        """
        This is to test the node link health based on system stats
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        tmpUrl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        devFile = open('test/deviceBLRData.yaml', "r")
        devData = yaml.load_all(devFile)
        devCol = {}
        for j in devData:
            devCol = j
        cnfgFile = open('test/raviVlanTestData.yaml', "r")
        cnfgData = yaml.load_all(cnfgFile)
        cnfgCol = {}
        for j in cnfgData:
            cnfgCol = j
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        #devIp = '10.102.201.63'
        #devIp = '10.102.113.195'
        devIp = '10.102.102.51'
        infCol = infCol = {(11, '', '10_1'): {'state': 0, 'label': ''}, (11, '', '10_2'): {'state': 0, 'label': ''}}
        #infCol = infCol = {(11, '', '1_1'): {'state': 0, 'label': ''}, (11, '', '1_2'): {'state': 0, 'label': ''}}
        #devStatResp = monitorUtil.processNodeLinkHealth(tmpUrl, devIp, sesId, infCol, None, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ Node Health response = %s' , devStatResp
        
        return

#
# This is to unit test serviceHealth
#
    def test_a_ServiceHealth(self):
        """
        This is to test the service health based on system stats
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #devCol = {'name': 'ADCCluster1', 'virtual': False, 'devs': {'ADC1': {'host': '10.102.102.51', 'port': 80, 'creds': {'username': 'nsroot', 'password': 'nsroot'}}}, 'host': '10.102.102.51', 'port': 80, 'creds': {'username': 'nsroot', 'password': 'nsroot'}}
        devCol = {'name': 'ADCCluster1', 'virtual': False, 'devs': {'ADC1': {'host': '172.23.50.132', 'port': 80, 'creds': {'username': 'nsroot', 'password': 'nsroot'}}}, 'host': '172.23.50.132', 'port': 80, 'creds': {'username': 'nsroot', 'password': 'nsroot'}}
        #cnfgFile = open('test/connectorTestData.yaml', "r")
        #cnfgFile = open('test/serviceHealthTestData.yaml', "r")
        #cnfgFile = open('test/monitorTestData.yaml', "r")
        #cnfgFile = open('test/ifcLoadBalancingData.yaml', "r")
        cnfgFile = open('test/newMonitorTestData.yaml', "r")
        cnfgData = yaml.load_all(cnfgFile)
        cnfgCol = {}
        for j in cnfgData:
            cnfgCol = j

        #devIp = '10.102.201.63'
        #devIp = '10.102.113.195'
        #devIp = '10.102.201.141'
        devIp = '10.102.102.51'

        #devStatResp = monitorUtil.getServiceHealth(cnfgCol, devCol, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ Service Health response = %s' , devStatResp
        
        return

    def test_b_deviceCounters(self):
        """
        This is to test the device deviceCounters based on system stats
        """
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.113.195" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #cnfgFile = open('test/interfaceData.yaml', "r")
        cnfgFile = open('test/newMonitorTestData.yaml', "r")
        #cnfgFile = open('test/monitorTestData.yaml', "r")
        cnfgData = yaml.load_all(cnfgFile)
        cnfgCol = {}
        for j in cnfgData:
            cnfgCol = j
        #devIp = '10.102.201.141'
        devIp = '172.23.50.132'
        #devIp = '10.102.102.51'
        #devIp = '10.102.113.195'
        
        devUrl = "http://" + "172.23.50.132" + "/nitro/v1/config/"
        #devStatResp = monitorUtil.getDeviceCounters(cnfgCol, None, devUrl, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ Device Counters response = ' , devStatResp
        
        return

    def test_b_serviceCounters(self):
        """
        This is to test the service counters based on system stats
        """
        #url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.113.195" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #cnfgFile = open('test/connectorTestData.yaml', "r")
        #cnfgFile = open('test/monitorTestData.yaml', "r")
        cnfgFile = open('test/newMonitorTestData.yaml', "r")
        cnfgData = yaml.load_all(cnfgFile)
        cnfgCol = {}
        for j in cnfgData:
            cnfgCol = j
        #devIp = '10.102.102.51'
        devIp = '172.23.50.132'
        #devIp = '10.102.201.141'
        #devIp = '10.102.113.195'
        devUrl = "http://" + "172.23.50.132" + "/nitro/v1/config/"
        
        #devStatResp = monitorUtil.getServiceCounters(cnfgCol, devUrl, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ Service Counters response = ' , devStatResp
	
	return 
if __name__ == '__main__':
    unittest.main()
