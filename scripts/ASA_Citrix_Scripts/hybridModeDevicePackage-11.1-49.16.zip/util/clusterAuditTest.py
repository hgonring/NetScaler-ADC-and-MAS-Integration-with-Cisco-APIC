#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import unittest
import yaml

import NSServer
import NSDeviceScript
import DeviceScriptController
import NSLogin
import LogService
import clusterAudit
import json

from util import vServerUtil 

from util import configUtil as util

#
# This is to unit Test clusterAuditConfig
#

class TestAuditConfig(unittest.TestCase):
    """
    This is to unit test cluster audit config functions 
    """
    def setup(self):
        pass

#
# This is to unit test computeModify
#
    def test_b_computeModify(self):
        """
        This is to test compute modify function from cluster auditConfig
        """
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.102.58" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.58" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        sesId = nsLgObj.login()
        #deviceFile = open('test/deviceVDataCisco.yaml', "r")
        deviceFile = open('test/deviceBLRData.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for m in deviceData:
            deviceCol = m

        #devIp = '172.23.50.132'
        devIp = '10.102.102.58'
        #devIp = '10.102.102.51'
	virtualFlag = False
        #auditData = open('test/vipulServiceModify_2.yaml', 'r')
        #auditData = open('test/snmpTestData.yaml', 'r')
        auditData = open('test/clusterAudit105TestData.yaml', 'r')
        ipUrl = "http://" + "10.102.102.58" + "/nitro/v1/config/"
        genData = yaml.load_all(auditData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
                                           #(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
	respObj = clusterAudit.computeModify(serviceConfig, deviceCol, ipUrl, devIp, virtualFlag, sesId, logger)
	#respObj = clusterAudit.computeDelete(serviceConfig, deviceCol, ipUrl, devIp, sesId, logger)
        nsLgObj.logout(sesId)
        print ' ++++ Cluster Audit compute modify response = %s' , respObj

        return

#
# This is to unit test computeModify
#
    def test_a_computeDelete(self):
        """
        This is to test compute Delete function from auditConfig
        """
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        #deviceFile = open('test/deviceVDataCisco.yaml', "r")
        deviceFile = open('test/deviceBLRData.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for m in deviceData:
            deviceCol = m

        #devIp = '10.102.102.51'

        devIp = '10.102.102.51'
        #auditData = open('test/vipulServiceModify_2.yaml', 'r')
        #auditData = open('test/vipulServiceModifyTestData.yaml', 'r')
        auditData = open('test/snmpTestData.yaml', 'r')
        #auditData = open('test/vipul300Graphs.yaml', 'r')
        #auditData = open('test/apicTestData_1.yaml', 'r')
        ipUrl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
        genData = yaml.load_all(auditData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
	#respObj = clusterAudit.computeDelete(serviceConfig, deviceCol, ipUrl, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ AuditDevice compute delete response = %s' , respObj

        return

if __name__ == '__main__':
    unittest.main()
