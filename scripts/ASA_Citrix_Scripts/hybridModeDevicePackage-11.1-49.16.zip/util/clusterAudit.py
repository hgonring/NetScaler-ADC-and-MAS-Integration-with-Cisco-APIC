#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import sys
import scriptConst as const
import nitroUtil as nitro
import configUtil as util
import objectOrderNKey as constKey
import NSLogin
import objectOrderNKey as constKey
import vServerUtil as vser

from urllib import urlencode


#
# This is to get modify object from the config
#
def computeModify(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
    """
    This is compute diff for object which are present in the NetScaler device
    """
    logger.debug('++++++ This is to Compute cluster Modify +++++')
    modCol = {}
    addCol = {}
    retCol = {}
    tmpCol = {}
    # process all config objects first before processing VLAN & and its binding
    tmpCol = handleAllConfigEntities(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger)
    retCol = dict(tmpCol.items() + retCol.items())

    return retCol

#
# This is to handle all the config entities
#
def handleAllConfigEntities(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
    """
    This is to handle all the config entities from the APIC
    """
    auditFlag = True
    addCol = {}
    retCol = {}
    objState = const.CREATE # here object won't matter since the auditFlag is true
    cnfgObjCol = util.getClusterStateSpecificObjectsFromConfig(objState, cnfg, logger, auditFlag)
    #logger.debug('++++ Cluster Object details = %s' % (cnfgObjCol))
    #process device level config objects
    for a1, b1 in cnfgObjCol.iteritems():
	if a1[1].strip().lower() == const.ENABLE_FEATURE.strip().lower() or a1[1].strip().lower() == const.ENABLE_MODE.strip().lower() :
	    continue
        instObj = {}
       
        objName = a1[1]
        #logger.debug('======== A1 = %s, B1 = %s' % (a1,b1))
        tmpObjCol = {}
        objAtrCol = {}
        objAtrCol[a1[1]] = b1
        logger.debug('++++ Cluster Object attribute collection for object = %s, attribute = %s' % (objName, objAtrCol))
        # get object's key
        keyTup = None
        keyAtr = None
        keyTup = util.getObjectKey(objName, logger)
        logger.debug('Key Tuple = %s, length = %s' % (str(keyTup), len(keyTup)))
        if len(keyTup) > 1:
            # handle composite keys here
            tmpRetCol = {}
            tmpRetCol, addFlag = handleCompositKeyObject(objName, keyTup, objAtrCol[a1[1]], cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger)
            logger.debug('Response from handle Composite tmpRetCol = %s, addFlag = %s' % (tmpRetCol, addFlag))
            if addFlag:
                addCol[a1] = b1
            elif len(tmpRetCol) > 0:
                retCol = dict(tmpCol.items() + retCol.items())
            continue # this is to skip rest of the steps processing in the loop
        else:
            if keyTup is not None:
                keyAtr = keyTup[0]  #util.getObjectKey(objName, logger)
            else:
                keyAtr = None
        if (keyAtr):
            instVal = getKeyValueFromAttributeCollection(keyAtr, objAtrCol, logger)
            logger.debug('++++ Instance object = %s, key attribute = %s' % (instVal, keyAtr))
            if (instVal):
                respObj = {}
                instObj = []
                # get object from device
                if objName.strip().lower() == const.SNMPTRAP.strip().lower() or objName.strip().lower() == const.NTP_SERVER.strip().lower():
                    respObj = nitro.getInstanceByFilterFromDevice(objName, keyAtr, instVal, url, devIp, sesId, logger)
                else:
                    respObj = nitro.getInstanceConfigFromDevice(objName, instVal, url, devIp, sesId, logger)
                #logger.debug('Device instance objects = %s' % (respObj))
                instObj = getObjectInstanceFromResponse(objName, respObj, logger)
                #logger.debug('Device object from the response = %s' % (instObj))
                if len(instObj) > 0:
                    tmpCol = {}
                    tmpCol = compareDeviceAPICObjects(objAtrCol, instObj, url, devIp, sesId, logger)
                    retCol = dict(tmpCol.items() + retCol.items())
                else:
                    addCol[a1] = b1
    #logger.debug('Add collection from APIC config = %s' % (addCol))                                    
    if len(addCol) > 0:
        tmpCol = {}
        tmpCol = createObjectInDevice(addCol, url, devIp, sesId, cnfg, logger)
        retCol = dict(tmpCol.items() + retCol.items())

    logger.debug(' Add collection response = %s' % (retCol))
    # at present cluster config doesn't have any bindings
    #vserObj = vser.VServerUtil(logger)
    #tmpCol =  vserObj.processCreateBindDataSet(cnfg, url, devIp, sesId, True)
    return retCol 

#
# handle composite key entities
#
def handleCompositKeyObject(objName, keyTup, objAtrCol, cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
    """
    This is to handle composite key entities
    """
    logger.debug(' Object Attribute Collection = %s' % (objAtrCol))
    argStr = None
    addFlag = False
    retCol = {}
    for tmpKey in keyTup:
        #logger.debug('Tmp key = %s' % (str(tmpKey)))
        keyStr = str(tmpKey)
        #logger.debug('Key Str = %s' % (keyStr))
        if tmpKey in objAtrCol:
            argVal = None
            # this is to single encode values 
            argVal = objAtrCol[tmpKey]
            tmp1 = {'id' : argVal}
            tmpEncode = urlencode(tmp1)
            argVal = tmpEncode[3:]
            if (argStr):
                argStr = argStr + ',' + tmpKey + ':' + argVal
            else:
                argStr = 'args=' + tmpKey + ':' + argVal
    logger.debug('ArgStr = %s' % (argStr))
    if (argStr):
        objNameWithParams = objName + '?' + argStr
        respCol = {}
        instObj = []
        respCol = nitro.getObjectsConfigFromDevice(objNameWithParams, url, devIp, sesId, logger)
        
        instObj = getObjectInstanceFromResponse(objName, respCol, logger)
        logger.debug('Device object for composite key from the response = %s' % (instObj))
        if len(instObj) > 0:
            retCol = compareDeviceAPICObjects(objAtrCol, instObj, url, devIp, sesId, logger)
        else:
            # add this object
            addFlag = True
    resp = (retCol, addFlag)
    return resp

#
# create object in device using order 
#
def createObjectInDevice(createObjCol, url, devIp, sesId, devCfg, logger):
    """
    This is to add objects in device using object order list
    """
    respCode = {}
    vservObj  = vser.VServerUtil(logger)
    configOrderCol = {}
    backupLBVCol = {}
    orderObjList = util.getObjectOrderList(logger)  #const.OBJECTLIST
    #logger.debug('++++++++ Create config object collection length = %s' % len(createObjCol))
    for a1, b1 in createObjCol.iteritems():
        tmpName = a1[1]
        #logger.debug('+++++++++ Create object Name  = %s' % (tmpName.upper()))
        for i in orderObjList:
            if i.strip().lower() == tmpName.strip().lower():
                    # this will store only one value since others will get overwritten
                configOrderCol[orderObjList.index(i)] = tmpName.strip().lower()
                #logger.debug('+++++++++ Create object details = %s' % (tmpName.upper()))
                break

    # now configure this object based on config order

    #logger.debug('++++++++ Create config object order collection length = %s' % len(configOrderCol))
    for k1 in sorted(configOrderCol.iterkeys()):
        objkey = configOrderCol[k1]
        tmpObjCol = {}
        for p1 in createObjCol.keys():
            tmpTuple_2 = p1
            keyStr = p1[1]
            # here key is config object name i.e. lbvserver
            if objkey == keyStr.strip().lower():
                tmpObjCol = {}
                tmpObjCol[tmpTuple_2] = createObjCol[p1]
                #logger.debug('+++++++++++ Objkey = %s , object val = %s' % (objkey, tmpObjCol))
                keyVal = keyStr #p1[1]
                #instVal = p1[2]
                instVal = tmpTuple_2[2]
                # now create this object
                for s1, o1 in tmpObjCol.iteritems():
                    # handle objects which can not be added
                    #logger.debug('++++++++ Create config object data key = %s  value = %s' % (s1, o1))
                    if s1 == const.SNMPALARM:
                        respCode[p1] = nitro.setConfigObjects(s1[1], o1, url, devIp,sesId, logger)
                    else:
                        respCode[p1] = nitro.createConfigObjects(s1[1], o1, url, devIp, sesId, logger)

    return respCode


#
# get instance object from the response
#
def getObjectInstanceFromResponse(objType, respCol, logger):
    """
    This is to get object from response
    """
    objResp = {}
    #logger.debug(' get Objects Instance from Response = %s' % (respCol))
    tmpError = None
    for a1, b1 in respCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.ERRORCODE:
                tmpError = b2
            elif a2 == objType:
                #logger.debug('B2 -------- = %s' % (b2))
                if type(b2) is list and len(b2) > 0:
                    objResp[objType] = b2[0] # since most of the time objects will be in list 
    if tmpError == 0:
        return objResp
    else:
        return []
#
# This is to get object from Device
#
def getObjectFromDevice(objCol, url, devIp, sesId, logger):
    """
    This is to get object from the device
    """
    #logger.debug('+++ getObject from device, object = %s' % (objCol))
    objName = None
    keyAtr = None
    retCol = {}
    for k1, v1 in objCol.iteritems():
        objName = k1[1]
        if (objName):
            objKeyAtr = util.getObjectKey(objName, logger)
            if (objKeyAtr):
                keyAtr = objKeyAtr[0]
                # get the instance value from the object collection
                instVal = getKeyValueFromObject(keyAtr, objCol, logger)
                # get this object's instance from the NetScaler 
                if keyAtr == const.ID:
                    instVal = str(instVal) # convert ID to string since REST throws exception
                instCol = {}
                instCol = nitro.getInstanceConfigFromDevice(objName, instVal, url, devIp, sesId, logger)
                #logger.debug('Instance value from the device = %s' % (instCol))
                # this is to avoid empty collection returning back
                for i1, j1 in instCol.iteritems():
                    if j1 is not None and len(j1) > 0:
                        retCol = instCol
                
    return retCol
#
# This is to get object instance/configuration from Device 
#
def getNSObjectFromDevice(objName, url, devIp, sesId, logger):
    """
    This is to get object's config or intance from the device 
    """
    #logger.debug('+++++ This is to get config from the device for the object = %s' % (objName))
    retCol = {}
    retCol = nitro.getObjectsConfigFromDevice(objName, url, devIp, sesId, logger)
    #logger.debug('Instance value from the device = %s' % (retCol))

    return retCol
#
# get key value from object's attribute collection
#
def getKeyValueFromAttributeCollection(keyAtr, objCol, logger):
    """
    This is to get key's value from object's attribute collection
    """
    #logger.debug('+++ Key value from object collection key attribute = %s, object collection = %s' % (keyAtr, objCol))
    for a1, b1 in objCol.iteritems():
        # here a1 is object type i.e. service
        for a2, b2 in b1.iteritems():
            if a2 == keyAtr:
                return b2

    # if execution reaches here then not found
    return None
#
# ignore few objects which are of special type
#
def ignoreObjectWithSpecificValue(objName, objCol, logger):
    """
    This is to ignore objects with certain values
    """
    for a1, b1 in objCol.iteritems():
        if objName == const.NSIP and a1 == const.IPTYPE:
            if const.NSIP in b1:  # since IPTYPE is type of an array
                #logger.debug('Ignore object type = %s value = %s' % (objName, b1))
                return True
    
    return False
#
# get key value from NetScaler's response collection
#
def getNSKeyValueFromCollection(keyAtr, objCol, logger):
    """
    This is to get key's value from NetScaler's response
    """
    #logger.debug('++++++ get Key value for key = %s, objCol = %s' % (keyAtr,objCol))
    for a1, b1 in objCol.iteritems():
        if a1 == keyAtr:
            return b1

    # if the execution reaches here then key not found
    return None

#
# get Object's key value from object collection 
#                                                     
def getKeyValueFromObject(keyAtr, objCol, logger):
    """
    This is to get key's value from the object
    """
    #logger.debug('+++++++ get Key Value from Object ++++ keyAttr = %s, objCol = %s' % (keyAtr, objCol))
    objInstance = None
    for i1, j1 in objCol.iteritems():
        objInstance = i1[1]
        #logger.debug('++++ object instance = %s' % (objInstance))
        for i2, j2 in j1.iteritems():
            #logger.debug(' i2 = %s j2 = %s' % (i2,j2))
            if objInstance is not None and objInstance.strip().lower() == const.VLAN_BIND:
                if i2 == const.TAG:
                    return j2
            elif i2 == const.VALUE:
                for i3, j3 in j2.iteritems():
                    if i3[1] == keyAtr:
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                return j4

    return None
#
# get attribute collection for APIC object
#
def getAttributeCollectionForObject(apicObj, logger):
    """
    This is to get attribute collection for an APIC object
    """
    #logger.debug('++++++++++ get Attribute collection for object = %s' % (apicObj))
    objType = None
    retCol = {}
    for a1, b1 in apicObj.iteritems():
        objType = a1[1]
        for a2, b2 in b1.iteritems():
            if objType == const.VLAN_BIND:
                if a2 == const.TAG:
                    tmpCol = {}
                    tmpCol[const.ID] = b2
                    retCol[objType] = tmpCol
                    return retCol
            elif a2 == const.VALUE:
                tmpCol = {}
                for a3, b3 in b2.iteritems():
                    if a3[0] == const.PARAM:
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                tmpCol[a3[1]] = b4
                if len(tmpCol) > 0:
                    retCol[objType] = tmpCol
    return retCol
#
# get the device Object in dict format 
#
def getAttributeObjectFromList(devObj, logger):
    """
    This is to get object in dict format from device object 
    """
    retCol = {}
    for a1, b1 in devObj.iteritems():
        if type(b1) is list:
            # here the assumption is list will have only one element
            for i in b1:
                retCol[a1] = i
    return retCol

#
# compare two APIC & Device objects
#
def compareDeviceAPICObjects(apicAtrCol, devAtrCol, url, devIp, sesId, logger):
    """
    This is to compare apic and device objects using their attribute collection
    """
    #logger.debug('+++ compare two objects using attribute collection ++++')
    #logger.debug('... APIC Attr COl = %s' % (apicAtrCol))
    #logger.debug('....Device Attr Col = %s' % (devAtrCol))
    retCol = {}
    vserObj = vser.VServerUtil(logger)
    for i in apicAtrCol.keys():
        #logger.debug('......... keys in compare object = %s' % (i))
        tmpACol = {}
        tmpDCol = {}
        tmpDiffCol = {}
        if i in devAtrCol:
            tmpACol = apicAtrCol[i]
            tmpDCol = devAtrCol[i]
            for k in tmpACol.keys():
                if k in tmpDCol:
                    if k == const.IP:
                        if tmpACol[k] != tmpDCol[const.IPADDRESS]:
                            tmpDiffCol[k] = tmpACol[k]
                    elif tmpACol[k] != tmpDCol[k]:
                        tmpDiffCol[k] = tmpACol[k]
            if len(tmpDiffCol) > 0:
	        tmpCol = {}
            # execute the set command here to since the object exist but values differ
                #logger.debug('Setting the object attributes in NetScaler ... = %s' % (i))
                retCol[i] = nitro.setConfigObjects(i, tmpACol, url, devIp, sesId, logger)
            #retCol[i] = tmpDiffCol

    logger.debug('Compare diff collection = %s' % (retCol))
    return retCol
 
#
# Compare the two objects
#
def compareObjects(apicObj, devObj, logger):
    """
    This is to compare the two objects from APIC and NetScaler
    """
    #logger.debug('++++++++ compare objects apicObject = %s, device object = %s' % (apicObj, devObj))
    apicAtrCol = {}
    devAtrCol = {}
    retCol = {}
    apicAtrCol = getAttributeCollectionForObject(apicObj, logger)
    devAtrCol = getAttributeObjectFromList(devObj, logger)
    #logger.debug('++++ Attribute collection  APIC col = %s, Device Col = %s' % (apicAtrCol,devAtrCol))
    for i in apicAtrCol.keys():
        #logger.debug('......... keys in compare object = %s' % (i))
        tmpACol = {}
        tmpDCol = {}
        tmpDiffCol = {}
        if i in devAtrCol:
            tmpACol = apicAtrCol[i]
            tmpDCol = devAtrCol[i]
            #logger.debug('++++ Comparing attributes APIC col = %s, Device Col = %s' % (tmpACol, tmpDCol))
            for k in tmpACol.keys():
                if tmpACol[k] != tmpDCol[k]:
                    tmpDiffCol[k] = tmpACol[k]
        if len(tmpDiffCol) > 0:
            retCol[i] = tmpDiffCol

    logger.debug('Compare diff collection = %s' % (retCol))
    return retCol 
#
# This is to compare VLANs 
#
def compareVLANs(apicCol, devCol, logger):
    """
    This is to compare VLAns between APIC and NetScaler
    """
    #logger.debug('This is to compare VLANs APIC Col = %s, deviceCol = %s' % (apicCol, devCol))

    tagVal = apicCol[const.TAG]
    idVal = devCol[const.ID]
    #logger.debug('.. VLAN values Tag = %s, ID = %s' % (tagVal, idVal))
    if int(tagVal) == int(idVal):
        return True
    else:
        return False
#
# process Node level configuration 
#
def processNodeLevelDelete(objName, objCol, cnfg, nodeName, nodeUrl, nodeIp, nodeSesId, logger):
    """
    This is to handle delete details per Node
    """
    #logger.debug('Node level processing -------------- nodeName = %s' % (nodeName))
    respCode = {}
    instList = []
    keyAtr = util.getObjectKey(objName, logger)
    if (keyAtr):
        keyAtr = keyAtr[0]
    for a1, b1 in objCol.iteritems():
        if a1 == const.ERRORCODE:
            errVal = b1
        elif a1 == objName:
            instList = b1
    #logger.debug('Porcess object For errorcode = %s instList = %s' % (errVal, instList))
    tmpObjCol = {}
    for i in instList:
        # check if i is not type of dict then ignore
        if type(i) is not dict:
            continue
        tmpObjCol = i
        keyVal = None
        # get the key value from the instance 
        keyVal = getNSKeyValueFromCollection(keyAtr, tmpObjCol, logger)
        if keyVal is None:
            continue
        if objName == const.NSIP and keyVal == nodeIp:
            #logger.debug('Ignore device node IPs ..... value = %s' % (keyVal))
            continue
        # find this object in APIC config
        findResp = False
        #logger.debug('KeyName = %s, keyVal = %s, objName = %s' % (keyAtr, keyVal, objName))
        findResp = findObjectUsingKeyInAPICConfig(keyAtr, keyVal, objName, cnfg, logger)
        # this is to ignore the object which are 
        #if keyVal == None:
        #    continue
        #logger.debug('FIND Object Resp = %s' % (findResp))
        if findResp is False: # if object not found then compare bindings
            #logger.debug(' objName = %s, snmp alarm = %s' % (objName, const.SNMPALARM))
            if objName.strip().lower() == const.SNMPALARM.strip().lower():
                tmpUnCol = {}
                tmpUnCol[keyAtr] = keyVal
                respCode[keyVal] = nitro.unsetConfigObjects(objName, tmpUnCol, url, devIp, sesId, logger)
            else:
                # delete this object 
                respCode[keyVal] = nitro.removeNitroObject(objName, keyVal, None, nodeUrl, nodeIp, nodeSesId, logger)
    return respCode

#
# Find Object using multiple keys
# objName, tmpObjCol, completeKey, devCfg, logger
def getObjectFromAPICConfig(objName, objCol, keyAtrs, cnfg, url, devIp, sesId, logger):
    """
    This is to get object from APIC's cluster config
    """
    devObjKeyCol = {}
    objKeyFlag = {}
    keyValTup = None
    findObjCol = {}
    # first get the key's value from device object
    for tmpKey in keyAtrs:
        if tmpKey in objCol:
            devObjKeyCol[tmpKey] = objCol[tmpKey]
            
    logger.debug('Device object = %s key collection = %s' % (objName, devObjKeyCol))
    atrCol = {}
    keyAtrCol = {}
    objFlag = False
    retCol = {}
    for a1, b1 in cnfg.iteritems():
        if a1[0] == const.FOLDER and a1[1] == objName:
            tmpCol = {}
            tmpKeyCol = {}
            for a2, b2 in b1.iteritems():
                if a2 == const.VALUE:
                    for a3, b3 in b2.iteritems():
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                tmpCol[a3[1]] = b4
                                # check if the attribute is the key
                                if a3[1] in keyAtrs:
                                    tmpKeyCol[a3[1]] = b4
            atrCol[a1] = tmpCol
            keyAtrCol[a1] = tmpKeyCol

    # now compare the key values with device object 
    logger.debug('get Object APIC attribute collection for object = %s device collection = %s APIC collection = %s' % (objName, objCol, atrCol))
    # device object key attribute collection
    findObjCol= {}
    # check if the key values match
    for x1, y1 in keyAtrCol.iteritems():
        for x2, y2 in y1.iteritems():
                if x2 in devObjKeyCol:
                    if y2 == devObjKeyCol[x2]:
                        objKeyFlag[x2] = True
                    else:
                        objKeyFlag[x2] = False
        # check if all the keys match
        logger.debug('Keys find attribute collection = %s' % (objKeyFlag))
        findFlag = True
        for m1, n1 in objKeyFlag.iteritems():
            if n1 == False:
                findFlag = False
                break
        # if the keys match then break
        if findFlag:
            findObjCol[x1]  = y1
            objFlag = True
            break
    # if objects are the same then compare its attributes
    logger.debug('Find object collection = %s' % (findObjCol))
    if objFlag:
        diffCol = {}
        for i1,j1 in findObjCol.iteritems():
            tmpApCol = {}
            tmpApCol = atrCol[i1] # this is to get APIC object for the matched object
            for i2, j2 in tmpApCol.iteritems():
                if i2 in objCol:
                    if j2 != tmpApCol[i2]:
                        diffCol[i2] = j2
        if len(diffCol) > 0: # if there is difference in the value
            # add the key values 
            diffCol = dict(keyAtrCol.items() + diff.items())
            # set these in NetScaler
            logger.debug('set this object = %s, collection = %s' % (objName, diffCol))
            retCol = nitro.setConfigObjects(objName, diffCol, url, devIp, sesId, logger)

    resp = (retCol, objFlag)
    logger.debug('Response from getObjectFromAPICConfig = %s' % (str(resp)))
    return resp


#
# process the NITRO response from NetScaler
#
def processObjectForDelete(objName, objCol, deviceCol, devCfg, url, devIp, sesId, logger):
    """
    This is to process nitro response 
    """
    logger.debug('+++++++++ processing nitro response for object = %s' % (objName))
    errVal = None
    instList = []
    keyAtr = None
    deleteCol = {}
    respCode = {}
    objAtrCol = {}
    completeKey = None

    keyAtr = util.getObjectKey(objName, logger)
    if (keyAtr):
        completeKey = keyAtr
        keyAtr = keyAtr[0]
    for a1, b1 in objCol.iteritems():
        if a1 == const.ERRORCODE:
            errVal = b1
        elif a1 == objName:
            instList = b1
    logger.debug('Porcess object For errorcode = %s instList = %s' % (errVal, instList))
    tmpObjCol = {}
    for i in instList:
        # check if i is not type of dict then ignore
        if type(i) is not dict:
            continue
        tmpObjCol = i
        # now compare this with APIC objects 
        objFindFlag = False
        respTup = getObjectFromAPICConfig(objName, tmpObjCol, completeKey, devCfg, url, devIp, sesId, logger)
        if len(respTup[0]) > 0:
            respCode[objName] = respTup[0]
        ignoreFlag = False
        # check if this object needs to be ignored
        ignoreFlag = ignoreObjectWithSpecificValue(objName, tmpObjCol, logger)
        if (ignoreFlag):
            continue
        keyVal = None
        # get the key value from the instance 
        keyVal = getNSKeyValueFromCollection(keyAtr, tmpObjCol, logger)
	if keyVal is None:
            continue
        if objName == const.NSIP and keyVal == devIp:
            #logger.debug('Ignore the device IP/SNIP ..... value = %s' % (keyVal))
            continue
        # find this object in APIC config
        #logger.debug('KeyName = %s, keyVal = %s, objName = %s' % (keyAtr, keyVal, objName))
        findResp = respTup[1]
        #findResp = findObjectUsingKeyInAPICConfig(keyAtr, keyVal, objName, devCfg, logger)
        #logger.debug('FIND Object Resp = %s' % (findResp))
        if (findResp): # if object found then ignore
            pass
        else: 
            if objName.strip().lower() == const.SNMPALARM.strip().lower():
                tmpUnCol = {}
                for j_1 in tmpObjCol.keys():
                    if j_1 != keyAtr and j_1 not in ('timeout', 'time'): # 'timeout attributes shouldn't get reset
                        tmpUnCol[j_1] = True
                tmpUnCol[keyAtr] = keyVal
                respCode[objName] = nitro.unsetConfigObjects(objName, tmpUnCol, url, devIp, sesId, logger)
                continue
            elif objName.strip().lower() == const.ROUTE.strip().lower():
                gatewayVal = getParamValFromCollection(const.GATEWAY, tmpObjCol, logger)
                netmskVal = getParamValFromCollection(const.NETMASK, tmpObjCol, logger)
                if netmskVal and gatewayVal:
                    args = 'args='+const.NETMASK + ':' + netmskVal + ',' + const.GATEWAY+':'+gatewayVal
                    #logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyAtr, keyVal))
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, args, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.DNSSRVREC:
                tgVal = getParamValFromCollection(const.TARGET, tmpObjCol, logger)
                if tgVal:
                    argStr = 'args='+ const.TARGET + ':' + tgVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.DNSMXREC:
                mxVal = getParamValFromCollection(const.MX, tmpObjCol, logger)
                if mxVal:
                    argStr = 'args='+ const.MX + ':' + mxVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.DNSNSREC:
                nsVal = getParamValFromCollection(const.NAMESERVER, tmpObjCol, logger)
                if nsVal:
                    argStr = 'args='+ const.NAMESERVER + ':' + nsVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.LBMONITOR:
                tyVal = getParamValFromCollection(const.TYPE, tmpObjCol, logger)
                if tyVal:
                    argStr = 'args='+ const.TYPE + ':' + tyVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.SERVICE:
                        # delete the service and server also since server doesn't get deleted from the config
                #logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyAtr, keyVal))
                respCode[objName] = nitro.removeNitroObject(objName, keyVal, None, url, devIp, sesId, logger)
                        # now exclusive delete the server based on the services IP value
                tmpIpVal = getParamValFromCollection(const.IP, tmpObjCol, logger)
                if tmpIpVal: # this is just to make sure value is not NULL
                    tmpTup = (objName, (const.FOLDER, const.SERVER, tmpIpVal))
                    respCode[tmpTup] = nitro.removeNitroObject(const.SERVER, tmpIpVal, None, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.SNMPTRAP:
                #logger.debug('SNMPN trap delete object collection = %s' % (tmpObjCol))
                tyVal = getParamValFromCollection('trapdestination', tmpObjCol, logger)
                #logger.debug('Trap destination value = %s' % (tyVal))
                if tyVal:
                    argStr = 'args='+ 'trapdestination' + ':' + tyVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            else:
                logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyVal, keyVal))
                respCode[objName] = nitro.removeNitroObject(objName, keyVal, None, url, devIp, sesId, logger)
        #else:
        #    logger.debug('+++++++ get the BINDINGS for the existing object ++++++++++++')
            # if object exist then look for objects binding
        #    tmpCol = {}
        #    tmpCol = getObjectBindingsFromNetScaler(devCfg, objName, keyVal, url, devIp, sesId, logger)
        #    deleteCol = dict(tmpCol.items() + deleteCol.items())

    logger.debug(' process object for Delete Response  = %s' % (respCode))

    return respCode

#
# get the attribute value from the collection
#
def getParamValFromCollection(atrName, objCol, logger):
    """
    This is to get parameter value from the object collection
    """
    for a1, b1 in objCol.iteritems():
        if a1 == atrName:
            return b1

    # if the execution reaches here then not found
    return None

#
# Search APIC config for an object with KeyValue
#
def findObjectUsingKeyInAPICConfig(keyAtr, keyVal, objName, cnfg, logger):
    """
    This is to find an object in APIC config using object's key and value
    """
    # this is to check if this is HighAvailability Config
    
    #logger.debug('++++++ comparison params key Str = %s keyVal = %s objName = %s' % (keyAtr, keyVal, objName))
    for a1, b1 in cnfg.iteritems():
        logger.debug('+ Comparison Object A1 = %s B1 = %s objectName = %s' % (a1,b1, objName))
        if a1[1] ==objName:
            tmpCol = {}
            tmpCol[a1] = b1
            instVal = None
            # compare the o:qbject's key to make sure if it is the same instance
            instVal = getKeyValueFromObject(keyAtr, tmpCol, logger)
            logger.debug('+ INSTANCE VALUE for the comparison = %s' % (instVal))
            if instVal == keyVal:
                return True

    # if execution reaches here then not found
    return False
#
# Search Bind object in APIC config
#
def findBindObjectInAPICConfig(cnfg, bindObj, keyVal, keyName, instVal, url, devIp, sesId, logger, nodeName=None):
    """
    This is to find bind object in APIC config, compare the key's value to find if it is the same 
    """
    logger.debug('++++++++ find bind object = %s, keyName = %s, instVal = %s' % (bindObj, keyName, instVal))
    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                # get the deviceConfig object
                for a3, b3 in b2.iteritems():
                    if bindObj == const.VLAN_INTERFACE_BIND_NAME:
                        tmpCol = {}
                        tmpCol = getVLANInfBindForVLANAPIC(cnfg, keyVal, instVal, nodeName, logger)
                        if len(tmpCol) > 0:
                            for x1, y1 in tmpCol.iteritems():
                                for x2, y2 in y1.iteritems():
                                    if x2[const.IFNUM] == instVal:
                                        return True
                    elif bindObj == const.VLAN_NSIP_BINDING:
                        tmpCol = {}
                        cmpResp = False
                        cmpResp = compareNSVLANBindFromDevice(cnfg, keyVal, instVal, url, devIp, sesId, logger)
                        if cmpResp:
                            return True
                        #if len(tmpCol) > 0:
                        #    for m1, n1 in tmpCol.iteritems():
                        #        # collection for NSIP VLAN binding bindName, keyVal, instVal)] = (keyVal, instVal)
                        #        logger.debug(' Function specific VLAN NSIP binding key = %s Value = %s' % (m1,n1))
                        #        if instVal == n1[1]:
                        #            return True
                    elif util.checkFolderInsideFolder(b3): # check if the folder contains another folder inside it
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems():
                                    if util.checkBindFolderInsideFolder(b5):
                                        for a6, b6 in b5.iteritems():
                                            if a6  == const.VALUE:
                                                for a7, b7 in b6.iteritems():
                                                    if a7[0] == const.FOLDER and a7[1] == bindObj:
                                                        for a8, b8 in b7.iteritems():
                                                            if a8 == const.VALUE:
                                                                for a9, b9 in b8.iteritems():
                                                                    if a9[0] == const.MREL and a9[1] == keyName:
                                                                        for a10, b10 in b9.iteritems():
                                                                            if a10 == const.TARGET and b10 == instval:
                                                                                #logger.debug('Bind object found bind obj = %s, keyName = %s, instVal = %s'% (a7[1], a9[1], b10))
                                                                                return True
                    else:
                         if util.checkBindFolderInsideFolder(b3):
                             for k1, v1 in b3.iteritems():
                                 if k1 == const.VALUE:
                                     for k2, v2 in v1.iteritems():
                                         if k2[0] == const.FOLDER and k2[1] == bindObj:
                                             for k3, v3 in v2.iteritems():
                                                 if k3 == const.VALUE:
                                                     for k4, v4 in v3.iteritems():
                                                         if k4[0] == const.MREL and k4[1] == keyName:
                                                             for k5, v5 in v4.iteritems():
                                                                 if k5 == const.TARGET and v5 == instVal:
                                                                     #logger.debug('Bind object found bind obj = %s, keyName = %s, instVal = %s' % (k2[1], k4[1], v5)) 
                                                                     return True

    # if execution reaches here then bind object not found
    return False                                                                        
#
# get bind target value from the collection
#
def getVLANInfBindForVLANAPIC(devCfg, vlanVal, instVal, nodeName, logger):
    """
    This is to get VLAN interface bindings from APIC for given VLAN
    """
    #logger.debug('+++ get VLAN interface binding +++++')

    retCol = {}
    retList = []
    deviceAuditFlag = True
    createObjCol = {}
    respCode = {}
    configOrderCol = {}
        # create the VLANs 
    tagCol = {}
    tmpCode = {}

    # now get VIF object for this node
    vifObjCol = util.getStateSpecificNodeVIFsFromConfig(const.CREATE, nodeName, devCfg, logger, deviceAuditFlag)
    #logger.debug('++++++++ VIFs for nodeName = %s, VIFs = %s' % (nodeName, vifObjCol))
    tmpList = []
    for r1, s1 in vifObjCol.iteritems():
        encapCol = {}
        # here s1 is the dict of type VIFs such as {'ADC1': '1_1'} 
        vifNum = s1[nodeName]
        vifNum = vifNum.replace('_', '/')
        # here r1 is object name 
        encapCol = util.getStateSpecificVIFEncapassFromConfig(const.CREATE, r1[1], devCfg, logger, deviceAuditFlag)
        #logger.debug('++++++++ ENCAP collection for VIF object = %s, encapass collection = %s' % (r1[1], encapCol))
        for r2, s2 in encapCol.iteritems():
            keyTuple = r2
            tmpCol = {}
            for r3, s3 in s2.iteritems():
                if r3.strip().lower() == const.ENCAP:
                    # now get the IFC tags based on the encap object name 
                    tagObjName = s3
                    tagCol = {}
                    tmpCol = {}
                    tagCol = util.getStateSpecificEncapTagFromConfig(const.CREATE, tagObjName, devCfg, logger, deviceAuditFlag)
                        # get the tag value from collection 
                    for i1, j1 in tagCol.iteritems():
                        # compare this VLAN id passed as param
                        if vlanVal  == j1: # here the assumption is VLAN_INTERFACE_BINDING
                            tmpCol[const.ID] = j1
                            tmpCol[const.IFNUM] = vifNum
                    retCol[tagObjName] = tmpCol
    logger.debug('VLAN interface binding collection from APIC = %s' % (retCol))
    return retCol

#
# get Bind object collection from NITRO Response
#
def getBindColFromResponse(bindCol, bindName, logger):
    """
    This is to get bind collection from the response
    """
    #logger.debug('++++ bind collection from NITRO response = %s' % (bindCol))
    retCol = {}
    tmpErrCode = None
    tmpBindList = []
    for a1, b1 in bindCol.iteritems():
        if a1 == const.ERRORCODE:
            tmpErrCode = b1
        elif a1 == bindName:
            tmpBindList = b1
    for i in tmpBindList:
        for m1, n1 in i.iteritems():
            if m1.find(const.FINDING) != -1:
               retCol[m1] = n1

    #logger.debug('Bind collection from NITRO response = %s' % (retCol))
    
    return retCol

#
# get the object bindings from device
#                            
def getObjectBindingsFromNetScaler(devCfg, objName, keyVal, url, devIp, sesId, logger, nodeName=None):
    """
    This is to get object's bindings from the NetScaler
    """
    #logger.debug('Getting bind collection for object type = %s object name = %s' % (objName, keyVal))
    retCol = {}
    bindCol = {}
    tmpBindCol = {}
    bindKeyCol = constKey.bindObjOrder
    tmpRespCol = {}
    bindName = objName + '_binding'
    bindCol = nitro.getObjectsBinding(bindName, keyVal, url, devIp, sesId, logger)
    #tmpBindCol = getBindColFromResponse(bindCol, bindName, logger)
    #logger.debug('bind collection from NetScaler = %s' % (tmpBindCol))
    # get the binding from the
    for a1, b1 in bindCol.iteritems():
        tmpCol = {}
        bindObj = a1  # here a1 will bind object i.e. vlan_nsip_binding
        bindKey = None
        bindKey = getBindKeyFromConst(bindObj, logger) 
        #logger.debug('BIND Objects key = %s' % (bindKey))
        # now look for this binding in APIC config 
        for i in b1:
            bolResp = False
            instVal = None
            instVal = getNSKeyValueFromCollection(bindKey, i, logger) # here is a dict of bind attributes
	    if instVal is None:
	        continue
            #logger.debug('Bind Key = %s, inst val = %s, I = %s' % (bindKey, instVal, i))
            bolResp = findBindObjectInAPICConfig(devCfg, bindObj, keyVal, bindKey, instVal, url, devIp, sesId, logger, nodeName)
	    #logger.debug('Bool Response from Find object = %s retCol = %s' % (bolResp, retCol))
            if bolResp is False:
                retCol[(a1,bindKey,instVal, keyVal)] = (keyVal, instVal)
    logger.debug('Bind object not in APIC = %s' % (retCol))             
    return retCol 

#
# get bind Object's binding i.e. lbvserver_service_binding from NetScaler
#
def getBindingsForBindObject(bindName, keyVal, url, devIp, sesId, logger):
    """
    This is to get binding details from the device
    """
    #logger.debug('Get objects binding from NetScaler = %s' % (keyVal))
    retCol = {}
    bindCol = {}
    tmpBindCol = {}
    bindKeyCol = constKey.bindObjOrder
    tmpRespCol = {}

    bindCol = nitro.getBindObjectsBinding(bindName, keyVal, url, devIp, sesId, logger)
    for a1, b1 in bindCol.iteritems():
        tmpCol = {}
        bindObj = a1
        bindKey = None
        bindKey = getBindKeyFromConst(a1, logger)
        #logger.debug('BIND objects key = %s' % (bindKey))
        for i in b1:
            bolResp = False
            instVal = None
            instVal = getNSKeyValueFromCollection(bindKey, i, logger) # here is a dict of bind attributes 
	    if instVal is None:
	        continue
            #logger.debug('Bind Key = %s, inst val = %s, I = %s' % (bindKey, instVal, i))
            if (instVal):
                retCol[(bindName, keyVal, instVal)] = (keyVal, instVal)

    #logger.debug('++++++++ Binding objects return results = %s' % (retCol))
    return retCol
#
# This is to get bind key
#
def getBindKeyFromConst(keyName, logger):
    """
    This is to get bind key from const definition
    """
    #logger.debug('Get bind key from const for = %s' % (keyName))
    bindKeyCol = constKey.bindObjOrder
    for i in bindKeyCol:
        tmpTuple = i # key is tuple
        if tmpTuple[0] == keyName:
            keyTup = tmpTuple[1]
            #logger.debug('Bind key found = %s' % (keyTup))
            return keyTup

    # if execution is here that means not found
    return None

#
# get the delete collection 
#    
def computeDelete(cnfg, deviceCol, url, devIp, sesId, logger):
    """
    This is to compute delete collection by looking at NetScaler's config
    """
    keyList = []
    keyList = const.CLUSTER_OBJECTS_LIST
    delCol = {}
    retCol = {}
    for i in reversed(keyList):    
        objectName = i
        # get the object instance from NetScaler 
        if (objectName):
            objCol = {}
            #logger.debug('lbvserver object Name = %s' % (objectName))
            objCol = getNSObjectFromDevice(objectName, url, devIp, sesId, logger)
            # check for default
            defResp = False
            defResp = checkForDefaultObject(objCol[objectName], logger)
            if defResp:
                logger.debug('Default object ignore...... objectName = %s' % (objectName))
                continue
            # process object 
            tmpCol = {}
            tmpCol = processObjectForDelete(objectName, objCol[objectName], deviceCol, cnfg, url, devIp, sesId, logger)
            delCol = dict(tmpCol.items() + delCol.items())

    logger.debug('+++ Config Delete Collection = %s' % (delCol))
    return delCol
#
# this is to check if the object is default
#
def checkForDefaultObject(objCol, logger):
    """
    This is to check if this is the default object 
    """
    for i in objCol:
        tmpObj = i
        if type(tmpObj) is dict:
            if tmpObj.has_key(const.ISDEFAULT):
                if bool(tmpObj[const.ISDEFAULT]) == True:
                    return True
    # if the execution reaches here then it is not default
    return False

#
# get vlan_interface_binding collection from the APIC config
#
def getVLANInfBindFromAPIC(devCfg, nodeName, virtualFlag, url, devIp, sesId, logger):
    """
    This is to get vlan_interface_binding from the APIC config
    """
    #logger.debug('++++++ Get VLAN interface binding ++++++')
   
    retCol = {}
    retList = []
    deviceAuditFlag = True
    createObjCol = {}
    respCode = {}
    configOrderCol = {}
        # create the VLANs
    tagCol = {}
    tmpCode = {}
    tagCol = util.getStateSpecificVLANFromConfig(const.CREATE, devCfg, logger, deviceAuditFlag)
        
        # now get VIF object for this node
    vifObjCol = util.getStateSpecificNodeVIFsFromConfig(const.CREATE, nodeName, devCfg, logger, deviceAuditFlag)
    #logger.debug('++++++++ VIFs for nodeName = %s, VIFs = %s' % (nodeName, vifObjCol))
    tmpList = []
    for r1, s1 in vifObjCol.iteritems():
        encapCol = {}
        # here s1 is the dict of type VIFs such as {'ADC1': '1_1'}
        vifNum = s1[nodeName]
        vifNum = vifNum.replace('_', '/')
        # here r1 is object name
        encapCol = util.getStateSpecificVIFEncapassFromConfig(const.CREATE, r1[1], devCfg, logger, deviceAuditFlag)
        logger.debug('++++++++ ENCAP collection for VIF object = %s, encapass collection = %s' % (r1[1], encapCol))
        for r2, s2 in encapCol.iteritems():
            keyTuple = r2
            tmpCol = {}
            for r3, s3 in s2.iteritems():
                if r3.strip().lower() == const.ENCAP:
                    # now get the IFC tags based on the encap object name
                    tagObjName = s3
                    tagCol = {}
                    tmpCol = {}
                    tagCol = util.getStateSpecificEncapTagFromConfig(const.CREATE, tagObjName, devCfg, logger, deviceAuditFlag)
                        # get the tag value from collection
                    for i1, j1 in tagCol.iteritems():
                        tmpCol[const.ID] = j1
                        tmpCol[const.IFNUM] = vifNum
                        # get the vlan_interface_binding for this vlan 
                        devBindCol = {}
                        devBindCol = getBindingsForBindObject(const.VLAN_INTERFACE_BIND_NAME, tmpCol, url, devIp, sesId, logger)
                        if len(devBindCol) > 0:
                            findFlag = False
                            for x1, y1 in devBindCol.iteritems():
                                # compare the device details with APIC
                                # device reponse in this format ('vlan_interface_binding', '308', 1/3): ('308', '1/3')
                                if tmpCol[const.IFNUM] == y1:
                                    findFlag = True
                                    #logger.debug('........VLAN_INTERFACE_BINDING exist ignoring ........ Key = %s Value = %s' % (x1,y1))
                            if findFlag == False:
                                 if virtualFlag is False: # since tagged is only supported on MPX not on VPX 
                                     tmpCol[const.TAGGED] = True
                                 retCol[keyTuple] = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, tmpCol, url, devIp, sesId, logger)
                        else:
                            # bind this VLAN with IFNUM
                            #logger.debug('VLAN_INTERFACE_BIND does not exist adding in device........')
                            if virtualFlag is False: # since tagged is only supported on MPX not on VPX
                                tmpCol[const.TAGGED] = True
                            retCol[keyTuple] = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, tmpCol, url, devIp, sesId, logger)
 
    logger.debug('++++++++ VLAN interface binding collection = %s' % (retCol))
    return retCol
#
# get the VLAN bindings from the device
#
def getVLANBindingsFromDevice(nodeName, nodeSesId, nodeUrl, nodeIp, vlanCol, logger):
    """
    This is to get VLAN's binding from the device
    """
    #logger.debug('+++ get VLAN bindings for Node = %s, Node IP = %s' % (nodeName, nodeIp))
    retCol = {}
    for a1, b1 in vlanCol.iteritems():
        tmpList = b1 # since b1 is list here
        for i in b1:
            vlanId = None
            ifNum = None
            devVlanCol = {}
            bindTmpCol = {}
            if type(i) is dict:
                for a2, b2 in i.iteritems():
                    if a2 == const.ID:
                        vlanId = b2
                    elif a2 == const.IFNUM:
                        ifNum = b2
                # now get the vlan interface binding from NetScaler
                devVlanCol = {}
                devVlanCol = getBindingsForBindObject(const.VLAN_INTERFACE_BIND_NAME, str(vlanId), nodeUrl, nodeIp, nodeSesId, logger)
                # compare this with VLAN details from APIC
                if len(devVlanCol) > 0:
                 retCol =  compareVLANBindings(vlanCol, devVlanCol, logger)
    return retCol

#
# compare the VLANs from APIC & device
#
def compareVLANBindings(apicCol, devCol, logger):
    """
    This is to compare VLAN bindings from APIC and device
    """
    #logger.debug('+++++ Binding collection to compare APIC col = %s, Device Col = %s' % (apicCol, devCol))
    unBindCol = {}
    retCol = {}
    for a1, b1 in apicCol.iteritems():
        bindList = []
        for i in b1: # since this is list
            idVal = None
            ifNumVal = None
            for a2, b2 in i.iteritems():
                if a2 == const.ID:
                    idVal = b2
                elif a2 == const.IFNUM:
                    ifNumVal = b2
            # compare this with device
            foundFlag = False
            for k1, v1 in devCol.iteritems():
                # device vlan binding details are in following format 
                # ('vlan_interface_binding', u'1/1'): ('303', u'1/1')
                if idVal == k1[1]: # check for the VLAN
                    if ifNumVal == v1[0]: 
                        foundFlag = True
            if foundFlag is False:
                # add new binding in NetScaler 
                # remove existing bind from device
                bindList.append(i)
        if len(bindList) > 0:
            retCol[a1] = bindList

    #logger.debug('Compare VLAN return results = %s' % (retCol))
                    
    return retCol
#
# get APIC's VLAN_NSIP binding
#
def getFunctionSpecificVLANNSIPBinding(cnfg, url, devIp, sesId, logger):
    """
    This is to get function specific VLAN and NSIP binding
    """
    retCol = {}
    extCol = {}
    inCol = {}
    # get external network and connector for each function
    extCol = util.getNetworkNConnectorFromConfig(const.EXTERNAL, cnfg, logger)
    intCol = util.getNetworkNConnectorFromConfig(const.INTERNAL, cnfg, logger)

    tmpCol = {}
    tmpCol = getNSIPVLANBindCol(extCol, cnfg, url, devIp, sesId, logger)
    retCol = dict(tmpCol.items() + retCol.items())
    tmpCol = {}
    tmpCol = getNSIPVLANBindCol(intCol,cnfg, url, devIp, sesId, logger)
    retCol = dict(tmpCol.items() + retCol.items())    

    return retCol
#
# compare VLAN NSIP binding between Device & APIC
#
def compareNSVLANBindFromDevice(cnfg, keyVal, instVal, url, devIp, sesId, logger):
    """
    This is to compare VLAN NSIP bind from device to APIC
    """
    devCol = {}
    apicCol = {}
    devCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(keyVal), url, devIp, sesId, logger)
    if len(devCol) > 0:
        extCol = {}
        inCol = {}
        # get external network and connector for each function
        extCol = util.getNetworkNConnectorFromConfig(const.EXTERNAL, cnfg, logger)
        intCol = util.getNetworkNConnectorFromConfig(const.INTERNAL, cnfg, logger)

        tmpCol = {}
        tmpCol = getVLANNSIPBindFromAPIC(extCol, keyVal, cnfg, url, devIp, sesId, logger)
        apicCol = dict(tmpCol.items() + apicCol.items())
        tmpCol = {}
        tmpCol = getVLANNSIPBindFromAPIC(intCol, keyVal, cnfg, url, devIp, sesId, logger)
        apicCol = dict(tmpCol.items() + apicCol.items())
        if len(apicCol) > 0:
            #logger.debug('Collection for vlan_nsip_binding apic = %s, device = %s' % (apicCol, devCol))
            # compare device collection with APIC collection
            for i1, j1 in devCol.iteritems():
                # device collection format (bindName, keyVal, instVal)] = (keyVal, instVal)
                #{('vlan_nsip_binding', '555', u'3.4.5.6'): ('555', u'3.4.5.6')} 
                tmpVal = j1[1]
                for i2, j2 in apicCol.iteritems():
                    # APIC return collection {'netmask': '255.255.255.0', 'ipaddress': '10.4.1.5', 'id': 308}
                    if j1[1] == j2[const.IPADDRESS]:
                            return True

    # if execution reaches here that means not found
    return False

#
# get IPVLANBind from APIC config
#
def getNSIPVLANBindCol(conCol, cnfg, url, devIp, sesId, logger):
    """
    This is to get NSIPVLAN binding from APIC config
    """
    retCol = {}
    # check for the state and if it is create get the object and bind them
    for i1, j1 in conCol.iteritems():
        netObj = None
        conObj = None
        netStat = -1
        # key is function name
        #funName = i1
        for i2, j2 in j1.iteritems():
            #self.logger.debug(' i2 = %s, j2 = %s' % (i2,j2))
            # key will be network with state i.e. ('network/snip2', 1)
            netObj = i2[0]
            # remove the '/' from name and just get the value
            if netObj.find('/'):
                netObj = netObj[netObj.rfind('/') + 1:]
            netStat = i2[1]
            conObj = j2
        #logger.debug('Details netObj = %s, conObj = %s, netStat = %s' % (netObj, conObj, netStat))
        # now get the object from config
        netObjCol = util.getCompleteObjectFromSubFolderConfig(const.NETWORK, netObj, cnfg, logger)
        conObjCol = util.getCompleteObjectFromConfig(conObj, cnfg)
        #logger.debug('Network object = %s  Connector object = %s' % (netObjCol, conObjCol))
        ipValCol = util.getAttributeCollectionForObject(netObjCol, cnfg, logger)
        #logger.debug(' Network object Attribute Value = %s' % (ipValCol))
        # get the ipaddress and netmask from the ipValCol
        bindCol = {}
        argStr = None
        for l1, m1 in ipValCol.iteritems():
            for l2, m2 in m1.iteritems():
                if l2 == const.IPADDRESS:
                    bindCol[const.IPADDRESS] = m2
                elif l2 == const.NETMASK:
                    bindCol[const.NETMASK] = m2
        bindCol[const.ID] = conObj
        #logger.debug('++++ NSIP VLAN Binding details = %s' % (bindCol))
        # get the vlan_nsip_binding from NetScaler 
        tmpCol = {}
        tmpCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(conObj), url, devIp, sesId, logger)
        #logger.debug(' NSIP VLAN Binding from device = %s' % (tmpCol))
        # compare the device details with APIC
        # device reponse in this format ('vlan_nsip_binding', '308'): ('308', u'10.10.10.100')
        findFlag = False
        if len(tmpCol) > 0:
            for x1, y1 in tmpCol.iteritems():
                if bindCol[const.IPADDRESS] == y1[1]:
                    findFlag = True
        if findFlag is False:
            # add this Bind and remove the existing bind from NetScaler
            retCol[(const.VLAN_NSIP_BINDING, conObj)] = nitro.createBindObject(const.VLAN_NSIP_BINDING, bindCol, url, devIp, sesId, logger)
                    # unBind - Existing NetS
    logger.debug('VLAN_NSIP_Binding collection = %s' % (retCol))
    return retCol 
#
# get NSIP Bind col from APIC using connector
#
def getVLANNSIPBindFromAPIC(conCol, vlanVal, cnfg, url, devIp, sesId, logger):
    """
    This is to get VLAN NSIP bind col from APIC config since they are based on connector
    """
    retCol = {}
    # check for the state and if it is create get the object and bind them
    for i1, j1 in conCol.iteritems():
        netObj = None
        conObj = None
        netStat = -1
        # key is function name 
        #funName = i1
        for i2, j2 in j1.iteritems():
            #self.logger.debug(' i2 = %s, j2 = %s' % (i2,j2))
            # key will be network with state i.e. ('network/snip2', 1)
            netObj = i2[0]
            # remove the '/' from name and just get the value
            if netObj.find('/'):
                netObj = netObj[netObj.rfind('/') + 1:]
            netStat = i2[1]
            conObj = j2
            if conObj != vlanVal:
                continue
        #logger.debug('Details netObj = %s, conObj = %s, netStat = %s' % (netObj, conObj, netStat))
        # now get the object from config
        netObjCol = util.getCompleteObjectFromSubFolderConfig(const.NETWORK, netObj, cnfg, logger)
        conObjCol = util.getCompleteObjectFromConfig(conObj, cnfg)
        #logger.debug(' Network object = %s  Connector object = %s' % (netObjCol, conObjCol))
        ipValCol = util.getAttributeCollectionForObject(netObjCol, cnfg, logger)
        #logger.debug(' Network object Attribute Value = %s' % (ipValCol))
        # get the ipaddress and netmask from the ipValCol
        bindCol = {}
        argStr = None
        for l1, m1 in ipValCol.iteritems():
            for l2, m2 in m1.iteritems():
                if l2 == const.IPADDRESS:
                    bindCol[const.IPADDRESS] = m2
                elif l2 == const.NETMASK:
                    bindCol[const.NETMASK] = m2
        bindCol[const.ID] = conObj
        #logger.debug('++++ NSIP VLAN Binding details from APIC = %s' % (bindCol))

        # get the vlan_nsip_binding from NetScaler
        #tmpCol = {}
        #tmpCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(conObj), url, devIp, sesId, logger)
        #logger.debug(' NSIP VLAN Binding from APIC = %s' % (tmpCol))    
        retCol[i1] = bindCol
    return retCol

if __name__ == '__main__':
    lgObj = LogService()
    log1 = lgObj.getLogger()
    computeModify(None, None, None, log1)
                     


