#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import sys
import traceback
import json

import scriptConst as const
from feature import genericNitro
import configUtil as util


#
# Set generic object using NITRO APIs
#

def setConfigObjects(objKey, attrCol, url, devIp, sesId, logger):
    logger.debug('+++++++++++++ set Config objects ------- objectName = %s, attribute details = %s' %(objKey, attrCol))
    # this is to remove any key which has underscore in the name i.e. action_filteraction
    tAtrCol = {}
    for a1, b1 in attrCol.iteritems():
        if a1.find('_') != -1:
            # remove the string followed by the underscore
            tmpKey = a1[:a1.find('_')]
            tAtrCol[tmpKey] = b1
        else:
            tAtrCol[a1] = b1
    attrCol = tAtrCol # put it back to original collection
    logger.debug('+++ Object Attribute Collection = %s'% (attrCol))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode[objKey] = nsGenSerObj.setNitroParams(objKey, attrCol, url, devIp, sesId)
        #respDat = respDat.json()
        #resCode = respDat[self.ERRORCODE]
    except Exception as exMsg:
        logger.error('Exception from setConfigObjects = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objKey] = retCol
    
    return resCode

#
# UnSet generic object using NITRO APIs
#

def unsetConfigObjects(objKey, attrCol, url, devIp, sesId, logger):
    logger.debug('+++++++++++++ unset Config objects ------- objectName = %s, attribute details = %s' %(objKey, attrCol))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode[objKey] = nsGenSerObj.unsetNitroParams(objKey, attrCol, url, devIp, sesId)
        #respDat = respDat.json()
        #resCode = respDat[self.ERRORCODE]
        #resp = resCode[objKey]
        #errCode = resp["errorcode"]
    except Exception as exMsg:
        logger.error('Exception from unsetConfigObjects = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objKey] = retCol
    #logger.debug('objKey= %s, errCode=%s' % (objKey, errCode))

    #if objKey == "service" and errCode == 278:  
    #    logger.debug('Raise Exception from unsetConfigObjects for service')
    #    errorMsg = "unsupported configuration "+','.join(['%s:: %s' % (key, value) for (key, value) in attrCol.items()])
    #    raise Exception (errorMsg)

    
    return resCode
#
# Create generic object using NITRO APIs 
# 

def createConfigObjects(objKey, attrCol, url, devIp, sesId, logger):
    logger.debug('+++++++++++++ Create Config objects ------- objectName = %s, attribute details = %s' %(objKey, attrCol))
    # this is to remove any key which has underscore in the name i.e. action_filteraction
    tAtrCol = {}
    for a1, b1 in attrCol.iteritems():
        if a1.find('_') != -1:
            # remove the string followed by the underscore
            tmpKey = a1[:a1.find('_')]
            tAtrCol[tmpKey] = b1
        else:
            tAtrCol[a1] = b1
    attrCol = tAtrCol # put it back to original collection
    logger.debug('+++ Object Attribute Collection = %s'% (attrCol))
    resCode = {}
    try:
        if objKey == "vlan":
            attrCol["ipv6dynamicrouting"] = "ENABLED"
            attrCol["dynamicRouting"] = "ENABLED"
        argTup = util.getSetArg(objKey, logger)
	logger.debug('Argument Tuple = %s' % (str(argTup)))
        if util.getObjAdd(argTup, logger):
            addAttrCol = dict(attrCol)
            logger.debug('Add Attr col = %s' % (addAttrCol))
            setAttrCol = {} 
            for key, value in attrCol.iteritems():
                retTup = util.getParamSetOnly(argTup, key, logger)
	        #logger.debug('Ret Tup = %s' % (str(retTup)))
                if not (retTup is None):
                    del addAttrCol[key]
                    if setAttrCol == {}:
                        for setuid in retTup:
                            # here check if the attribute collection has the particular key in it or not
                            if setuid in attrCol:
                                setAttrCol[setuid] = attrCol[setuid]
                    setAttrCol[key] = value           
            nsGenSerObj = genericNitro.NitroMapper(logger)
            resCode[objKey] = nsGenSerObj.addNitroObject(objKey, addAttrCol, url, devIp, sesId)
            if setAttrCol != {}:
                resCode[objKey] = nsGenSerObj.setNitroParams(objKey, setAttrCol, url, devIp, sesId)
        # This object does not have add operation in Nitro, use set    
        else:
            nsGenSerObj = genericNitro.NitroMapper(logger)
            resCode[objKey] = nsGenSerObj.setNitroParams(objKey, attrCol, url, devIp, sesId)
        
        #respDat = respDat.json() 
        #resCode = respDat[self.ERRORCODE]
    except Exception as exMsg:
        logger.error('Exception from createConfigObjects = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objKey] = retCol

    return resCode

#
# Handle Binding relations
#
def createBindObject(bindObjName, bindCol, url, devIp, sesId, logger):
    logger.debug('+++++++++++ Binding objectName = %s, collection = %s' % (bindObjName, bindCol))
    resCode = {}
    try :
        nsGenSerObj = genericNitro.NitroMapper(logger)
        if len(bindCol) > 0: # if there are any binding object 
            resCode[bindObjName] = nsGenSerObj.addNitroBinding(bindObjName, bindCol, url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from createBindObjects = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[bindObjName] = retCol

    return resCode

#
# Remove nitro object from the NetScaler this includes unbind as well 
#                                                                                                                           
def removeNitroObject(objName, objVal, args, url, devIp, sesId, logger):
    logger.debug('+++++++++++ Remove  objectName = %s, collection = %s Args = %s' % (objName, objVal, args))
    resCode = {}
    try :
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode[objName] = nsGenSerObj.removeNitroObject(objName, objVal, args, url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from removeNitroObject = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objName] = retCol

    return resCode

#
# This is for EP Attach
#
def bindSGPortIPForEpAttach(sgPortCol, ep, url, devIp, sesId, logger):
    logger.debug('+++++++++++ Bind SG port IP for EP Attach = %s' % (sgPortCol))
    respCode = {}
    # now bind the service group, IP and port
    for l1, m1 in sgPortCol.iteritems():
        bindCol = {}
        tmpCol = {}
        bindCol[const.SERVICEGROUPNAME] = l1
        bindCol[const.PORT] = m1
        bindCol[const.IP] = ep
        tmpCol = createBindObject(const.SVCGROUP_SGMEM_BIND, bindCol, url, devIp, sesId, logger)
	respCode = dict(respCode.items() + tmpCol.items())

    return respCode

#
# This is for EP Attach
#
def unbindSGPortIPForEpDetach(sgPortCol, ep, url, devIp, sesId, logger):
    logger.debug('+++++++++++ Unbind SG port IP for EP detach = %s' % (sgPortCol))
    respCode = {}
    # now unbind the service group, IP and port
    bindCol = {}
    for l1, m1 in sgPortCol.iteritems():
        args = 'args='  + const.IP + ':' + ep + ',' + const.PORT + ':' + m1 
        bindCol[const.IP] = ep
        respCode[l1] = removeNitroObject(const.SVCGROUP_SGMEM_BIND, l1, args, url, devIp, sesId, logger)

    return respCode

#
#
# This is to get Interface stat from NetScaler
#
def getInterfaceStat(objName, objVal, url, devIp, sesId, logger):
    logger.debug('+++++++++++++ Get Interface Stat for Config object ------- objectName = %s, instance name = %s' %(objName, objVal))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode = nsGenSerObj.getInterfaceStat(objName, objVal, url, devIp, sesId)
        #respDat = respDat.json() 
        #resCode = respDat[self.ERRORCODE]
    except Exception as exMsg:
        logger.error('Exception from getInterfaceStat = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objName] = retCol

    return resCode
#
#
# This is to get stat from NetScaler
#
def getStats(objName, objVal, url, devIp, sesId, logger):
    logger.debug('+++++++++++++ Get Stat for Config object ------- objectName = %s, instance name = %s' %(objName, objVal))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode = nsGenSerObj.getNitroStat(objName, objVal, url, devIp, sesId)
        #respDat = respDat.json() 
        #resCode = respDat[self.ERRORCODE]
    except Exception as exMsg:
        logger.error('Exception from getStats = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objName] = retCol

    return resCode
#
#
# This is to get member stat from NetScaler
#
def getMemberStats(objName, objVal, url, devIp, sesId, logger):
    logger.debug('+++++++++++++ Get Member Stat for Config object ------- objectName = %s, param details  = %s' %(objName, objVal))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode = nsGenSerObj.getNitroMemberStat(objName, objVal, url, devIp, sesId)
        #respDat = respDat.json() 
        #resCode = respDat[self.ERRORCODE]
    except Exception as exMsg:
        logger.error('Exception from getMemberStats = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objName] = retCol

    return resCode

#
# This is to send ARP request from NetScaler
#
def sendArpPostRequest(ipAdr, allBoolVal, url, devIp, sesId, logger):
    """
    This is to send ARP request from device for a given Ip address or all
    """

    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[ipAdr] = nsGenObj.sendArp(ipAdr, allBoolVal, url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from sendArpPostRequest = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[ipAdr] = retCol

    return resCode

#
# This is to execute CLI types of commands via NITRO in NetScaler
#
def postCLIRequest(payload, url, devIp, sesId, logger):
    """
    This is to send CLI request from device such as apply nspbrs 
    """

    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[devIp] = nsGenObj.executeCLI(payload, url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from postCLIRequest  = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[devIp] = retCol

    return resCode

#
# This is to save config in NetScaler
#
def saveNSConfig(url, devIp, sesId, logger):
    """
    This is to save config in NetScaler 
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[devIp] = nsGenObj.saveConfig(url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from saveConfig = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[devIp] = retCol

    return resCode

#
# This is to save config in NetScaler
#
def applyNsAcls(url, devIp, sesId, logger):
    """
    This is to apply ns acls in NetScaler 
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[devIp] = nsGenObj.applyAcls(url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from applyNsAcls = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[devIp] = retCol

    return resCode

#
# This is to save config in NetScaler
#
def applyNsAcls6(url, devIp, sesId, logger):
    """
    This is to save config in NetScaler 
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[devIp] = nsGenObj.applyAcls6(url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from applyNsAcl6 = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[devIp] = retCol

    return resCode

#
# This is to get device configuration from the NetScaler
#
def getObjectsConfigFromDevice(objName, url, devIp, sesId, logger):
    """
    This is to get object's detail from device
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[objName]  = nsGenObj.getNitroObjectsConfigFromDevice(objName, url, devIp, sesId)
        logger.debug('++++ Get Objects Config From Device = %s ' % (resCode[objName]))

    except Exception as exMsg:
        logger.error('Exception from getObjectsConfigFromDevice = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objName] = retCol

    return resCode
#
# This is to get instance details from device configuration 
#
def getInstanceConfigFromDevice(objName, instName, url, devIp, sesId, logger):
    """
    This is to get object's instance detail from device
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[objName]  = nsGenObj.getNitroInstanceFromDevice(objName, instName, url, devIp, sesId)
        #logger.debug('++++ Get instance Config From Device = %s ' % (tmpResp[objName]))

    except Exception as exMsg:
        logger.error('Exception from getInstanceConfigFromDevice = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objName] = retCol

    return resCode

#
# This is to get bindings for object
#
def getObjectsBinding(objName, objVal, url, devIp, sesId, logger):
    """
    This is to get objects binding for an object
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        tmpResp  = nsGenObj.getNitroBindingsForObject(objName, objVal, url, devIp, sesId)
        #logger.debug('++++ Get Objects Binding Config From Device = %s ' % (tmpResp[objName]))                                                                              
        try:
            if tmpResp[const.ERRORCODE] == 0:
                # look for binding keys in the dict 
                tmpCol = tmpResp[objName]
                if type(tmpCol) is list:
                    for tmpListVal in tmpCol:
                        for k1, v1 in tmpListVal.iteritems():
                            if k1.find(const.BINDING) != -1 and v1 is not None:
                                resCode[k1] = v1
            else:
               logger.debug('+++++++ Error in Binding Response = %s' % (tmpResp))
        except KeyError:
            logger.debug('+++++++++ Key not found for object = %s ' % (objName))

    except Exception as exMsg:
        logger.error('Exception from getObjectsBinding = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[objName] = retCol

    return resCode

#
# This is to get bind object's bindings for example lbvserver_service_bind
#
def getBindObjectsBinding(objName, objVal, url, devIp, sesId, logger):
    """
    This is to get bind objects binding for an example vlan_interface_binding
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        tmpResp  = nsGenObj.getNitroBindingsForObject(objName, objVal, url, devIp, sesId)
        #logger.debug('++++ Get Objects Binding Config From Device = %s ' % (tmpResp[objName]))                                                                              
        try:
            if tmpResp[const.ERRORCODE] == 0:
                # look for binding keys in the dict 
                resCode[objName] = tmpResp[objName]
        except KeyError:
            logger.debug('+++++++++ Key not found for object = %s ' % (objName))

    except Exception as exMsg:
        logger.error('Exception from getBindObjectsBinding = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[objName] = retCol

    return resCode

#
# This is to do clear config from NetScaler
#
def clearConfigFromDevice(url, devIp, cfgLevel, sesId, logger):
    """
    This is to clear config from NetScaler device
    """
    resCode = {}

    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        tmpResp  = nsGenObj.doClearConfigFromNetScaler(url, devIp, cfgLevel, sesId)
        resCode[devIp] = tmpResp
    except Exception as exMsg:
        logger.error('Exception from clear config from Device = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[devIp] = retCol
        
    return resCode

#
# This is to remove all VLANs from NetScaler
#
def clearVLANsFromNS(url, devIp, sesId, logger):
    """
    This is to clear all VLANs from NetScaler
    """
    
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        tmpResp = nsGenObj.removeAllVLANs(url, devIp, sesId)
        resCode[devIp] = tmpResp
    except Exception as exMsg:
        logger.error('Exception from clear VLANs from Device = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[devIp] = retCol
    
    return resCode

#
# This is to get instance details using filter from device configuration 
#
def getInstanceByFilterFromDevice(objName, paramName, paramVal, url, devIp, sesId, logger):
    """
    This is to get object's instance details using filter from device
    """
    resCode = {}
    try:
        nsGenObj = genericNitro.NitroMapper(logger)
        resCode[objName]  = nsGenObj.getNitroInstanceByFilterFromDevice(objName, paramName, paramVal, url, devIp, sesId)
        #logger.debug('++++ Get instance by filter From Device = %s ' % (tmpResp[objName]))

    except Exception as exMsg:
        logger.error('Exception from getInstanceByFilterFromDevice = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objName] = retCol

    return resCode



    
#
# Switch generic object using NITRO APIs
#

def switchConfigObjects(objKey, attrCol, url, devIp, sesId, logger):
    logger.debug('+++++++++++++ switch Config objects ------- objectName = %s, attribute details = %s' %(objKey, attrCol))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode[objKey] = nsGenSerObj.switchNitroParams(objKey, attrCol, url, devIp, sesId)
    except Exception as exMsg:
        logger.error('Exception from switchConfigObjects = %s' % str(exMsg))
	retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

	resCode[objKey] = retCol
    return resCode
