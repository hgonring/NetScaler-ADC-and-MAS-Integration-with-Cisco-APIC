#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import unittest

import nitroUtil
import NSLogin
import LogService

#
# This is to unit nitroUtil class
#

class TestNitroUtil(unittest.TestCase):
    """
    This is to unit test nitroUtil functions 
    """
    def setup(self):
        pass

#
# This is to unit test sendArp
#
    def test_a_sendArpReq(self):
        """
        This is to test send ARP
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.113.195" + "/nitro/v1/config/login" 10.102.201.141
        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        devIp = '10.102.201.141'
        #devIp = '10.102.113.195'
        epgIp = '10.1.1.1'
        #devArpResp = nitroUtil.sendArpPostRequest(epgIp, False, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ Device Arp response = %s' , devArpResp
        
        return

#
# This is to unit test clearVLANs
#
    def test_b_clearVlans(self):
        """
        This is to test clear VLANs from NS
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.113.195" + "/nitro/v1/config/login" 10.102.201.141
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        devIp = '10.102.102.51'
        #devIp = '10.102.113.195'
        #devArpResp = nitroUtil.clearVLANsFromNS(devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ Device clear VLANs response = %s' , devArpResp
#
# This is to unit test createObject
#
    def test_b_createObjects(self):
        """
        This is to test clear VLANs from NS
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.113.195" + "/nitro/v1/config/login" 10.102.201.141
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        sesId = nsLgObj.login()
        objKey = "nsip"
        atrCol = {"dynamicrouting": "ENABLED", "netmask": "255.255.255.0", "ipaddress": "10.4.193.5"}
        #objKey = "vlan_interface_binding"
        #atrCol =  {"ifnum": "1/5", "tagged": True, "id": 3717}
        devIp = '172.23.50.132'
        devArpResp = nitroUtil.createConfigObjects(objKey, atrCol, devIp, sesId, logger)
        nsLgObj.logout(sesId)
        print ' ++++ Device create response = %s' , devArpResp
        
        
if __name__ == '__main__':
    unittest.main()
