#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import unittest
import yaml

import NSServer
import NSDeviceScript
import DeviceScriptController
import NSLogin
import LogService
import auditConfig
import configUtil as util
import json

from util import vServerUtil 

from util import configUtil as util

#
# This is to unit Test auditConfig
#

class TestAuditConfig(unittest.TestCase):
    """
    This is to unit test audit config functions 
    """
    def setup(self):
        pass

#
# This is to unit test computeModify
#
    def test_b_computeModify(self):
        """
        This is to test compute modify function from auditConfig
        """
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #deviceFile = open('test/deviceVDataCisco.yaml', "r")
        deviceFile = open('test/deviceBLRData.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for m in deviceData:
            deviceCol = m
	rootKey = (7, '', '2097153_32897')
        #devIp = '172.23.50.132'
        devIp = '10.102.102.51'
	virtualFlag = False
        #auditData = open('test/vipulServiceModify_2.yaml', 'r')
        #auditData = open('test/vipulServiceModifyTestData.yaml', 'r')
        #auditData = open('test/auditTestData.yaml', 'r')
        auditData = open('test/auditIssue.yaml', 'r')
        ipUrl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
        #auditData = open('test/vipul300Graphs.yaml', 'r')
        genData = yaml.load_all(auditData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
                                           #(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
	#respObj = auditConfig.computeModify(serviceConfig, deviceCol, ipUrl, devIp, virtualFlag, sesId, logger)
	#respObj = auditConfig.computeDelete(serviceConfig, deviceCol, ipUrl, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ AuditDevice compute modify response = %s' , respObj
	#resp = util.getFaults(rootKey, respObj, logger)
	#print '+++++ Fault resp = ', resp

        return

#
# This is to unit test computeModify
#
    def test_a_computeDelete(self):
        """
        This is to test compute Delete function from auditConfig
        """
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.52" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        #deviceFile = open('test/deviceVDataCisco.yaml', "r")
        deviceFile = open('test/deviceBLRData.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for m in deviceData:
            deviceCol = m

        #devIp = '10.102.102.51'

        devIp = '10.102.102.52'
        #auditData = open('test/vipulServiceModify_2.yaml', 'r')
        #auditData = open('test/vipulServiceModifyTestData.yaml', 'r')
        #auditData = open('test/auditIssue.yaml', 'r')
        auditData = open('test/mgmtIpIssueAuditLog.yaml', 'r')
        #auditData = open('test/vipul300Graphs.yaml', 'r')
        #auditData = open('test/apicTestData_1.yaml', 'r')
        ipUrl = "http://" + "10.102.102.52" + "/nitro/v1/config/"
        genData = yaml.load_all(auditData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
	#respObj = auditConfig.computeDelete(serviceConfig, deviceCol, ipUrl, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ AuditDevice compute delete response = %s' , respObj

        return
#
# This is to unit test findBindObjectInAPICConfig
#
    def test_b_findBindObject(self):
        """
        This is to test find bind object 
        """
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()

        auditData = open('test/vipulServiceModifyTestData.yaml', 'r')
        genData = yaml.load_all(auditData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
	#respObj = auditConfig.findBindObjectInAPICConfig(serviceConfig, 'lbvserver_service_binding', 'servicename', 'webservice2_Epg705ctx0tn2', logger)
        #print ' ++++ AuditDevice find bind object response = %s' , respObj

        return
#
# This is to unit test checkForMgmt Access method
#
    def test_c_checkForMgmtAccess(self):
        """
        This is to test checkForMgmtAccess for NSIP
        """
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        devIp = '10.102.102.51'
        ipVal = '40.4.0.200'
        ipurl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
        #resp = auditConfig.checkForMgmtAccessForNSIP(ipVal, ipurl, devIp, sesId, logger)
	#print 'Check for mgmt access response = ', resp

        return
#
# this is for Attach IP 
#
    def test_c_computeModify(self):
        """
        This is to test compute modify function from auditConfig
        """
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.62" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #deviceFile = open('test/deviceVDataCisco.yaml', "r")
        deviceFile = open('test/deviceBLRData.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for m in deviceData:
            deviceCol = m
	rootKey = (7, '', '2097153_32897')
        #devIp = '172.23.50.132'
        devIp = '10.102.102.62'
	virtualFlag = False
        #auditData = open('test/vipulServiceModify_2.yaml', 'r')
        #auditData = open('test/vipulServiceModifyTestData.yaml', 'r')
        #auditData = open('test/auditTestData.yaml', 'r')
        auditData = open('test/raviEpAttachTestData.yaml', 'r')
        ipUrl = "http://" + "10.102.102.62" + "/nitro/v1/config/"
        #auditData = open('test/vipul300Graphs.yaml', 'r')
        genData = yaml.load_all(auditData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
                                           #(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
	#respObj = auditConfig.computeModifyForAttachIp(serviceConfig, deviceCol, ipUrl, devIp, virtualFlag, sesId, logger)
	#respObj = auditConfig.computeDelete(serviceConfig, deviceCol, ipUrl, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ AuditDevice compute modify for attach IP  response = %s' , respObj
	#resp = util.getFaults(rootKey, respObj, logger)
	#print '+++++ Fault resp = ', resp

        return

#
# this is for Attach IP 
#
    def test_d_computeDeleteforAttachIP(self):
        """
        This is to test compute modify function from auditConfig
        """
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.62" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #deviceFile = open('test/deviceVDataCisco.yaml', "r")
        deviceFile = open('test/deviceBLRData.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for m in deviceData:
            deviceCol = m
	rootKey = (7, '', '2097153_32897')
        #devIp = '172.23.50.132'
        devIp = '10.102.102.62'
	virtualFlag = False
        #auditData = open('test/vipulServiceModify_2.yaml', 'r')
        #auditData = open('test/vipulServiceModifyTestData.yaml', 'r')
        #auditData = open('test/auditTestData.yaml', 'r')
        auditData = open('test/raviEpAttachTestData.yaml', 'r')
        ipUrl = "http://" + "10.102.102.62" + "/nitro/v1/config/"
        #auditData = open('test/vipul300Graphs.yaml', 'r')
        genData = yaml.load_all(auditData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
            #(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
	#respObj = auditConfig.computeDeleteforAttachIp(serviceConfig, deviceCol, ipUrl, devIp, virtualFlag, sesId, logger)
	#respObj = auditConfig.computeDelete(serviceConfig, deviceCol, ipUrl, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
        #print ' ++++ AuditDevice compute modify for attach IP  response = %s' , respObj
	#resp = util.getFaults(rootKey, respObj, logger)
	#print '+++++ Fault resp = ', resp

        return

#
# get config collection test
#
    def test_e_getConfigCollection(self):
        """
        This is to get config collection in dict
        """
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()

        #cnfgFile = open('test/pbrTestData.yaml', 'r')
        cnfgFile = open('test/blrAuditTestData925.yaml', 'r')
        cnfgData = yaml.load_all(cnfgFile)
        auditCnfg = {}
        for i in cnfgData:
            auditCnfg = i

        resp = auditConfig.getMajorEntityCollection(auditCnfg, logger)
        print 'Audit collection results = ', resp
        
        return

if __name__ == '__main__':
    unittest.main()
