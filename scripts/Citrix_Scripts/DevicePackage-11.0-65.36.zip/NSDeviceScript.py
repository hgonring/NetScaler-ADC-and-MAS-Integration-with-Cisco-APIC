#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import LogService
import sys
import DeviceScriptController
from  pprint import pformat
import pprint

from rhi import rhiConfig as rhconf
from util import scriptConst as const

"""
This is for IFC to invoke NetScaler's device script base on various trigger points i.e. 'servicemodify'
"""

#
# This is to validate the device version, enable NetScaler's feature
#
def deviceValidate(device, version ):
    #
    # Validate version and device type 
    #
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is device validate +++++++++ %s %s " % (device['host'],version))
    devResp = cntrlObj.validateDevice(device, version)
    
    return devResp 
    

#
# This is to handle device config changes i.e. interface
#
def deviceModify(device, interfaces, configuration):
    #
    # Update Global device configuration 
    #
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is device modify +++++++++  device = %s, interface =%s" % ( device['host'], interfaces))
    devResp = cntrlObj.deviceModify(device, interfaces, configuration)
    return devResp 
    

def deviceAudit( device, 
	         interfaces,
                 configuration ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is device Audit +++++++++ device =  %s, interfaces = %s" % ( device['host'], interfaces))
    devResp = cntrlObj.deviceAudit(device, interfaces, configuration)
    return devResp 
    

#
# This is to poll and collect the device's health
#
def deviceHealth( device,
                  interfaces,
                  configuration ):
    #
    # Monitor device health. Poll device resource and status 
    # Return a health score between 0 - 100 (bad = 0 good  = 100) 
    # Example: 
    # Poll CPU usage, free memory, disk usage etc. 
    #
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is device health +++++++++ device = %s" % (device['host']))
    devResp = cntrlObj.deviceHealth(device, interfaces, configuration)
    
    return devResp
    

def deviceCounters( device,
                    interfaces,
                    configuration ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is device Counters +++++++++ device = %s" % (device['host']))
    devResp = cntrlObj.getDeviceCounters(device, interfaces, configuration)
       
    return devResp
    
#
# This is to handle cluster Modify configuration
#
def clusterModify( device, interfaces,
                   configuration ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    logger.debug("+++++++ This is cluster Modify +++++++++ " % ())
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    devResp = cntrlObj.clusterModify(device, interfaces, configuration)
    
    return devResp
    

def clusterAudit( device, interfaces,
                  configuration ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    logger.debug("+++++++ This is cluster Audit +++++++++ " % ())
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    devResp = cntrlObj.clusterAudit(device, interfaces, configuration)
    return devResp 
#
# This is to handle FunctionGroup changes
#
def serviceModify(device,
                  configuration ):
    #
    # This function is called a graph is instantiated or modified 
    # The configuration parameter will contain
    #    1. Device Configuration 
    #       (global device configuration as defined in the device model)
    #    2. Group Configuration: 
    #       (Configuration applicable and shared by set of functions within 
    #        a graph instance)
    #    3. Function Configuration: 
    #       This is function specific configuration for each function 
    #       being rendered on this device 
    #
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is service modify +++++++++ %s " % (device['host']))
    serResp = cntrlObj.serviceModify(device, configuration)
    return serResp
    
#
# This is for serviceAudit
#
def serviceAudit( device,
                  configuration ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is Service Audit +++++++++  %s " % ( device['host'] ))
    
    devResp = cntrlObj.serviceAudit(device, configuration)
    return devResp
#
# This is for ServiceHealth
#    
def serviceHealth( device,
                  configuration ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is service health +++++++++ %s" % (device['host']))
    devResp = cntrlObj.getServiceHealth(configuration, device, logger)
    
    return devResp
    
#
# This is for Service Counters
#
def serviceCounters( device,
                     configuration ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is service counters  +++++++++ %s" % (device['host']))    
    devResp = cntrlObj.getServiceCounters(device, configuration)
    
    return devResp
    
#
# This is to handle EndPoint attchment to the EPG
#
def attachEndpoint( device,
                    configuration,
                    endpoints ):
    #
    # Called when EP for a given EPG attaches 
    #
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    logger.debug("+++++++ This is attach end point +++++++++ %s, %s " % (device['host'], endpoints))

    epAthResp = cntrlObj.epAttachEvent(device, configuration, endpoints, logger)
    return epAthResp
    
    
#
# This is to handle detach end point 
#
def detachEndpoint( device,
                    configuration,
                    endpoints ):
    logSerObj = LogService.LogService()
    logger = logSerObj.getLogger()
    logger.debug("+++++++ This is detach end point +++++++++ %s, %s " % (device['host'], endpoints ))    
    cntrlObj = DeviceScriptController.DeviceScriptController(logger)
    detahResp = cntrlObj.detachEvent(device, configuration, endpoints, logger)
    return detahResp
    

#
# This is to handle attach network event in NetScaler
#
def attachNetwork( device,
                   configuration,
                   connector,
                   network ):
    #
    # Called when a new subnet is defined for an EPG associated with this 
    # Graph
    # 
    return {
        'state': 0,
        'faults': {},
        'health': {},            
        }

#
# This is to handle detach network event from IFC
#
def detachNetwork( device,
                   configuration,
                   connector,
                   network ):
    return {
        'state': 0,
        'faults': {},
        'health': {},            
        }
