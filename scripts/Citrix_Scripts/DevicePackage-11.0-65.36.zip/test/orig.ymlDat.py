import yaml

class YmlDat(object):

    def __init__(self, fileName='sampleData.yaml'):
        self.fileName = fileName

    def loadDat(self):
        loginData = open(self.fileName, "r")
        credData = yaml.load_all(loginData)
        for d1 in credData:
            for d2, v2 in d1.iteritems():
                for d3, v3 in v2.iteritems():
                    print d3, v3
                    if d3 == 'NSLogin':
                        print "NSLogin data = ", v2
                    if d3 == 'DeviceValidate':
                        print "Device Validate data = ", v2

if __name__ == '__main__':
    ymObj = YmlDat()
    ymObj.loadDat()
