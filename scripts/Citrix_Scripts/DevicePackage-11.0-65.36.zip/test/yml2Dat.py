import yaml

class YmlDat(object):

    def __init__(self, fileName='deviceConfigEPAttach.yaml'):
    #def __init__(self, fileName='modifyDeviceConfig.yaml'):
    #def __init__(self, fileName='modifyCsvServer.yaml'):
    #def __init__(self, fileName='csvServer.yaml'):
        self.fileName = fileName

    def loadDat(self):
        loginData = open(self.fileName, "r")
        credData = yaml.load_all(loginData)
	for ymDat in credData:
	   print type(ymDat)
        nsIPData = {}
        #print lbVSer
        nslbVSerCol = {}
	v3Dict = {} 
	k5State = 0
	#print type(credData)
        #for mcol in credData:
	#  print "MCol = ",mcol
        for k1, v1 in ymDat.iteritems(): # iterating over device level
	    #print "K1 = ", k1, v1
            for k2, v2 in v1.iteritems(): # iterating over device value dict 
	        #print "K2 = ", k2, v2
                if k2 == 'value':
		    for key1 in v2.keys():
			print "Keys = ", key1
                    for k3, v3 in v2.iteritems(): # iterating over function group
                        for k4, v4 in v3.iteritems(): # iterating over function group value dict
	                    #print "K4 = ", k4, v4
                            if k4 == 'value': 
                                for k5, v5 in v4.iteritems(): #iterating over value details of function group
	                            #print "K5 = ", k5, v5
                                    k5type = k5[0] # folder type
                                    k5name = k5[1] # folder name 
                                    for k6, v6 in v5.iteritems():
                                        if k6 == 'state':
                                            k6state = v6
                                        if k6 == 'value':
                                            for k7, v7 in v6.iteritems():
	                                        #print "K7 = ", k7, v7
                                                k7type = k7[0] # get the type of param
                                                k7paramName = k7[1]
                                                for k8, v8 in v7.iteritems():
                                                    if k8 == 'state':
                                                        k8state = v8 # param State
                                                    if k8 == 'value':
                                                        k8value = v8 # param value
                                                if k8state == 1 and k7paramName.find('bind') == -1:
                                                    nslbVSerCol[k7paramName] = k8value
				


	print " nslbVSerCol = ", nslbVSerCol

        print " NS IP = ", nsIPData

                       
if __name__ == '__main__':
    ymObj = YmlDat()
    ymObj.loadDat()
