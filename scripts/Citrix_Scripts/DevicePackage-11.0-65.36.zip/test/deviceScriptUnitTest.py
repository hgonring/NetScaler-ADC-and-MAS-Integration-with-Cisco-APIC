import unittest
import yaml

import LogService
import NSLogin
import NSDeviceScript

from  util.ScriptUtil import ScriptUtil

class TestDeviceScriptFunctions(unittest.TestCase):

    def setup(self):
        self.LBData = range(10)

    def test_LBParam(self):
        element = 5
	scrObj = ScriptUtil()
	tmpPayload = {"name" : "Test1", "ip" : "1.1.1.1", "port" : 80, "lbmethod" : "RoundRobin"}
	tmpStr = scrObj.getPayload(tmpPayload)
        #self.assertTrue(element in self.LBData)
        self.assertTrue(tmpStr.find('"name" : "Test1"'))

    def test_DeviceValidate(self):
	loginData = open("test/nsData.yaml", "r")
	credData = yaml.load_all(loginData)
	for d1 in credData:
	    #First level parsing from YAML 'NetScaler'
	    for k1, v1 in d1.iteritems():
	  	# Second level 'NSLogin' parsing 
		for k2, v2 in v1.iteritems():
		   #print "Type k2 = ", type(v2), v2
		   if k2 == 'DeviceValidate':
                      cred = v2
		      #print "Device Validate = ", v2
        dev = {'host': '10.102.201.141', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        ver = '10.1'
        nsResp = NSDeviceScript.deviceValidate(dev, ver)
        self.assertTrue(nsResp == True)
    
    def test_NSLogin(self):
	loginData = open("test/nsData.yaml", "r")
	credData = yaml.load_all(loginData)
	# root level from the Yaml data
	for d1 in credData:
	    #First level parsing from YAML 'NetScaler'
	    for k1, v1 in d1.iteritems():
	  	# Second level 'NSLogin' parsing 
		for k2, v2 in v1.iteritems():
		   #print "Type k2 = ", type(v2), v2
		   if k2 == 'NSLogin':
                      cred = v2
 	lgObj = LogService.LogService()
   	logEr = lgObj.getLogger()
        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        #url = "http://" + ipAdr + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logEr)
        sesId = nsLgObj.login()
        #print sesId
        erCode = nsLgObj.logout(sesId)
        self.assertTrue(erCode == 0)
    
    def test_a_DeviceModify(self):
        #nsIpFile = open('test/nsIPData.yaml', 'r')
        nsIpFile  = open('test/deviceConfigEPAttach.yaml', "r")
        nsIpData = yaml.load_all(nsIpFile)
        serviceConfig = {}
        for i in nsIpData:
            serviceConfig = i
        dev = {'host': '10.102.201.141', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        interface = { }
        nsResp = NSDeviceScript.deviceModify(dev, interface, serviceConfig)
        print 'Device Modify response = ', nsResp
        #self.assertTrue(nsResp == True)

    def test_b_ServiceModify(self):
        #serviceData = open('test/lbvServerData.yaml', "r")
        #serviceData = open('test/deviceConfig.yaml', "r")
        #serviceData = open('test/deviceConfigEPAttach.yaml', "r")
        #serviceData = open('test/ifcConfigData.yaml', "r")
        #serviceData = open('test/SSLData.yaml', "r")
        #serviceData = open('test/QA-Test_1.yaml', "r")
        serviceData = open('test/modifyDeviceConfig.yaml', "r")
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
        
        dev = {'host': '10.102.201.141', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        deviceFile = open('test/deviceData.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for k in deviceData:
            deviceCol = k
        interface = { }
        nsResp = NSDeviceScript.serviceModify(deviceCol, serviceConfig)    
	print "Response from service Modify = ", nsResp

    def test_c_EpAttachEvent(self):
        tmpData = open('test/conn_1.yaml', "r")
        cData = yaml.load_all(tmpData)
        for conData in cData:
	    conn = conData

        serviceData = open('test/deviceConfigEPAttach.yaml', 'r')
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
        
        dev = {'host': '10.102.201.141', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
	name = None
        ep = '10.10.10.1'
        nsResp = NSDeviceScript.attachEndPoint(dev, name, serviceConfig, conn, ep)
        print "Response from EP Attach  = ", nsResp

    def test_d_DeviceHealth(self):
        dev = {'host': '10.102.201.141', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        #dev = {'host': '10.102.113.195', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        nsResp = NSDeviceScript.deviceHealth(dev)
   	print '------------- Device Health = ' , nsResp 
    def test_NSLogin(self):
	loginData = open("test/nsData.yaml", "r")
	credData = yaml.load_all(loginData)
        
if __name__ == '__main__':
    suite = unittest.TestLoader().loadTestsFromTestCase(TestDeviceScriptFunctions)
    unittest.TextTestRunner(verbosity=2).run(suite)
    
