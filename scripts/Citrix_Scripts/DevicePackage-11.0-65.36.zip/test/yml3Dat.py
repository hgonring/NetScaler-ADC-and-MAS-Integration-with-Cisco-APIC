import yaml

class Yml3Dat(object):

    def __init__(self, fileName='request.cfg'): #conn_1.yaml'):
        self.fileName = fileName

    def loadDat(self):
        loginData = open(self.fileName, "r")
        credData = yaml.load_all(loginData)
        ymDat = {}
	#for ymDat in credData:
	#   print type(ymDat)
        for k in credData:
            ymDat = k

        nsIPData = {}
        print 'YmData = ', ymDat
        #print lbVSer
        nslbVSerCol = {}
	v3Dict = {} 
	k5State = 0
	#print type(credData)
        #for mcol in credData:
	#  print "MCol = ",mcol
        for k1, v1 in ymDat.iteritems(): # iterating over device level
	    print "K1 = ", k1
	    print "V1 = ", v1
 	#print 'Type = ', type(ymDat)
	hostVal = None
	#print 'device Host value =', ymDat['host']                      
	#print 'Creds Host value =', ymDat['creds']                      
if __name__ == '__main__':
    ymObj = Yml3Dat()
    ymObj.loadDat()
