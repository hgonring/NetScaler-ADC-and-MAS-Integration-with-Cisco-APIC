#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import unittest
import yaml

import NSServer
import NSDeviceScript
import DeviceScriptController
import NSLogin
import LogService
import json

from util import vServerUtil 

from util import configUtil as util

#
# This is to unit Test various script classes
#

class TestGenUtil(unittest.TestCase):
    """
    This is to unit test script functions 
    """
    def setup(self):
        pass

#
# This is to unit test deviceHealth
#
    def test_a_getDeviceHealth(self):
        """
        This is to test the device health
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        devFile = open('test/deviceBLRData.yaml', "r")
        devData = yaml.load_all(devFile)
        devCol = {}
        for j in devData:
            devCol = j
        #cnfgFile = open('test/raviVlanTestData.yaml', "r")
        cnfgFile = open('test/debugTestData.yaml', "r")
        cnfgData = yaml.load_all(cnfgFile)
        cnfgCol = {}
        for j in cnfgData:
            cnfgCol = j

        infCol = infCol = {(11, '', '1_1'): {'state': 0, 'label': ''}, (11, '', '1_2'): {'state': 0, 'label': ''}}

        #nsResp = NSDeviceScript.deviceHealth(devCol, infCol, cnfgCol)

        #print ' ++++ Device health response = %s' , nsResp
	return 
#
# This is to unit test deviceHealth
#
    def test_a_getNSFeature(self):
        """
        This is to test the device feture
        """
        #url = "http://" + "10.102.201.43" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()


        #devIp = '10.102.201.63'
        #devIp = '10.102.113.195'
        #devIp = '10.102.102.51'
        devIp = '172.23.50.132'

	nsObj = NSServer.NSServer(logger)
	#feaList = nsObj.getNSFeatureList(sesId, devIp)
	#resp = nsObj.enableFeatures(sesId, devIp)
        #resp = nsObj.enableNSMode(sesId, devIp)
        #nsLgObj.logout(sesId)
        #print ' ++++ Device feature List response = %s' , feaList
        #print ' ++++ Device enable feature response = %s' , resp
        #print ' ++++ Device enable Moderesponse = %s' , resp
        return

    def test_b_deviceAudit(self):
        """
        This is to test the deviceAudit feture
        """
        #haData = open("test/clusterHAConfig_3.yaml", "r")
        haData = open("test/deviceBLRData.yaml", "r")
        tmpData = yaml.load_all(haData)
        deviceCol = {}
        for m in tmpData:
            deviceCol = m
        dev = {}
	inf = {}
	cnfg = {}
	for i1, j1 in deviceCol.iteritems():
         
            #print 'i1 =', i1, ' j1 =', j1
            if i1 == 'ha':
                dev = j1
            elif i1 == 'inf':
                inf = j1
            elif i1 == 'peer':
                #cnfg = j1
                cnfg = {}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
	#print 'dev = ', dev, ' inf =', inf, ' cnfg =', cnfg
	#dev = '10.102.102.58'
	inf = { (11, '', '1_1'): { 'state': 0, 'label': '' }, (11, '', '1_2'): { 'state': 0, 'label': '' } }
	cnfg = {}
        #nsResp = NSDeviceScript.deviceAudit(dev, inf, cnfg)
	#vservObj  = vServerUtil.VServerUtil(logger)
        #nsResp = vservObj.processDeviceAudit(dev, inf, cnfg)
	#print '+++++ deviceAudit response = ', nsResp
	return

    def test_g_deviceModify(self):
        """
        This is to test the deviceModify feture
        """
        #haData = open("test/clusterHAConfig_2.yaml", "r")
        haData = open("test/deviceBLRData.yaml", "r")
        tmpData = yaml.load_all(haData)
        deviceCol = {}
        for m in tmpData:
            deviceCol = m
        dev = {}
	inf = {}
	cnfg = {}
	for i1, j1 in deviceCol.iteritems():
         
            #print 'i1 =', i1, ' j1 =', j1
            if i1 == 'ha':
                dev = j1
            elif i1 == 'inf':
                inf = j1
            elif i1 == 'peer':
                cnfg = j1
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
	#print 'dev = ', dev, ' inf =', inf, ' cnfg =', cnfg
        #nsResp = NSDeviceScript.deviceModify(dev, inf, cnfg)
	#vservObj  = vServerUtil.VServerUtil(logger)
        #nsResp = vservObj.processDeviceAudit(dev, inf, cnfg)
	#print '+++++ deviceModify response = ', nsResp
	return


    def test_DeviceValidate(self):
        loginData = open("test/deviceBLRData.yaml", "r")
        credData = yaml.load_all(loginData)
        #10.102.113.194
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        #url = "http://" + "10.102.113.194" + "/nitro/v1/config/login"
        #url = "http://" + "172.21.158.253" + "/nitro/v1/config/login"
        #url = "http://" + "172.21.158.253" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        #dev = {'host': '10.102.201.56', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        #dev = {'host': '10.102.113.194', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        dev = {'host': '10.102.102.51', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        #dev = {'host': '172.23.50.133', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        #dev = {'host': '172.21.158.253', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        #devIp = '10.102.102.51'
        #devIp = '172.23.50.132'
        #devIp = '172.21.158.253'
        ver = 10.1
        ipurl = "http://" + "10.102.102.51" + "/nitro/v1/config/"
        #nsResp = NSDeviceScript.deviceValidate(dev, ver)
	#nsObj = NSServer.NSServer(logger)
	#nsResp = nsObj.validate(ver, sesId, devIp)
        #print ' Device validate response = ', nsResp
	#nsLgObj.logout(sesId)
	return

    def test_ClearConfig(self):
        loginData = open("test/deviceBLRData.yaml", "r")
        credData = yaml.load_all(loginData)

        url = "http://" + "10.102.201.113" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()

        #dev = {'host': '10.102.102.51', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        #devIp = '10.102.102.51'
        dev = {'host': '10.102.201.113', 'port': 80, 'creds': {'username': 'nsroot', 'password' : 'nsroot'} }
        #devIp = '10.102.56.75'
	#nsObj = NSServer.NSServer(logger)
	#nsResp = util.clearNSConfigFromDevice(devIp, sesId, logger)
        #print ' Clear configureation response = ', nsResp
	#nsLgObj.logout(sesId)
	return 

    def test_c_serviceModify(self):
        loginData = open("test/deviceBLRData.yaml", "r")
        #loginData = open("test/deviceVDataCisco.yaml", "r")
        #loginData = open("test/newDeviceData.yaml", "r")
        credData = yaml.load_all(loginData)
        devData = {}
        for j in credData:
            devData = j
        #serviceData = open('test/appFWTestData.yaml', 'r')
        #serviceData = open('test/lbMonitorModifyTestData.yaml', 'r')
        #serviceData = open('test/vipulServiceModifyTestData.yaml', 'r')
        #serviceData = open('test/pariModTestData.yaml', 'r')
        #serviceData = open('test/policyTestData.yaml', 'r')
        #serviceData = open('test/prajDebugTestData.yaml', 'r')
        #serviceData = open('test/vipul300Graphs.yaml', 'r')
        #serviceData = open('test/twoGraphTestData.yaml', 'r')
        #serviceData = open('test/graph_5TestData.yaml', 'r')
        #serviceData = open('test/interfaceModifyTestData.yaml', 'r')
        serviceData = open('test/pariModTestData.yaml', 'r')
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i
        #for i in devData.keys():
	#     print 'Key = ', i
        nsResp = NSDeviceScript.serviceModify(devData, serviceConfig)
        print ' service modify response = ', nsResp
	return 
       
    def test_d_serviceAudit(self):
        #loginData = open("test/deviceVDataCisco.yaml", "r")
        #loginData = open("test/blrNSDevice.yaml", "r")
        loginData = open("test/deviceBLRData.yaml", "r")
        credData = yaml.load_all(loginData)
        devData = {}
        for j in credData:
            devData = j
        
        #serviceData = open('test/sameConnTestData.yaml', 'r')
        #serviceData = open('test/apicTestData_1.yaml', 'r')
        #serviceData = open('test/vipulServiceModifyTestData.yaml', 'r')
        #serviceData = open('test/auditTestData.yaml', 'r')
        #serviceData = open('test/aaaTestData_1.yaml', 'r')
        serviceData = open('test/debugTestData.yaml', 'r')
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i

        #nsResp = NSDeviceScript.serviceAudit(devData, serviceConfig)
        #print ' service Audit response = ', nsResp
	return

    def test_e_clusterAudit(self):
        #loginData = open("test/deviceVDataCisco.yaml", "r")
        loginData = open("test/deviceBLRData.yaml", "r")
        credData = yaml.load_all(loginData)
        devData = {}
        for j in credData:
            devData = j
        #serviceData = open('test/enableFeatureTestData_2.yaml', 'r')
        #serviceData = open('test/featureModeTestData.yaml', 'r')
        #serviceData = open('test/clusterAuditTestData.yaml', 'r')
        #serviceData = open('test/kiranClusterModifyTestData.yaml', 'r')
        serviceData = open('test/clusterAuditTestData.yaml', 'r')
        #serviceData = open('test/snmpTestData.yaml', 'r')
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i


        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        #cntrlObj = DeviceScriptController.DeviceScriptController(logger)
        nsResp = NSDeviceScript.clusterAudit(devData, None, serviceConfig)     
        #nsResp = cntrlObj.clusterAudit(devData, None, serviceConfig)
        print 'cluster Audit response = ', nsResp
	return 

    def test_f_clusterModify(self):
        #loginData = open("test/deviceVDataCisco.yaml", "r")
        loginData = open("test/deviceBLRData.yaml", "r")
        #loginData = open("test/blrNSDevice.yaml", "r")
        credData = yaml.load_all(loginData)
        devData = {}
        for j in credData:
            devData = j
        #serviceData = open('test/enableFeatureTestData_2.yaml', 'r')
        #serviceData = open('test/featureModeTestData.yaml', 'r')
        #serviceData = open('test/clusterAuditTestData.yaml', 'r')
        serviceData = open('test/debugTestData.yaml', 'r')
        #serviceData = open('test/snmpTestData.yaml', 'r')
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i


        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        #cntrlObj = DeviceScriptController.DeviceScriptController(logger)
        #nsResp = NSDeviceScript.clusterModify(devData, None, serviceConfig)     
        #nsResp = cntrlObj.clusterAudit(devData, None, serviceConfig)
        #print 'cluster Modify response = ', nsResp
	return

    def test_i_attachEndPoint(self):
        #loginData = open("test/deviceVDataCisco.yaml", "r")
        loginData = open("test/deviceBLRData.yaml", "r")
        #loginData = open("test/blrNSDevice.yaml", "r")
        credData = yaml.load_all(loginData)
        devData = {}
        for j in credData:
            devData = j
        #serviceData = open('test/enableFeatureTestData_2.yaml', 'r')
        #serviceData = open('test/featureModeTestData.yaml', 'r')
        serviceData = open('test/debugTestData.yaml', 'r')
        #serviceData = open('test/snmpTestData.yaml', 'r')
	#endPoint = [ { 'addr': '192.168.2.102/32', 'conn': 'internal' } ]
	endPoint = [{'addr': '34.34.34.12', 'conn': 'internal'}]
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i

        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        #nsResp = NSDeviceScript.attachEndpoint(devData, serviceConfig, endPoint)     
        #print 'attachEndPoint response = ', nsResp
	return

    def test_j_detachEndPoint(self):
        #loginData = open("test/deviceVDataCisco.yaml", "r")
        loginData = open("test/deviceBLRData.yaml", "r")
        #loginData = open("test/blrNSDevice.yaml", "r")
        credData = yaml.load_all(loginData)
        devData = {}
        for j in credData:
            devData = j
        #serviceData = open('test/enableFeatureTestData_2.yaml', 'r')
        #serviceData = open('test/featureModeTestData.yaml', 'r')
        serviceData = open('test/debugTestData.yaml', 'r')
        #serviceData = open('test/snmpTestData.yaml', 'r')
	endPoint = [ { 'addr': '192.168.2.102/32', 'conn': 'internal' } ]
	#endPoint = [{'addr': '34.34.34.14', 'conn': 'internal'}]
        genData = yaml.load_all(serviceData)
        serviceConfig = {}
        for i in genData:
            serviceConfig = i

        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        #nsResp = NSDeviceScript.detachEndpoint(devData, serviceConfig, endPoint)     
        #print 'detachEndPoint response = ', nsResp
	return

if __name__ == '__main__':
    unittest.main()
