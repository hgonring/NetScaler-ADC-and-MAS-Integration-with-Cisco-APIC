
import xml.etree.ElementTree as ET

tree = ET.parse('NSModel.xml')
root = tree.getroot()

for folder in root.iter():
    print "Tag = ", folder.tag, " Attrib = ",  folder.attrib

