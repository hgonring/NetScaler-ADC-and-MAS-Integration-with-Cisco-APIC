#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import requests
import json
import traceback
import time

import NSServer
import NSLogin

from feature import lbVserver
from feature import genericNitro

from util import scriptConst as const
from util import auditConfig as audit
from util import clusterAudit 
from util import vServerUtil
from util import configUtil
from util import nitroUtil
from util import monitorUtil

from rhi import rhiConfig as rhconf
#
# This is to handle & delegate deviceScripts Call 
#
class DeviceScriptController(object):
     """
     This is the controller class for deviceScript's implementation to NetScaler
     """
     def __init__(self, logName):
         self.logger = logName

 #
 # This is to get sessionId from the NSLogin
 #
     def getLoginObj(self, device):    
         credCol = {}
         credDetails = {}
         hostVal = None
         url = None
         # This is temporary and will get replaced with IFC call to user & passwd
         #self.logger.debug('+++++++++ Device details from Login = %s' % (device[const.HOST]))
         try:
             credCol = device[const.CREDS]

             credDetails["userName"] = credCol[const.USERNAME]
             credDetails["password"] = credCol[const.PASSWORD]
             tmpUrl = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
             #url = "http://" + device[const.HOST] + "/nitro/v1/config/login"
             url = tmpUrl + "login"

             credDetails["url"] = url


         except Exception as exMsg:
              self.logger.error(' ++++ error in getLoginObj = %s' % str(exMsg))
              return None

         nsLoginObj = NSLogin.NSLogin(credDetails, self.logger)

         return nsLoginObj

 # 
 # This is for NetScaler device validation by comparing the version
 #
     def validateDevice(self, device, version):
         """
         This is to validate device's version and if it is valid then enable LB & CS features in the device
         """
         boolResp = False
         resp = {}
         nsLoginObj = self.getLoginObj(device)
         errState = None
         errTuple = ()
         try:
             sessionId = nsLoginObj.login()

             nsObj = NSServer.NSServer(self.logger)
             url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
             boolResp = nsObj.validate(version, sessionId, url)
             if boolResp is False:
                 nsLoginObj.logout(sessionId)	
                 self.logger.error("Device Validation failed")
                 # raise Exception("Device Validation failed")
                 errState = const.PERMANENT
                 errorMsg = "Device Validation failed Please make sure the device has supported version, for details check the release notes"
                 errTuple = ([], 1001, errorMsg) 
                 # raise faults
                 fltList = []
                 fltList.append(errTuple)
                 resp[const.STATE] = errState
                 resp[const.FAULTS] = fltList
                 resp[const.VERSION] = version
                 resp[const.HEALTH] = []
                 return resp
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in validate device = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in validate device = %s" + str(exMsg)
              errTuple = ([], 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              resp[const.VERSION] = version
              resp[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
              self.logger.error(' ++++ ERROR in validateDevice  = %s' % str(exMsg))
              errState = const.PERMANENT
              errorMsg = " ERROR in validate device = %s" + str(exMsg)
              errTuple = ([], 1001, errorMsg) 
              # raise faults
              fltList = []
              fltList.append(errTuple)
              resp[const.STATE] = errState
              resp[const.FAULTS] = fltList
              resp[const.VERSION] = version
              resp[const.HEALTH] = []
              return resp

         # if execution reaches here means no exception
         if boolResp:
             resp[const.STATE] = const.SUCCESS
         else:
             resp[const.STATE] = const.PERMANENT

         resp[const.VERSION]= version

         return resp

 #
 # This is to handle the device Config changes Create/Modify/Delete
 #
     def deviceModify(self, device, interfaces, configuration):
         """
         This is to manage the device modify request from IFC
         """
         #self.logger.debug('+++++++++ This is device modify method +++++++++')
         respCol = {}
         # get the NSIP and its credential for each node from the cluster config
         try:
              rootKey = None
              # root element of the configuration
              rootKey = configUtil.getRootKey(configuration, self.logger)
	      sesId = None
              nsLoginObj = self.getLoginObj(device)
              sesId = nsLoginObj.login()
         
              vserObj = vServerUtil.VServerUtil(self.logger)
              url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
              respCol = vserObj.processDeviceModify(url, device[const.HOST], device[const.VIRTUAL], interfaces, configuration, sesId)
              devHealthVal = monitorUtil.getDeviceHealth(url, device[const.HOST], sesId, interfaces, configuration, self.logger)
              nsLoginObj.logout(sesId)
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in deviceModify  = %s' % str(exMsg))
              tmpCol = {}
              errorMsg = " ERROR in device modify = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
             try:
                  if (sesId):
                       nsLoginObj.logout(sesId)
             except:
                  pass
             tmpCol = {}
             path = []
             if rootKey:
                   path.append(rootKey)
             errorCode = 1001
             errorMsg = " ERROR in deviceModify = %s" + str(exMsg)
             tmpTuple = (path, errorCode, errorMsg)
             tmpFltList = []
             tmpFltList.append(tmpTuple)
             self.logger.error(' ++++ ERROR in deviceModify = %s' % str(exMsg))
             tmpCol[const.STATE] = const.PERMANENT
             tmpCol[const.FAULTS] = tmpFltList
             tmpCol[const.HEALTH] = []
             return tmpCol
 
         self.logger.debug('+++++++++++++ Device Modify Response +++++++++++ = %s' % respCol)
         tmpHealthCol = {}
         # get the health details from the devHealthVal
         for k1, v1 in devHealthVal.iteritems():
              if k1 == const.HEALTH:
                   tmpHealthCol = v1
         respCol[const.STATE] = const.SUCCESS
         respCol[const.FAULTS] = []
         respCol[const.HEALTH] = tmpHealthCol
        
         return respCol

 #
 # This is to handle the serviceModify requests from NSDevice script
 # 
     def serviceModify(self, device, configuration):
         """
         This is to handle the IFC's service modify request 
         """
         #self.logger.debug('++++++++++++++ Service Modify request +++++++++++++++++')
         #self.logger.debug('+++++++ Device Details  = %s +++++++++++++++++'% (device[const.HOST]))

         resCode = {}
         tmpCode = {}
         serviceHealthScore = {}
         # handle various state of the config 
         vserObj = vServerUtil.VServerUtil(self.logger)
         # this is to take care all the network specific such as VLAN/VXLAN, VIFs VLAN binding etc. 
         nsLoginObj = self.getLoginObj(device)
         try:
              rootKey = None
              # root element of the configuration
              rootKey = configUtil.getRootKey(configuration, self.logger)
	      sesId = None
              vserObj.getContextAwareFlag(device)
              sesId = nsLoginObj.login()
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in service Modify = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in service modify = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg) 
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
	      return tmpCol
         except Exception as exMsg:
              self.logger.error(' ++++ ERROR in seviceModify login Failed = %s' % str(exMsg))
              tmpCol = {}
              path = []
              if rootKey:
                   path.append(rootKey)
              errorCode = 1001
              errorMsg = " ERROR in serviceModify = %s" + str(exMsg)
              tmpTuple = (path, errorCode, errorMsg)
              fltList = []
              fltList.append(tmpTuple)
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = fltList
              tmpCol[const.HEALTH] = []
              return tmpCol

         try :
              origConf = configuration
              # first get the URL
              url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
              # check if the interface state is in modify with no change state in VLAN & Encap association
              # this is related to change in the deployment toplogy from 2-arm to 1-arm or other way around
              auditResp = None
              auditResp = vserObj.getAuditFlagBasedOnInterface(device, configuration, url, device[const.HOST], device[const.VIRTUAL], sesId)
              if (auditResp):
                   # raise the audit
                    self.logger.error(' ++++ ERROR in serviceModify RAISING AUDIT due inconsistent dataset = %s' % (auditResp))
                    tmpCol = {}
                    path = []
                    if rootKey:
                         path.append(rootKey)
                    errorCode = 1001
                    errorMsg = " Invalid state data for VIFs/Interface with Modify state RAISING AUDIT "
                    tmpTuple = (path, errorCode, errorMsg)
                    fltList = []
                    fltList.append(tmpTuple)
                    tmpCol[const.STATE] = const.AUDIT
                    tmpCol[const.FAULTS] = fltList
                    return tmpCol
              # end of the vlan interface binding related issue
	      # there is problem with where it can not handle long folder names i.e. authenticationvserver_authenticationradiuspolicy_binding
	      # there is work around for this where 'aaa_' is replaced for authenticationvserver_authentication
	      # this is to replace 'aaa_' with authenticationvserver_authentication otherwise NITRO and other problem will occur
	      tmpCode = configUtil.replaceTokenName(const.AAA_TOKEN, const.AAA_REPLACE_TOKEN, configuration, self.logger)
              tmpCode = vserObj.adminPartitionHandling(origConf, url, device[const.HOST], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              # first handle the Param folder since it is only set or unset and remove them from config
              tmpCode = configUtil.handleParamObjects(configuration, url, device[const.HOST], sesId, self.logger)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.processDeleteNetworkDataSet(device, configuration, url, device[const.HOST], device[const.VIRTUAL], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.processUnbindDataSet(configuration, url, device[const.HOST], sesId)
             # this is to merge two dictionaries 
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.processDeleteDataSet(configuration, url, device[const.HOST],sesId)
              resCode = dict(resCode.items() + tmpCode.items())
	      # process modify bind dataset is just for user experience this is to check the config should not any 
 	      # modify state for bind object otherwise raise exception
              tmpCode = vserObj.processModifyBindDataSet(configuration, url, device[const.HOST],sesId)
              tmpCode = vserObj.processCreateNetworkDataSet(device, configuration, url, device[const.HOST], device[const.VIRTUAL], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.processCreateDataSet(configuration, url, device[const.HOST],sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.processModifyDataSet(configuration, url, device[const.HOST],sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.processCreateBindDataSet(configuration, url, device[const.HOST],sesId)
              resCode = dict(resCode.items() + tmpCode.items())
             # process NS IP binding with VLAN/VXLAN
              tmpCode = vserObj.processFunctionSpecificIPVLANBinding(configuration, url, device[const.HOST], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.applyAcls(url, device[const.HOST], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.applyAcls6(url, device[const.HOST], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              if vserObj.checkRouting(configuration) == True:
                  tmpCode = vserObj.processRoutingConfig(device, configuration, False, url, sesId)
                  resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.adminPartitionDel(origConf, url, device[const.HOST], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              tmpCode = vserObj.saveConfig(url, device[const.HOST], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              serviceHealthScore = monitorUtil.getServiceHealth(origConf, device, sesId, self.logger)
              nsLoginObj.logout(sesId)
         except ValueError as valError:
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              tmpCol = {}
              tmpErTup = valError.args
              tmpFltList = []
              tmpFltList.append(tmpErTup[0])
              self.logger.error(' ++++ ERROR in seviceModify = %s' % str(valError))
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in serviceModify  = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in service modify = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg) 
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except const.AdminDelete:
              tmpCode = vserObj.saveConfig(url, device[const.HOST], sesId)
              resCode = dict(resCode.items() + tmpCode.items())
              serviceHealthScore = monitorUtil.getServiceHealth(configuration, device, sesId, self.logger)
              nsLoginObj.logout(sesId)
              retCol = {}

              self.logger.debug('+++++++ Service Modify Response  = %s +++++++++++++++++'% (resCode))
              resList = configUtil.getFaults(rootKey, resCode, self.logger)
              if resList != []:
                  retCol[const.STATE] = const.PERMANENT
              else:
                  retCol[const.STATE] = const.SUCCESS
              retCol[const.FAULTS] = resList
              # get the health details from the devHealthVal
              if not resList:
                  for k1, v1 in serviceHealthScore.iteritems():
                      if k1 == const.HEALTH:
                          tmpHealthCol = v1
                  retCol[const.HEALTH] = tmpHealthCol
              self.logger.debug('++++++++++++++ Service Modify response = %s' % (retCol))  
              return retCol
         except Exception as exMsg:
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              tmpCol = {}
              path = []
              if rootKey:
                   path.append(rootKey)
              errorCode = 1001
              errorMsg = " ERROR in serviceModify = %s" + str(exMsg)
              tmpTuple = (path, errorCode, errorMsg)
              tmpFltList = []
              tmpFltList.append(tmpTuple)
              self.logger.error(' ++++ ERROR in seviceModify = %s' % str(exMsg))
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol

         retCol = {}

         #self.logger.debug('+++++++ Service Modify Response  = %s +++++++++++++++++'% (resCode))
         resList = configUtil.getFaults(rootKey, resCode, self.logger)
         if resList != []:
             retCol[const.STATE] = const.PERMANENT
         else:
             retCol[const.STATE] = const.SUCCESS
         retCol[const.FAULTS] = resList
         # get the health details from the devHealthVal
         if not resList:
              for k1, v1 in serviceHealthScore.iteritems():
                   if k1 == const.HEALTH:
                        tmpHealthCol = v1
              retCol[const.HEALTH] = tmpHealthCol
         self.logger.debug('++++++++++++++ Service Modify response = %s' % (retCol))  
         return retCol

 #
 # This is to handle EPAttach Event from the Fabric
 #
     def epAttachEvent(self, device, configuration, endpoints, logger):
         self.logger.debug('+++++++++++ epAttachEvent ++++++++ params endpoints = %s' % (endpoints))
         # As part of end-point attach device script will get the IP and port and bind it to service group
         # get the service group from the connector if the connector is an output
         # port details will be in configuration
         try:
	      sesId = None
	      respCode = {}
              rootKey = None
	      serviceHealthScore = {}
              vserObj = vServerUtil.VServerUtil(self.logger)
              # root element of the configuration
              rootKey = configUtil.getRootKey(configuration, self.logger)
              vserObj.getContextAwareFlag(device)
              nsLoginObj = self.getLoginObj(device)
              sesId = nsLoginObj.login()
	      # get URL
              url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
              vserObj = vServerUtil.VServerUtil(self.logger)
              tmpCode = vserObj.adminPartitionHandling(configuration, url, device[const.HOST], sesId)
              respCode = dict(respCode.items() + tmpCode.items())
              tmpCode = vserObj.processAttachEndpoint(endpoints, configuration, url, device[const.HOST], sesId)
              respCode = dict(respCode.items() + tmpCode.items())
              serviceHealthScore = monitorUtil.getServiceHealth(configuration, device, sesId, self.logger)
              nsLoginObj.logout(sesId)        
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in epAttachEvent  = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in epAttachEvent  = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
              self.logger.error(' ++++ ERROR in epAttachEvent  = %s' % str(exMsg))
              resp = {}
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              errState = const.PERMANENT
              errorMsg = " ERROR in epAttachEvent  = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              # raise faults
              fltList = []
              fltList.append(errTuple)
              resp[const.STATE] = errState
              resp[const.FAULTS] = fltList
              resp[const.HEALTH] = []
              return resp

         retCol = {}
         resList = []
         #self.logger.debug('+++++++ Attach Endpoint Event Response  = %s +++++++++++++++++'% (respCode))
         resList = configUtil.getFaults(rootKey, respCode, self.logger)
         if resList: # get Faults returned Faults
              retCol[const.STATE] = const.PERMANENT
         else:
              retCol[const.STATE] = const.SUCCESS

         retCol[const.FAULTS] = resList
         # get the health details from the devHealthVal
         if not resList:
              for k1, v1 in serviceHealthScore.iteritems():
                   if k1 == const.HEALTH:
                        tmpHealthCol = v1
              retCol[const.HEALTH] = tmpHealthCol
         self.logger.debug('++++++++++++++ Attach endpoint response = %s' % (retCol))  
         return retCol
 #
 # This is to handle detachEvent from the Fabric
 #
     def detachEvent(self, device, configuration, endpoints, logger):
         self.logger.debug('+++++++++++ detachEvent ++++++++ params endpoints = %s' % (endpoints))
         # As part of end-point detach device script will unbind IP and port from service group
         # get the service group from the connector if the connector is an output
         # port details will be in configuration
         try:
              sesId = None
	      respCode = {}
              rootKey = None
              vserObj = vServerUtil.VServerUtil(self.logger)
              # root element of the configuration
              rootKey = configUtil.getRootKey(configuration, self.logger)
	      serviceHealthScore = {}
              vserObj.getContextAwareFlag(device)
              nsLoginObj = self.getLoginObj(device)
              sesId = nsLoginObj.login()
	      # get URL 
              url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
              # first get the URL
              url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
              vserObj = vServerUtil.VServerUtil(self.logger)
              tmpCode = vserObj.adminPartitionHandling(configuration, url, device[const.HOST], sesId)
              respCode = dict(respCode.items() + tmpCode.items())
              tmpCode = vserObj.processDetachEndpoint(endpoints, configuration, url, device[const.HOST], sesId)
              respCode = dict(respCode.items() + tmpCode.items())
              serviceHealthScore = monitorUtil.getServiceHealth(configuration, device, sesId, self.logger)
              nsLoginObj.logout(sesId)        
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in detachEent  = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in detachEvent  = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
              self.logger.error(' ++++ ERROR in detachEvent  = %s' % str(exMsg))
              resp = {}
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              errorMsg = " ERROR in detachEvent  = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              fltList = []
              fltList.append(errTuple)
              resp[const.STATE] = const.PERMANENT
              resp[const.FAULTS] = fltList
              resp[const.HEALTH] = []
              return resp
         
         retCol = {}

         #self.logger.debug('+++++++ Detach Endpoint Event Response  = %s +++++++++++++++++'% (respCode))
         resList = configUtil.getFaults(rootKey, respCode, self.logger)
         if resList: # get Faults returned FAULTS
              retCol[const.STATE] = const.PERMANENT
         else:
              retCol[const.STATE] = const.SUCCESS
         retCol[const.FAULTS] = resList
         # get the health details from the devHealthVal
         if not resList:
              for k1, v1 in serviceHealthScore.iteritems():
                   if k1 == const.HEALTH:
                        tmpHealthCol = v1
              retCol[const.HEALTH] = tmpHealthCol
         self.logger.debug('++++++++++++++ detach endpoint response = %s' % (retCol))  
         return retCol
 #
 # This is to get device health
 #
     def deviceHealth(self, device, interface, cnfg):
         """
         This is to calculate device health based on stats from CPU, memory, disk etc.
         """

         self.logger.debug('++++++++++ This is device health from device Controller for device++++++++++')
         devHealthVal = {}
         try :
	     sesId = None
             rootKey = None
             nsLoginObj = self.getLoginObj(device)
             sesId = nsLoginObj.login()
             # root element of the configuration
             rootKey = configUtil.getRootKey(cnfg, self.logger)

             # first get the URL
             url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
             devHealthVal = monitorUtil.getDeviceHealth(url, device[const.HOST], sesId, interface, cnfg, self.logger)
             nsLoginObj.logout(sesId)
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in deviceHealth  = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in deviceHealth  = %s" + str(exMsg)
              path = []
              if rootKey:
                   path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
             try:
                  if (sesId):
                       nsLoginObj.logout(sesId)
             except:
                  pass
             tmpCol = {}
             self.logger.error(' ++++ ERROR in deviceHealth  = %s' % str(exMsg))
             errorMsg = " ERROR in deviceHealth  = %s" + str(exMsg)
             path = []
             if rootKey:
                 path.append(rootKey)
             errTuple = (path, 1001, errorMsg)
             tmpFltList = []
             tmpFltList.append(errTuple)
             tmpCol[const.STATE] = const.PERMANENT
             tmpCol[const.FAULTS] = tmpFltList 
             tmpCol[const.HEALTH] = [] 
             return tmpCol

         return devHealthVal

 #
 # This is to get service health
 #
     def getServiceHealth(self, cnfg, device, logger):
         """
         This is to calculate service health based on stats 
         """

         self.logger.debug('++++++++++ This is servcie health from device Controller for device++++++++++')
         servHealthVal = {}
         try :   
	     sesId = None
             rootKey = None
             nsLoginObj = self.getLoginObj(device)
             sesId = nsLoginObj.login()

             # root element of the configuration
             rootKey = configUtil.getRootKey(cnfg, self.logger)
             servHealthVal = monitorUtil.getServiceHealth(cnfg, device, sesId, self.logger)
             nsLoginObj.logout(sesId)
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in deviceHealth  = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in serviceHealth  = %s" + str(exMsg)
              path = []
              if rootKey:
                  path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
             try:
                  if (sesId):
                       nsLoginObj.logout(sesId)
             except:
                  pass
             tmpCol = {}
             self.logger.error(' ++++ ERROR in getServiceHealth  = %s' % str(exMsg))
             tmpCol[const.STATE] = const.PERMANENT
             errorMsg = " ERROR in serviceHealth  = %s" + str(exMsg)
             path = []
             if rootKey:
                  path.append(rootKey)
             errTuple = (path, 1001, errorMsg)
             tmpFltList = []
             tmpFltList.append(errTuple)
             tmpCol[const.FAULTS] = tmpFltList
             tmpCol[const.HEALTH] = []
             return tmpCol

         return servHealthVal

 #
 # This is to get device counters
 #
     def getDeviceCounters(self, device, interfaces, cnfg):
         """
         This is to get device counters for all the interfaces
         """

         self.logger.debug('+++ This is to get deviceCounters for all the interfaces = %s' % (interfaces))
         try:
	     sesId = None
             rootKey = None
             nsLoginObj = self.getLoginObj(device)
             sesId = nsLoginObj.login()

             # root element of the configuration
             rootKey = configUtil.getRootKey(cnfg, self.logger)

             # first get the URL
             url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
             respCol = monitorUtil.getDeviceCounters(interfaces, cnfg, url, device[const.HOST], sesId, self.logger)
             nsLoginObj.logout(sesId)
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in get Device Counters  = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in deviceCounter  = %s" + str(exMsg)
              path = []
              if rootKey:
                  path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
             try:
                  if (sesId):
                       nsLoginObj.logout(sesId)
             except:
                  pass
             tmpCol = {}
             self.logger.error(' ++++ ERROR in getDeviceCounters  = %s' % str(exMsg))
             errorMsg = " ERROR in deviceCounter  = %s" + str(exMsg)
             path = []
             if rootKey:
                 path.append(rootKey)
             errTuple = (path, 1001, errorMsg)
             tmpFltList = []
             tmpFltList.append(errTuple)
             tmpCol[const.STATE] = const.PERMANENT
             tmpCol[const.FAULTS] = tmpFltList
             tmpCol[const.HEALTH] = []
             return tmpCol

         return respCol
 #
 # This is to get service  counters
 #
     def getServiceCounters(self, device, cnfg):
         """
         This is to get service counters based on connectors
         """

         self.logger.debug('+++ This is to get serviceCounters for all the connectors')
         try:
	     sesId = None
             rootKey = None
             nsLoginObj = self.getLoginObj(device)
             sesId = nsLoginObj.login()

             # root element of the configuration
             rootKey = configUtil.getRootKey(cnfg, self.logger)

             # first get the URL
             url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)

             respCol = monitorUtil.getServiceCounters(cnfg, url, device[const.HOST], sesId, self.logger, device)
             nsLoginObj.logout(sesId)
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in get Service Counters  = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in serviceCounter  = %s" + str(exMsg)
              path = []
              if rootKey:
                 path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
             try:
                  if (sesId):
                       nsLoginObj.logout(sesId)
             except:
                  pass
             tmpCol = {}
             self.logger.error(' ++++ ERROR in getServiceCounters  = %s' % str(exMsg))
             errorMsg = " ERROR in serviceCounter  = %s" + str(exMsg)
             path = []
             if rootKey:
                path.append(rootKey)
             errTuple = (path, 1001, errorMsg)
             tmpFltList = []
             tmpFltList.append(errTuple)
             tmpCol[const.STATE] = const.PERMANENT
             tmpCol[const.FAULTS] = tmpFltList
             tmpCol[const.HEALTH] = []
             return tmpCol

         return respCol
# 
# This is to cluster audit 
#
     def clusterAudit(self, device, interface, cnfg):
          """
          This is to handle cluster audit details
          """
          self.logger.debug('+++++ This is to handle cluster audit +++++++++')
          credCol = {}
     
          respCol = {}
          credCol = device[const.CREDS]
          enableFeatureList = []
          disableFeatureList = []
          enableModeList = []
          disableModeList = []
          nsLoginObj = self.getLoginObj(device)
          vserObj = vServerUtil.VServerUtil(self.logger)
          rootKey = None
          sesId = None
          try:
               # first get the URL
               url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
               sesId = None
               enableFeatureList = configUtil.getDeviceFeatureCollection(cnfg, const.ENABLE_FEATURE, const.ENABLE_OPTIONS, self.logger, True)
               disableFeatureList = configUtil.getDeviceFeatureCollection(cnfg,const.ENABLE_FEATURE, const.DISABLE_OPTIONS, self.logger, True)
               partParmList = vserObj.getClusterPartParam(cnfg)
               sesId = nsLoginObj.login()
               nsObj = NSServer.NSServer(self.logger)

               rootKey = None
               # root element of the configuration
               rootKey = configUtil.getRootKey(cnfg, self.logger)

               tmpCol = {}

               partitionList = []
               
               retCol = vserObj.getClusterContextAwareFlag(device)
               if retCol[const.CONTEXTAWARE] == True:
                   path = vserObj.clusterConfigCheck(cnfg)
                   if len(path) > 0:
                      errTuple = (path, 3001, "parameters not supported in admin partition")
                      raise ValueError(errTuple)
                      
                   partitionList.append("default")
                   for vdev in retCol[const.VDEVS]:
                       partitionName = ""
                       if const.CONTEXT in vdev and const.TENANT in vdev and const.VDEV_ID in vdev:
                           partitionName = vdev[const.TENANT] + "_" + vdev[const.CONTEXT] + "_" + str(vdev[const.VDEV_ID])
                           partitionList.append(partitionName)
               else:
                   partitionList.append("default")  
                           
               for partition in partitionList:
                   vserObj.clusterAdminPartitionHandling(partition, url, device[const.HOST], partParmList, sesId)   
                   if len(enableFeatureList) > 0:
                       #self.logger.debug('Enable Feature List = %s' % (enableFeatureList))
                       tmpCol['enableFeatures'] = nsObj.enableFeatures(enableFeatureList, sesId, url)
                       respCol = dict(respCol.items() + tmpCol.items())
                       if const.OSPF in enableFeatureList:
                           # execute the RHI configuration
                           tmpCol = {}
                           time.sleep(10)  # sleep for 10 seconds since OSPF agent must be running before rhi config can run
                           tmpCol = configUtil.execRHIConfig(device, sesId, self.logger)
                           respCol = dict(respCol.items() + tmpCol.items())
                           #time.sleep(10)  # sleep for 10 seconds since OSPF agent must be running before rhi config can run
                           #rhconf.rhiNetworkConfig(url, device[const.HOST], credCol[const.USERNAME], credCol[const.PASSWORD], self.logger)
                       if len(disableFeatureList) > 0:
                           #self.logger.debug('Disable Feature List = %s' % (disableFeatureList))
                           tmpCol ={}
                           tmpCol['disableFeatures'] = nsObj.disableFeatures(disableFeatureList, sesId, url)
                           respCol = dict(respCol.items() + tmpCol.items())
                   # feature list collection
                   ferList = []
                   ferList = list(set(enableFeatureList) | set(disableFeatureList)) # this is to get union of the two lists
                   tmpCol = {}
                   tmpCol = nsObj.disableRemainigFeature(ferList, sesId, url)
                   respCol = dict(respCol.items() + tmpCol.items())

                   enableModeList = configUtil.getDeviceFeatureCollection(cnfg, const.ENABLE_MODE, const.ENABLE_OPTIONS, self.logger, True)
                   disableModeList = configUtil.getDeviceFeatureCollection(cnfg,const.ENABLE_MODE, const.DISABLE_OPTIONS, self.logger, True)
                   tmpCol = {}
                   # by default USNIP must be enabled
                   if const.USNIP not in enableModeList:
                       enableModeList.append(const.USNIP)
                   if len(enableModeList) > 0:
                       self.logger.debug('Enable Mode List = %s' % (enableModeList))
                       tmpCol['enableMode'] = nsObj.enableNSMode(enableModeList, const.ENABLE, sesId, url, device[const.HOST])
                       respCol = dict(respCol.items() + tmpCol.items())
                   tmpCol = {}
                   if len(disableModeList) > 0:
                       #self.logger.debug('Disable Mode List = %s' % (disableModeList))
                        tmpCol['disableMode'] = nsObj.enableNSMode(disableModeList, const.DISABLE, sesId, url, device[const.HOST])
                        respCol = dict(respCol.items() + tmpCol.items())

                   # turn off rest of the mode to avoid any stale config in device
                   devModeList = []
                   devModeList = nsObj.getNSModeList(sesId, url)
                   usrModeList = []
                   disModeList = []
                   usrModeList = list(set(enableModeList) | set(disableModeList))
                   for i in devModeList:
                        if i.lower() not in [nodeName.lower() for nodeName in usrModeList]:
                            disModeList.append(i)
                   if len(disModeList) > 0:
                        #self.logger.debug('Disable Rest of the modes in device  = %s' % (disModeList))
                        tmpCol['disableMode'] = nsObj.enableNSMode(disModeList, const.DISABLE, sesId, url, device[const.HOST])
                        respCol = dict(respCol.items() + tmpCol.items())
                   #end of partition handling
                   tmpCol = vserObj.saveConfig(url, device[const.HOST], sesId)
                   respCol = dict(respCol.items() + tmpCol.items())
                   vserObj.switchPartition("default", url, device[const.HOST], sesId) 
               
               if retCol[const.CONTEXTAWARE] == False:
                   tmpCol = {}
                   tmpCol['NTP'] = vserObj.processclusterAudit_NTP(url, device, interface, cnfg, sesId)
                   respCol = dict(respCol.items() + tmpCol.items())
               
                   tmpCol = {}
                   tmpCol = clusterAudit.computeDelete(cnfg, device, url, device[const.HOST], sesId, self.logger)
                   #resCode = dict(resCode.items() + tmpCode.items())
                   tmpCol = {}
                   resCode = {}
                   tmpCol = clusterAudit.computeModify(cnfg, device, url, device[const.HOST], device[const.VIRTUAL], sesId, self.logger)
                   resCode = dict(resCode.items() + tmpCol.items())
               else:
                   resCode = {}

	       tmpCol = vserObj.saveConfig(url, device[const.HOST], sesId)
	       resCode = dict(resCode.items() + tmpCol.items())

               #self.logger.debug('Final ClusterAudit response %s' % respCol)
               nsLoginObj.logout(sesId)

          except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in cluster Audit = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in clusterAudit device = %s" + str(exMsg)
              path = []
              if rootKey:
                 path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
          except Exception as exMsg:
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              tmpCol = {}
              path = []
              if rootKey:
                 path.append(rootKey)
              errorCode = 1001
              errorMsg = " ERROR in cluster Audit = %s" + str(exMsg)
              self.logger.error(' ++++ ERROR in Cluster Audit = %s' % str(exMsg))
              tmpTuple = (path, errorCode, errorMsg)
              fltList = []
              fltList.append(tmpTuple)
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = fltList
              tmpCol[const.HEALTH] = []
              return tmpCol
          retCol = {}
          resList = [] #configUtil.getFaults(respCol, self.logger)
          resList = configUtil.getFaults(rootKey, resCode, self.logger)
          
          if resList: # get Faults returned Faults
               retCol[const.STATE] = const.PERMANENT
          else:
               retCol[const.STATE] = const.SUCCESS
          
          retCol[const.FAULTS] = resList
          self.logger.debug('++++++++++++++ Cluster Audit response = %s' % (retCol))
          return retCol

# 
# This is to cluster Modify 
#
     def clusterModify(self, device, interface, cnfg):
          """
          This is to handle cluster Modify details
          """
          self.logger.debug('+++++ This is to handle cluster Modify +++++++++')
          credCol = {}
     
          respCol = {}
          credCol = device[const.CREDS]
          enableFeatureList = []
          disableFeatureList = []
          enableModeList = []
          disableModeList = []
          nsLoginObj = self.getLoginObj(device)
          vserObj = vServerUtil.VServerUtil(self.logger)
          try:
               # first get the URL
               rootKey = None
               url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
	       sesId = None

               # root element of the configuration
               rootKey = configUtil.getRootKey(cnfg, self.logger)

               enableFeatureList = configUtil.getDeviceFeatureCollection(cnfg, const.ENABLE_FEATURE, const.ENABLE_OPTIONS, self.logger, False)
               disableFeatureList = configUtil.getDeviceFeatureCollection(cnfg, const.ENABLE_FEATURE, const.DISABLE_OPTIONS, self.logger, False)
               partParmList = vserObj.getClusterPartParam(cnfg)
               sesId = nsLoginObj.login()
               nsObj = NSServer.NSServer(self.logger)
               tmpCol = {}

               partitionList = []
               
               retCol = vserObj.getClusterContextAwareFlag(device)
               if retCol[const.CONTEXTAWARE] == True:
                   path = vserObj.clusterConfigCheck(cnfg)
                   if len(path) > 0:
                      errTuple = (path, 3001, "parameters not supported in admin partition")
                      raise ValueError(errTuple)
                      
                   partitionList.append("default")
                   for vdev in retCol[const.VDEVS]:
                       partitionName = ""
                       if const.CONTEXT in vdev and const.TENANT in vdev and const.VDEV_ID in vdev:
                           partitionName = vdev[const.TENANT] + "_" + vdev[const.CONTEXT] + "_" + str(vdev[const.VDEV_ID])
                           partitionList.append(partitionName)
               else:
                   partitionList.append("default")  
                           
               for partition in partitionList:
                   vserObj.clusterAdminPartitionHandling(partition, url, device[const.HOST], partParmList, sesId)   
                   if len(enableFeatureList) > 0:
                       #self.logger.debug('cluster modify Enable Feature List = %s' % (enableFeatureList))
                       tmpCol['enableFeature'] = nsObj.enableFeatures(enableFeatureList, sesId, url)
                       respCol = dict(respCol.items() + tmpCol.items())
                       if const.OSPF in enableFeatureList:
                            tmpCol= {}
                            time.sleep(10)  # sleep for 10 seconds since OSPF agent must be running before rhi config can run
                            tmpCol['RHI'] = configUtil.execRHIConfig(device, sesId, self.logger)
                            respCol = dict(respCol.items() + tmpCol.items())
                            #time.sleep(10)  # sleep for 10 seconds since OSPF agent must be running before rhi config can run
                            #rhconf.rhiNetworkConfig(device[const.HOST], credCol[const.USERNAME], credCol[const.PASSWORD], self.logger)
                   if len(disableFeatureList) > 0:
                       #self.logger.debug('cluster modify Disable Feature List = %s' % (disableFeatureList))
                       tmpCol ={}
                       tmpCol['disableFeatures'] = nsObj.disableFeatures(disableFeatureList, sesId, url)
                       respCol = dict(respCol.items() + tmpCol.items())
                       tmpCol = {}
                   enableModeList = configUtil.getDeviceFeatureCollection(cnfg, const.ENABLE_MODE, const.ENABLE_OPTIONS, self.logger, False)
                   disableModeList = configUtil.getDeviceFeatureCollection(cnfg,const.ENABLE_MODE, const.DISABLE_OPTIONS, self.logger, False)
                   tmpCol = {}
                   # by default USNIP must be enabled
                   if const.USNIP not in enableModeList:
                       enableModeList.append(const.USNIP) 
                   if len(enableModeList) > 0:
                       #self.logger.debug('Enable Mode List = %s' % (enableModeList))
                       tmpCol['enableMode'] = nsObj.enableNSMode(enableModeList, const.ENABLE, sesId, url, device[const.HOST])
                       respCol = dict(respCol.items() + tmpCol.items())
                       tmpCol = {}
                   if len(disableModeList) > 0:
                       #self.logger.debug('Disable Mode List = %s' % (disableModeList))
                       tmpCol['disableMode'] = nsObj.enableNSMode(disableModeList, const.DISABLE, sesId, url, device[const.HOST])
                       respCol = dict(respCol.items() + tmpCol.items())
                   #end of partition handling
                   tmpCol = vserObj.saveConfig(url, device[const.HOST], sesId)
                   respCol = dict(respCol.items() + tmpCol.items())
                   vserObj.switchPartition("default", url, device[const.HOST], sesId) 

               if retCol[const.CONTEXTAWARE] == False:
                   tmpCol = {}
                   tmpCol['NTP'] = vserObj.processClusterModify_NTP(url, device, interface, cnfg, sesId)
                   respCol = dict(respCol.items() + tmpCol.items())
               
                   tmpCol = {}
                   tmpCol = vserObj.processClusterModify(url, device, interface, cnfg, sesId)
                   respCol = dict(respCol.items() + tmpCol.items())

	       tmpCol = vserObj.saveConfig(url, device[const.HOST], sesId)
	       respCol = dict(respCol.items() + tmpCol.items())

               #self.logger.debug('Final ClusterModify response %s' % respCol)
               nsLoginObj.logout(sesId)

          except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in cluster modify = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in clusterModify device = %s" + str(exMsg)
              path = []
              if rootKey:
                 path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
          except ValueError as valError:
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              tmpCol = {}
              tmpErTup = valError.args
              tmpFltList = []
              tmpFltList.append(tmpErTup[0])
              self.logger.error(' ++++ ERROR in clusterModify = %s' % str(valError))
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol

          except Exception as exMsg:
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              tmpCol = {}
              path = []
              if rootKey:
                 path.append(rootKey)
              errorCode = 1001
              errorMsg = " ERROR in cluster Modify = %s" + str(exMsg)
              self.logger.error(' ++++ ERROR in Cluster Modify = %s' % str(exMsg))
              tmpTuple = (path, errorCode, errorMsg)
              fltList = []
              fltList.append(tmpTuple)
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = fltList
              tmpCol[const.HEALTH] = []
              return tmpCol
          
          retCol = {}
          resList = [] 
          resList = configUtil.getFaults(rootKey, respCol, self.logger)

          if resList: # get Faults has returned Faults
               retCol[const.STATE] = const.PERMANENT
          else:
               retCol[const.STATE] = const.SUCCESS

          retCol[const.FAULTS] = resList
          self.logger.debug('++++++++++++++ Cluster Modify response = %s' % (retCol))
          return retCol

 #
 # This is to handle deviceAudit
 #
     def deviceAudit(self, device, interface, cnfg):
         """
         This is to handle the deviceAudit which will include clear config extended+, HA & SNIP config
         """
         #self.logger.debug('+++++++ Device Audit call for device = %s' % (device[const.HOST]))
         #try:
         #    nsLoginOb
         retCol = {} 
         self.logger.debug('+++++++ deviceAudit for device = %s' % (device[const.HOST]))
         vserObj = vServerUtil.VServerUtil(self.logger)
         nsLoginObj = self.getLoginObj(device)
         try:
	      sesId = None
              rootKey = None
              sesId = nsLoginObj.login()
              # root element of the configuration
              rootKey = configUtil.getRootKey(cnfg, self.logger)

         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in device Audit = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in deviceAudit device = %s" + str(exMsg)
              path = []
              if rootKey:
                 path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
              tmpCol = {}
              path = []
              if rootKey:
                 path.append(rootKey)
              errorCode = 1001
              errorMsg = " ERROR in Device Audit = %s" + str(exMsg)
              self.logger.error(' ++++ ERROR in deviceAudit = %s' % str(exMsg))
              tmpTuple = (path, errorCode, errorMsg)
              fltList = []
              fltList.append(tmpTuple)
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = fltList
              tmpCol[const.HEALTH] = []
              return tmpCol

         try :
            # first get the URL
            url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
            # get the state of the device since clear config will fail in secondary
            devState = configUtil.getHAStateOfDevice(const.HANODE, url, device[const.HOST], sesId, self.logger)
            #self.logger.debug('++++ deviceAudit device state = %s' % (devState))
            # first clear the configuration from the device               
            if devState is not None and devState.strip().lower() == const.PRIMARY:
                 #retCol = configUtil.clearNSConfigFromDevice(url, device[const.HOST], const.EXTENDED, sesId, self.logger)
	         #tmpCode = audit.computeDelete(cnfg, device, device[const.HOST], sesId, self.logger)
                 #retCol = dict(retCol.items() + tmpCode.items())
                 # ignore the device audit process if the config is empty 
                 if len(cnfg) > 0:
                      tmpCol = vserObj.processDeviceAudit(device, interface, cnfg, sesId)
                      retCol = dict(retCol.items() + tmpCol.items())
	         #tmpCode = audit.computeModify(cnfg, device, device[const.HOST], device[const.VIRTUAL], sesId, self.logger) 
                 #retCol = dict(retCol.items() + tmpCode.items())
                 #tmpCol = {}
            #nsObj = NSServer.NSServer(self.logger)
            #boolResp = nsObj.enableFeatures(sesId, device[const.HOST])
            #nsObj.enableNSMode(sesId, device[const.HOST])
            #if len(cnfg) > 0: # this is to check if config is empty
            #     tmpCol = vserObj.processDeviceAudit(device, interface, cnfg, sesId)
            #     retCol = dict(retCol.items() + tmpCol.items())
            #else:
            #     tmpCol = {}
            #     tmpCol = configUtil.getObjColFromDevModCnfg(cnfg, const.HAPEER, self.logger)
            #     if len(tmpCol) == 0:
            #          tmpCol = {}
            #          tmpCol = vserObj.removeHAPeerFromDevice(device[const.HOST], sesId)
            #          retCol = dict(retCol.items() + tmpCol.items())
            devHealthVal = monitorUtil.getDeviceHealth(url, device[const.HOST], sesId, interface, cnfg, self.logger)
            nsLoginObj.logout(sesId)
         except requests.exceptions.RequestException as exMsg:
              self.logger.error(' ++++ Connection error in device Audit = %s' % str(exMsg))
	      tmpCol = {}
              errorMsg = " ERROR in deviceAudit = %s" + str(exMsg)
              path = []
              if rootKey:
                 path.append(rootKey)
              errTuple = (path, 1001, errorMsg)
              tmpFltList = []
              tmpFltList.append(errTuple)
              tmpCol[const.STATE] = const.TRANSIENT 
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol
         except Exception as exMsg:
              tmpCol = {}
              try:
                   if (sesId):
                        nsLoginObj.logout(sesId)
              except:
                   pass
              self.logger.error(' ++++ ERROR in deviceAudit  = %s' % str(exMsg))
              path = []
              if rootKey:
                 path.append(rootKey)
              errorCode = 1001
              errorMsg = " ERROR in deviceAudit = %s" + str(exMsg)
              tmpTuple = (path, errorCode, errorMsg)
              tmpFltList = []
              tmpFltList.append(tmpTuple)
              self.logger.error(' ++++ ERROR in deviceAudit = %s' % str(exMsg))
              tmpCol[const.STATE] = const.PERMANENT
              tmpCol[const.FAULTS] = tmpFltList
              tmpCol[const.HEALTH] = []
              return tmpCol

         # get the health details from the devHealthVal
         tmpHealthCol = {}
         for k1, v1 in devHealthVal.iteritems():
              if k1 == const.HEALTH:
                   tmpHealthCol = v1
         respCol = {}
	 respCol[const.STATE] = const.SUCCESS
         respCol[const.FAULTS] = []
         respCol[const.HEALTH] = tmpHealthCol
         self.logger.debug('++++++++++++++ Device Audit  response = %s' % (retCol))
         return respCol
        
#
# This is to handle the serviceAudit requests from NSDevice script
# 
     def serviceAudit(self, device, configuration):
        """
        This is to handle the serviceAudit modify request 
        """
        self.logger.debug('+++++++ Service Audit Call for Device Details  = %s +++++++++++++++++'% (device[const.HOST]))

        resCode = {}
        tmpCode = {}
        serviceHealthScore = {}
	serviceAuditFlag = True
        # handle various state of the config 
        vserObj = vServerUtil.VServerUtil(self.logger)
	# this is to take care all the network specific such as VLAN/VXLAN, VIFs VLAN binding etc. 
        try :                           
            # first get the URL
            rootKey = None
            url = configUtil.getURL(device[const.PORT], device[const.HOST], self.logger)
            sesId = None
            vserObj.getContextAwareFlag(device)
            nsLoginObj = self.getLoginObj(device)
            sesId = nsLoginObj.login()

            # root element of the configuration
            rootKey = configUtil.getRootKey(configuration, self.logger)

	    # first clear the configuration from the device
	    tmpCode = {}
	    # there is problem with where it can not handle long folder names i.e. authenticationvserver_authenticationradiuspolicy_binding
	    # there is work around for this where 'aaa_' is replaced for authenticationvserver_authentication
	    # this is to replace 'aaa_' with authenticationvserver_authentication otherwise NITRO and other problem will occur
	    tmpCode = configUtil.replaceTokenName(const.AAA_TOKEN, const.AAA_REPLACE_TOKEN, configuration, self.logger)
            tmpCode = vserObj.adminPartitionHandling(configuration, url, device[const.HOST], sesId, serviceAuditFlag)
            resCode = dict(resCode.items() + tmpCode.items())
            # first handle the Param folder since it is only set or unset and remove them from config
            tmpCode = configUtil.handleParamObjects(configuration, url, device[const.HOST], sesId, self.logger, serviceAuditFlag)
            resCode = dict(resCode.items() + tmpCode.items())
	    entCol = audit.getMajorEntityCollection(configuration, self.logger)
	    tmpCode = audit.computeDelete(configuration, device, url, device[const.HOST], sesId, entCol, self.logger)
            #resCode = dict(resCode.items() + tmpCode.items())
	    tmpCode = audit.computeModify(configuration, entCol, device, url, device[const.HOST], device[const.VIRTUAL], sesId, self.logger)
            resCode = dict(resCode.items() + tmpCode.items())
            # this is to process attach & detach IPs
            tmpCode = audit.computeDeleteforAttachIp(configuration, device, url, device[const.HOST], device[const.VIRTUAL], sesId, self.logger)
            tmpCode = audit.computeModifyForAttachIp(configuration, device, url, device[const.HOST], device[const.VIRTUAL], sesId, self.logger)
            resCode = dict(resCode.items() + tmpCode.items())
            #resCode = dict(resCode.items() + tmpCode.items())
            #tmpCode = configUtil.clearNSConfigFromDevice(url, device[const.HOST], const.BASIC, sesId, self.logger)
            #resCode = dict(resCode.items() + tmpCode.items())
            #nsObj = NSServer.NSServer(self.logger)
            #boolResp = nsObj.enableFeatures(sesId, device[const.HOST])
            #nsObj.enableNSMode(sesId, device[const.HOST])
            #tmpCode = vserObj.processDeleteNetworkDataSet(device, configuration, device[const.HOST], device[const.VIRTUAL], sesId, serviceAuditFlag)
            #resCode = dict(resCode.items() + tmpCode.items())
            tmpCode = vserObj.processCreateNetworkDataSet(device, configuration, url, device[const.HOST], device[const.VIRTUAL], sesId, serviceAuditFlag)
            resCode = dict(resCode.items() + tmpCode.items())
            #tmpCode = vserObj.processCreateDataSet(configuration, device[const.HOST],sesId, serviceAuditFlag)
	    #resCode = dict(resCode.items() + tmpCode.items())
            #tmpCode = vserObj.processCreateBindDataSet(configuration, device[const.HOST],sesId, serviceAuditFlag)
	    #resCode = dict(resCode.items() + tmpCode.items())
	    # process NS IP binding with VLAN/VXLAN
	    tmpCode = vserObj.processFunctionSpecificIPVLANBinding(configuration, url, device[const.HOST], sesId, serviceAuditFlag)
	    resCode = dict(resCode.items() + tmpCode.items())
	    tmpCode = vserObj.applyAcls(url, device[const.HOST], sesId)
	    resCode = dict(resCode.items() + tmpCode.items())
	    tmpCode = vserObj.applyAcls6(url, device[const.HOST], sesId)
	    resCode = dict(resCode.items() + tmpCode.items())
	    tmpCode = vserObj.processRoutingConfig(device, configuration, True, url, sesId)
	    resCode = dict(resCode.items() + tmpCode.items())
	    tmpCode = vserObj.adminPartitionDel(configuration, url, device[const.HOST], sesId, serviceAuditFlag)
	    resCode = dict(resCode.items() + tmpCode.items())
	    tmpCode = vserObj.saveConfig(url, device[const.HOST], sesId)
	    resCode = dict(resCode.items() + tmpCode.items())
            serviceHealthScore = monitorUtil.getServiceHealth(configuration, device, sesId, self.logger)
            nsLoginObj.logout(sesId)
        except ValueError as valError:
             try:
                  if (sesId):
                       nsLoginObj.logout(sesId)
             except:
                  pass
             tmpCol = {}
             tmpErTup = valError.args
             tmpFltList = []
             tmpFltList.append(tmpErTup[0])
             self.logger.error(' ++++ ERROR in seviceModify = %s' % str(valError))
             tmpCol[const.STATE] = const.PERMANENT
             tmpCol[const.FAULTS] = tmpFltList
             tmpCol[const.HEALTH] = []
             return tmpCol
        except requests.exceptions.RequestException as exMsg:
             self.logger.error(' ++++ Connection error in service Audit = %s' % str(exMsg))
             tmpCol = {}
             errorMsg = " ERROR in serviceAudit = %s" + str(exMsg)
             path = []
             if rootKey:
                  path.append(rootKey)
             errTuple = (path, 1001, errorMsg)
             tmpFltList = []
             tmpFltList.append(errTuple)
             tmpCol[const.STATE] = const.TRANSIENT 
             tmpCol[const.FAULTS] = tmpFltList
             tmpCol[const.HEALTH] = []
             return tmpCol
        except Exception as exMsg:
             try:
                  if (sesId):
                       nsLoginObj.logout(sesId)
             except:
                  pass
             tmpCol = {}
             self.logger.error(' ++++ ERROR in serviceAudit  = %s' % str(exMsg))
             errorMsg = " ERROR in serviceAudit = %s" + str(exMsg)
             path = []
             if rootKey:
                  path.append(rootKey)
             tmpTuple = (path, 1001, errorMsg)
             tmpFltList = []
             tmpFltList.append(tmpTuple)
             tmpCol[const.STATE] = const.PERMANENT
             tmpCol[const.FAULTS] = tmpFltList
             tmpCol[const.HEALTH] = []
             return tmpCol

        retCol = {}
         
        #self.logger.debug('+++++++ Service Audit Response  = %s +++++++++++++++++'% (resCode))
        resList = configUtil.getFaults(rootKey, resCode, self.logger)
        if resList != []:
            retCol[const.STATE] = const.PERMANENT
        else:
            retCol[const.STATE] = const.SUCCESS
        retCol[const.FAULTS] = resList
        #retCol[const.STATE] = const.SUCCESS
        
        # get the health details from the serviceHealth
        if not resList:
             for k1, v1 in serviceHealthScore.iteritems():
                  if k1 == const.HEALTH:
                       tmpHealthCol = v1
             retCol[const.HEALTH] = tmpHealthCol
        
        self.logger.debug('++++++++++++++ ServiceAudit response = %s' % (retCol))  
        return retCol
