# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import pexpect 
import time
import sys
import os
import getpass
import re
from util import scriptConst as const
from feature import genericNitro

def rhiNetworkConfig(devIp, usrName, uPasswd, logger ):
	logger.debug('++++++ Configuring RHI network  device = %s ++++++++' % (devIp))
	vtyfile = '/nsconfig/ZebOS.static.conf'

	keys = ['authenticity','assword', ]
	os.system("ssh-keygen  -q -R " + devIp + ' 2>/dev/null')
	child = pexpect.spawn ('ssh ' + usrName + '@' + devIp)
	seen = child.expect (keys)
	if seen ==0:
		child.sendline ('yes')
		child.expect (keys)

	child.sendline (uPasswd)
	child.expect ('>')
	child.sendline ('shell vtysh -f ' + vtyfile)
	fout = open('/tmp/rhi.log', 'w')
	child.logfile = fout
        #child.logfile = sys.stdout
	child.expect ('>')
	print
	fout.close()
	#sys.exit()
	return 

def zebosConfigOpenSession(devIp, usrName, uPasswd, devCfg, logger):
	logger.debug('++++++ Configuring Zebos commands  device = %s ++++++++' % (devIp))
	objCol = getContextTenantName(devCfg, logger)

	keys = ['authenticity','assword', ]
	os.system("ssh-keygen  -q -R " + devIp + ' 2>/dev/null')
	child = pexpect.spawn ('ssh ' + usrName + '@' + devIp)
	#child.logfile = sys.stdout
	#fout = open('/tmp/routing.log', 'a')
	#child.logfile = fout
	seen = child.expect (keys)
	if seen ==0:
		child.sendline ('yes')
		child.expect (keys)

	child.sendline (uPasswd)
	child.expect ('>')
	
	if const.AdminPartitionSupport == True and const.TENANT in objCol:
		# default partition is created, and we can skip this part
		if objCol[const.TENANT] != 'default':
			partitionName = objCol[const.TENANT] + "_" + objCol[const.CONTEXT] + "_" + str(objCol[const.VDEV])
	else:
		partitionName = 'default'
	
	if partitionName != 'default':
		zebosConfigSendCommand (child, " switch ns partition " + partitionName , logger)
		#zebosConfigSendCommand (child, "enable ns feature IPv6PT", logger)
		zebosConfigSendCommand (child, "enable ns feature OSPF", logger)
		zebosConfigSendCommand (child, "enable ns feature BGP", logger)
		zebosConfigSendCommand (child, "set L3Param -dynamicRouting ENABLED", logger)
		zebosConfigSendCommand (child, "shell vtysh -v " + partitionName, logger)
	else:
		zebosConfigSendCommand (child, "enable ns feature IPv6PT", logger)
		zebosConfigSendCommand (child, "enable ns feature OSPF", logger)
		zebosConfigSendCommand (child, "enable ns feature BGP", logger)
		zebosConfigSendCommand (child, "set L3Param -dynamicRouting ENABLED", logger)
		zebosConfigSendCommand (child, "shell vtysh", logger)
	return child

def zebosConfigCloseSession(child, logger):
	logger.debug('++++++ Close Zebos commands  session ++++++++')

	if child.isalive():
	    #child.logfile.close()
	    child.close()
	return

def zebosConfigSendCommand(child, command, logger):
	logger.debug('++++++ Sending Zebos commands, command = %s ++++++++' %(command))
	errStr = ''
	if child.isalive():
	    child.sendline (command)
	else:
	    return errStr
	if command != 'exit':
	    child.expect (['#', '>', '%'])
	else :
	    child.expect (['#', '>', '%', 'Bye!'])
	inforStr = child.before
	logger.debug('++++++ child.before = %s ++++++++' %(inforStr))
	logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	counter = 0
	while child.before.find(command) < 0 and child.after.find(command) < 0:
	    counter += 1
	    if counter >= 20:
	        break
	    child.sendline(" ")
	    child.expect (['#', '>', '%'])
	    logger.debug('++++++ child.before = %s ++++++++' %(child.before))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	if (child.after == '%'):
	    child.expect (['#', '>'])
	    errMsg = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(errMsg))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	    errStr = errMsg.split('\n', 1)[0] + ' ' + command
	    logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	return errStr

def zebosConfigSendDelCommand(child, command, logger):
	errStr = zebosConfigSendCommand(child, command, logger)
	for item in const.OSPF_DEL_IGNORE_ERROR:
	    if errStr.strip().startswith(item) :
	        errStr = ''
	return errStr

def zebosSendOSPFIntfCreateCmd(child, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	errStr = ''
	ret = zebosGetOSPFIntf(child, vlan, logger)
	if ret['err'] != '':
	    return ret['err']
	errStr = errStr + zebosConfigSendCommand (child, "configure terminal", logger)
	#errStr = errStr + zebosConfigSendCommand (child, "ns ipv6-routing", logger)
	if ipv6:
	    errStr = 'No IPv6 support in partition' 
	    #errStr = errStr + zebosConfigSendCommand (child, "interface vlan"+str(vlan), logger)
	    #for cmdRouterLine in cmdRouterList:
	         #if cmdRouterLine.startswith('ipv6 router ospf area'):
	            #if ret['err'] == '':
	                #if ret['area'] != -1:
	                    #errStr = errStr + zebosConfigSendDelCommand (child, "no ipv6 router ospf area "+str(ret['area']) + " tag 1", logger)
	         #errStr = errStr + zebosConfigSendCommand (child, cmdRouterLine, logger)
	    #for cmdLine in cmdList:
	         #tempory solution since we don't support IPV6 OSPF interface in 10.1/10.5
	         #if not (cmdLine.startswith("authentication") or cmdLine.startswith("message-digest-key")):
	             #errStr = errStr + zebosConfigSendCommand (child, const.OSPFINTFIPV6 + cmdLine, logger)
	#else:
	    #errStr = errStr + zebosConfigSendCommand (child, "interface vlan"+str(vlan), logger)
	    #errStr = errStr + zebosSendOSPFIntfDelIpV6Cmd(child, ret, logger)
	#errStr = errStr + zebosConfigSendCommand (child, "exit", logger)
	    
	if ipv4:
	    errStr = errStr + zebosConfigSendCommand (child, "interface vlan"+str(vlan), logger)
	    for keyId in ret['authKeyId']:
	         errStr = errStr + zebosConfigSendDelCommand (child, "no ip ospf message-digest-key "+str(keyId), logger)
	    errStr = errStr + zebosConfigSendDelCommand (child, "no ip ospf authentication-key", logger)
	    for cmdLine in cmdList:    
	         errStr = errStr + zebosConfigSendCommand (child, const.OSPFINTFIPV4 + cmdLine, logger)
	else:
	    errStr = errStr + zebosConfigSendCommand (child, "interface vlan"+str(vlan), logger)
	    errStr = errStr + zebosSendOSPFIntfDelIpV4Cmd(child, ret, logger)
	errStr = errStr + zebosConfigSendCommand (child, "exit", logger)
	        
	errStr = errStr + zebosConfigSendCommand (child, "exit", logger)

	return errStr

def zebosOSPFIntfModCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	return zebosOSPFIntfCreateCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)

def zebosOSPFIntfAuditCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	return zebosOSPFIntfCreateCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)

def zebosSendOSPFIntfDelIpV4Cmd(child, param, logger):
	errStr = ''
	
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf cost", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf dead-interval", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf hello-interval", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf priority", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf retransmit-interval", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf transmit-delay", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf authentication", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf authentication-key", logger)
	errStr =  errStr + tmpErrStr
	if param['err'] == '':
	    for keyId in param['authKeyId']:
	        errStr = errStr + zebosConfigSendDelCommand (child, "no ip ospf message-digest-key "+str(keyId), logger)
	return errStr


def zebosSendOSPFIntfDelIpV6Nitro(child, param, logger):
	cmdstr = "no ipv6 ospf cost\n"
	cmdstr =  cmdstr + "no ipv6 ospf dead-interval\n"
	cmdstr =  cmdstr + "no ipv6 ospf hello-interval\n"
	cmdstr =  cmdstr + "no ipv6 ospf priority\n"
	cmdstr =  cmdstr + "no ipv6 ospf retransmit-interval\n"
	cmdstr =  cmdstr + "no ipv6 ospf transmit-delay\n"
	if param['err'] == 0:
	    if param['area'] != -1:
	        cmdstr =  cmdstr + "no ipv6 router ospf area "+str(param['area']) + " tag 1\n"
	logger.debug('+++++ zebosSendOSPFIntfCreateNitro cmdstr = %s ++++++' %(cmdstr))
	        

	return setZebosNitro(cmdstr, url, child, logger)

def zebosSendOSPFIntfDelCmd(child, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	errStr = ''
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendCommand (child, "interface vlan"+str(vlan), logger)
	errStr =  errStr + tmpErrStr
	if errStr != '':
	   return(zebosConfigSendCommand (child, "exit", logger))
	   
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf cost", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf dead-interval", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf hello-interval", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf priority", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf retransmit-interval", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf transmit-delay", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf authentication", logger)
	errStr =  errStr + tmpErrStr
	tmpErrStr = zebosConfigSendDelCommand (child, "no ip ospf authentication-key", logger)
	errStr =  errStr + tmpErrStr
	#tmpErrStr = zebosConfigSendDelCommand (child, "no ipv6 ospf cost", logger)
	#errStr =  errStr + tmpErrStr
	#tmpErrStr = zebosConfigSendDelCommand (child, "no ipv6 ospf dead-interval", logger)
	#errStr =  errStr + tmpErrStr
	#tmpErrStr = zebosConfigSendDelCommand (child, "no ipv6 ospf hello-interval", logger)
	#errStr =  errStr + tmpErrStr
	#tmpErrStr = zebosConfigSendDelCommand (child, "no ipv6 ospf priority", logger)
	#errStr =  errStr + tmpErrStr
	#tmpErrStr = zebosConfigSendDelCommand (child, "no ipv6 ospf retransmit-interval", logger)
	#errStr =  errStr + tmpErrStr
	#tmpErrStr = zebosConfigSendDelCommand (child, "no ipv6 ospf transmit-delay", logger)
	#errStr =  errStr + tmpErrStr
	ret = zebosGetOSPFIntf(child, vlan, logger)
	if ret['err'] == '':
	    #if ret['area'] != -1:
	        #errStr = errStr + zebosConfigSendDelCommand (child, "no ipv6 router ospf area "+str(ret['area'])+" tag 1", logger)
	    for keyId in ret['authKeyId']:
	        errStr = errStr + zebosConfigSendDelCommand (child, "no ip ospf message-digest-key "+str(keyId), logger)
	tmpErrStr = zebosConfigSendCommand (child, "exit", logger)
	errStr =  errStr + tmpErrStr
	        
	tmpErrStr = zebosConfigSendCommand (child, "exit", logger)
	errStr =  errStr + tmpErrStr
	        
	return errStr

def zebosSendOSPFIntfDelNitro(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	cmdstr = "interface vlan"+str(vlan)+"\n"
	   
	cmdstr = cmdstr +  "no ip ospf cost\n"
	cmdstr = cmdstr +  "no ip ospf dead-interval\n"
	cmdstr = cmdstr +  "no ip ospf hello-interval\n"
	cmdstr = cmdstr +  "no ip ospf priority\n"
	cmdstr = cmdstr +  "no ip ospf retransmit-interval\n"
	cmdstr = cmdstr +  "no ip ospf transmit-delay\n"
	cmdstr = cmdstr +  "no ip ospf authentication\n"
	cmdstr = cmdstr +  "no ip ospf authentication-key\n"
	cmdstr = cmdstr +  "no ipv6 ospf cost\n"
	cmdstr = cmdstr +  "no ipv6 ospf dead-interval\n"
	cmdstr = cmdstr +  "no ipv6 ospf hello-interval\n"
	cmdstr = cmdstr +  "no ipv6 ospf priority\n"
	cmdstr = cmdstr +  "no ipv6 ospf retransmit-interval\n"
	cmdstr = cmdstr +  "no ipv6 ospf transmit-delay\n"
	ret = zebosGetOSPFIntfNitro(child, url, vlan, logger)
	if ret['err'] == 0:
	    if ret['area'] != -1:
	        cmdstr = cmdstr + "no ipv6 router ospf area "+str(ret['area'])+" tag 1\n"
	    for keyId in ret['authKeyId']:
	        cmdstr = cmdstr + "no ip ospf message-digest-key "+str(keyId)+"\n"
	logger.debug('+++++ zebosSendOSPFIntfDelNitro cmdstr = %s ++++++' %(cmdstr))
	        

	return setZebosNitro(cmdstr, url, child, logger)

def zebosOSPFIntfDelCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	if const.DefaultPartition == True:
		return zebosSendOSPFIntfDelNitro(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)
	else:
		return zebosSendOSPFIntfDelCmd(child, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)

def zebosOSPFIntfCreateCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	if const.DefaultPartition == True:
		return zebosSendOSPFIntfCreateNitro(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)
	else:
		return zebosSendOSPFIntfCreateCmd(child, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)

def zebosSendOSPFIntfCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger, state):
	errStr = ''
	
	if state == const.CREATE:
	    errStr = zebosOSPFIntfCreateCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)
	elif state == const.MODIFY:
	    errStr = zebosOSPFIntfModCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)
	elif state == const.DELETE:
	    errStr = zebosOSPFIntfDelCmd(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger)
	#errStr = errStr + zebosConfigSendCommand (child, "write mem", logger)
	#errStr = errStr + zebosConfigSendCommand (child, "exit", logger)
	
	logger.debug('++++++ latest errStr = %s ++++++++' %(errStr))
	return errStr

def zebosSendOSPFProcessCreateCmd(child, cmdList, logger):
	errStr = ''
	tmpErrStr = ''
	
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr = errStr + tmpErrStr
	    
	#errStr = errStr + zebosConfigSendCommand (child, "ns route-install ipv6 ospf", logger)
	errStr = errStr + zebosConfigSendCommand (child, "ns route-install ospf", logger)
	#errStr = errStr + zebosConfigSendCommand (child, "ns ipv6-routing", logger)
	    
	for cmdLine in cmdList:
	    if cmdLine.startswith("no"):
	        tmpErrStr = zebosConfigSendDelCommand (child,cmdLine, logger)
	    else: 
	        tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	    if tmpErrStr.strip().startswith("The area is configured as NSSA"):
	        tmpErrStr = zebosConfigSendCommand (child,"no " + cmdLine.split()[0] + " " + cmdLine.split()[1] + " nssa")
	        errStr = errStr + tmpErrStr
	        tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	        errStr = errStr + tmpErrStr
	    elif tmpErrStr.strip().startswith("The area is configured as stub"):
	        tmpErrStr = zebosConfigSendCommand (child,"no " + cmdLine.split()[0] + " " + cmdLine.split()[1] + " stub")
	        errStr = errStr + tmpErrStr
	        tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	        errStr = errStr + tmpErrStr
	    elif tmpErrStr.strip().startswith("There is already the same network statement"):
	        errStr = errStr
	    else:
	        errStr = errStr + tmpErrStr
	    
	         
	tmpErrStr = zebosConfigSendCommand (child, "exit", logger)
	errStr = errStr + tmpErrStr        
	tmpErrStr =  zebosConfigSendCommand (child, "exit", logger)
	errStr = errStr + tmpErrStr
	
	return errStr

def zebosSendOSPFProcessCreateNitro(child, url, cmdList, logger):
	cmdstr = "ns route-install ipv6 ospf\n"
	cmdstr = cmdstr + "ns route-install ospf\n"
	cmdstr = cmdstr + "ns ipv6-routing\n"   
	
	setZebosNitro(cmdstr, url, child, logger)
	
	cmdstr = ''    	    
	for cmdLine in cmdList:
	    if cmdLine.strip().startswith("no redistribute") == False:
	    	cmdstr = cmdstr + cmdLine + "\n"

	    #if cmdLine.startswith("no"):
	    #    tmpErrStr = zebosConfigSendDelCommand (child,cmdLine, logger)
	    #else: 
	    #    tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	    #if tmpErrStr.strip().startswith("The area is configured as NSSA"):
	    #    tmpErrStr = zebosConfigSendCommand (child,"no " + cmdLine.split()[0] + " " + cmdLine.split()[1] + " nssa")
	    #    errStr = errStr + tmpErrStr
	    #    tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	    #    errStr = errStr + tmpErrStr
	    #elif tmpErrStr.strip().startswith("The area is configured as stub"):
	    #    tmpErrStr = zebosConfigSendCommand (child,"no " + cmdLine.split()[0] + " " + cmdLine.split()[1] + " stub")
	    #    errStr = errStr + tmpErrStr
	    #    tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	    #    errStr = errStr + tmpErrStr
	    #elif tmpErrStr.strip().startswith("There is already the same network statement"):
	    #    errStr = errStr
	    #else:
	    #    errStr = errStr + tmpErrStr
	    
	         
	
	return setZebosNitro(cmdstr, url, child, logger)

def zebosSendOSPFProcessDelCmd(child, cmdList, logger):
	errStr = ''
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr =  errStr + tmpErrStr
	
	tmpErrStr = zebosConfigSendCommand (child, cmdList[0], logger)
	errStr =  errStr + tmpErrStr
	
	for cmdLine in cmdList:
	    if cmdLine.strip().startswith('area'):
	        tmpErrStr = zebosConfigSendDelCommand (child, "no " + cmdLine, logger)
	        errStr =  errStr + tmpErrStr
	
	tmpErrStr = zebosConfigSendCommand (child, "exit", logger)
	errStr =  errStr + tmpErrStr
	        
	tmpErrStr = zebosConfigSendCommand (child, "exit", logger)
	errStr =  errStr + tmpErrStr
	return errStr
	
def zebosSendOSPFProcessDelNitro(child, url, cmdList, logger):
	cmdstr = cmdList[0]+"\n"
	
	for cmdLine in cmdList:
	    if cmdLine.strip().startswith('area'):
	        cmdstr = cmdstr + "no " + cmdLine + "\n"
	        
	return setZebosNitro(cmdstr, url, child, logger)
	

def zebosSendOSPFProcessMod(child, url, cmdList, logger):
	return zebosOSPFProcessCreate(child, url, cmdList, logger)

def zebosSendOSPFProcessCmd(child, url, cmdList, logger, state):
	if state == const.CREATE:
	    errStr = zebosOSPFProcessCreate(child, url, cmdList, logger)
	elif state == const.MODIFY:
	    errStr = zebosSendOSPFProcessMod(child, url, cmdList, logger)
	elif state == const.DELETE:
	    errStr = zebosSendOSPFProcessDel(child, url, cmdList, logger)
	
	logger.debug('++++++ latest errStr = %s ++++++++' %(errStr))
	return errStr
	

def zebosOSPFProcessCreate(child, url, cmdList, logger):
	if const.DefaultPartition == True:
		return zebosSendOSPFProcessCreateNitro(child, url, cmdList, logger)
	else:
		return zebosSendOSPFProcessCreateCmd(child, cmdList, logger)

def zebosSendOSPFProcessDel(child, url, cmdList, logger):
	if const.DefaultPartition == True:
		return zebosSendOSPFProcessDelNitro(child, url, cmdList, logger)
	else:
		return zebosSendOSPFProcessDelCmd(child, cmdList, logger)

def zebosSendBGPProcessCreateCmd(child, cmdList, logger):
	errStr = ''
	tmpErrStr = ''
	
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr = errStr + tmpErrStr
	    
	tmpErrStr = zebosConfigSendCommand (child, "bgp multiple-instance", logger)
	errStr = errStr + tmpErrStr
	
	#tmpErrStr = zebosConfigSendCommand (child, "ns ipv6-routing", logger)
	#errStr = errStr + tmpErrStr
	
	#errStr = errStr + zebosConfigSendCommand (child, "ns route-install ipv6 bgp", logger)
	errStr = errStr + zebosConfigSendCommand (child, "ns route-install bgp", logger)
	
	for cmdLine in cmdList:
	    if cmdLine.startswith("no"):
	        tmpErrStr = zebosConfigSendDelCommand (child,cmdLine, logger)
	    else: 
	        tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	        if tmpErrStr.strip().startswith("The same object already exists"):
	            tmpErrStr = ''
	    errStr = errStr + tmpErrStr
	    
	tmpErrStr = zebosConfigSendCommand (child, "exit", logger)
	errStr = errStr + tmpErrStr        
	tmpErrStr =  zebosConfigSendCommand (child, "exit", logger)
	errStr = errStr + tmpErrStr
	
	return errStr

def zebosSendBGPProcessCreateNitro(child, url, cmdList, logger):
	cmdstr =  "bgp multiple-instance\n"
	cmdstr = cmdstr + "ns ipv6-routing\n"
	cmdstr = cmdstr + "ns route-install ipv6 bgp\n"
	cmdstr = cmdstr + "ns route-install bgp\n"
	
	
	setZebosNitro(cmdstr, url, child, logger)
	
	cmdstr = ''
	cmdRtrID = ''
	for cmdLine in cmdList:
	    #if cmdLine.startswith("no"):
	        #tmpErrStr = zebosConfigSendDelCommand (child,cmdLine, logger)
	    #else: 
	        #tmpErrStr = zebosConfigSendCommand (child,cmdLine, logger)
	        #if tmpErrStr.strip().startswith("The same object already exists"):
	            #tmpErrStr = ''
	    #errStr = errStr + tmpErrStr
	    if cmdLine.strip().startswith("bgp router-id"):
	        cmdRtrID = cmdLine
	    if "remote-as" in cmdLine.strip():
	        setZebosNitro(cmdstr, url, child, logger)
	        cmdstr = cmdList[0] + "\n"
	        cmdstr = cmdstr + cmdRtrID + "\n"
	    cmdstr = cmdstr + cmdLine + "\n"
	    
	return setZebosNitro(cmdstr, url, child, logger)


def zebosSendBGPProcessDelCmd(child, cmdList, logger):
	errStr = ''
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr =  errStr + tmpErrStr
	
	tmpErrStr = zebosConfigSendDelCommand (child, "no "+ cmdList[0], logger)
	errStr =  errStr + tmpErrStr
	
	tmpErrStr = zebosConfigSendCommand (child, "exit", logger)
	errStr =  errStr + tmpErrStr
	return errStr
	

def zebosSendBGPProcessDelNitro(child, url, cmdList, logger):
	cmdstr = "no "+ cmdList[0] + "\n"
	return setZebosNitro(cmdstr, url, child, logger)
	

def zebosSendBGPProcessDel(child, url, cmdList, logger):
	if const.DefaultPartition == True:
		return zebosSendBGPProcessDelNitro(child, url, cmdList, logger)
	else:
		return zebosSendBGPProcessDelCmd(child, cmdList, logger)


def zebosSendBGPProcessModCmd(child, url, cmdList, logger):
	return zebosSendBGPProcessCreate(child, url, cmdList, logger)

def zebosSendBGPProcessCreate(child, url, cmdList, logger):
	if const.DefaultPartition == True:
		return zebosSendBGPProcessCreateNitro(child, url, cmdList, logger)
	else:
		return zebosSendBGPProcessCreateCmd(child, cmdList, logger)


def zebosSendBGPProcessCmd(child, url, cmdList, logger, state):
	errStr = ''
	
	if state == const.CREATE:
	    errStr = zebosSendBGPProcessCreate(child, url, cmdList, logger)
	elif state == const.MODIFY:
	    errStr = zebosSendBGPProcessModCmd(child, url, cmdList, logger)
	elif state == const.DELETE:
	    errStr = zebosSendBGPProcessDel(child, url, cmdList, logger)
	
	logger.debug('++++++ latest errStr = %s ++++++++' %(errStr))
	return errStr

def zebosSaveRoutingConfig(child, logger):
	errStr = ''
	retry = 0
	
	while retry < const.MAX_RETRY: 
		errStr = ''
		errStr = errStr + zebosConfigSendCommand (child, "write mem", logger)
		if errStr.find("modules not ready") <0 :
			break
		else:
			retry += 1
			time.sleep(5)
		
	#we just tried to save config here, if it could not be saved, we will save it later in Nitro
	errStr = zebosConfigSendCommand (child, "exit", logger)
	
	logger.debug('++++++ latest errStr = %s ++++++++' %(errStr))
	return errStr

def zebosGetOSPFIntf(child, vlan, logger):
	ret = {}
	ret['area'] =  -1
	ret['authKeyId'] =  []
	errStr = ''
	
	logger.debug('++++++ show running-config interface vlan ++++++++')
	child.sendline ("show running-config interface vlan" + str(vlan) + " | include ospf")
	child.expect (['#', '%'])
	infoStr = child.before
	logger.debug('++++++ child.before = %s ++++++++' %(infoStr))
	logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	counter = 0
	while child.before.find("show running-config") < 0 and child.after.find("show running-config") < 0:
	    counter += 1
	    if counter >= 20:
	        break
	    child.sendline(" ")
	    child.expect (['#', '%'])
	    infoStr = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(child.before))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	if (child.after == '%'):
	    child.expect (['#', '>'])
	    errMsg = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(errMsg))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	    errStr = errMsg.split('\n', 1)[0]
	    logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	else :
	    for item in infoStr.split('\n'):
	        pos = item.find('ipv6 router ospf area')
	        if pos >= 0:
	            temp = map(int, re.findall(r'\d+', item[pos:]))
	            ret['area'] =  temp[1]
	        elif item.strip().startswith('ip ospf message-digest-key'):
	            ret['authKeyId'].append(int(re.search(r'\d+', item).group()))
	ret['err'] = errStr
	logger.debug('++++++ ret = %s ++++++++' %(ret))
	return ret

def zebosGetOSPFIntfNitro(child, url, vlan, logger):
	ret = {}
	ret['area'] =  -1
	ret['authKeyId'] =  []
	
	cmdstr = "show+running-config+interface+vlan" + str(vlan)
	respCol = getZebosConfig(cmdstr, url, child, logger)
	if respCol["errorcode"] == 0:
	    routing = respCol[const.ROUTING]
	    infoStr = routing[0][const.ROUTINGSHOWOUTPUT]
	    for item in infoStr.split('\n'):
	        pos = item.find('ipv6 router ospf area')
	        if pos >= 0:
	            temp = map(int, re.findall(r'\d+', item[pos:]))
	            ret['area'] =  temp[1]
	        elif item.strip().startswith('ip ospf message-digest-key'):
	            ret['authKeyId'].append(int(re.search(r'\d+', item).group()))
	ret['err'] = respCol["errorcode"]
	logger.debug('++++++ ret = %s ++++++++' %(ret))
	return ret

def zebosCheckOSPFIntf(child, vlan, logger):
	errStr = ''
	infoStr = ''
	ret = {}
	ret['area'] =  -1
	ret['authKeyId'] =  []
	
	logger.debug('++++++ show running-config interface vlan ++++++++')
	child.sendline ("show running-config interface vlan" + str(vlan))
	child.expect (['#', '%'])
	infoStr = child.before
	logger.debug('++++++ child.before = %s ++++++++' %(infoStr))
	logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	counter = 0
	while child.before.find("show running-config") < 0 and child.after.find("show running-config") < 0:
	    counter += 1
	    if counter >= 20:
	        break
	    child.sendline(" ")
	    child.expect (['#', '%'])
	    infoStr = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(child.before))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	if (child.after == '%'):
	    child.expect (['#', '>'])
	    errMsg = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(errMsg))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	    errStr = errMsg.split('\n', 1)[0]
	    logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	else :
	    if ("ospf" in infoStr) :
	        return True
	ret['err'] = errStr
	logger.debug('++++++ ret = %s ++++++++' %(ret))
	return False
	
	

def zebosCheckOSPFIntfNitro(child, url, vlan, logger):
	ret = {}
	ret['area'] =  -1
	ret['authKeyId'] =  []
	
	cmdstr = "show+running-config+interface+vlan" + str(vlan)
	respCol = getZebosConfig(cmdstr, url, child, logger)
	if respCol["errorcode"] == 0:
	    routing = respCol[const.ROUTING]
	    infoStr = routing[0][const.ROUTINGSHOWOUTPUT]   
	    if ("ospf" in infoStr) :
	        return True
	ret['err'] = respCol["errorcode"]
	logger.debug('++++++ ret = %s ++++++++' %(ret))
	return False
	
	
def zebosDeletOspfProcessIDCmd(child, processID, logger):
	errStr = ''
	
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr = errStr + tmpErrStr
	
	tmpErrStr = zebosConfigSendDelCommand (child, "no router ospf " + str(processID), logger)
	errStr = errStr + tmpErrStr
	    
	#tmpErrStr = zebosConfigSendDelCommand (child, "no router ipv6 ospf " + str(processID), logger)
	#errStr = errStr + tmpErrStr
	
	errStr = errStr + zebosConfigSendCommand (child, "exit", logger)
	logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	return errStr

def zebosDeletOspfProcessIDNitro(child, url, processID, logger):
	cmdstr = "no router ospf " + str(processID) + "\n"
	cmdstr = cmdstr + "no router ipv6 ospf " + str(processID) + "\n"
	return setZebosNitro(cmdstr, url, child, logger)

def zebosDeletOspfProcessID(child, url, processID, logger):
	if const.DefaultPartition == True:
		return zebosDeletOspfProcessIDNitro(child, url, processID, logger)
	else:
		return zebosDeletOspfProcessIDCmd(child,  processID, logger)

def zebosDeletOspfProcessCmd(child, logger):
	errStr = ''
	cmdList = []
	
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr = errStr + tmpErrStr
	
	logger.debug('++++++ show running-config router ospf | include ospf ++++++++')
	child.sendline ("show running-config router ospf | include ospf")
	child.expect (['#', '%'])
	infoStr = child.before
	logger.debug('++++++ child.before = %s ++++++++' %(infoStr))
	logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	counter = 0
	while child.before.find("show running-config") < 0 and child.after.find("show running-config") < 0:
	    counter += 1
	    if counter >= 20:
	        break
	    child.sendline(" ")
	    child.expect (['#', '%'])
	    infoStr = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(child.before))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	if (child.after == '%'):
	    child.expect (['#', '>'])
	    errMsg = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(errMsg))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	    errStr = errMsg.split('\n', 1)[0]
	    logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	else :
	    for item in infoStr.split('\n'):
	        pos = item.find('router ospf')
	        if pos >= 0 and item.find('running-config')<0:
	            tempStr = "no " + item[pos:]
	            cmdList.append(tempStr)
	
	#logger.debug('++++++ show running-config router ipv6 ospf | include ospf ++++++++')
	#child.sendline ("show running-config router ipv6 ospf | include ospf")
	#child.expect (['#', '%'])
	#infoStr = child.before
	#logger.debug('++++++ child.before = %s ++++++++' %(infoStr))
	#logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	#counter = 0
	#while child.before.find("show running-config") < 0 and child.after.find("show running-config") < 0:
	    #counter += 1
	    #if counter >= 20:
	        #break
	    #child.sendline(" ")
	    #child.expect (['#', '%'])
	    #infoStr = child.before
	    #logger.debug('++++++ child.before = %s ++++++++' %(child.before))
	    #logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	#if (child.after == '%'):
	    #child.expect (['#', '>'])
	    #errMsg = child.before
	    #logger.debug('++++++ child.before = %s ++++++++' %(errMsg))
	    #logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	    #errStr = errMsg.split('\n', 1)[0]
	    #logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	#else :
	    #for item in infoStr.split('\n'):
	        #pos = item.find('router ipv6 ospf')
	        #if pos >= 0 and item.find('running-config')<0:
	            #tempStr = "no " + item[pos:]
	            #cmdList.append(tempStr)
	            
	if cmdList != [] :
	    for cmdLine in cmdList:
	        logger.debug('++++++ cmdLine = %s ++++++++' %(cmdLine))
	        tmpErrStr = zebosConfigSendDelCommand (child,cmdLine, logger)
	        errStr = errStr + tmpErrStr
	    
	errStr = errStr + zebosConfigSendCommand (child, "exit", logger)
	logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	return errStr

def zebosDeletOspfProcessNitro(child, url, logger):
	logger.debug('++++++ show running-config router ospf | include ospf ++++++++')
	cmdstr = ""  
	retCol = {}
	cmdstrShow = "show+running-config+router+ospf+|+include+ospf" + "\n"
	respCol = getZebosConfig(cmdstrShow, url, child, logger)
	if respCol["errorcode"] == 0:
	    routing = respCol[const.ROUTING]
	    infoStr = routing[0][const.ROUTINGSHOWOUTPUT] 
	    for item in infoStr.split('\n'):
	        pos = item.find('router ospf')
	        if pos >= 0 and item.find('running-config')<0:
	            cmdstr =  cmdstr + "no " + item[pos:] + "\n"
	
	logger.debug('++++++ show running-config router ipv6 ospf | include ospf ++++++++')
	cmdstrShow = "show+running-config+router+ipv6+ospf+|+include+ospf" + "\n"
	respCol = getZebosConfig(cmdstrShow, url, child, logger)
	if respCol["errorcode"] == 0:
	    routing = respCol[const.ROUTING]
	    infoStr = routing[0][const.ROUTINGSHOWOUTPUT] 
	    for item in infoStr.split('\n'):
	        pos = item.find('router ipv6 ospf')
	        if pos >= 0 and item.find('running-config')<0:
	            cmdstr =  cmdstr + "no " + item + "\n"
	            
	if cmdstr != "" :
	    retCol = setZebosNitro(cmdstr, url, child, logger)
	return retCol

def zebosDeletOspfProcess(child, url, logger):
	if const.DefaultPartition == True:
		return zebosDeletOspfProcessNitro(child, url, logger)
	else:
		return zebosDeletOspfProcessCmd(child, logger)
	
	
def zebosDeletBGPCmd(child, logger):
	errStr = ''
	cmdList = []
	
	tmpErrStr = zebosConfigSendCommand (child, "configure terminal", logger)
	errStr = errStr + tmpErrStr
	
	logger.debug('++++++ show running-config router bgp ++++++++')
	child.sendline ("show running-config router bgp | include bgp")
	child.expect (['#', '%'])
	logger.debug('++++++ child.before = %s ++++++++' %(child.before))
	logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	infoStr = child.before
	counter = 0
	while child.before.find("show running-config") < 0 and child.after.find("show running-config") < 0:
	    counter += 1
	    if counter >= 20:
	        break
	    child.sendline(" ")
	    child.expect (['#', '%'])
	    infoStr = child.before
	    logger.debug('++++++ child.before = %s ++++++++' %(child.before))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	#fix me, will add multi page support later
	if (child.after == '%'):
	    child.expect (['#', '>'])
	    errMsg = infoStr
	    logger.debug('++++++ child.before = %s ++++++++' %(errMsg))
	    logger.debug('++++++ child.after = %s ++++++++' %(child.after))
	    errStr = errMsg.split('\n', 1)[0]
	    logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	else :
	    for item in infoStr.split('\n'):
	        pos = item.find('router bgp')
	        if pos >= 0 and item.find('running-config')<0:
	            tempStr = "no " + item[pos:]
	            cmdList.append(tempStr)
	            
	
	if cmdList != [] :
	    for cmdLine in cmdList:
	        logger.debug('++++++ cmdLine = %s ++++++++' %(cmdLine))
	        tmpErrStr = zebosConfigSendDelCommand (child,cmdLine, logger)
	        errStr = errStr + tmpErrStr
	    
	errStr = errStr + zebosConfigSendCommand (child, "exit", logger)
	logger.debug('++++++ errStr = %s ++++++++' %(errStr))
	return errStr

def zebosDeletBGPNitro(child, url, logger):
	logger.debug('++++++ show running-config router bgp ++++++++')
	cmdstr = ""  
	retCol = {}
	
	cmdstrShow = "show+running-config+router+bgp" + "\n"
	respCol = getZebosConfig(cmdstrShow, url, child, logger)
	if respCol["errorcode"] == 0:
	    routing = respCol[const.ROUTING]
	    infoStr = routing[0][const.ROUTINGSHOWOUTPUT] 
	    for item in infoStr.split('\n'):
	        pos = item.find('router bgp')
	        if pos >= 0 and item.find('running-config')<0:
	            cmdstr =  cmdstr + "no " + item[pos:] + "\n"
	            
	if cmdstr != "" :
	    retCol = setZebosNitro(cmdstr, url, child, logger)
	return retCol


def zebosDeletBGP(child, url, logger):
	if const.DefaultPartition == True:
		return zebosDeletBGPNitro(child, url,logger)
	else:
		return zebosDeletBGPCmd(child, logger)


#
# getContextTenantName
#
def getContextTenantName(devCfg, logger):
	logger.debug('+++++ get context tenant name from Config ++++++')
	objCol = {}

        for a1, b1 in devCfg.iteritems():
            objCol[const.VDEV] = a1[2]
            for a2, b2 in b1.iteritems():
                if (a2 == const.CONTEXT) or (a2 == const.TENANT) or(a2 == const.STATE) :
                    objCol[a2] = b2
        logger.debug('+++++ getContextTenantName = %s ++++++' %(objCol))
        return objCol


def zebosSendOSPFIntfCreateNitro(child, url, cmdList, cmdRouterList, ipv4, ipv6, vlan, logger):
	cmdstr = "ns ipv6-routing\n"
	setZebosNitro(cmdstr, url, child, logger)
	cmdstr = "interface vlan"+str(vlan)+ "\n"
	tempStr = None
	#ret = zebosGetOSPFIntfNitro(child, vlan, logger)
	
	if ipv6:
	    for cmdRouterLine in cmdRouterList:
	         #if cmdRouterLine.startswith('ipv6 router ospf area'):
	            #if ret['err'] == 0:
	                #if ret['area'] != -1:
	                    #errStr = errStr + zebosConfigSendDelCommand (child, "no ipv6 router ospf area "+str(ret['area']) + " tag 1", logger)
	         cmdstr = cmdstr + cmdRouterLine +"\n"
	    for cmdLine in cmdList:
	         #tempory solution since we don't support IPV6 OSPF interface in 10.1/10.5
	         if not (cmdLine.startswith("authentication") or cmdLine.startswith("message-digest-key")):
	             cmdstr = cmdstr + const.OSPFINTFIPV6 + cmdLine + "\n"
	#else:
	    #cmdstr = cmdstr + zebosSendOSPFIntfDelIpV6Cmd(child, ret, logger)
	    
	if ipv4:
	    #if ret['err'] == 0:
	        #for keyId in ret['authKeyId']:
	             #errStr = errStr + zebosConfigSendDelCommand (child, "no ip ospf message-digest-key "+str(keyId), logger)
	    #errStr = errStr + zebosConfigSendDelCommand (child, "no ip ospf authentication-key", logger)
	    for cmdLine in cmdList:    
	         cmdstr = cmdstr + const.OSPFINTFIPV4 + cmdLine + "\n"
	#else:
	    #errStr = errStr + zebosConfigSendCommand (child, "interface vlan"+str(vlan), logger)
	    #errStr = errStr + zebosSendOSPFIntfDelIpV4Cmd(child, ret, logger)
	logger.debug('+++++ zebosSendOSPFIntfCreateNitro cmdstr = %s ++++++' %(cmdstr))
	        

	return setZebosNitro(cmdstr, url, child, logger)

#
# Switch generic object using NITRO APIs
#

def setZebosNitro(cmdstr, url, sessionId, logger):
    logger.debug('+++++++++++++ setZebosNitro ------- cmdstr = %s' %(cmdstr))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode[const.ROUTING] = nsGenSerObj.setZebosNitroParams(cmdstr, url, sessionId)
    except Exception as exMsg:
        logger.error('Exception from setZebosNitro = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[const.ROUTING] = retCol
    return resCode

#
#
# This is to get routing related configuration from NetScaler
#
def getZebosConfig(cmdstr, url, sesId, logger):
    logger.debug('+++++++++++++ getZebosConfig ------- cmdstr = %s' %(cmdstr))
    resCode = {}
    try:
        nsGenSerObj = genericNitro.NitroMapper(logger)
        resCode = nsGenSerObj.getZebosNitroFromDevice(cmdstr, url, sesId)
        #respDat = respDat.json() 
        #resCode = respDat[self.ERRORCODE]
    except Exception as exMsg:
        logger.error('Exception from getZebosConfig = %s' % str(exMsg))
        retCol = {}
        retCol[const.ERRORCODE] = 1001
        retCol[const.MESSAGE] = str(exMsg)
        retCol[const.STATE] = const.PERMANENT
        retCol[const.SEVERITY] = "ERROR"

        resCode[const.ROUTING] = retCol

    return resCode

if __name__=='__main__':
	rhiNetworkConfig('172.23.50.132', 'nsroot', 'nsroot')
