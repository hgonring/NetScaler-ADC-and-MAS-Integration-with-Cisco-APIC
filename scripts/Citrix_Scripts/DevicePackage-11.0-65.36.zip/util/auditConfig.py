#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import sys
import sys
import scriptConst as const
import nitroUtil as nitro
import configUtil as util
import objectOrderNKey as constKey
import NSLogin
import objectOrderNKey as constKey
import vServerUtil as vser

#
# check if the binding has target or not
#
def checkBindingWithTarget(bndCol, logger):
    """
    This is to check if the binding has target or not
    """
    binFlag = False
    for a1, b1 in bndCol.iteritems():
        if a1 == const.VALUE:
            for a2, b2 in b1.iteritems():
                if a2[0] == const.MREL:
                   binFlag = True
                   break
    return binFlag

#
# get key value pair of attribute
#
def getObjectAttrValuePair(objName, objCol, logger):
    """
    This is to get key value pair for object attribute
    """
    logger.debug('objName = %s collection = %s' % (objName, objCol))
    retCol = {}
    nameCol = {}
    keyVal = None
    bindingList =  []
    keyName = None
    # get the key for the object 
    keyName = util.getObjectKey(objName, logger)
    if keyName is not None:
        keyName = keyName[0]
    logger.debug('ObjName = %s keyName = %s' % (objName, keyName))
    for c1, d1 in objCol.iteritems():
        #logger.debug('c1 = %s, d1 = %s' % (c1,d1))
        tmpBindCol = {}
        if c1[0] == const.PARAM:
            # param name will be second attribute of the tuple
            for c2, d2 in d1.iteritems():
                if c2 == const.VALUE:
                    if keyName is not None and c1[1] == keyName:
                        keyVal = d2
                    else:
                        retCol[c1[1]] = d2
        elif c1[0] == const.FOLDER and c1[1].find(const.BINDING) != -1: # this is for binding
            chkBndCol = d1
            bndWithNoTargetCol = {}
            mrelFlag = checkBindingWithTarget(chkBndCol, logger)
            if mrelFlag is False: # c1[1] == const.SVCGROUP_SGMEM_BIND:
                tmpSvmBindCol = {}
                # service group member has only key value pair no MREL
                for m1, n1 in d1.iteritems():
                    #logger.debug('m1 = %s n1 = %s' % (m1,n1))
                    if m1 == const.VALUE:
                        for m2, n2 in n1.iteritems():
                            #logger.debug('m2 = %s n2 = %s' % (m2,n2))
                            for m3, n3 in n2.iteritems():
                                if m3 == const.VALUE:
                                    bndWithNoTargetCol[m2[1]] = n3
                            #logger.debug('tmp bind col = %s' % (tmpBindCol))
                if len(bndWithNoTargetCol) > 0 :
                    tmpBindCol[c1[1]] = bndWithNoTargetCol
            else:
                for f1, g1 in d1.iteritems():
                #bindKey = getBindKeyFromConst(c1[1], logger)
                    if f1 == const.VALUE:
                        for f2, g2 in g1.iteritems():
                            if type(f2) is tuple and f2[0] == const.MREL:
                                for f3, g3 in g2.iteritems():
                                    if f3 == const.TARGET:
                                        tmpBindCol[c1[1]] = { f2[1] : g3 }
        if len(tmpBindCol) > 0:
            bindingList.append(tmpBindCol)

    if len(bindingList) > 0:
        retCol[objName + '_binding'] = bindingList
    logger.debug('Return collection = ' % (retCol))
    # make the entire attr key val collection based on key name
    #nameCol[keyVal] = retCol
    return (keyVal, retCol)
#
# get object dict collection
#
def getMajorEntityCollection(cnfg, logger):
    """
    This is to get major entities dictionary for later comparison from the APIC config
    """
    lbvSerCol = {}
    sgCol = {}
    nsipCol = {}
    vlanCol = {}
    encapCol = {}
    vifCol = {}
    funCol = {}
    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if type(a3) is tuple and a3[0] == const.FOLDER and a3[1] == const.LBVSERVER:
                        # this is to collect lbvserver collection
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                # get the key value pair for this object
                                keyVal = None
                                tmpCol = {}
                                keyVal, tmpCol = getObjectAttrValuePair(a3[1], b4, logger)
                                logger.debug('Return values name = %s, collection = %s' % (keyVal, tmpCol))
                                if keyVal is not None and len(tmpCol) > 0:
                                    tmpCol['apicTarget'] = a3[2]# lbvserver's instance name 
                                    lbvSerCol[keyVal] = tmpCol
                    elif type(a3) is tuple and a3[0] == const.FOLDER and a3[1] == const.SERVICEGROUP:
                         # this is to collect lbvserver collection
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                # get the key value pair for this object
                                keyVal = None
                                tmpCol = {}
                                keyVal, tmpCol = getObjectAttrValuePair(a3[1], b4, logger)
                                logger.debug('Service Group Return values name = %s, collection = %s' % (keyVal, tmpCol))
                                if keyVal is not None and len(tmpCol) > 0:
                                    tmpCol['apicTarget'] = a3[2] # this will be used for MREL since it is based on object's instance name
                                    sgCol[keyVal] = tmpCol
                    elif type(a3) is tuple and a3[0] == const.FOLDER and a3[1] == 'Network': # Network is defined in the Model
                        # this is to get nsip collection
                        netFldrName = a3[2] # this is required for establishing relationship with connector
                        for x1, y1 in b3.iteritems():
                            if x1 == const.VALUE:
                                for x2, y2 in y1.iteritems():
                                    #logger.debug('X2 = %s Y2 = %s' % (x2, y2))
                                    if x2[0] == const.FOLDER and x2[1] == const.NSIP:
                                        for x3, y3 in y2.iteritems():
                                            if x3 == const.VALUE:
                                                keyVal = None
                                                tmpCol = {}
                                                keyVal, tmpCol = getObjectAttrValuePair(x2[1], y3, logger)
                                                if keyVal is not None and len(tmpCol) > 0:
                                                    tmpCol['apicTarget'] = netFldrName + '/' + x2[2]
                                                    nsipCol[keyVal] = tmpCol
                    elif type(a3) is tuple and a3[0] == const.IFCTAG: # this is for VLAN
                        tagVal = None
                        tagType = None
                        for x1, y1 in b3.iteritems():
                            if x1 == const.TAG:
                                tagVal = y1
                            elif x1 == const.TYPE:
                                tagType = y1
                        if tagVal is not None and tagType == 1:
                            vlanCol[tagVal] = a3[2] # here store the vlan relationship to encap association
                    elif type(a3) is tuple and a3[0] == const.VENCAPASS: # this is vlan association with interface & connector
                        encapVal = None
                        vifVal = None
                        for x1, y1 in b3.iteritems():
                            if x1 == const.ENCAP:
                                encapVal = y1
                            elif x1 == const.VIF_NAME:
                                vifVal = y1
                        if encapVal is not None:
                            encapCol[encapVal] = {const.VIF_NAME : vifVal, 'apicTarget' : a3[2]}
                    elif type(a3) is tuple and a3[0] == const.VIF: # this is interface
                        cifVal = None
                        for x1, y1 in b3.iteritems():
                            if x1 == const.CIFS:
                                cifVal = y1
                        vifCol[a3[2]] = cifVal
                    elif type(a3) is tuple and a3[0] == const.FUNCTIONGROUP: # this is to create function object collection
                        tmpFunCol = {}
                        for x1, y1 in b3.iteritems():
                            if x1 == const.VALUE:
                                for x2, y2 in y1.iteritems(): # this is function
                                    for x3, y3 in y2.iteritems():
                                        if x3 == const.VALUE:
                                            funCol[((a3[2]),(x2[2]))] = getFunObjectCol(y3, logger)
                                     
                        
    #logger.debug('LBVServer Return collection = %s' % (lbvSerCol))
    #logger.debug('Service Group Return Collection = %s' % (sgCol))
    #logger.debug('NSIP Collection = %s' % (nsipCol))
    #logger.debug('VLan Collection = %s' % (vlanCol))
    #logger.debug('Encap assoicaition collection = %s' % (encapCol))
    #logger.debug('VIF or interface collection = %s' % (vifCol))
    #logger.debug('Fnction Object Collection = %s' % (funCol))

    return (lbvSerCol, sgCol, nsipCol, vlanCol, encapCol, vifCol, funCol)
#
# get function object col from APIC config
#
def getFunObjectCol(objCol, logger):
    """
    This is to get function object col from APIC config
    """
    netExConVal = None
    exNsipTargetVal = None
    inConVal = None
    exConVal = None
    netInConVal = None
    inNsipTargetVal = None
    inTargetEncapVal = None
    exTargetEncapVal = None
    for a1, b1 in objCol.iteritems():
        logger.debug('A1 = %s B1 = %s' % (a1, b1))
        if a1[0] == const.FOLDER and a1[1] == 'external_network':
            for a2, b2 in b1.iteritems():
                if a2 == const.CONNECTOR:
                    netExConVal = b2
                elif a2 == const.VALUE:
                    for a3, b3 in b2.iteritems():
                        if a3[0] == const.MREL and a3[1] == 'external_network_key':
                            for a4, b4 in b3.iteritems():
                                if a4 == const.TARGET:
                                    exNsipTargetVal = b4
        elif a1[0] == const.FOLDER and a1[1] == 'internal_network':
            for a2, b2 in b1.iteritems():
                if a2 == const.CONNECTOR:
                    netInConVal = b2
                elif a2 == const.VALUE:
                    for a3, b3 in b2.iteritems():
                        if a3[0] == const.MREL and a3[1] == 'internal_network_key':
                            for a4, b4 in b3.iteritems():
                                if a4 == const.TARGET:
                                    inNsipTargetVal = b4
        elif a1[0] == const.CONNECTION  and a1[1] == 'internal':
            inConVal = a1[2]
            for a2,b2 in b1.iteritems():
                if a2 == const.VALUE:
                    for a3, b3 in b2.iteritems():
                        if a3[0] == const.ENCAPREL:
                            for a4, b4 in b3.iteritems():
                                if a4 == const.TARGET:
                                    inEncapTargetVal = b4
        elif a1[0] == const.CONNECTION  and a1[1] == 'external':
            exConVal = a1[2]
            for a2,b2 in b1.iteritems():
                if a2 == const.VALUE:
                    for a3, b3 in b2.iteritems():
                        if a3[0] == const.ENCAPREL:
                            for a4, b4 in b3.iteritems():
                                if a4 == const.TARGET:
                                    exEncapTargetVal = b4
        
        #logger.debug('External Con Val = %s external NSIP val = %s' % (exConVal, exNsipTargetVal))
        #elif
    retCol = {}
    retCol[inConVal] = { 'nsipTarget' : inNsipTargetVal, 'encapTarget' : inEncapTargetVal }
    retCol[exConVal] = { 'nsipTarget' : exNsipTargetVal, 'excapTarget' : exEncapTargetVal }
    logger.debug('Return Function  Connector col  = %s'  % (retCol))
    return retCol

#
# This is to get modify object from the config
#
def computeModify(cnfg, entCol, deviceObj, url, devIp, virtualFlag, sesId, logger):
    """
    This is compute diff for object which are present in the NetScaler device
    """
    #logger.debug('++++++ Compute Modify +++++')
    modCol = {}
    addCol = {}
    retCol = {}
    tmpCol = {}
    # process all config objects first before processing VLAN & and its binding
    tmpCol = handleAllConfigEntities(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger)
    retCol = dict(tmpCol.items() + retCol.items())
    tmpCol = {}
    # process all VLANs & its related bindings
    #tmpCol = handleVLANNBindings(cnfg, deviceObj, entCol, url, devIp, virtualFlag, sesId, logger)
    tmpCol = processVLANNBindingsInCModify(cnfg, entCol, deviceObj, url, devIp, virtualFlag, sesId, logger)
    retCol = dict(tmpCol.items() + retCol.items())

    return retCol

#
# get the VLAN collection 
#
def getVlanIdsFromDevice(url, devIp, sesId, logger):
    """
    This is to get all the VLANs from the device
    """
    respCol = {}
    tmpCol = {}   #(objName, url, devIp, sesId, logger)
    tmpCol = nitro.getObjectsConfigFromDevice(const.VLAN_BIND, url, devIp, sesId, logger)
    for a1, b1 in tmpCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VLAN_BIND:
                logger.debug(' VLAN from device a2 = %s b2 = %s' % (a2, b2))
                tmpVal = {}
                for tmpVal in b2:
                    for a3, b3 in tmpVal.iteritems():
                        if a3 == const.ID:
                            respCol[b3] = a3 # here vlan ids will be unique and using dictionary is better than list
    logger.debug('Device Vlan collection = %s' % (respCol))
    return respCol

#
# find vlan key attribute from bind col
#
def findVlanKeyAtrFromBindCol(bndCol, bndName, keyVal, logger):
    """
    This is to get specific binding from the collection
    """
    findFlag = False
    logger.debug('Bind Col  = %s' % (bndCol))
    for a1, b1 in bndCol.iteritems():
        if a1 == 'vlan_binding':
            for tmpVlan in b1:
                for a2, b2 in tmpVlan.iteritems():
                    if a2 == bndName:
                        for tmpBindVal in b2:
                            for a3, b3 in tmpBindVal.iteritems():
                                if bndName == const.VLAN_INTERFACE_BIND_NAME:
                                    if a3 == const.IFNUM and b3 == keyVal:
                                        findFlag = True
                                        break
                                elif bndName == const.VLAN_NSIP_BINDING:
                                    if a3 == const.IPADDRESS and b3 == keyVal:
                                        findFlag = True
                                        break

    return findFlag
                            
#
# APIC's VLAN and related bindings during compute modify 
#
def processVLANNBindingsInCModify(cnfg, entCol, deviceObj, url, devIp, virtualFlag, sesId, logger):
    """
    This is to process VLAN N Bindings while processing compute Modify module
    """
    respCol = {}
    # get the vlan from device 
    devVlanCol = {}
    nodeVlanIfBindCol = {}
    nsipVlanBindCol = {}
    devVlanCol = getVlanIdsFromDevice(url, devIp, sesId, logger)
    #entity col is tuple of (lbvSerCol, sgCol, nsipCol, vlanCol, encapCol, vifCol, funCol) 
    audLbvCol, audSgCol, audNsipCol, audVlanCol, audEncapCol, audVifCol, audFunCol = entCol
    for a1, b1 in audVlanCol.iteritems():
        bindCol = {}
	#logger.debug('VLan from collection A1 = %s B1 = %s' % (a1, b1))
        # here a1 is vlan b1 is encap association
        # find if the VLAN exist in NetScaler or not
        if str(a1) in devVlanCol:
            logger.debug('VLAN  Id = %s' % (a1))
            # search for NSIP binding
            bindCol = nitro.getBindObjectsBinding('vlan_binding', a1, url, devIp, sesId, logger)
            encapAsVal = b1
            if encapAsVal in audEncapCol:
                tmpEnCol = {}
                tmpEnCol = audEncapCol[encapAsVal]
                vifNodeVal = None
                nsipTargetVal = None
                for f1, f2 in tmpEnCol.iteritems():
                    logger.debug('F1 = %s, F2 = %s' % (f1, f2))
                    if f1 == const.VIF_NAME:
                        vifNodeVal = f2
                    elif f1 == 'apicTarget':
                        nsipTargetVal = f2
                logger.debug('vif Node Val  = %s, nsipTarget = %s' % (nsipTargetVal, vifNodeVal))
                if vifNodeVal is not None:
                    nodeIfCol = {}
                    # get the node and interface
                    if vifNodeVal in audVifCol:
                        nodeIfCol = audVifCol[vifNodeVal]
                        logger.debug('nodeIf Col  = %s' % (nodeIfCol))
                        if len(nodeIfCol) > 0:
                            nodeVlanIfBindCol[a1] = nodeIfCol # here a1 is vlan id
                if nsipTargetVal is not None:
                    nsipValCol = {}
                    for x1, y1 in audFunCol.iteritems():
                        for x2, y2 in y1.iteritems():
                            # ignore x2 since it is either inside or outside
                            for x3, y3 in y2.iteritems():
                                if x3 == 'excapTarget' and y3 == nsipTargetVal:
                                    nsipValCol = y2
                                elif x3 == 'encapTarget' and y3 == nsipTargetVal:
                                    nsipValCol = y2
                    logger.debug('nsip col  = %s' % (nsipValCol))
                    if len(nsipValCol) > 0:
                        nsipTarVal = None
                        bindCol = {}
                        # get the nsip target value
                        nsipTarVal = nsipValCol['nsipTarget']
                        # find this nsip from nsip collection
                        for i1, o1 in audNsipCol.iteritems():
                            for i2, o2 in o1.iteritems():
                                if i2 == 'apicTarget' and o2 == nsipTarVal:
                                    # Find the nsip binding with the vlan in Device 
                                    nsipVlanBindCol[a1] = i1 # here i1 is NSIP
                                    srchFlag = findVlanKeyAtrFromBindCol(bindCol, const.VLAN_NSIP_BINDING, i1, logger)
                                    if srchFlag is False:
                                        # add this binding
                                        addBndCol = {}
                                        addBndCol[const.ID] = a1
                                        addBndCol[const.IPADDRESS] = i1
                                        tmpCol = {}
                                        tmpCol = nitro.createBindObject(const.VLAN_NSIP_BINDING, addBndCol, url, devIp, sesId, logger)
                                        respCol = dict(tmpCol.items() + respCol.items())
        else:
            logger.debug('Adding this vlan in device = %s' % (a1))
            # add this vlan
            vlanCol = {}
            vlanCol[const.ID] = a1
            tmpCol = {}
            # first get the cluster node from config
            nodeCol = util.getClusterColFromConfig(deviceObj, logger)
            # for each node get the ip and credential
            for m1, n1 in nodeCol.iteritems():
                for m2, n2 in n1.iteritems():
                    if m2.strip().lower() == const.HOST:
                        nodeHostVal = n2
                    elif m2.strip().lower() == const.PORT:
                        nodePortVal = n2
                    elif m2.strip().lower() == const.CREDS:
                        nodeCredCol = n2
            nodeUrl = util.getURL(deviceObj[const.PORT], deviceObj[const.HOST], logger)
            # get loginObj to create the sesId
            loginObj = util.getLoginObj(nodeUrl, deviceObj[const.HOST], deviceObj[const.CREDS], logger)
            # this is to handle in admin partition case and HA case
            try:
                nodeSesId = loginObj.login()
            except Exception as exMsg:
                logger.error(' ++++ error in getLoginObj from auditConfig processVLANNBindingsInCModify = %s' % str(exMsg))
                continue
            tmpCol = nitro.createConfigObjects(const.VLAN_BIND, vlanCol, url, devIp, nodeSesId, logger)
            respCol = dict(tmpCol.items() + respCol.items())
            vservObj  = vser.VServerUtil(logger)
            partitionCol = vservObj.getContextTenantName(cnfg)
            if const.AdminPartitionSupport == True and const.TENANT in partitionCol:
                # default partition is created, and we can skip this part)
                if partitionCol[const.TENANT] != 'default':
                    partitionName = partitionCol[const.TENANT] + "_" + partitionCol[const.CONTEXT]+ "_" + str(partitionCol[const.VDEV])
                    tmpCol = vservObj.bindVlanPartition(partitionName, vlanCol, nodeUrl, nodeHostVal, nodeSesId)
                    respCol = dict(tmpCol.items() + respCol.items())

            # now logout and end the session
            loginObj.logout(nodeSesId)
            # add the bindings
            encapAsVal = b1
            logger.debug('Encap value = %s' %(encapAsVal))
            if encapAsVal in audEncapCol:
                tmpEnCol = {}
                tmpEnCol = audEncapCol[encapAsVal] # get the association
                vifNodeVal = None
                nsipTargetVal = None
                for f1, f2 in tmpEnCol.iteritems():
                    if f1 == const.VIF_NAME:
                        vifNodeVal = f2
                    elif f1 == 'apicTarget':
                        nsipTargetVal = f2
                if vifNodeVal is not None:
                    nodeIfCol = {}
                    # get the node and interface 
                    if vifNodeVal in audVifCol:
                        nodeIfCol = audVifCol[vifNodeVal]
                        if len(nodeIfCol) > 0:
                            nodeVlanIfBindCol[a1] = nodeIfCol # here a1 is vlan id
                logger.debug(' Add node If Col  = %s' % (nodeIfCol))
                if nsipTargetVal is not None:
                    nsipValCol = {}
                    for x1, y1 in audFunCol.iteritems():
                        for x2, y2 in y1.iteritems():
                            # ignore x2 since it is either inside or outside 
                            for x3, y3 in y2.iteritems():
                                if x3 == 'excapTarget' and y3 == nsipTargetVal:
                                    nsipValCol = y2
                                elif x3 == 'encapTarget' and y3 == nsipTargetVal:
                                    nsipValCol = y2
                    if len(nsipValCol) > 0:
                        nsipTarVal = None
                        bindCol = {}
                        # get the nsip target value
                        nsipTarVal = nsipValCol['nsipTarget']
                        # find this nsip from nsip collection 
                        for i1, o1 in audNsipCol.iteritems():
                            for i2, o2 in o1.iteritems():
                                if i2 == 'apicTarget' and o2 == nsipTarVal:
                                    # add this binding
                                    addBndCol = {}
                                    addBndCol[const.ID] = a1
                                    addBndCol[const.IPADDRESS] = i1
                                    tmpCol = {}
                                    tmpCol = nitro.createBindObject(const.VLAN_NSIP_BINDING, addBndCol, url, devIp, sesId, logger)
                                    respCol = dict(tmpCol.items() + respCol.items())
    # now perform node level binding i.e. vlan_interface_binding
    nodeCol = {}
    logger.debug('Device Obj = %s' % (deviceObj))
    nodeCol = util.getClusterColFromConfig(deviceObj, logger)
    logger.debug('Node collection = %s' % (nodeCol))
    # for each node get the ip and credential 
    for m1, n1 in nodeCol.iteritems():
        vifObjCol = {}
        vifNum = None
        nodeName = m1
        nodeHostVal = None
        nodeVirtualFlag = False
        nodePortVal = 0
        nodeCredCol = {}
        for m2, n2 in n1.iteritems():
            if m2.strip().lower() == const.HOST:
                nodeHostVal = n2
            elif m2.strip().lower() == const.PORT:
                nodePortVal = n2
            elif m2.strip().lower() == const.CREDS:
                nodeCredCol = n2
            elif m2.strip().lower() == const.VIRTUAL:
                nodeVirtualFlag = n2
        nodeUrl = util.getURL(nodePortVal, nodeHostVal, logger)
        # get loginObj to create the sesId
        loginObj = util.getLoginObj(nodeUrl, nodeHostVal, nodeCredCol, logger)
        # this is to handle HA case where one of the node could be down 
        try:
            nodeSesId = loginObj.login()
        except Exception as exMsg:
            logger.error(' ++++ error in getLoginObj from auditConfig processVLANNBindingsInCModify  = %s' % str(exMsg))
            continue
        nodeVlanBndCol = {}
        logger.debug(' Node Vlan Bind col = %s' % (nodeVlanIfBindCol))
        for p1, q1 in nodeVlanIfBindCol.iteritems():
            for p2, q2 in q1.iteritems():
                logger.debug('Node name = %s, p2 = %s, q2 = %s' % (nodeName, p2, q2))
                if p2 == nodeName:
                    nodeVlanBndCol = nitro.getBindObjectsBinding('vlan_binding', str(p1), nodeUrl, nodeHostVal, nodeSesId, logger)
                    srchFlag = findVlanKeyAtrFromBindCol(nodeVlanBndCol, const.VLAN_INTERFACE_BIND_NAME, p1, logger)
                    if srchFlag is False:
                        addIfBndCol = {}
                        addIfBndCol[const.ID] = p1
			tmpIfVal = q2
			tmpIfVal = tmpIfVal.replace('_', '/')
                        addIfBndCol[const.IFNUM] = tmpIfVal
                        if nodeVirtualFlag is False:
                            addIfBndCol[const.TAGGED] = True
                        tmpCol = {}
                        tmpCol = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, addIfBndCol, nodeUrl, nodeHostVal, nodeSesId, logger)
                        respCol = dict(tmpCol.items() + respCol.items())
        # logout from the node here
        loginObj.logout(nodeSesId)
    return respCol 
           
#
# handle VLAN & its bindings vlan_interface and vlan_nsip bindings
#
def handleVLANNBindings(cnfg, deviceObj, entCol, url, devIp, virtualFlag, sesId, logger):
    """
    This is to handle VLAN n its bindings from APIC config
    """
    addCol = {}
    tmpCol = {}
    atrCol = {}
    modCol = {}
    retCol = {}
    #entity col is tuple of (lbvSerCol, sgCol, nsipCol, vlanCol, encapCol, vifCol, funCol) 
    audLbvCol, audSgCol, audNsipCol, audVlanCol, audEncapCol, audVifCol, audFunCol = entCol

    for a1, b1 in cnfg.iteritems():  # root level
        for a2, b2 in b1.iteritems(): # values 
            if a2 == const.VALUE:
                # get the deviceConfig object
                for a3, b3 in b2.iteritems():
                    # at device level
                    tmpObj = {}
                    instObj = {}
                    if a3[0] == const.IFCTAG : # this is of type VLAN
                        tmpTuple = (a3[0], const.VLAN_BIND, a3[2])
                        tmpObj[tmpTuple] = b3
                        vlanVal = b3[const.TAG]
                    # first get the cluster node from config
                        nodeCol = util.getClusterColFromConfig(deviceObj, logger)
                    # for each node get the ip and credential
                        for m1, n1 in nodeCol.iteritems():
                            vifObjCol = {}
                            vifNum = None
                            nodeName = m1
                            nodeHostVal = None
                            nodePortVal = 0
                            nodeCredCol = {}
                            for m2, n2 in n1.iteritems():
                                if m2.strip().lower() == const.HOST:
                                    nodeHostVal = n2
                                elif m2.strip().lower() == const.PORT:
                                    nodePortVal = n2
                                elif m2.strip().lower() == const.CREDS:
                                    nodeCredCol = n2
		     	    nodeUrl = util.getURL(nodePortVal, nodeHostVal, logger)
                        # get loginObj to create the sesId
                            loginObj = util.getLoginObj(nodeUrl, nodeHostVal, nodeCredCol, logger)
                            # this is to handle HA case where one of the node could be down
                            try:
                                nodeSesId = loginObj.login()
                            except Exception as exMsg:
                                logger.error(' ++++ error in getLoginObj from auditConfig handleVLANBindings = %s' % str(exMsg))
                                continue

			    tmpCol = {}
		            instObj = None
                            instObj = getObjectFromDevice(tmpObj, nodeUrl, nodeHostVal, nodeSesId, logger)
                            tmpCol = getObjectInstanceFromResponse(const.VLAN_BIND, instObj, logger)
                            if len(tmpCol) > 0:
                                cmpCol = {}
                            # compare this with APIC object 
	                        respVal = False
                                respVal = compareVLANs(tmpObj[tmpTuple], tmpCol[const.VLAN_BIND], logger)
                                #logger.debug('+++++++ Compae VLAN response = %s' % (respVal))
                                if (respVal):
                                    modCol[a3] = cmpCol
                                    # process VLAN bindings
                                    infBindCol = {}
                                    ipBindCol = {}
                                    tmpCol = {}
                                    #infBindCol[vlanVal] = getBindingsForBindObject(const.VLAN_INTERFACE_BIND_NAME, str(vlanVal), nodeUrl, nodeHostVal, nodeSesId, logger) 
                                    tmpCol = getVLANInfBindFromAPIC(cnfg, str(vlanVal), nodeName, virtualFlag, nodeUrl, nodeHostVal, nodeSesId, logger)
                                    retCol = dict(tmpCol.items() + retCol.items())
                            else:
                                # add these VLAN
                                addCol[a3] = b3
                                vlanCol = {}
                                vlanCol[const.ID] = vlanVal
                                tmpCol = {}
                                tmpCol = nitro.createConfigObjects(const.VLAN_BIND, vlanCol, nodeUrl, nodeHostVal, nodeSesId, logger)
                                retCol = dict(tmpCol.items() + retCol.items())
                                

                            tagCol = {}
                            tagCol[const.ID] = vlanVal
                            vservObj  = vser.VServerUtil(logger)
                            partitionCol = vservObj.getContextTenantName(cnfg)
                            if const.AdminPartitionSupport == True and const.TENANT in partitionCol:
                                # default partition is created, and we can skip this part)
                                if partitionCol[const.TENANT] != 'default':
                                    partitionName = partitionCol[const.TENANT] + "_" + partitionCol[const.CONTEXT]+ "_" + str(partitionCol[const.VDEV])
                                    tmpCol = vservObj.bindVlanPartition(partitionName, tagCol, nodeUrl, nodeHostVal, nodeSesId)
                                    retCol = dict(tmpCol.items() + retCol.items())

                             # now logout and end the session
                            loginObj.logout(nodeSesId)
    return retCol
#
# This is to handle all the config entities
#
def handleAllConfigEntities(cnfg, deviceObj, url, devIp, virtualFlag, sesId, logger):
    """
    This is to handle all the config entities from the APIC
    """
    auditFlag = True
    addCol = {}
    retCol = {}
    objState = const.CREATE # here object won't matter since the auditFlag is true
    cnfgObjCol = util.getStateSpecificObjectsFromConfig(objState, cnfg, logger, auditFlag)
    #process device level config objects
    for a1, b1 in cnfgObjCol.iteritems():
        instObj = {}
        tmpTuple_1 = a1[1]
        objName = tmpTuple_1[1]
        objVal = tmpTuple_1[2]
        #logger.debug('======== A1 = %s, B1 = %s' % (a1,b1))
        tmpObjCol = {}
        tmpObjCol[a1[1]] = b1
                # check if the objCol has any objects in it or not
            # handle all the MRELs if there is any for second level objects i.e. responderpolicy
            #respCode[const.MREL] = vservObj.processMRELObjects(objCol, devCfg, devIp, sesId)
                        # get the attribute collection
        objAtrCol = util.getAttributeCollectionForObject(tmpObjCol, cnfg, logger)
        if objName == const.SERVICE:
            if const.IP in objAtrCol[objName]:
                tmpIp = objAtrCol[objName][const.IP]
                del objAtrCol[objName][const.IP]
                objAtrCol[objName][const.IPADDRESS] = tmpIp 

        #objCol = getAttributeCollectionForObject(b1, logger)
        #objAtrCol = util.getAttributeCollectionForObject(, devCfg, logger)
        logger.debug('Object attribute collection for object = %s, attribute = %s' % (objName, objAtrCol))
        # get object's key
        keyAtr = util.getObjectKey(objName, logger)
        if (keyAtr):
            keyAtr = keyAtr[0]
            instVal = getKeyValueFromAttributeCollection(keyAtr, objAtrCol, logger)
            if (instVal):
                respObj = {}
                instObj = []
                # get object from device
                respObj = nitro.getInstanceConfigFromDevice(objName, instVal, url, devIp, sesId, logger)
                #logger.debug('Deice instance objects = %s' % (respObj))
                instObj = getObjectInstanceFromResponse(objName, respObj, logger)
                #logger.debug('Device object from the response = %s' % (instObj))
                if len(instObj) > 0:
                    tmpCol = {}
                    tmpCol = compareDeviceAPICObjects(objAtrCol, instObj, url, devIp, sesId, logger)
                    retCol = dict(tmpCol.items() + retCol.items())
                else:
                    addCol[a1] = b1
    #logger.debug('Add collection from APIC config = %s' % (addCol))                                    
    if len(addCol) > 0:
        tmpCol = {}
        tmpCol = createObjectInDevice(addCol, url, devIp, sesId, cnfg, logger)
        retCol = dict(tmpCol.items() + retCol.items())
        retCol = dict(tmpCol.items() + retCol.items())
    logger.debug(' Add collection response = %s' % (retCol))
    vserObj = vser.VServerUtil(logger)
    tmpCol =  vserObj.processCreateBindDataSet(cnfg, url, devIp, sesId, True)
    return retCol 

#
# create object in device using order 
#
def createObjectInDevice(createObjCol, url, devIp, sesId, devCfg, logger):
    """
    This is to add objects in device using object order list
    """
    respCode = {}
    vservObj  = vser.VServerUtil(logger)
    configOrderCol = {}
    backupLBVCol = {}
    orderObjList = util.getObjectOrderList(logger)  #const.OBJECTLIST
    #logger.debug('++++++++ Create config object collection length = %s' % len(createObjCol))
    for a1, b1 in createObjCol.iteritems():
        tmpTuple = a1[1]
        tmpName = tmpTuple[1]

        for i in orderObjList:
            if i.strip().lower() == tmpName.strip().lower():
                    # this will store only one value since others will get overwritten
                configOrderCol[orderObjList.index(i)] = tmpName.strip().lower()
                    #logger.debug('+++++++++ Create object details = %s' % (tmpName.upper()))
                break

    # now configure this object based on config order

    #logger.debug('++++++++ Create config object order collection length = %s' % len(configOrderCol))
    for k1 in sorted(configOrderCol.iterkeys()):
        objkey = configOrderCol[k1]
        tmpObjCol = {}
        for p1 in createObjCol.keys():
            tmpTuple_2 = p1[1]
            keyStr = tmpTuple_2[1]
            # here key is config object name i.e. lbvserver
            if objkey == keyStr.strip().lower():
                tmpObjCol = {}
                tmpObjCol[tmpTuple_2] = createObjCol[p1]
                #logger.debug('+++++++++++ Objkey = %s , object val = %s' % (objkey, tmpObjCol))
                keyVal = keyStr #p1[1]
                #instVal = p1[2]
                instVal = tmpTuple_2[2]
                #instVal = instVal[:instVal.find('_cfg')]
                # get the attribute list for this object
                tmpAtrCol = util.getAttributeCollectionForObject(tmpObjCol, devCfg, logger)
                #logger.debug('++++++++++ Attribute collection = %s' % (tmpAtrCol))
                # now create this object
                if keyStr == const.CSVSERVER:
                    tmpResCode = vservObj.processCSVServerDataSet(keyVal, instVal, tmpAtrCol,url, devIp, sesId)
                    for x1, y1 in tmpResCode.iteritems():
                        respCode[(p1, x1)] = y1
                elif keyStr == const.LBVSERVER or keyStr == const.GSLBVSERVER or keyStr == const.CRVSERVER or keyStr == const.VSERVER:
                    backupLBVCol[(keyVal,instVal)] = tmpAtrCol
                    tmpResCode = vservObj.processLBVServerDataSet(keyVal, instVal, tmpAtrCol,url, devIp, sesId)
                    for x1, y1 in tmpResCode.iteritems():
                        respCode[(p1, x1)] = y1
                elif keyStr == const.NSPBRS: # if the nspbrs is present in the payload then just apply
                    payload = {}
                    payload = { 'params' : { 'action' : 'apply' },
                                 'sessionid' : sesId, const.NSPBRS : {}}
                    respCode[p1] = nitro.postCLIRequest(payload, url, devIp, sesId, logger)
 		elif keyStr == const.SSLCERTKEY:
                    # This is to handle linking certificate 
                    logger.debug('+++++ SSLCERT Key payload = %s' % (tmpAtrCol))
                    for l1, m1 in tmpAtrCol.iteritems():
                        tmpObjName = l1 # this is the object name i.e. sslcertkey 
                        tmpLinkVal = None
                        tmpCertKeyVal = None
                        for l2, m2 in m1.iteritems():
                            if l2.strip().lower() == const.LINKCERTKEYNAME:
                                tmpLinkVal = m2
                            elif l2.strip().lower() == const.CERTKEY:
                                tmpCertKeyVal = m2
                        if tmpLinkVal is not None:
                            rmLinkCol = m1
                                # remove this entry from the payload
                            del rmLinkCol[const.LINKCERTKEYNAME]
                            respCode[p1] = nitro.createConfigObjects(l1, rmLinkCol, url, devIp, sesId, logger)
                        else:
                            # first add sslcertkey
                            respCode[p1] = nitro.createConfigObjects(l1, m1, url, devIp, sesId, logger)
                            # now check if the linkcert key value is present then link them 
                        if tmpLinkVal is not None and tmpCertKeyVal is not None:
                            tmpPayload = {}
                            tmpPayload = { 'params' : { 'action' : 'link' },
                                            'sessionid' : sesId, const.SSLCERTKEY : {
                                            const.CERTKEY : tmpCertKeyVal,
                                            const.LINKCERTKEYNAME : tmpLinkVal, } }
                            # execute this as 
                            respCode[p1] = nitro.postCLIRequest(tmpPayload, url, devIp, sesId, logger)
                else:
                    for s1, o1 in tmpAtrCol.iteritems():
                        # handle the backupvserver for CSVServer
                        #logger.debug('++++++++ Create config object data key = %s objectname = %s, value = %s' % (p1, s1, o1))
                        if s1 == const.SSLVSERVER:
                            respCode[p1] = nitro.setConfigObjects(s1, o1, url, devIp,sesId, logger)
                        else:
                            respCode[p1] = nitro.createConfigObjects(s1, o1, url, devIp, sesId, logger)
    # now set the backup lbvservers if it is present in the config
    for x1, y1 in backupLBVCol.iteritems():
        keyStr = x1[0]
        instStr = x1[1]
        respCode[x1] = vservObj.processBackupLBVServer(keyStr, instStr, y1, url, devIp, sesId)

    return respCode


#
# get instance object from the response
#
def getObjectInstanceFromResponse(objType, respCol, logger):
    """
    This is to get object from response
    """
    objResp = {}
    #logger.debug(' get Objects Instance from Response = %s' % (respCol))
    tmpError = None
    for a1, b1 in respCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.ERRORCODE:
                tmpError = b2
            elif a2 == objType:
                #logger.debug('B2 -------- = %s' % (b2))
                if type(b2) is list and len(b2) > 0:
                    objResp[objType] = b2[0] # since most of the time objects will be in list 
    if tmpError == 0:
        return objResp
    else:
        return []
#
# This is to get object from Device
#
def getObjectFromDevice(objCol, url, devIp, sesId, logger):
    """
    This is to get object from the device
    """
    logger.debug('+++ getObject from device, object = %s' % (objCol))
    objName = None
    keyAtr = None
    retCol = {}
    for k1, v1 in objCol.iteritems():
        objName = k1[1]
        if (objName):
            objKeyAtr = util.getObjectKey(objName, logger)
            if (objKeyAtr):
                keyAtr = objKeyAtr[0]
                # get the instance value from the object collection
                instVal = getKeyValueFromObject(keyAtr, objCol, logger)
                # get this object's instance from the NetScaler 
                if keyAtr == const.ID:
                    instVal = str(instVal) # convert ID to string since REST throws exception
                instCol = {}
                instCol = nitro.getInstanceConfigFromDevice(objName, instVal, url, devIp, sesId, logger)
                #logger.debug('Instance value from the device = %s' % (instCol))
                # this is to avoid empty collection returning back
                for i1, j1 in instCol.iteritems():
                    if j1 is not None and len(j1) > 0:
                        retCol = instCol
                
    return retCol
#
# This is to get object instance/configuration from Device 
#
def getNSObjectFromDevice(objName, url, devIp, sesId, logger):
    """
    This is to get object's config or intance from the device 
    """
    #logger.debug('+++++ This is to get config from the device for the object = %s' % (objName))
    retCol = {}
    retCol = nitro.getObjectsConfigFromDevice(objName, url, devIp, sesId, logger)
    #logger.debug('Instance value from the device = %s' % (retCol))

    return retCol
#
# get key value from object's attribute collection
#
def getKeyValueFromAttributeCollection(keyAtr, objCol, logger):
    """
    This is to get key's value from object's attribute collection
    """
    #logger.debug('+++ Key value from object collection key attribute = %s, object collection = %s' % (keyAtr, objCol))
    for a1, b1 in objCol.iteritems():
        # here a1 is object type i.e. service
        for a2, b2 in b1.iteritems():
            if a2 == keyAtr:
                return b2

    # if execution reaches here then not found
    return None
#
# ignore few objects which are of special type
#
def ignoreObjectWithSpecificValue(objName, objCol, logger):
    """
    This is to ignore objects with certain values
    """
    tmpAdr = None
    tmpMgmtAccess = None
    #logger.debug('Ignore Object with specific Value object name = %s col = %s' % (objName, objCol))
    for a1, b1 in objCol.iteritems():
        if objName == const.NSIP:
            if a1 == const.IPADDRESS:
                tmpAdr = b1
            elif a1 == const.MGMTACCESS:
                tmpMgmtAccess = b1
            #logger.debug('Ignore object LOOP ObjectName = %s A1 & B1  type = %s value = %s' % (objName, a1, b1))
    if objName == const.NSIP and tmpMgmtAccess is not None:
        if tmpMgmtAccess.strip().lower() == const.ENABLED.strip().lower():  # since IPTYPE is type of an array
            logger.debug('Ignore NSIP with Management Access object value = %s MGMT Access = %s' % (tmpAdr, tmpMgmtAccess))
            return True

    return False
#
# get key value from NetScaler's response collection
#
def getNSKeyValueFromCollection(keyAtr, objCol, logger):
    """
    This is to get key's value from NetScaler's response
    """
    logger.debug('++++++ get Key value for key = %s, objCol = %s' % (keyAtr,objCol))
    for a1, b1 in objCol.iteritems():
        if a1 == keyAtr:
            return b1

    # if the execution reaches here then key not found
    return None

#
# get Object's key value from object collection 
#                                                     
def getKeyValueFromObject(keyAtr, objCol, logger):
    """
    This is to get key's value from the object
    """
    #logger.debug('+++++++ get Key Value from Object ++++ keyAttr = %s, objCol = %s' % (keyAtr, objCol))
    objInstance = None
    for i1, j1 in objCol.iteritems():
        objInstance = i1[1]
        #logger.debug('++++ object instance = %s' % (objInstance))
        for i2, j2 in j1.iteritems():
            #logger.debug(' i2 = %s j2 = %s' % (i2,j2))
            if objInstance is not None and objInstance.strip().lower() == const.VLAN_BIND:
                if i2 == const.TAG:
                    return j2
            elif i2 == const.VALUE:
                for i3, j3 in j2.iteritems():
                    if i3[1] == keyAtr:
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                return j4

    return None
#
# get attribute collection for APIC object
#
def getAttributeCollectionForObject(apicObj, logger):
    """
    This is to get attribute collection for an APIC object
    """
    #logger.debug('++++++++++ get Attribute collection for object = %s' % (apicObj))
    objType = None
    retCol = {}
    for a1, b1 in apicObj.iteritems():
        objType = a1[1]
        for a2, b2 in b1.iteritems():
            if objType == const.VLAN_BIND:
                if a2 == const.TAG:
                    tmpCol = {}
                    tmpCol[const.ID] = b2
                    retCol[objType] = tmpCol
                    return retCol
            elif a2 == const.VALUE:
                tmpCol = {}
                for a3, b3 in b2.iteritems():
                    if a3[0] == const.PARAM:
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                tmpCol[a3[1]] = b4
                if len(tmpCol) > 0:
                    retCol[objType] = tmpCol
    return retCol
#
# get the device Object in dict format 
#
def getAttributeObjectFromList(devObj, logger):
    """
    This is to get object in dict format from device object 
    """
    retCol = {}
    for a1, b1 in devObj.iteritems():
        if type(b1) is list:
            # here the assumption is list will have only one element
            for i in b1:
                retCol[a1] = i
    return retCol

#
# compare two APIC & Device objects
#
def compareDeviceAPICObjects(apicAtrCol, devAtrCol, url, devIp, sesId, logger):
    """
    This is to compare apic and device objects using their attribute collection
    """
    #logger.debug('+++ compare two objects using attribute collection ++++')
    #logger.debug('... APIC Attr COl = %s' % (apicAtrCol))
    #logger.debug('....Device Attr Col = %s' % (devAtrCol))
    retCol = {}
    vserObj = vser.VServerUtil(logger)
    for i in apicAtrCol.keys():
        logger.debug('......... keys in comapre object = %s' % (i))
        tmpACol = {}
        tmpDCol = {}
        tmpDiffCol = {}
        if i in devAtrCol:
            tmpACol = apicAtrCol[i]
            tmpDCol = devAtrCol[i]
            tmpDiffCol = {}
            for k in tmpACol.keys():
                if k in tmpDCol:
                    if tmpACol[k] != tmpDCol[k]:
                        if type(tmpDCol[k]) is int:
                            if type(tmpACol[k]) is str and tmpACol[k].isdigit():
                                if int(tmpACol[k]) != tmpDCol[k]:
                                    tmpDiffCol[k] = tmpACol[k]   
                        else:
                            tmpDiffCol[k] = tmpACol[k]
            if len(tmpDiffCol) > 0:
	        tmpCol = {}
            # execute the set command here to since the object exist but values differ
                #logger.debug('Setting the object attributes in NetScaler ... = %s' % (i))
                retCol[i] = nitro.setConfigObjects(i, tmpACol, url, devIp, sesId, logger)
            #retCol[i] = tmpDiffCol

    logger.debug('Compare diff collection = %s' % (retCol))
    return retCol
 
#
# Compare the two objects
#
def compareObjects(apicObj, devObj, logger):
    """
    This is to compare the two objects from APIC and NetScaler
    """
    logger.debug('++++++++ compare objects apicObject = %s, device object = %s' % (apicObj, devObj))
    apicAtrCol = {}
    devAtrCol = {}
    retCol = {}
    apicAtrCol = getAttributeCollectionForObject(apicObj, logger)
    devAtrCol = getAttributeObjectFromList(devObj, logger)
    logger.debug('++++ Attribute collection  APIC col = %s, Device Col = %s' % (apicAtrCol,devAtrCol))
    for i in apicAtrCol.keys():
        #logger.debug('......... keys in comapre object = %s' % (i))
        tmpACol = {}
        tmpDCol = {}
        tmpDiffCol = {}
        if i in devAtrCol:
            tmpACol = apicAtrCol[i]
            tmpDCol = devAtrCol[i]
            #logger.debug('++++ Comparing attributes APIC col = %s, Device Col = %s' % (tmpACol, tmpDCol))
            for k in tmpACol.keys():
                if tmpACol[k] != tmpDCol[k]:
                    tmpDiffCol[k] = tmpACol[k]
        if len(tmpDiffCol) > 0:
            retCol[i] = tmpDiffCol

    logger.debug('Compare diff collection = %s' % (retCol))
    return retCol 
#
# This is to compare VLANs 
#
def compareVLANs(apicCol, devCol, logger):
    """
    This is to compare VLAns between APIC and NetScaler
    """
    #logger.debug('This is to compare VLANs APIC Col = %s, deviceCol = %s' % (apicCol, devCol))

    tagVal = apicCol[const.TAG]
    idVal = devCol[const.ID]
    #logger.debug('.. VLAN values Tag = %s, ID = %s' % (tagVal, idVal))
    if int(tagVal) == int(idVal):
        return True
    else:
        return False

#
# process Node level configuration 
#
def processNodeLevelDelete(objName, objCol, cnfg, entCol, nodeName, nodeUrl, nodeIp, nodeSesId, devIp, logger):
    """
    This is to handle delete details per Node
    """
    #logger.debug('Node level processing -------------- nodeName = %s' % (nodeName))
    respCode = {}
    instList = []
    #entity col is tuple of (lbvSerCol, sgCol, nsipCol, vlanCol, encapCol, vifCol, funCol)
    audLbvCol, audSgCol, audNsipCol, audVlanCol, audEncapCol, audVifCol, audFunCol = entCol
    keyAtr = util.getObjectKey(objName, logger)
    if (keyAtr):
        keyAtr = keyAtr[0]
    for a1, b1 in objCol.iteritems():
        if a1 == const.ERRORCODE:
            errVal = b1
        elif a1 == objName:
            instList = b1
    #logger.debug('Porcess object For errorcode = %s instList = %s' % (errVal, instList))
    tmpObjCol = {}
    for i in instList:
        # check if i is not type of dict then ignore
        if type(i) is not dict:
            continue
        tmpObjCol = i
        keyVal = None
        # get the key value from the instance 
        keyVal = getNSKeyValueFromCollection(keyAtr, tmpObjCol, logger)
        if keyVal is None:
            continue
        if objName == const.NSIP and (keyVal == nodeIp or keyVal == devIp):
            logger.debug('Ignore device node IPs ..... value = %s' % (keyVal))
            continue
            
        # find this object in APIC config
        findResp = False
        #logger.debug('KeyName = %s, keyVal = %s, objName = %s' % (keyAtr, keyVal, objName))
        if objName == const.VLAN_BIND: # check if the object is vlan then look this up in vlanCol
            #all the vlan shows up in default partition, but we only deals with vlan which partition name not exists in this case
            #if const.DefaultPartition == True and const.PARTITION_NAME in tmpObjCol:
                #logger.debug('In default partition, Ignore vlan of other partition')
                #continue
            if int(keyVal) in audVlanCol:
                findResp = True
        else:
            findResp = findObjectUsingKeyInAPICConfig(keyAtr, keyVal, objName, cnfg, logger)
        # this is to ignore the object which are 
        #if keyVal == None:
        #    continue
        #logger.debug('FIND Object Resp = %s' % (findResp))
        if (findResp): # if object found then compare bindings
            # get object's bindings 
            #logger.debug('+++++++ get the BINDINGS for the existing object = %s instance = %s' % (objName, keyVal))
            tmpCol = {}
            tmpCol = getObjectBindingsFromNetScaler(cnfg, objName, keyVal, nodeUrl, nodeIp, nodeSesId, logger, nodeName, entCol)
            # delete these bindings since they are not in APIC
            # getObjectBindings return collection format {(u'service_lbmonitor_binding', u'tcp-default'): u'tcp-default'} 
            #logger.debug('Binding delete calls = %s' % (tmpCol))
            if len(tmpCol) > 0:
                for d1, f1 in tmpCol.iteritems():
                    tmpResp = {}
                    rmBndName = d1[0]
                    if rmBndName == const.VLAN_NSIP_BINDING or rmBndName == const.VLAN_NSIP6_BINDING :
                        rmBndVal = f1[0]
                        argStr = 'args=' + d1[1] + ':' + f1[1]
                        respCode[d1] = nitro.removeNitroObject(rmBndName, rmBndVal, argStr, nodeUrl, nodeIp, nodeSesId, logger)
                    else:
                        argStr = 'args='+d1[1] + ':' + f1[1]
                        rmBndVal = f1[0]
                        respCode[d1] = nitro.removeNitroObject(rmBndName, rmBndVal, argStr, nodeUrl, nodeIp, nodeSesId, logger)
        else:
            # delete this VLAN
            if objName == const.VLAN_BIND:
                vservObj  = vser.VServerUtil(logger)
                parCol = vservObj.getContextTenantName(cnfg)
                if const.AdminPartitionSupport == True and const.TENANT in parCol:
                    # default partition is created, and we can skip this part
                    if parCol[const.TENANT] != 'default':
                        partitionName = parCol[const.TENANT] + "_" + parCol[const.CONTEXT] + "_" + str(parCol[const.VDEV])
                        vservObj.switchPartition("default", nodeUrl, nodeIp, nodeSesId)
                        vservObj.unbindVlanPartition(partitionName, keyVal, nodeUrl, nodeIp, nodeSesId)
                        respCode[keyVal] = nitro.removeNitroObject(objName, keyVal, None, nodeUrl, nodeIp, nodeSesId, logger)
                        vservObj.switchPartition(partitionName, nodeUrl, nodeIp, nodeSesId)
                else:
                    respCode[keyVal] = nitro.removeNitroObject(objName, keyVal, None, nodeUrl, nodeIp, nodeSesId, logger)
            else:
                respCode[keyVal] = nitro.removeNitroObject(objName, keyVal, None, nodeUrl, nodeIp, nodeSesId, logger)
    return respCode
#
# process the NITRO response from NetScaler
#
def processObjectForDelete(objName, objCol, deviceCol, entCol,  devCfg, url, devIp, sesId, nodeIp, logger):
    """
    This is to process nitro response 
    """
    #logger.debug('+++++++++ processing nitro response for object = %s' % (objName))
    #entity col is tuple of (lbvSerCol, sgCol, nsipCol, vlanCol, encapCol, vifCol, funCol)
    audLbvCol, audSgCol, audNsipCol, audVlanCol, audEncapCol, audVifCol, audFunCol = entCol

    errVal = None
    instList = []
    keyAtr = None
    deleteCol = {}
    respCode = {}
    keyAtr = util.getObjectKey(objName, logger)
    if (keyAtr):
        keyAtr = keyAtr[0]
    for a1, b1 in objCol.iteritems():
        if a1 == const.ERRORCODE:
            errVal = b1
        elif a1 == objName:
            instList = b1
    logger.debug('Porcess object For objectName  = %s instList = %s' % (objName, instList))
    tmpObjCol = {}
    for i in instList:
        # check if i is not type of dict then ignore
        if type(i) is not dict:
            continue
        tmpObjCol = i
        ignoreFlag = False
        # check if this object needs to be ignored
        ignoreFlag = ignoreObjectWithSpecificValue(objName, tmpObjCol, logger)
        if (ignoreFlag):
            continue
        keyVal = None
        # get the key value from the instance 
        keyVal = getNSKeyValueFromCollection(keyAtr, tmpObjCol, logger)
	if keyVal is None:
            continue
        if objName == const.NSIP and (keyVal == devIp or keyVal == nodeIp):
            #logger.debug('Ignore the device IP/SNIP ..... value = %s' % (keyVal))
            continue
        # find this object in APIC config
        #logger.debug('KeyName = %s, keyVal = %s, objName = %s' % (keyAtr, keyVal, objName))
        findResp = False
        # compare some of the objects in collection
        if objName == const.LBVSERVER:
            if keyVal in audLbvCol:
                findResp = True
        elif objName == const.SERVICEGROUP:
            if keyVal in audSgCol:
                findResp = True
        else:
            findResp = findObjectUsingKeyInAPICConfig(keyAtr, keyVal, objName, devCfg, logger)
        #logger.debug('FIND Object Resp = %s' % (findResp))
        if (findResp): # if object found then compare bindings
            # get object's bindings
            #logger.debug('+++++++ get the BINDINGS for the existing object = %s instance = %s' % (objName, keyVal))
            tmpCol = {}
            tmpCol = getObjectBindingsFromNetScaler(devCfg, objName, keyVal, url, devIp, sesId, logger, None, entCol) # here None for NodeName
            # delete these bindings since they are not in APIC 
            # getObjectBindings return collection format {(u'service_lbmonitor_binding', u'tcp-default'): u'tcp-default'}
            #logger.debug('Binding delete calls = %s' % (tmpCol))
            if len(tmpCol) > 0:
                for d1, f1 in tmpCol.iteritems():
                    rmBndName = d1[0]
                    if rmBndName == const.VLAN_NSIP_BINDING or rmBndName == const.VLAN_NSIP6_BINDING :
                        rmBndVal = f1[0]
                        respCode[d1] = nitro.removeNitroObject(rmBndName, rmBndVal, None, devIp, sesId, logger)
                    else:
                        tmpResp = {}
                        rmBndName = d1[0]
                        argStr = 'args='+d1[1] + ':' + f1[1]
                        rmBndVal = f1[0]
                        respCode[d1] = nitro.removeNitroObject(rmBndName, rmBndVal, argStr, url, devIp, sesId, logger)
        else: 
            #deleteCol[(objectName, keyVal)] = keyVal
            deleteCol[(objName, keyVal)] = keyVal
            #logger.debug('+++++++++ Ket Attr Name  = %s' % (keyAtr))
                    
            if objName.strip().lower() == const.ROUTE.strip().lower():
                gatewayVal = util.getParamAttributeValueFromCollection(const.GATEWAY, tmpObjCol, logger)
                netmskVal = util.getParamAttributeValueFromCollection(const.NETMASK, tmpObjCol, logger)
                if netmskVal and gatewayVal:
                    args = 'args='+const.NETMASK + ':' + netmskVal + ',' + const.GATEWAY+':'+gatewayVal
                    #logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyAtr, keyVal))
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, args, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.DNSSRVREC:
                if const.TARGET in tmpObjCol:
                    tgVal = tmpObjCol[const.TARGET]
                if tgVal:
                    argStr = 'args='+ const.TARGET + ':' + tgVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.DNSMXREC:
                if const.MX in tmpObjCol:
                    mxVal = tmpObjCol[const.MX]
                if mxVal:
                    argStr = 'args='+ const.MX + ':' + mxVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.DNSNSREC:
                if const.NAMESERVER in tmpObjCol:
                    nsVal = tmpObjCol[const.NAMESERVER]
                if nsVal:
                    argStr = 'args='+ const.NAMESERVER + ':' + nsVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.LBMONITOR:
                if const.TYPE in tmpObjCol:
                    tyVal = tmpObjCol[const.TYPE]
                if tyVal:
                    argStr = 'args='+ const.TYPE + ':' + tyVal
                    respCode[objName] = nitro.removeNitroObject(objName, keyVal, argStr, url, devIp, sesId, logger)
            elif objName.strip().lower() == const.SERVICE:
                        # delete the service and server also since server doesn't get deleted from the config
                #logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyAtr, keyVal))
                respCode[objName] = nitro.removeNitroObject(objName, keyVal, None, url, devIp, sesId, logger)
                        # now exclusive delete the server based on the services IP value
                if const.IPADDRESS in tmpObjCol:
                    tmpIpVal = tmpObjCol[const.IPADDRESS]
                if tmpIpVal: # this is just to make sure value is not NULL
                    tmpTup = (objName, (const.FOLDER, const.SERVER, tmpIpVal))
                    respCode[tmpTup] = nitro.removeNitroObject(const.SERVER, tmpIpVal, None, url, devIp, sesId, logger)
            else:
                #logger.debug('++++++++++++ delete object key = %s, val = %s' % (keyVal, keyVal))
                respCode[objName] = nitro.removeNitroObject(objName, keyVal, None, url, devIp, sesId, logger)
        #else:
        #    logger.debug('+++++++ get the BINDINGS for the existing object ++++++++++++')
            # if object exist then look for objects binding
        #    tmpCol = {}
        #    tmpCol = getObjectBindingsFromNetScaler(devCfg, objName, keyVal, url, devIp, sesId, logger)
        #    deleteCol = dict(tmpCol.items() + deleteCol.items())

    logger.debug(' Delete Collection = %s' % (deleteCol))

    return deleteCol
#
# Search APIC config for an object with KeyValue
#
def findObjectUsingKeyInAPICConfig(keyAtr, keyVal, objName, cnfg, logger):
    """
    This is to find an object in APIC config using object's key and value
    """
    # this is to check if this is HighAvailability Config
    
    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                # get the deviceConfig object
                for a3, b3 in b2.iteritems():
                    if util.checkFolderInsideFolder(b3): # check if the folder contains another folder inside it 
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems():
                                    if a5[1] == objName:
                                        tmpCol = {}
                                        tmpCol[a5] = b5
                                        instVal = None
                                        #compare the object's key to make sure if it is the same instance 
                                        instVal = getKeyValueFromObject(keyAtr, tmpCol, logger)
                                        #logger.debug('+ INSTANCE VALUE for the comparison = %s' % (instVal))
                                        if instVal == keyVal:
                                            return True
                    elif a1[1] == const.HIGHAVAILABILITY: # this is to check if the HighAvailability config from deviceAudit
                        if keyAtr == const.IPADDRESS:
                            # compare SNIP with ipaddress value
                            if a3[1] == const.SNIP and keyVal == b3[const.VALUE]:
                                return True
                        elif keyAtr == const.VLAN_BIND: # this is to compare VLAN 
                            if a3[1] == const.VLAN_BIND and keyVal == b3[const.VALUE]:
                                return True
                    elif a3[1] == objName: # device level objects
                        tmpCol = {}
                        tmpCol[a3] = b3
                        instVal = None
                        # compare the o:qbject's key to make sure if it is the same instance 
                        instVal = getKeyValueFromObject(keyAtr, tmpCol, logger)
                        #logger.debug('+ INSTANCE VALUE for the comparison = %s' % (instVal))
                        if instVal == keyVal:
                            return True
                    elif a3[0] == const.IFCTAG and objName == const.VLAN_BIND: # this is to compare VLAN
                        #logger.debug('VLAN detail - A3 = %s, B3 = %s' % (a3,b3))
                        if int(b3[const.TAG]) == 1: # this is default VLAN do not remove
                            return True
                        #logger.debug('VLAN comparison objName = %s, keyAtr = %s, keyVal = %s' % (objName, keyAtr, keyVal))
                        if int(b3[const.TAG]) == int(keyVal):
                            return True
    # if execution reaches here then not found
    return False
#
# Search Bind object in APIC config
#
def findBindObjectInAPICConfig(cnfg, bindObj, keyVal, keyName, instVal, url, devIp, sesId, logger, nodeName=None):
    """
    This is to find bind object in APIC config, compare the key's value to find if it is the same 
    """
    logger.debug('++++++++ find bind object = %s, keyName = %s, instVal = %s' % (bindObj, keyName, instVal))
    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                # get the deviceConfig object
                for a3, b3 in b2.iteritems():
                    if bindObj == const.VLAN_INTERFACE_BIND_NAME:
                        tmpCol = {}
                        tmpCol = getVLANInfBindForVLANAPIC(cnfg, keyVal, instVal, nodeName, logger)
                        if len(tmpCol) > 0:
                            for x1, y1 in tmpCol.iteritems():
                                for x2, y2 in y1.iteritems():
                                    if x2[const.IFNUM] == instVal:
                                        return True
                    elif bindObj == const.VLAN_NSIP_BINDING:
                        tmpCol = {}
                        cmpResp = False
                        cmpResp = compareNSVLANBindFromDevice(cnfg, keyVal, instVal, url, devIp, sesId, logger)
                        if cmpResp:
                            return True
                    elif bindObj == const.VLAN_NSIP6_BINDING :
                        tmpCol = {}
                        cmpResp = False
                        cmpResp = compareNSIPv6VLANBindFromDevice(cnfg, keyVal, instVal, url, devIp, sesId, logger)
                        if cmpResp:
                            return True
                        #if len(tmpCol) > 0:
                        #    for m1, n1 in tmpCol.iteritems():
                        #        # collection for NSIP VLAN binding bindName, keyVal, instVal)] = (keyVal, instVal)
                        #        logger.debug(' Function specific VLAN NSIP binding key = %s Value = %s' % (m1,n1))
                        #        if instVal == n1[1]:
                        #            return True
                    elif util.checkFolderInsideFolder(b3): # check if the folder contains another folder inside it
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems():
                                    if util.checkBindFolderInsideFolder(b5):
                                        for a6, b6 in b5.iteritems():
                                            if a6  == const.VALUE:
                                                for a7, b7 in b6.iteritems():
                                                    if a7[0] == const.FOLDER and a7[1] == bindObj:
                                                        for a8, b8 in b7.iteritems():
                                                            if a8 == const.VALUE:
                                                                for a9, b9 in b8.iteritems():
                                                                    if a9[0] == const.MREL and a9[1] == keyName:
                                                                        for a10, b10 in b9.iteritems():
                                                                            if a10 == const.TARGET and b10 == instVal:
                                                                                #logger.debug('Bind object found bind obj = %s, keyName = %s, instVal = %s'% (a7[1], a9[1], b10))
                                                                                return True
                    else:
                         if util.checkBindFolderInsideFolder(b3):
                             for k1, v1 in b3.iteritems():
                                 if k1 == const.VALUE:
                                     for k2, v2 in v1.iteritems():
                                         if k2[0] == const.FOLDER and k2[1] == bindObj:
                                             for k3, v3 in v2.iteritems():
                                                 if k3 == const.VALUE:
                                                     for k4, v4 in v3.iteritems():
                                                         if k4[0] == const.MREL and k4[1] == keyName:
                                                             for k5, v5 in v4.iteritems():
                                                                 if k5 == const.TARGET and v5 == instVal:
                                                                     #logger.debug('Bind object found bind obj = %s, keyName = %s, instVal = %s' % (k2[1], k4[1], v5)) 
                                                                     return True

    # if execution reaches here then bind object not found
    return False                                                                        
#
# get bind target value from the collection
#
def getVLANInfBindForVLANAPIC(devCfg, vlanVal, instVal, nodeName, logger):
    """
    This is to get VLAN interface bindings from APIC for given VLAN
    """
    #logger.debug('+++ get VLAN interface binding +++++')

    retCol = {}
    retList = []
    deviceAuditFlag = True
    createObjCol = {}
    respCode = {}
    configOrderCol = {}
        # create the VLANs 
    tagCol = {}
    tmpCode = {}

    # now get VIF object for this node
    vifObjCol = util.getStateSpecificNodeVIFsFromConfig(const.CREATE, nodeName, devCfg, logger, deviceAuditFlag)
    logger.debug('++++++++ VIFs for nodeName = %s, VIFs = %s' % (nodeName, vifObjCol))
    tmpList = []
    for r1, s1 in vifObjCol.iteritems():
        encapCol = {}
        # here s1 is the dict of type VIFs such as {'ADC1': '1_1'} 
        vifNum = s1[nodeName]
        vifNum = vifNum.replace('_', '/')
        # here r1 is object name 
        encapCol = util.getStateSpecificVIFEncapassFromConfig(const.CREATE, r1[1], devCfg, logger, deviceAuditFlag)
        logger.debug('++++++++ ENCAP collection for VIF object = %s, encapass collection = %s' % (r1[1], encapCol))
        for r2, s2 in encapCol.iteritems():
            keyTuple = r2
            tmpCol = {}
            for r3, s3 in s2.iteritems():
                if r3.strip().lower() == const.ENCAP:
                    # now get the IFC tags based on the encap object name 
                    tagObjName = s3
                    tagCol = {}
                    tmpCol = {}
                    tagCol = util.getStateSpecificEncapTagFromConfig(const.CREATE, tagObjName, devCfg, logger, deviceAuditFlag)
                        # get the tag value from collection 
                    for i1, j1 in tagCol.iteritems():
                        # compare this VLAN id passed as param
                        if vlanVal  == j1: # here the assumption is VLAN_INTERFACE_BINDING
                            tmpCol[const.ID] = j1
                            tmpCol[const.IFNUM] = vifNum
                    retCol[tagObjName] = tmpCol
    logger.debug('VLAN interface binding collection from APIC = %s' % (retCol))
    return retCol

#
# get Bind object collection from NITRO Response
#
def getBindColFromResponse(bindCol, bindName, logger):
    """
    This is to get bind collection from the response
    """
    #logger.debug('++++ bind collection from NITRO response = %s' % (bindCol))
    retCol = {}
    tmpErrCode = None
    tmpBindList = []
    for a1, b1 in bindCol.iteritems():
        if a1 == const.ERRORCODE:
            tmpErrCode = b1
        elif a1 == bindName:
            tmpBindList = b1
    for i in tmpBindList:
        for m1, n1 in i.iteritems():
            if m1.find(const.FINDING) != -1:
               retCol[m1] = n1

    #logger.debug('Bind collection from NITRO response = %s' % (retCol))
    
    return retCol

#
# get the object bindings from device
#                            
def getObjectBindingsFromNetScaler(devCfg, objName, keyVal, url, devIp, sesId, logger, nodeName=None, entCol=None):
    """
    This is to get object's bindings from the NetScaler
    """
    #entity col is tuple of (lbvSerCol, sgCol, nsipCol, vlanCol, encapCol, vifCol, funCol)
    audLbvCol, audSgCol, audNsipCol, audVlanCol, audEncapCol, audVifCol, audFunCol = entCol
    retCol = {}
    if objName == "nsip":
        return retCol
    logger.debug('Getting bind collection for object type = %s object name = %s' % (objName, keyVal))
    bindCol = {}
    tmpBindCol = {}
    bindKeyCol = constKey.bindObjOrder
    tmpRespCol = {}
    bindName = objName + '_binding'
    bindCol = nitro.getObjectsBinding(bindName, keyVal, url, devIp, sesId, logger)
    #tmpBindCol = getBindColFromResponse(bindCol, bindName, logger)
    #logger.debug('bind collection from NetScaler = %s' % (tmpBindCol))
    # get the binding from the
    for a1, b1 in bindCol.iteritems():
        if a1 == "lbvserver_servicegroupmember_binding" or a1 == "servicegroup_servicegroupentitymonbindings_binding":
            continue
        tmpCol = {}
        bindObj = a1  # here a1 will bind object i.e. vlan_nsip_binding
        bindKey = None
        bindKey = getBindKeyFromConst(bindObj, logger) 
        logger.debug('BIND Objects key = %s' % (bindKey))
        # now look for this binding in APIC config 
        for i in b1:
            logger.debug('I ==== %s' % (i))
            bolResp = False
            instVal = None
            instVal = getNSKeyValueFromCollection(bindKey, i, logger) # here is a dict of bind attributes
            logger.debug('instVAL ==== %s' % (instVal))
	    if instVal is None:
	        continue
            logger.debug('Bind Key = %s, inst val = %s, I = %s' % (bindKey, instVal, i))
            logger.debug('Bind Object = %s, key val = %s' % (bindObj, keyVal))
            # if this is vlan_nsip_binding then
            if bindObj == const.VLAN_NSIP_BINDING or bindObj == const.VLAN_INTERFACE_BIND_NAME:
                # first get the encapass from vlan col
                encapVal = audVlanCol[int(keyVal)]
                logger.debug('Encap val = %s' % (encapVal))
                # from encap association get the the interface & function relation
                encapAsCol = audEncapCol[encapVal]
                #logger.debug('EncapAsCol val = %s' % (encapAsCol))
                if bindObj == const.VLAN_INTERFACE_BIND_NAME:
                    # get the interface from Vif col
                    infVal = encapAsCol[const.VIF_NAME]
                    #logger.debug('infVal val = %s' % (infVal))
                    # get the node & its interface value from vif collection
                    ifNodeValCol = audVifCol[infVal]
                    instVal = instVal.replace('/', '_')
                    for o1, o2 in ifNodeValCol.iteritems():
                        if o1 == nodeName and o2 == instVal:
                            bolResp = True
                            break
                elif bindObj == const.VLAN_NSIP_BINDING:
                    # get the connection target
                    conTarVal = encapAsCol['apicTarget']
                    # loop over function object and get the corresponding nsip
                    nsipTarValCol = {}
                    for x1, x2 in audFunCol.iteritems():
                        for x3, x4 in x2.iteritems():
                            # ignore x3 since it will be either inside or outside
                            for x5, x6 in x4.iteritems():
                                if x5 == 'excapTarget' and x6 == conTarVal:
                                    nsipTarValCol = x4
                                elif x5 == 'encapTarget' and x6 == conTarVal:
                                    nsipTarValCol = x4
                    if len(nsipTarValCol) > 0:
                        nsipTarVal = nsipTarValCol['nsipTarget']
                        # find this nsip target value in nsip collection
                        for h1, h2 in audNsipCol.iteritems():
                            for h3, h4 in h2.iteritems():
                                if h3 == 'apicTarget' and h4 == nsipTarVal:
                                    bolResp = True
                                    break
            elif bindObj.startswith(const.LBVSERVER): # handle lbvserver bindings by looking lbvserver collection
                lbvCol = {}
                if keyVal in audLbvCol:
                    lbvCol = audLbvCol[keyVal]
                    logger.debug('LBV col = %s' % (lbvCol))
                    # get the lbvserver_binding from the lbvCol
                    lbvBindCol = []
                    if 'lbvserver_binding' in lbvCol:
                        lbvBindCol = lbvCol['lbvserver_binding']
                        logger.debug('LBV Bind col = %s' % (lbvBindCol))
                        if type(lbvBindCol) is list:
                            for tmpVal in lbvBindCol:
                                for c1, c2 in tmpVal.iteritems(): # binding contains list of binding collection
                                    if c1 == bindObj: # bind name must be the same i.e. lbvserver_servicegroup_binding
                                        for c3, c4 in c2.iteritems():
                                            if c3 == bindKey: # and c4 == instVal:
                                                if instVal in audSgCol:
                                                    if audSgCol[instVal]['apicTarget'] == c4:
                                                        bolResp = True
                                                        break
                                                else:
                                                    bolResp = False
                                                    break
            elif bindObj.startswith(const.SERVICEGROUP): # handle servicegroup binding
                sgvCol = {}
                if keyVal in sgvCol:
                    sgvCol = audSgCol[keyVal]
                    sgBndCol = []
                    if const.SERVICEGROUP_BINDING in sgBndCol:
                        sgBndCol = sgvCol[const.SERVICEGROUP_BINDING]
                        logger.debug('SG Bind Col = %s' % (sgBndCol))
                        if type(sgBndCol) is list:
                            for tmpVal in sgBndCol: # since this list
                                for c1, c2 in tmpVal.iteritems(): # list contains dictionary
                                    if c1 == bindObj:
                                        for c3, c4 in c2.iteritems():
                                            if c3 == bindKey and c4 == instVal:
                                                bolResp = True
                                                break
            else:
                # from encap get the connection
                bolResp = findBindObjectInAPICConfig(devCfg, bindObj, keyVal, bindKey, instVal, url, devIp, sesId, logger, nodeName)
                #logger.debug('Bool Response from Find object = %s retCol = %s' % (bolResp, retCol))
            if bolResp is False:
                retCol[(a1,bindKey,instVal, keyVal)] = (keyVal, instVal)
    logger.debug('Bind object not in APIC = %s' % (retCol))             
    return retCol 
#
# get bind Object's binding i.e. lbvserver_service_binding from NetScaler
#
def getBindingsForBindObject(bindName, keyVal, url, devIp, sesId, logger):
    """
    This is to get binding details from the device
    """
    #logger.debug('Get objects binding from NetScaler = %s' % (keyVal))
    retCol = {}
    bindCol = {}
    tmpBindCol = {}
    bindKeyCol = constKey.bindObjOrder
    tmpRespCol = {}

    bindCol = nitro.getBindObjectsBinding(bindName, keyVal, url, devIp, sesId, logger)
    for a1, b1 in bindCol.iteritems():
        tmpCol = {}
        bindObj = a1
        bindKey = None
        bindKey = getBindKeyFromConst(a1, logger)
        #logger.debug('BIND objects key = %s' % (bindKey))
        for i in b1:
            bolResp = False
            instVal = None
            instVal = getNSKeyValueFromCollection(bindKey, i, logger) # here is a dict of bind attributes 
	    if instVal is None:
	        continue
            #logger.debug('Bind Key = %s, inst val = %s, I = %s' % (bindKey, instVal, i))
            if (instVal):
                retCol[(bindName, keyVal, instVal)] = (keyVal, instVal)

    logger.debug('++++++++ Binding objects return results = %s' % (retCol))
    return retCol
#
# This is to get bind key
#
def getBindKeyFromConst(keyName, logger):
    """
    This is to get bind key from const definition
    """
    #logger.debug('Get bind key from const for = %s' % (keyName))
    bindKeyCol = constKey.bindObjOrder
    for i in bindKeyCol:
        tmpTuple = i # key is tuple
        if tmpTuple[0] == keyName:
            keyTup = tmpTuple[1]
            #logger.debug('Bind key found = %s' % (keyTup))
            return keyTup

    # if execution is here that means not found
    return None

#
# get the delete collection 
#    
def computeDelete(cnfg, deviceCol, url, devIp, sesId, entityCol, logger):
    """
    This is to compute delete collection by looking at NetScaler's config
    """
    keyList = []
    keyList = constKey.objOrder
    delCol = {}
    nodeHostVal = None
    retCol = {}
    for i in reversed(keyList):    
        objectName = i[0] # since each object is a tuple in objectOrderNKey
        # get the object instance from NetScaler 
        if (objectName):
            if objectName in const.IGNORE_OBJECTS_LIST:
                continue
            elif objectName == const.VLAN_BIND: # VLAN and its bindings are per node level not at the host level
                # first get the cluster node from config 
                nodeCol = util.getClusterColFromConfig(deviceCol, logger)
                # for each node get the ip and credential 
                for m1, n1 in nodeCol.iteritems():
                    vifObjCol = {}
                    vifNum = None
                    nodeName = m1
                    nodePortVal = 0
                    nodeCredCol = {}
                    for m2, n2 in n1.iteritems():
                        if m2.strip().lower() == const.HOST:
                            nodeHostVal = n2
                        elif m2.strip().lower() == const.PORT:
                            nodePortVal = n2
                        elif m2.strip().lower() == const.CREDS:
                            nodeCredCol = n2
                        # get loginObj to create the sesId 
		    nodeUrl = util.getURL(nodePortVal, nodeHostVal, logger)
                    loginObj = util.getLoginObj(nodeUrl, nodeHostVal, nodeCredCol, logger)
                    nodeSesId = loginObj.login()
                    vservObj  = vser.VServerUtil(logger)
                    vservObj.adminPartitionHandling(cnfg, nodeUrl, nodeHostVal, nodeSesId, True)
                    objCol = {}
                    objCol = getNSObjectFromDevice(objectName, nodeUrl, nodeHostVal, nodeSesId, logger)
                    tmpCol = {}
                    tmpCol = processNodeLevelDelete(objectName, objCol[objectName], cnfg, entityCol, nodeName, nodeUrl, nodeHostVal, nodeSesId, devIp, logger)
                    # logout from Node
                    loginObj.logout(nodeSesId)
                # handle vlan nsip binding here since it is based on connector in APIC                
            #elif objectName == const.LBVSERVER or objectName == const.SERVICE:
            else:
                objCol = {}
                #logger.debug('lbvserver object Name = %s' % (objectName))
                objCol = getNSObjectFromDevice(objectName, url, devIp, sesId, logger)
                # check for default
                defResp = False
                defResp = checkForDefaultObject(objCol[objectName], logger)
                if defResp:
                    #logger.debug('Default object ignore...... objectName = %s' % (objectName))
                    continue
                # process object 
                tmpCol = {}
                tmpCol = processObjectForDelete(objectName, objCol[objectName], deviceCol, entityCol, cnfg, url, devIp, sesId, nodeHostVal, logger)
                delCol = dict(tmpCol.items() + delCol.items())

    logger.debug('+++ Config Delete Collection = %s' % (delCol))
    return delCol
#
# this is to check if the object is default
#
def checkForDefaultObject(objCol, logger):
    """
    This is to check if this is the default object 
    """
    for i in objCol:
        tmpObj = i
        if type(tmpObj) is dict:
            if tmpObj.has_key(const.ISDEFAULT):
                if bool(tmpObj[const.ISDEFAULT]) == True:
                    return True
    # if the execution reaches here then it is not default
    return False

#
# get vlan_interface_binding collection from the APIC config
#
def getVLANInfBindFromAPIC(devCfg, vlanId, nodeName, virtualFlag, url, devIp, sesId, logger):
    """
    This is to get vlan_interface_binding from the APIC config
    """
    logger.debug('++++++ Get VLAN interface binding for Vlan id = %s ++++++' % (vlanId))
   
    retCol = {}
    retList = []
    deviceAuditFlag = True
    createObjCol = {}
    respCode = {}
    configOrderCol = {}
        # create the VLANs
    tagCol = {}
    tmpCode = {}
    tagCol = util.getStateSpecificVLANFromConfig(const.CREATE, devCfg, logger, deviceAuditFlag)
        
        # now get VIF object for this node
    vifObjCol = util.getStateSpecificNodeVIFsFromConfig(const.CREATE, nodeName, devCfg, logger, deviceAuditFlag)
    logger.debug('++++++++ VIFs for nodeName = %s, VIFs = %s' % (nodeName, vifObjCol))
    tmpList = []
    for r1, s1 in vifObjCol.iteritems():
        encapCol = {}
        # here s1 is the dict of type VIFs such as {'ADC1': '1_1'}
        vifNum = s1[nodeName]
        vifNum = vifNum.replace('_', '/')
        # here r1 is object name
        encapCol = util.getStateSpecificVIFEncapassFromConfig(const.CREATE, r1[1], devCfg, logger, deviceAuditFlag)
        logger.debug('++++++++ ENCAP collection for VIF object = %s, encapass collection = %s' % (r1[1], encapCol))
        for r2, s2 in encapCol.iteritems():
            keyTuple = r2
            tmpCol = {}
            for r3, s3 in s2.iteritems():
                if r3.strip().lower() == const.ENCAP:
                    # now get the IFC tags based on the encap object name
                    tagObjName = s3
                    tagCol = {}
                    tmpCol = {}
                    tagCol = util.getStateSpecificEncapTagFromConfig(const.CREATE, tagObjName, devCfg, logger, deviceAuditFlag)
                        # get the tag value from collection
                    for i1, j1 in tagCol.iteritems():
                        tmpCol[const.ID] = j1
                        tmpCol[const.IFNUM] = vifNum
                        # get the vlan_interface_binding for this vlan 
                        devBindCol = {}
                        devBindCol = getBindingsForBindObject(const.VLAN_INTERFACE_BIND_NAME, str(tmpCol[const.ID]), url, devIp, sesId, logger)
                        if len(devBindCol) > 0:
                            findFlag = False
                            for x1, y1 in devBindCol.iteritems():
                                # compare the device details with APIC
                                # device reponse in this format ('vlan_interface_binding', '308', 1/3): ('308', '1/3')
                                if tmpCol[const.IFNUM] == y1:
                                    findFlag = True
                                    #logger.debug('........VLAN_INTERFACE_BINDING exist ignoring ........ Key = %s Value = %s' % (x1,y1))
                            if findFlag == False:
                                 if virtualFlag is False: # since tagged is only supported on MPX not on VPX 
                                     tmpCol[const.TAGGED] = True
                                 retCol[keyTuple] = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, tmpCol, url, devIp, sesId, logger)
                        else:
                            # bind this VLAN with IFNUM
                            #logger.debug('VLAN_INTERFACE_BIND does not exist adding in device........')
                            if virtualFlag is False: # since tagged is only supported on MPX not on VPX
                                tmpCol[const.TAGGED] = True
                            retCol[keyTuple] = nitro.createBindObject(const.VLAN_INTERFACE_BIND_NAME, tmpCol, url, devIp, sesId, logger)
 
    logger.debug('++++++++ VLAN interface binding collection = %s' % (retCol))
    return retCol
#
# get the VLAN bindings from the device
#
def getVLANBindingsFromDevice(nodeName, nodeSesId, nodeUrl, nodeIp, vlanCol, logger):
    """
    This is to get VLAN's binding from the device
    """
    #logger.debug('+++ get VLAN bindings for Node = %s, Node IP = %s' % (nodeName, nodeIp))
    retCol = {}
    for a1, b1 in vlanCol.iteritems():
        tmpList = b1 # since b1 is list here
        for i in b1:
            vlanId = None
            ifNum = None
            devVlanCol = {}
            bindTmpCol = {}
            if type(i) is dict:
                for a2, b2 in i.iteritems():
                    if a2 == const.ID:
                        vlanId = b2
                    elif a2 == const.IFNUM:
                        ifNum = b2
                # now get the vlan interface binding from NetScaler
                devVlanCol = {}
                devVlanCol = getBindingsForBindObject(const.VLAN_INTERFACE_BIND_NAME, str(vlanId), nodeUrl, nodeIp, nodeSesId, logger)
                # compare this with VLAN details from APIC
                if len(devVlanCol) > 0:
                 retCol =  compareVLANBindings(vlanCol, devVlanCol, logger)
    return retCol

#
# compare the VLANs from APIC & device
#
def compareVLANBindings(apicCol, devCol, logger):
    """
    This is to compare VLAN bindings from APIC and device
    """
    logger.debug('+++++ Binding collection to compare APIC col = %s, Device Col = %s' % (apicCol, devCol))
    unBindCol = {}
    retCol = {}
    for a1, b1 in apicCol.iteritems():
        bindList = []
        for i in b1: # since this is list
            idVal = None
            ifNumVal = None
            for a2, b2 in i.iteritems():
                if a2 == const.ID:
                    idVal = b2
                elif a2 == const.IFNUM:
                    ifNumVal = b2
            # compare this with device
            foundFlag = False
            for k1, v1 in devCol.iteritems():
                # device vlan binding details are in following format 
                # ('vlan_interface_binding', u'1/1'): ('303', u'1/1')
                if idVal == k1[1]: # check for the VLAN
                    if ifNumVal == v1[0]: 
                        foundFlag = True
            if foundFlag is False:
                # add new binding in NetScaler 
                # remove existing bind from device
                bindList.append(i)
        if len(bindList) > 0:
            retCol[a1] = bindList

    logger.debug('Compare VLAN return results = %s' % (retCol))
                    
    return retCol
#
# get APIC's VLAN_NSIP binding
#
def getFunctionSpecificVLANNSIPBinding(cnfg, url, devIp, sesId, logger):
    """
    This is to get function specific VLAN and NSIP binding
    """
    retCol = {}
    extCol = {}
    inCol = {}
    # get external network and connector for each function
    extCol = util.getNetworkNConnectorFromConfig(const.EXTERNAL, cnfg, logger)
    intCol = util.getNetworkNConnectorFromConfig(const.INTERNAL, cnfg, logger)

    tmpCol = {}
    tmpCol = getNSIPVLANBindCol(extCol, cnfg, url, devIp, sesId, logger)
    retCol = dict(tmpCol.items() + retCol.items())
    tmpCol = {}
    tmpCol = getNSIPVLANBindCol(intCol,cnfg, url, devIp, sesId, logger)
    retCol = dict(tmpCol.items() + retCol.items())    

    return retCol
#
# compare VLAN NSIP binding between Device & APIC
#
def compareNSVLANBindFromDevice(cnfg, keyVal, instVal, url, devIp, sesId, logger):
    """
    This is to compare VLAN NSIP bind from device to APIC
    """
    devCol = {}
    apicCol = {}
    devCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(keyVal), url, devIp, sesId, logger)
    if len(devCol) > 0:
        extCol = {}
        inCol = {}
        # get external network and connector for each function
        extCol = util.getNetworkNConnectorFromConfig(const.EXTERNAL, cnfg, logger)
        intCol = util.getNetworkNConnectorFromConfig(const.INTERNAL, cnfg, logger)

        tmpCol = {}
        tmpCol = getVLANNSIPBindFromAPIC(extCol, keyVal, cnfg, url, devIp, sesId, logger)
        apicCol = dict(tmpCol.items() + apicCol.items())
        tmpCol = {}
        tmpCol = getVLANNSIPBindFromAPIC(intCol, keyVal, cnfg, url, devIp, sesId, logger)
        apicCol = dict(tmpCol.items() + apicCol.items())
        if len(apicCol) > 0:
            #logger.debug('Collection for vlan_nsip_binding apic = %s, device = %s' % (apicCol, devCol))
            # compare device collection with APIC collection
            for i1, j1 in devCol.iteritems():
                # device collection format (bindName, keyVal, instVal)] = (keyVal, instVal)
                #{('vlan_nsip_binding', '555', u'3.4.5.6'): ('555', u'3.4.5.6')} 
                tmpVal = j1[1]
                for i2, j2 in apicCol.iteritems():
                    # APIC return collection {'netmask': '255.255.255.0', 'ipaddress': '10.4.1.5', 'id': 308}
                    if j2.has_key(const.IPADDRESS):
                        if j1[1] == j2[const.IPADDRESS]:
                            return True

    # if execution reaches here that means not found
    return False
#
# compare VLAN NSIP6 binding between Device & APIC
#
def compareNSIPv6VLANBindFromDevice(cnfg, keyVal, instVal, url, devIp, sesId, logger):
    """
    This is to compare VLAN NSIP bind from device to APIC
    """
    devCol = {}
    apicCol = {}
    devCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(keyVal), url, devIp, sesId, logger)
    if len(devCol) > 0:
        extCol = {}
        inCol = {}
        # get external network and connector for each function
        extCol = util.getNetworkNConnectorFromConfig(const.EXTERNAL, cnfg, logger)
        intCol = util.getNetworkNConnectorFromConfig(const.INTERNAL, cnfg, logger)

        tmpCol = {}
        tmpCol = getVLANNSIPv6BindFromAPIC(extCol, keyVal, cnfg, url, devIp, sesId, logger)
        apicCol = dict(tmpCol.items() + apicCol.items())
        tmpCol = {}
        tmpCol = getVLANNSIPv6BindFromAPIC(intCol, keyVal, cnfg, url, devIp, sesId, logger)
        apicCol = dict(tmpCol.items() + apicCol.items())
        if len(apicCol) > 0:
            #logger.debug('Collection for vlan_nsip_binding apic = %s, device = %s' % (apicCol, devCol))
            # compare device collection with APIC collection
            for i1, j1 in devCol.iteritems():
                # device collection format (bindName, keyVal, instVal)] = (keyVal, instVal)
                #{('vlan_nsip6_binding', '555', u'3.4.5.6'): ('555', u'3.4.5.6')} 
                tmpVal = j1[1]
                for i2, j2 in apicCol.iteritems():
                    # APIC return collection {'netmask': '255.255.255.0', 'ipaddress': '10.4.1.5', 'id': 308}
                    if j2.has_key(const.IPADDRESS):
                        if j1[1] == j2[const.IPADDRESS]:
                            return True

    # if execution reaches here that means not found
    return False

#
# get IPVLANBind from APIC config
#
def getNSIPVLANBindCol(conCol, cnfg, url, devIp, sesId, logger):
    """
    This is to get NSIPVLAN binding from APIC config
    """
    retCol = {}
    # check for the state and if it is create get the object and bind them
    for i1, j1 in conCol.iteritems():
        netObj = None
        conObj = None
        netStat = -1
        # key is function name
        #funName = i1
        for i2, j2 in j1.iteritems():
            #logger.debug(' i2 = %s, j2 = %s' % (i2,j2))
            # key will be network with state i.e. ('network/snip2', 1)
            netObj = i2[0]
            # remove the '/' from name and just get the value
            if netObj.find('/'):
                netObj = netObj[netObj.rfind('/') + 1:]
            netStat = i2[1]
            conObj = j2
        #logger.debug('Details netObj = %s, conObj = %s, netStat = %s' % (netObj, conObj, netStat))
        # now get the object from config
        netObjCol = util.getCompleteObjectFromSubFolderConfig(const.NETWORK, netObj, cnfg, logger)
        conObjCol = util.getCompleteObjectFromConfig(conObj, cnfg)
        #logger.debug('Network object = %s  Connector object = %s' % (netObjCol, conObjCol))
        ipValCol = util.getAttributeCollectionForObject(netObjCol, cnfg, logger)
        #logger.debug(' Network object Attribute Value = %s' % (ipValCol))
        # get the ipaddress and netmask from the ipValCol
        bindCol = {}
        argStr = None
        for l1, m1 in ipValCol.iteritems():
            for l2, m2 in m1.iteritems():
                if l2 == const.IPADDRESS:
                    bindCol[const.IPADDRESS] = m2
                elif l2 == const.NETMASK:
                    bindCol[const.NETMASK] = m2
        bindCol[const.ID] = conObj
        #logger.debug('++++ NSIP VLAN Binding details = %s' % (bindCol))
        # get the vlan_nsip_binding from NetScaler 
        tmpCol = {}
        tmpCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(conObj), url, devIp, sesId, logger)
        #logger.debug(' NSIP VLAN Binding from device = %s' % (tmpCol))
        # compare the device details with APIC
        # device reponse in this format ('vlan_nsip_binding', '308'): ('308', u'10.10.10.100')
        findFlag = False
        if len(tmpCol) > 0:
            for x1, y1 in tmpCol.iteritems():
                if bindCol[const.IPADDRESS] == y1[1]:
                    findFlag = True
        if findFlag is False:
            # add this Bind and remove the existing bind from NetScaler
            retCol[(const.VLAN_NSIP_BINDING, conObj)] = nitro.createBindObject(const.VLAN_NSIP_BINDING, bindCol, url, devIp, sesId, logger)
                    # unBind - Existing NetS
    logger.debug('VLAN_NSIP_Binding collection = %s' % (retCol))
    return retCol 
#
# get NSIP Bind col from APIC using connector
#
def getVLANNSIPBindFromAPIC(conCol, vlanVal, cnfg, url, devIp, sesId, logger):
    """
    This is to get VLAN NSIP bind col from APIC config since they are based on connector
    """
    retCol = {}
    # check for the state and if it is create get the object and bind them
    for i1, j1 in conCol.iteritems():
        netObj = None
        conObj = None
        netStat = -1
        # key is function name 
        #funName = i1
        for i2, j2 in j1.iteritems():
            #logger.debug(' i2 = %s, j2 = %s' % (i2,j2))
            # key will be network with state i.e. ('network/snip2', 1)
            netObj = i2[0]
            # remove the '/' from name and just get the value
            if netObj.find('/'):
                netObj = netObj[netObj.rfind('/') + 1:]
            netStat = i2[1]
            conObj = j2
            if conObj != vlanVal:
                continue
        #logger.debug('Details netObj = %s, conObj = %s, netStat = %s' % (netObj, conObj, netStat))
        # now get the object from config
        netObjCol = util.getCompleteObjectFromSubFolderConfig(const.NETWORK, netObj, cnfg, logger)
        conObjCol = util.getCompleteObjectFromConfig(conObj, cnfg)
        #logger.debug(' Network object = %s  Connector object = %s' % (netObjCol, conObjCol))
        ipValCol = util.getAttributeCollectionForObject(netObjCol, cnfg, logger)
        #logger.debug(' Network object Attribute Value = %s' % (ipValCol))
        # get the ipaddress and netmask from the ipValCol
        bindCol = {}
        argStr = None
        for l1, m1 in ipValCol.iteritems():
            for l2, m2 in m1.iteritems():
                if l2 == const.IPADDRESS:
                    bindCol[const.IPADDRESS] = m2
                elif l2 == const.NETMASK:
                    bindCol[const.NETMASK] = m2
        bindCol[const.ID] = conObj
        #logger.debug('++++ NSIP VLAN Binding details from APIC = %s' % (bindCol))

        # get the vlan_nsip_binding from NetScaler
        #tmpCol = {}
        #tmpCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(conObj), url, devIp, sesId, logger)
        #logger.debug(' NSIP VLAN Binding from APIC = %s' % (tmpCol))    
        retCol[i1] = bindCol
    return retCol
#
# get NSIP Bind col from APIC using connector
#
def getVLANNSIPv6BindFromAPIC(conCol, vlanVal, cnfg, url, devIp, sesId, logger):
    """
    This is to get VLAN NSIP bind col from APIC config since they are based on connector
    """
    retCol = {}
    # check for the state and if it is create get the object and bind them
    for i1, j1 in conCol.iteritems():
        netObj = None
        conObj = None
        netStat = -1
        # key is function name 
        #funName = i1
        for i2, j2 in j1.iteritems():
            #logger.debug(' i2 = %s, j2 = %s' % (i2,j2))
            # key will be network with state i.e. ('network/snip2', 1)
            netObj = i2[0]
            # remove the '/' from name and just get the value
            if netObj.find('/'):
                netObj = netObj[netObj.rfind('/') + 1:]
            netStat = i2[1]
            conObj = j2
            if conObj != vlanVal:
                continue
        #logger.debug('Details netObj = %s, conObj = %s, netStat = %s' % (netObj, conObj, netStat))
        # now get the object from config
        netObjCol = util.getCompleteObjectFromSubFolderConfig(const.NETWORK, netObj, cnfg, logger)
        conObjCol = util.getCompleteObjectFromConfig(conObj, cnfg)
        #logger.debug(' Network object = %s  Connector object = %s' % (netObjCol, conObjCol))
        ipValCol = util.getAttributeCollectionForObject(netObjCol, cnfg, logger)
        #logger.debug(' Network object Attribute Value = %s' % (ipValCol))
        # get the ipaddress and netmask from the ipValCol
        bindCol = {}
        argStr = None
        for l1, m1 in ipValCol.iteritems():
            for l2, m2 in m1.iteritems():
                if l2 == const.IPV6ADDRESS:
                    bindCol[const.IPADDRESS] = m2
                elif l2 == const.NETMASK:
                    bindCol[const.NETMASK] = m2
        bindCol[const.ID] = conObj
        #logger.debug('++++ NSIP VLAN Binding details from APIC = %s' % (bindCol))

        # get the vlan_nsip_binding from NetScaler
        #tmpCol = {}
        #tmpCol = getBindingsForBindObject(const.VLAN_NSIP_BINDING, str(conObj), url, devIp, sesId, logger)
        #logger.debug(' NSIP VLAN Binding from APIC = %s' % (tmpCol))    
        retCol[i1] = bindCol
    return retCol
#
# compute modify for Attach IP 
#
def computeModifyForAttachIp(cnfg, devCol, url, devIp, virtualFlag, sesId, logger):
    """
    This is to get connector for IP attach or detach event
    """
    conCol = {}
    respCol = {}
    conCol = util.getIPNConForAttach(cnfg, logger)
    for a1, b1 in conCol.iteritems():
        attachIpList = b1 # here b1 is list
        sgNameNPort = util.getSGForAttachIPConnector(a1, cnfg, logger)
        # get the service group's servicegroup_servicegroupmember_binding
        sgValCol = {}
        sgName = sgNameNPort[0]
        sgValCol = nitro.getBindObjectsBinding(const.SVCGROUP_SGMEM_BIND, sgName, url, devIp, sesId, logger)
        logger.debug('+++ sgValCol = %s' % (sgValCol))
        sgMemIpList = []
        for x1, y1 in sgValCol.iteritems():
            for tmpVal in y1: # here y1 is list
                for s1, t1 in tmpVal.iteritems():
                    if s1 == const.IP:
                        sgMemIpList.append(str(t1))
        logger.debug('+++ IP from service group member binding = %s type = %s' % (sgMemIpList, type(sgMemIpList)))
        addIpList = []
        for item in attachIpList:
            tmpKey = item[1]
            tmpIp = str(item[2]) # since this is complete tuple i.e. (22, '', "u'10.10.10.12'")
            #logger.debug('+++ type of IP = %s' % (type(tmpIp)))
            if tmpIp not in sgMemIpList:
                #logger.debug('++++ Tmp IP not in = %s type = %s' % (tmpIp, type(tmpIp)))
                addIpList.append(tmpIp)
        logger.debug('++++ Add IP list from attach IP = %s' % (addIpList))
        if len(addIpList) > 0:
            for tmpIPVal in addIpList:
                # get key and port collection
                sgPortCol = {}
                if sgNameNPort[1] is not None:  # this is to avoid None service group getting in bind op
                    sgPortCol[sgName] = sgNameNPort[1]
                    tmpCol = {}
                    tmpCol[tmpKey] = nitro.bindSGPortIPForEpAttach(sgPortCol, tmpIPVal, url, devIp, sesId, logger)
                    respCol = dict(respCol.items() + tmpCol.items())
    return respCol
#
# Compute Delete for Attach IP
#
def computeDeleteforAttachIp(cnfg, devCol, url, devIp, virtualFlag, sesId, logger):
    """
    This is to remove additional service member bindings from Netscaler
    """
    instCol = {}
    respCol = {}
    #getObjectsConfigFromDevice(objName, url, devIp, sesId, logger)
    instCol = nitro.getObjectsConfigFromDevice(const.SERVICEGROUP, url, devIp, sesId, logger)
    logger.debug('++++ service group object from device = %s' % (instCol))
    #tmpCol = getBindObjectsBinding(objName, objVal, url, devIp, sesId, logger)
    if len(instCol) > 0:
        bindCol = {}
        tmpGroupList = []
        for a1, b1 in instCol.iteritems():
            for a2, b2 in b1.iteritems():
                tmpList = b2 # since b1 is list
                if type(tmpList) is list:
                    for item in tmpList:
                        #logger.debug('++++ Item = %s' % (item))
                        for a3, b3 in item.iteritems():
                            if a3 == const.SERVICEGROUPNAME:
                                tmpGroupList.append(b3)
        logger.debug('++++++ Service group Name = %s' % (tmpGroupList))
        # now get the bindings
        for tmpGrpName in tmpGroupList:
            bindCol = nitro.getBindObjectsBinding(const.SVCGROUP_SGMEM_BIND, tmpGrpName, url, devIp, sesId, logger)
            sgMemIpCol = {}
            for x1, y1 in bindCol.iteritems():
                for tmpVal in y1: # here y1 is list
                    tmpIp = None
                    tmpPort = None
                    for s1, t1 in tmpVal.iteritems():
                        if s1 == const.IP:
                            tmpIp = t1
                        elif s1 == const.PORT:
                            tmpPort = t1
                    if tmpPort and tmpIp:
                        sgMemIpCol[tmpIp] = tmpPort
            logger.debug('+++++ service group IP & port collection = %s' % (sgMemIpCol))
            apicSgCol = {}
            apicSgCol = util.getSGObjectNMemberBinding(tmpGrpName, cnfg, logger)
            logger.debug('++++++ SG member collection from APIC = %s' % (apicSgCol))
            # now compute delete based on service group members from Device & APIC
            tmpDelList = []
            tmpDelList  = computeDeleteForAttachIps(sgMemIpCol, apicSgCol, logger)
            logger.debug('++++++++ delete collection for service group = %s' % (tmpDelList))
            if len(tmpDelList) > 0:
                for tmpIp in tmpDelList:
                    argStr = 'args=' +  const.IP + ':' + tmpIp + ',' + const.PORT + ':' + str(sgMemIpCol[tmpIp])
                    respCol[tmpGrpName] = nitro.removeNitroObject(const.SVCGROUP_SGMEM_BIND, tmpGrpName, argStr, url, devIp, sesId, logger)
    return respCol
#
# compute delete for service group members 
#
def computeDeleteForAttachIps(devCol, apCol, logger):
    """
    This is to compute delete for attach Ips
    """
    # dev col format {u'10.10.10.11': 80, u'10.10.10.13': 80, u'10.10.10.12': 80}
    delList = []
    for a1, b1 in devCol.iteritems():
        tmpIp = a1
        tmpPort = b1
        foundFlag = False
        #apCol could have two collections 
        # {((0, '', 4537), (1, '', 4159), (3, 'LoadBalancing', 'ADC'), (2, 'internal', 'internal')): [(22, '', '10.10.10.13'), (22, '', '10.10.10.12'), (22, '', '10.10.10.11')], u'Srv35': {(4, 'servicegroup_servicegroupmember_binding', 'servicegroup_servicegroupmember_binding-DefaultInst'): ('34.34.34.12', '80')}}
        # if there is single IP then it would be jsut a tuple {u'SG1': {(4, 'servicegroup_servicegroupmember_binding', 'membind3'): ('110.110.110.105', '8080'), (4, 'servicegroup_servicegroupmember_binding', 'membind1'): ('110.110.110.103', '80'), (4, 'servicegroup_servicegroupmember_binding', 'membind2'): ('110.110.110.104', '80')}}
        for a2, b2 in apCol.iteritems():
            if type(b2) is list:
                for item in b2:
                    if type(item) is tuple:
                        # check first if it (22, '', '10.10.10.13')
                        if item[0] == const.ATTACHIP and item[2] == tmpIp:
                            foundFlag = True
                            break
            elif type(b2) is tuple: # ('34.34.34.12', '80')
                if b2[0] == tmpIp:
                    foundFlag = True
                    break
            elif type(b2) is dict:
		for p1,	q1 in b2.iteritems():
                    #logger.debug('p1 = %s, q1 = %s, tmpIp = %s' % (p1, q1, tmpIp))
                    if type(q1) is tuple and q1[0] == tmpIp: # this is for single entry 
                        foundFlag = True
                        break
                    elif type(q1) is list: # this for more than one return in list just in case
                        for tmpItem in q1:
                            #logger.debug('tmpItem = %s' % (str(tmpItem)))
                            if type(tmpItem) is tuple and tmpItem[0] == tmpIp:
                                foundFlag = True
                                break

        if foundFlag is False:
           delList.append(tmpIp)
    logger.debug('+++++++++ compute delete for Attach IPs = %s' % (delList))
    return delList
                
def processPartitionForDelete(objName, objCol, deviceCol, devCfg, url, devIp, sesId, nodeIp, logger):
    """
    This is to process nitro response 
    """
    logger.debug('+++++++++ processing nitro response for object = %s' % (objName))
    errVal = None
    instList = []
    keyAtr = ('partitionname', )
    deleteCol = {}
    respCode = {}
    tmpCol = {}
    if (keyAtr):
        keyAtr = keyAtr[0]
    for a1, b1 in objCol.iteritems():
        if a1 == const.ERRORCODE:
            errVal = b1
        elif a1 == objName:
            instList = b1
    logger.debug('Porcess object For errorcode = %s instList = %s' % (errVal, instList))
    tmpObjCol = {}
    for i in instList:
        # check if i is not type of dict then ignore
        if type(i) is not dict:
            continue
        tmpObjCol = i
        # get the key value from the instance 
        keyVal = getNSKeyValueFromCollection(keyAtr, tmpObjCol, logger)
        logger.debug('+++++++++ Ket Value  = %s' % (keyVal))
        #deleteCol[(objectName, keyVal)] = keyVal
        deleteCol[(objName, keyVal)] = keyVal
        logger.debug('+++++++++ Ket Attr Name  = %s' % (keyAtr))
        respCode[objName] = nitro.removeNitroObject(objName, keyVal, None, url, devIp, sesId, logger)                    
        tmpCol = dict(tmpCol.items() + respCode.items())

    logger.debug(' Delete Collection = %s' % (deleteCol))

    return tmpCol
        

#
# get the delete collection 
#    
def deleteAllPartition(cnfg, deviceCol, url, devIp, sesId, logger):
    """
    This is to compute delete collection by looking at NetScaler's config
    """
    keyList = [('nspartition', ('partitionname', ))]
    delCol = {}
    nodeHostVal = None
    retCol = {}
    for i in reversed(keyList):    
        objectName = i[0] # since each object is a tuple in objectOrderNKey
        # get the object instance from NetScaler 
        if (objectName):
            objCol = {}
            objCol = getNSObjectFromDevice(objectName, url, devIp, sesId, logger)
            # process object 
            tmpCol = {}
            tmpCol = processPartitionForDelete(objectName, objCol[objectName], deviceCol, cnfg, url, devIp, sesId, nodeHostVal, logger)
            delCol = dict(tmpCol.items() + delCol.items())

    logger.debug('+++ deleteAllPartition Collection = %s' % (delCol))
    return delCol

       
                            
        
if __name__ == '__main__':
    lgObj = LogService()
    log1 = lgObj.getLogger()
    computeModify(None, None, None, log1)
                     
