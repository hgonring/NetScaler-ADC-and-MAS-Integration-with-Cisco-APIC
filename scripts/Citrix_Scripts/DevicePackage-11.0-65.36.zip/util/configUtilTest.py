#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import unittest
import ScriptUtil
import scriptConst as const
import LogService
import vServerUtil
import configUtil
import json
import nitroUtil
import yaml
import NSLogin

class TestConfigUtilFunction(unittest.TestCase):

    def setup(self):
        self.tmpParam = {"name" : "Test1", "ip" : "1.1.1.1", "port" : 80, "lbmethod" : "RoundRobin"}
        self.LBData = range(10)
        self.scrObj = ScriptUtil.ScriptUtil()

    def test_GetStateSpecificObjectsFromConfig(self):
        #csvFile = open('test/modifyCsvServer.yaml', "r")
        #csvFile = open('test/deviceConfigEPAttach.yaml', "r")
        #csvFile = open('test/vlanTestData.yaml', "r")
	#csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	#for i in csvData:
        #    csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        #cnfgFile = open('test/appFWTestData.yaml', "r")
        #cnfgFile = open('test/vlanTestData.yaml', "r")
        #cnfgFile = open('test/vlanIssueData.yaml', "r")
        #cnfgFile = open('test/aaaTestData.yaml', "r")
        #cnfgFile = open('test/vipul300Graphs.yaml', "r")
        cnfgFile = open('test/snmpTestData.yaml', "r")
        #cnfgFile = open('test/ifc_ICTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getStateSpecificVLANFromConfig(const.CREATE, cnfgCol, logger, True)
	#print 'VLAN CREATE Collection = ', respCol
	#respCol = configUtil.getStateSpecificVLANFromConfig(const.DELETE, cnfgCol, logger, False)
	#print 'VLAN DELETE Collection = ', respCol
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.CREATE, cnfgCol, logger, True)
	#print 'CREATE Collection = ', respCol
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.MODIFY, cnfgCol, logger)
	#print 'MODIFY Collection = ', respCol
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.DELETE, cnfgCol, logger)
	#respCol = configUtil.getClusterStateSpecificObjectsFromConfig(const.MODIFY, cnfgCol, logger)
	#print 'Cluster MODIFY Collection = ', respCol
	#respCol = configUtil.getClusterModifyObjectAtrsFromConfig(const.MODIFY, cnfgCol, logger)
	#print 'Cluster MODIFY Collection = ', respCol
        #nsLgObj.logout(sesId)
	#print 'DELETE Collection = ', respCol

    def test_GetStateSpecificAtrColFromConfig(self):
        csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        #cnfgFile = open('test/vipulServiceModifyTestData.yaml', "r")
        #cnfgFile = open('test/modifyTestData.yaml', "r")
        cnfgFile = open('test/pariModTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
        #objFile = open('test/modifyTestData.yaml', "r")
        objFile = open('test/pariModifyTestData.yaml', "r")
	objData = yaml.load_all(objFile)
	objCol = {}
	for j in objData:
            objCol = j

	devIp = '10.102.201.141'
	sesId = '1234555'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.CREATE, cnfgCol, logger)
	#print 'CREATE Collection = ', respCol
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.MODIFY, cnfgCol, logger)
	#respCol = configUtil.getModifyStateSpecificAtrColFromConfig(cnfgCol, logger)
	#respCol = configUtil.getModifyAttributeCollectionForObject(cnfgCol, logger)
	#respCol = configUtil.getSetAttrCol(objCol, const.MODIFY, cnfgCol, logger)
	#print 'Attribute MODIFY Collection = ', respCol
	#respCol = configUtil.getSetAttrCol(objCol, const.MODIFY, cnfgCol, logger, True)
	#print 'Attribute MODIFY Collection = ', respCol
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.DELETE, cnfgCol, logger)
	#print 'DELETE Collection = ', respCol

    def test_GetBindStateSpecificObjectsFromConfig(self):
        csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
    	#cnfgFile = open('test/ApicTestData.yaml', 'r')
    	#cnfgFile = open('test/ifc_PolicyTest.yaml', 'r')
    	#cnfgFile = open('test/ifc_ICTestData.yaml', 'r')
        #cnfgFile = open('test/appFWTestData.yaml', "r")
    	#cnfgFile = open('test/routeData.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        cnfgFile = open('test/serviceGroupTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.201.141'
	sesId = '1234555'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
    	vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = configUtil.getStateSpecificBindObjectsFromConfig(const.CREATE, cnfgCol, logger, True)
	#print ' BIND CREATE Collection = ', respCol
	#respCol = configUtil.getStateSpecificBindObjectsFromConfig(const.DELETE, cnfgCol, logger)
	#print 'DELETE Collection = ', respCol
	
    
    def test_GetSGPortCollectionForConnector(self):
        csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        cnfgFile = open('test/graph_5TestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
        connName = 'conn_1'
	devIp = '10.102.201.141'
	sesId = '1234555'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = configUtil.getStateSpecificBindObjectsFromConfig(const.DELETE, cnfgCol, logger)
	#print ' BIND DELETE Collection = ', respCol
	#respCol = configUtil.getSGPortCollectionForConnector(connName, cnfgCol, logger)
	#print 'SG Port Collection = ', respCol

    def test_GetServiceStat(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
        instName = 'webcs'
	devIp = '10.102.201.141'
        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = configUtil.getMonitoringStat('csvserver', instName, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
	#print ' Stat Data Response  = ', respCol

    def test_LoadObjectListFromFile(flName):
        """
        This is to load the object list from file to a list
        """
        #objCol = configUtil.loadObjectListFromFile(const.FILENAME)
        #print 'List data = ', objCol

    def test_GetDeviceDetailsFromConfig(self):
        csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        cnfgFile = open('test/deviceData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.201.141'
	sesId = '1234555'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getClusterColFromConfig(cnfgCol, logger)
	#print ' ------- Get Device name from Config =======', respCol

    def test_GetStateSpecificVEncapassObjectsFromConfig(self):
        #csvFile = open('test/modifyCsvServer.yaml', "r")
        csvFile = open('test/deviceConfigEPAttach.yaml', "r")
	csvData = yaml.load_all(csvFile)
  	csvCol = {}
	respCol = {}
	for i in csvData:
            csvCol = i
	#print 'csvCol = ', csvCol
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
        #cnfgFile = open('test/deviceConfigEPAttach.yaml', "r")
        #cnfgFile = open('test/ifcConfigData.yaml', "r")
        #cnfgFile = open('test/connectorTestData.yaml', "r")
        #cnfgFile = open('test/scaleTestData.yaml', "r")
        cnfgFile = open('test/interfaceModifyTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.201.141'
	sesId = '1234555'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getNodeVIFsFromConfigForState(const.MODIFY, 'ADC1', cnfgCol, logger, False)
	#print 'VIFs Collection = ', respCol
	#respCol = configUtil.getVIFEncapassFromConfigNState('ADCCluster1_inside', cnfgCol, logger, True)
	#print 'Encap Collection = ', respCol
	#respCol = configUtil.getStateSpecificNodeVIFsFromConfig(const.CREATE, 'NS_1', cnfgCol, logger, False)
	#print 'VIFs Collection = ', respCol
	#respCol = configUtil.getEncapTagNStateFromConfig('2719744_32771', cnfgCol, logger, True)
	#print 'Tag Collection = ', respCol
	#respCol = configUtil.getStateSpecificVIFEncapassFromConfig(const.CREATE, 'ADCCluster1_inside', cnfgCol, logger, True)
	#respCol = configUtil.getStateSpecificVIFEncapassFromConfig(const.CREATE, 'NS_Cluster_1_inside', cnfgCol, logger, True)
	#print 'Encap Collection = ', respCol
	#respCol = configUtil.getStateSpecificEncapTagFromConfig(const.CREATE, '9743', cnfgCol, logger, True)
	#respCol = configUtil.getStateSpecificEncapTagFromConfig(const.CREATE, '57899', cnfgCol, logger, True)
	#print 'Tag Collection = ', respCol
    	#vservObj  = vServerUtil.VServerUtil(logger)
	#respCol = configUtil.getStateSpecificVEncapassObjects(const.CREATE, cnfgCol, logger)
	#print 'CREATE VEncapass Collection = ', respCol
	#respCol = configUtil.getStateSpecificNetworkObjects(const.CREATE, cnfgCol, logger)
	#print 'CREATE IFCTag and other network Collection = ', respCol
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.MODIFY, cnfgCol, logger)
	#print 'MODIFY Collection = ', respCol
	#respCol = configUtil.getStateSpecificObjectsFromConfig(const.DELETE, cnfgCol, logger)
	#print 'DELETE Collection = ', respCol

    def test_getNetworkNConnector(self):
        #csvFile = open('test/modifyCsvServer.yaml', "r")
        #csvFile = open('test/deviceConfigEPAttach.yaml', "r")
    	#cnfgFile = open('test/modifyDeviceConfig.yaml', 'r')
    	#cnfgFile = open('test/vipul100Graphs.yaml', 'r')
    	#cnfgFile = open('test/amitTest_2.yaml', 'r')
    	cnfgFile = open('test/AmitTestLog.yaml', 'r')
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j

	devIp = '10.102.201.141'
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getNetworkNConnectorFromConfig(const.EXTERNAL, cnfgCol, logger)
	#print 'External Network N Connector =', respCol
	#respCol = configUtil.getNetworkNConnectorFromConfig(const.INTERNAL, cnfgCol, logger)
	#print 'Internal Network N Connector =', respCol

    def test_getServiceGroupMemCol(self):
        cnfgFile = open('test/serviceHealthWSGTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getServiceGroupMemCol('serviceGroup', cnfgCol, logger)
	#print 'Service group member collection =', respCol
	
	return 

    def test_getServiceGroupForConnector(self):
        cnfgFile = open('test/connectorTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getObjectForConnector('inside', 'service', cnfgCol, logger)
	#respCol = configUtil.getLBVServerBasedOnObject('lbvserver_service_binding', 'webservice1', cnfgCol, logger)
	#print 'SG for Connector =', respCol

    def test_getVserverNConnector(self):
        cnfgFile = open('test/connectorTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getVserverNConnectorsFromConfig(cnfgCol, logger)
	#respCol = configUtil.getLBVServerBasedOnObject('lbvserver_service_binding', 'webservice1', cnfgCol, logger)
	#print 'Versers collection  with Connector =', respCol

    def test_getVserverNServiceForeachFunction(self):
        cnfgFile = open('test/connectorTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getVserverNServiceForeachFunction(cnfgCol, logger)
	#respCol = configUtil.getLBVServerBasedOnObject('lbvserver_service_binding', 'webservice1', cnfgCol, logger)
	#print 'Versers collection  foreach function =', respCol
	
	return


    def test_getKeyAttrValForObjectFromConfig(self):
        cnfgFile = open('test/connectorTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	tmpName = 'lbvserver'
	#respCol = configUtil.getKeyAttrValForObjectFromConfig(tmpName, cnfgCol, logger)
	#respCol = configUtil.getLBVServerBasedOnObject('lbvserver_service_binding', 'webservice1', cnfgCol, logger)
	#print 'Object key value for object  =', respCol
	
	return

    def test_getFaults(self):
        #cnfgFile = open('test/connectorTestData.yaml', "r")
        cnfgFile = open('test/faultsTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	respCol = {}
	rootKey = (7, '', '2097153_32897')
	for j in cnfgData:
            cnfgCol = j
	cnfgCol = {(((0, '', 5104), (4, 'Policy', 'cachePolicy')), (4, 'cachepolicy', 'Pol2')): {'cachepolicy': {u'errorcode': 1093, 'status_code': 400, u'message': u'Argument pre-requisite missing [invalGroups, action==INVAL]', u'severity': u'ERROR', 'operation_name': 'add_op'}}, (8, '', 'ADCCluster1_outside_2293760_32771'): {'vlan_interface_binding': {u'errorcode': 0, 'status_code': 201, u'message': u'Done', u'severity': u'NONE', 'operation_name': 'bind_op'}}, (8, '', 'ADCCluster1_inside_2293760_32772'): {'vlan_interface_binding': {u'errorcode': 0, 'status_code': 201, u'message': u'Done', u'severity': u'NONE', 'operation_name': 'bind_op'}}, (((0, '', 5104), (4, 'Policy', 'cachePolicy')), (4, 'cachepolicy', 'Pol1')): {'cachepolicy': {u'errorcode': 786, 'status_code': 599, u'message': u'Invalid rule.', u'severity': u'ERROR', 'operation_name': 'add_op'}}}
        #cnfgCol = {'servicegroup_key': {'servicegroup1': {'servicegroup_servicegroupmember_binding': {u'errorcode': 258, 'status_code': 404, u'message': u'No such resource [serviceGroupName, servicegroup1]', u'severity': u'ERROR', 'operation_name': 'bind_op'}}}}
        #cnfgCol = {(8, '', 'NS_Cluster_1_outside_2097153_32892'): { 'vlan_interface_binding': { 'errorcode': 2082, 'status_code': 599, 'message': 'Maximum number of tagged VLANs bound to the interface exceeded or the binding of this VLAN is not allowed on the interface.', 'severity': 'ERROR', 'operation_name': 'bind_op' } } }
	#cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
	#cnfgCol = {(((0, '', 4306), (4, 'Network', 'network')), (4, 'nsip', 'snip2')): {'nsip': {u'errorcode': 273, 'status_code': 409, u'message': u'Resource already exists', u'severity': u'ERROR', 'operation_name': 'add_op'}}, ((0, '', 4306), (4, 'service', 'service1')): {'service': {u'errorcode': 273, 'status_code': 409, u'message': u'Resource already exists', u'severity': u'ERROR', 'operation_name': 'add_op'}}, (((0, '', 4306), (4, 'lbvserver', 'lbvserver')), 'lbvserver'): {'lbvserver': {u'errorcode': 273, 'status_code': 409, u'message': u'Resource already exists', u'severity': u'ERROR', 'operation_name': 'add_op'}}, ('lbvserver', 'lbvserver'): {}, ((0, '', 4306), (4, 'service', 'service2')): {'service': {u'errorcode': 273, 'status_code': 409, u'message': u'Resource already exists', u'severity': u'ERROR', 'operation_name': 'add_op'}}, (((0, '', 4306), (4, 'Network', 'network')), (4, 'nsip', 'snip1')): {'nsip': {u'errorcode': 273, 'status_code': 409, u'message': u'Resource already exists', u'severity': u'ERROR', 'operation_name': 'add_op'}}}
        #cnfgCol = {(8, '', 'ADCCluster1_inside_51714'): {'vlan_interface_binding': {u'errorcode': 2080, 'status_code': 599, u'message': u'Interface is already bound to this VLAN', u'severity': u'ERROR', 'operation_name': 'bind_op'}} }
	#cnfgCol = {((0, '', 4096), (1, '', 5480), (3, 'LoadBalancing', 'Node1'), (2, 'external', 'outside')): { 'vlan_nsip_binding': { u'errorcode': 397, 'status_code': 404, u'message': u'IPdoesnotexistfordefaultorspecifiedtd', u'severity': u'ERROR', 'operation_name': 'del_op' } } }
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	#respCol = configUtil.getFaults(rootKey, cnfgCol,logger)
	#print 'Faults = ', respCol
	
	return

    def test_handleParam(self):
        #cnfgFile = open('test/connectorTestData.yaml', "r")
        cnfgFile = open('test/ICTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
	#cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
	logSerObj = LogService.LogService()
	devIp = '10.102.201.141'
    	logger = logSerObj.getLogger()
        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #tmpCol = configUtil.handleParamObjects(cnfgCol, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
	#print 'handle Param Response = ', tmpCol
	
	#print 'Config collection = ', cnfgCol

	return

    def test_getHANodeOfDevice(self):
	#cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
	logSerObj = LogService.LogService()
	#devIp = '10.102.201.141'
	devIp = '172.23.50.132'
    	logger = logSerObj.getLogger()
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #tmpCol = configUtil.getPeerHANodeOfDevice(const.HANODE, devIp, sesId, logger)
        #nsLgObj.logout(sesId)
	#print 'Device HA Node  = ', tmpCol

	return

    def test_getDeviceFeatureCollection(self):
	#cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
	logSerObj = LogService.LogService()
	#devIp = '10.102.201.141'
	devIp = '172.23.50.132'
    	logger = logSerObj.getLogger()
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        #url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        url = "http://" + "10.102.102.51" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        #cnfgFile = open('test/enableFeatureTestData_2.yaml', "r")
        #cnfgFile = open('test/featureModeTestData.yaml', "r")
        cnfgFile = open('test/clusterAuditTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #tmpCol = configUtil.getDeviceFeatureCollection(cnfgCol, const.ENABLE_FEATURE, const.ENABLE_OPTIONS, logger, True)
	#print 'Device Feature Collection = ', tmpCol
        #nsLgObj.logout(sesId)
        #tmpCol = configUtil.getDeviceFeatureCollection(cnfgCol, const.ENABLE_MODE, const.ENABLE_OPTIONS, logger, True)
	#print 'Device Mode Collection = ', tmpCol
        #tmpCol = configUtil.getDeviceFeatureCollection(cnfgCol, const.ENABLE_FEATURE, const.DISABLE_OPTIONS, logger, True)
	#print 'Disable Device Feature Collection = ', tmpCol
        #tmpCol = configUtil.getDeviceFeatureCollection(cnfgCol, const.ENABLE_MODE, const.DISABLE_OPTIONS, logger, True)
	#print 'Disable Device Mode Collection = ', tmpCol

	return


    def test_getDeviceConfig(self):
	#cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
	logSerObj = LogService.LogService()
	devIp = '10.102.201.141'
    	logger = logSerObj.getLogger()
        url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #tmpCol = configUtil.getDeviceConfig(devIp, sesId, logger)
        #nsLgObj.logout(sesId)
	#print 'Device Config = ', tmpCol

	return

    def test_getObjColFromDevModCnfg(self):
	devModCol = {(4, 'HAPeer', 'HAPeer'): {'state': 0, 'value': {(5, 'peerIp', 'peerIp'): {'state': 0, 'value': '10.102.102.59'}, (5, 'peerId', 'peerId'): {'state': 0, 'value': '1'}}}, (4, 'HighAvailability', 'HighAvailability'): {'state': 0, 'value': {(5, 'snip', 'snip'): {'state': 0, 'value': '2.3.4.6'}, (5, 'vlan', 'vlan'): {'state': 0, 'value': '500'}, (5, 'netmask', 'netmask'): {'state': 0, 'value': '255.255.255.0'}, (5, 'interface', 'interface'): {'state': 0, 'value': '1_2'}}}}
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
        #tmpCol = configUtil.getObjColFromDevModCnfg(devModCol, const.HAPEER, logger)
	#print 'Collection for HA PEER  = ', tmpCol
        #tmpCol = configUtil.getObjColFromDevModCnfg(devModCol, const.HIGHAVAILABILITY, logger)
	#print 'Collection for HIGHAVAILABILITY collection  = ', tmpCol

	return

    def test_execRHI(self):
	#cnfgCol = { ('nsip', 'csvip_B'): { 'nsip': { 'errorcode': 273, 'message': 'Resourcealreadyexists', 'severity': 'ERROR' } } }
	logSerObj = LogService.LogService()
	#devIp = '10.102.201.141'
	devIp = '172.23.50.132'
    	logger = logSerObj.getLogger()
        #url = "http://" + "10.102.201.141" + "/nitro/v1/config/login"
        deviceFile = open('test/deviceData_2.yaml', "r")
        deviceData = yaml.load_all(deviceFile)
        deviceCol = {}
        for m in deviceData:
            deviceCol = m
        url = "http://" + "172.23.50.132" + "/nitro/v1/config/login"
        cred = {"userName":"nsroot", "password":"nsroot", "url": url}
        nsLgObj = NSLogin.NSLogin(cred, logger)
        #sesId = nsLgObj.login()
        #tmpFlg = configUtil.execRHIConfig(deviceCol, sesId, logger)
	#print 'RHI Flag = ', tmpFlg
        #nsLgObj.logout(sesId)
	return

    def test_replaceLargeKeyFromConfig(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        cnfgFile = open('test/aaaTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cnfgCol = {}
	for j in cnfgData:
            cnfgCol = j
	#newCfg = configUtil.replaceLargeKeyFromConfig(cnfgCol, logger)
	#print 'New Config = ', newCfg

    def test_getURL(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        cnfgFile = open('test/deviceVDataCisco.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	devCol = {}
	for j in cnfgData:
            devCol = j
	#url = configUtil.getURL(devCol[const.PORT], devCol[const.HOST], logger)
	#print 'Returned URL = ', url

	return 

    def test_getTupleList(self):
        logSerObj = LogService.LogService()
        logger = logSerObj.getLogger()
        tupVal = (((0, '', 4096), (4, 'Network', 'network')), (4, 'nsip', 'snip1'))
        #tupList = configUtil.getTupleList(tupVal, logger)
        #print 'Returned Tuple list = ', tupList
        return

    def test_compareAPICNDeviceObjects(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()
	apiCol = {'ipv46': '10.101.79.200', 'servicetype': 'HTTP', 'name': 'webVirtualServer', 'persistencetype': 'SourceIP', 'lbmethod': 'LEASTCONNECTION', 'port': '80', 'clttimeout': '180', 'backupserver' : 'Test'}
	devCol = {u'maxautoscalemembers': u'0', u'curstate': u'DOWN', u'cachetype': u'SERVER', u'consolidatedlconn': u'GLOBAL', u'mysqlcharacterset': u'0', u'consolidatedlconngbl': u'YES', u'rtspnat': u'OFF', u'statechangetimemsec': u'977', u'bypassaaaa': u'NO', u'downstateflush': u'ENABLED', u'macmoderetainvlan': u'DISABLED', u'mysqlprotocolversion': u'0', u'icmpvsrresponse': u'PASSIVE', u'statechangetimesec': u'Mon Sep 15 05:13:43 2014', u'ipmask': u'*', u'insertvserveripport': u'OFF', u'redirectportrewrite': u'DISABLED', u'port': 80, u'clttimeout': u'180', u'connfailover': u'DISABLED', u'servicetype': u'HTTP', u'cacheable': u'NO', u'invoke': False, u'persistencebackup': u'NONE', u'activeservices': u'0', u'authn401': u'OFF', u'pushlabel': u'none', u'statechangetimeseconds': u'1410758023', u'priority': u'0', u'authentication': u'OFF', u'dataoffset': u'0', u'healththreshold': u'0', u'vsvrbindsvcip': u'10.101.79.200', u'datalength': u'0', u'health': u'0', u'td': u'0', u'gt2gb': u'DISABLED', u'type': u'ADDRESS', u'lbmethod': u'LEASTCONNECTION', u'mysqlservercapabilities': u'0', u'status': 1, u'map': u'OFF', u'isgslb': False, u'sopersistence': u'DISABLED', u'appflowlog': u'ENABLED', u'vsvrbindsvcport': 0, u'dbslb': u'DISABLED', u'dns64': u'DISABLED', u'version': 0, u'lbrrreason': 0, u'ruletype': u'0', u'skippersistency': u'None', u'persistencetype': u'SOURCEIP', u'tickssincelaststatechange': u'9579882', u'pq': u'OFF', u'effectivestate': u'DOWN', u'push': u'DISABLED', u'l2conn': u'OFF', u'pushmulticlients': u'NO', u'sessionless': u'DISABLED', u'policysubtype': u'0', u'ipv46': u'10.101.79.200', u'minautoscalemembers': u'0', u'ipmapping': u'0.0.0.0', u'name': u'webVirtualServer', u'ippattern': u'0.0.0.0', u'disableprimaryondown': u'DISABLED', u'backuppersistencetimeout': 2, u'hits': u'0', u'dynamicweight': u'0', u'pipolicyhits': u'0', u'm': u'IP', u'somethod': u'NONE', u'totalservices': u'0', u'sopersistencetimeout': u'2', u'range': u'1', u'persistmask': u'255.255.255.255', u'timeout': 2, u'newservicerequestunit': u'PER_SECOND', u'sc': u'OFF', u'v6persistmasklen': u'128', u'thresholdvalue': 0}
        #boolResp = configUtil.compareAPICNDeviceObjects(apiCol, devCol, logger)
        #print 'Compare Bool Response' , boolResp
        return

    def test_getInterfaceByNode(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        cnfgFile = open('test/raviVlanTestData.yaml', "r")
	cnfgData = yaml.load_all(cnfgFile)
	cfgCol = {}
	for j in cnfgData:
            cfgCol = j
	nodeName = 'ADC1'
	infCol = {(11, '', '10_1'): {'state': 0, 'label': ''}, (11, '', '10_2'): {'state': 0, 'label': ''}}
	#respVal = configUtil.getInterfaceByNode(infCol, logger)
	#print 'Returned Interface by node  = ', respVal

	return 

    def test_getClusterNodeName(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        devFile = open('test/deviceBLRData.yaml', "r")
	devData = yaml.load_all(devFile)
	devCol = {}
	for j in devData:
            devCol = j
	#respVal = configUtil.getClusterNodeNameFromDeviceCol(devCol, logger)
	#print 'Returned Node Name  = ', respVal

	return 

    def test_replaceTokenName(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        devFile = open('test/aaaTestData_1.yaml', "r")
	devData = yaml.load_all(devFile)
	devCol = {}
	for j in devData:
            devCol = j
	#respVal = configUtil.replaceTokenName('aaa_', 'authenticationvserver_authenticationr', devCol, logger)
	#print 'the changed dict = ', devCol
	return

    def test_getAttachIPCon(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        devFile = open('test/newAttachPayload.yaml', "r")
	devData = yaml.load_all(devFile)
	devCol = {}
	for j in devData:
            devCol = j
#	respVal = configUtil.getIPNConForAttach(devCol, logger)
#	print 'the Attach IP  List = ', devCol
	return

    def test_getSGForCon(self):
	logSerObj = LogService.LogService()
    	logger = logSerObj.getLogger()

        devFile = open('test/raviEpAttachTestData.yaml', "r")
	devData = yaml.load_all(devFile)
	devCol = {}
	for j in devData:
            devCol = j
        con = ((0, '', 4537),(1,'',4159),(3,'LoadBalancing','ADC'),(2,'internal', 'internal')) # ((0, '', 5348), (1, '', 5661), (3, 'SubnetFunc', 'Node'), (2, 'external', 'inside'))
	respVal = configUtil.getSGForAttachIPConnector(con, devCol, logger)
	print 'the Attach IP  List = ', devCol
	return




if __name__ == '__main__':
    unittest.main()
