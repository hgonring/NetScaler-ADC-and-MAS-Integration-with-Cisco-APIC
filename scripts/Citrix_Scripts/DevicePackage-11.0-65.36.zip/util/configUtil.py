#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import sys
import scriptConst as const
import nitroUtil as nitro
import objectOrderNKey as constKey
import NSLogin
import NSServer
import time
import setArgs

from rhi import rhiConfig as rhconf

#
# get the complete object from config
#
def getCompleteObjectFromConfig(objValName, devCfg):
    """
    This is to get the complete object from the config
    """
    #self.logger.debug('+++++++++++++ get complete object from config = %s' % objValName)
    tmpCol = {}
    for k1, v1 in devCfg.iteritems(): # iterating over device level
        for k2, v2 in v1.iteritems(): # iterating over device value dict
            if k2 == const.VALUE: # check for 'value':
                for cfgkey in v2.keys(): # This is for global configuration
                    if cfgkey[2] == objValName:
                        tmpCol[cfgkey] = v2[cfgkey]
    #self.logger.debug('++++++ Complete object from config = %s' % (tmpCol))
    return tmpCol

#
# get the complete object from folder inside the device config i.e. NS IP from Network folder
#
def getCompleteObjectFromSubFolderConfig(subFolderName, objValName, devCfg, logger):
    """
    This is to get the complete object from folder inside the config
    """
    #self.logger.debug('+++++++++++++ get complete object from config = %s' % objValName)
    tmpCol = {}
    for k1, v1 in devCfg.iteritems(): # iterating over device level
        for k2, v2 in v1.iteritems(): # iterating over device value dict
            if k2 == const.VALUE: # check for 'value':
                for k3, v3  in v2.iteritems(): # This is for global configuration
                    if k3[0] == const.FOLDER and k3[1].strip().lower() == subFolderName.strip().lower():
                        for k4, v4 in v3.iteritems():
                            #logger.debug('++++++ Network object from config k4 = %s v4 = %s' % (k4, v4))
                            if k4 == const.VALUE:
                                for k5, v5 in v4.iteritems():
                                    #logger.debug('++++++ Network object from config k5 = %s v5 = %s' % (k5, v5))
                                    if k5[2] == objValName:
                                        tmpCol[k5] = v4[k5]
    return tmpCol
#
# This is to get state specific attribute collection from the object
#
def getModifyStateSpecificAtrColFromConfig(devCfg, logger):
    """
    This is to get state specific attributes from the object
    """
    #logger.debug('++++++++++ getModify State Specific Atr Col for Object ++++++++++')
    objAtrCol = {}
    atrKey = None
    atrVal = None
    objKey = None
    objVal = None
    for a1, b1 in devCfg.iteritems():
        tmpObjCol = {}
        for a2, b2 in b1.iteritems():
            #logger.debug('+++++++ logger attribute col A2 = %s B2 = %s' % (a2, b2))
            tmpCol = {}
            if a2 == const.STATE:
                objState = b2
            if a2 == const.VALUE:
                tmpCol = {} # This is to initialize at device level
                for a3, b3 in b2.iteritems():
                    #logger.debug('+++++++ logger attribute col A3 = %s B3 = %s' % (a3, b3))

                    # check the object's state
                    objState = getRootObjectState(b3)
                    # ignore the object which has CREATE state since that will get handled seperately
                    #if objState == const.MODIFY:
                        # now process the object based on its state
                    objKey = (a1,a3)
                    objName = a3[1]
                    tmpCol = {} # reset this for every object
                    for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems():
                                    if a5[0] == const.PARAM:
                                        atrKey = a5[1]
                                        for a6, b6 in b5.iteritems():
                                            if a6 == const.STATE:
                                                atrState = b6
                                            if a6 == const.VALUE:
                                                atrVal = b6
                                        # get the attribute collection for modify object
                                        if objName == const.SERVICEGROUP:
                                            if atrKey.lower().strip() != const.PORT:
                                                tmpCol[atrState, atrKey] = atrVal
                                            elif (objName == const.SERVICE and atrKey.lower().strip() == const.IP):
                                                tmpCol[atrState, const.IPADDRESS] = atrVal
                                        else:
                                            tmpCol[atrState, atrKey] = atrVal
                                    if a5[0]  == const.MREL and a5[1].find(const.BINDING) == -1:
                                        atrKey = a5[1]
                                        if a4[1] != const.VENCAPREL:
                                            for a8, b8 in b4.iteritems():
                                                if a8 == const.STATE:
                                                    atrState = b8
						# MREL's will have TARGET not VALUE
                                                if a8 == const.VALUE or a8 == const.TARGET:
                                                    atrVal = b8
                                                    # remove absolute path if it is present int he value
                                                    atrVal = atrVal[atrVal.rfind('/')+1:]
                                            if atrState != const.NOCHANGE:
                                                tmpCol[atrState, atrKey] = atrVal
                            if len(tmpCol) >  0 :
                                objAtrCol[objKey] = tmpCol
                                #logger.debug('+++++++ logger attribute col = %s ' % (objAtrCol))

    return objAtrCol

#
# This is to get all attributes which has modify state
#
def getModifyAttributeCollectionForObject(objCol):
    """
    This is to get all the attributes which has modify state
    """
    objAtrCol = {}
    for a1, b1 in objCol.iteritems():
        tmpCol = {}
        for a2, b2 in b1.iteritems():
            tmpState = -1
            tmpVal = None
            t1Val = None
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if a3[0] == const.PARAM:
                        for a4, b4 in b3.iteritems():
                            if a4 == const.STATE:
                                tmpState = b4
                            if a4 == const.VALUE:
                                tmpVal = b4
                        if tmpState != const.NOCHANGE:
                            if a1[1] == const.SERVICEGROUP:
                                if a3[1].lower().strip() != const.PORT:
                                    tmpCol[a3[1]] = tmpVal
                            else:
                                tmpCol[a3[1]] = tmpVal
                    if a3[0] == const.MREL and a3[1].find(const.BINDING) == -1:
                        # skip the vEncaRel
                        if a3[1] != const.VENCAPREL:
                            for a5, b5 in b3.iteritems():
                                if a5 == const.STATE:
                                    tmpState = b5
                                if a5 == const.VALUE or a5 == const.TARGET:
                                    tmpVal = b5
                                    # remove absolute path if it is present in the value
                                    t1Val = tmpVal[tmpVal.rfind('/')+1:]
                            if tmpState == const.MODIFY:
                                tmpCol[a3[1]] = t1Val
        # this is to add object's identifier in the modify collection since NITRO needs the id
        tmpCol[const.NAME] = a1[2]
        objAtrCol[a1[1]] = tmpCol

    return objAtrCol

#
# This is to get all attributes which has modify state
#
def getDeleteAttributeCollectionForObject(objCol):
    """
    This is to get all the attributes which has modify state
    """
    objAtrCol = {}
    for a1, b1 in objCol.iteritems():
        tmpCol = {}
        for a2, b2 in b1.iteritems():
            tmpState = -1
            tmpVal = None
            t1Val = None
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if a3[0] == const.PARAM:
                        for a4, b4 in b3.iteritems():
                            if a4 == const.STATE:
                                tmpState = b4
                            if a4 == const.VALUE:
                                tmpVal = b4
                        if tmpState != const.NOCHANGE:
                            if a1[1] == const.SERVICEGROUP:
                                if a3[1].lower().strip() != const.PORT:
                                    tmpCol[a3[1]] = tmpVal
                            else:
                                tmpCol[a3[1]] = tmpVal
                    if a3[0] == const.MREL and a3[1].find(const.BINDING) == -1:
                        # skip the vEncaRel
                        if a3[1] != const.VENCAPREL:
                            for a5, b5 in b3.iteritems():
                                if a5 == const.STATE:
                                    tmpState = b5
                                if a5 == const.VALUE or a5 == const.TARGET:
                                    tmpVal = b5
                                    # remove absolute path if it is present in the value
                                    t1Val = tmpVal[tmpVal.rfind('/')+1:]
                            if tmpState == const.DELETE:
                                tmpCol[a3[1]] = t1Val
        # this is to add object's identifier in the modify collection since NITRO needs the id
        tmpCol[const.NAME] = a1[2]
        objAtrCol[a1[1]] = tmpCol

    return objAtrCol
#
# this is to get all the attributes from the object collection
#
def getAttributeCollectionForObject(objCol, devCfg, logger):
    """
    This is to get attribute collection from config object
    """
    #logger.debug('++++++++++ Get Attribute object collection for object = %s' % (objCol))
    objAtrCol = {}
    for i1, j1 in objCol.iteritems(): # this is at object level
        for i2, j2 in j1.iteritems(): # this is to get value
            if i2 == const.VALUE:
                tmpCol = {}
                for i3, j3 in j2.iteritems():
                    # look for reference attribute such as action from responder policy
                    if i3[0] == const.MREL and i3[1].find(const.BINDING) == -1:
                        #logger.debug('MREL Key = %s  value = %s' % (i3[1], i3[2]))
                        # skip the vEncapRel from the collection
                        if i3[1] != const.VENCAPREL:
                            for m1, n1 in j3.iteritems():
                                if m1 == const.VALUE or m1 == const.TARGET:
                                    tmpVal = n1
                                    # check if the target is MREL with '/' i.e. policy/responderpolicy
                                    if tmpVal.find('/') != -1:
                                        prntObj = tmpVal[:tmpVal.find('/')]
                                        chldObj = tmpVal[tmpVal.find('/')+1:]
                                        #logger.debug('++++++++ MREL Object Value parent = %s, child = %s' % (prntObj, chldObj))
                                        atrVal =  getAttrValFromParentNChildObjectFromConfig(prntObj, chldObj, devCfg, logger)
                                        tmpCol[i3[1]] = atrVal
                                    else:
                                        #logger.debug('++++++++ MREL Object Value = %s' % (tmpVal))
                                        atrVal = getKeyAttrValForObjectFromConfig(tmpVal, devCfg, logger)
                                        tmpCol[i3[1]] = atrVal
                                    #keyParam = getKeyForMREL(t1Val, devCfg, logger)
                                    #logger.debug('Key param = %s' % (keyParam))
	                            # now get reference object's name value from the config
			            #t1Val = getKeyAttrValForObjectFromConfig(t1Val, devCfg, logger)
                                    #tmpCol[i3[1]] = t1Val
                    if i3[0] == const.PARAM: # create attributes for all Params
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                # this is to avoid the port getting in service group object
                                if i1[1] == const.SERVICEGROUP:
                                    if i3[1].lower().strip() != const.PORT:
                                        tmpCol[i3[1]] = j4
                                    #else:
                                    #    tmpCol[i3[1]] = j4
                                else:
                                    tmpCol[i3[1]] = j4
                objAtrCol[i1[1]] = tmpCol

        # remove the '_cfg' from the key
	#keyStr = i1[1]
        #if keyStr.find('_cfg'):
        #    keyStr = keyStr[:keyStr.find('_cfg')]
        #objAtrCol[keyStr] = tmpCol # this is get the object name and its collection i.e. lbvserver : { }
    logger.debug('++++++++++ Object attribute collection = %s' % (objAtrCol))
    return objAtrCol
#
# this is to get set attribute col where attribute's state is modify
#
def getSetAttrCol(objCol, setState, devCfg, logger, allAtrFlag=False):
    """
    This is to get Modify attribute collection from config object
        - Modify collection of two types
            - Set - where the state is modify
            - Unset - where the state is delete
    """
    logger.debug('++++++++++ Get Modify Attribute object collection for object = %s, State = %s' % (objCol, setState))
    objAtrCol = {}
    for i1, j1 in objCol.iteritems(): # this is at object level
        tObjCol = {}
        tStateVal = None
        for i2, j2 in j1.iteritems(): # this is to get value
            if i2 == const.VALUE:
                tObjCol = j2
            elif i2 == const.STATE:
                tStateVal = j2
        tmpCol = {}
        for i3, j3 in tObjCol.iteritems():

            # look for reference attribute such as action from responder policy
            if i3[0] == const.MREL and i3[1].find(const.BINDING) == -1:
                        #logger.debug('MREL Key = %s  value = %s' % (i3[1], i3[2]))
                        # skip the vEncapRel from the collection
                if i3[1] != const.VENCAPREL:
                    rVal = {}
                    rStat = None
                    for m1, n1 in j3.iteritems():
                        if m1 == const.VALUE or m1 == const.TARGET:
                            rVal = n1
                        elif m1 == const.STATE:
                            rStat = n1

                    if rStat != const.NOCHANGE:
                        tmpVal = rVal
                    # check if the target is MREL with '/' i.e. policy/responderpolicy
                    if tmpVal.find('/') != -1:
                        prntObj = tmpVal[:tmpVal.find('/')]
                        chldObj = tmpVal[tmpVal.find('/')+1:]
                        #logger.debug('++++++++ getSetAttrCol MREL Object Value parent = %s, child = %s' % (prntObj, chldObj))
                        atrVal =  getAttrValFromParentNChildObjectFromConfig(prntObj, chldObj, devCfg, logger)
                        tmpCol[i3[1]] = atrVal
                    else:
                        #logger.debug('++++++++ getSetAttrCol MREL Object Value = %s' % (tmpVal))
                        atrVal = getKeyAttrValForObjectFromConfig(tmpVal, devCfg, logger)
                        tmpCol[i3[1]] = atrVal

            if i3[0] == const.PARAM: # create attributes for all Params
                pStat = None
                pVal = {}
                for i4, j4 in j3.iteritems():
                    if i4 == const.VALUE:
                        pVal = j4
                    elif i4 == const.STATE:
                            pStat = j4
                # this is avoid serviceType attribute getting modified by user
                #if i1[1] == const.LBVSERVER or i1[1] == const.SERVICE:
                #    if pStat != const.NOCHANGE and (i3[1].lower().strip() == const.PORT or i3[1].lower().strip() == const.SERVICETYPE):
                         # raise exception
                #        raise Exception("ServiceType or Port can not be modified")
                # this is to avoid the port getting in service group object
                if i1[1] == const.SERVICEGROUP: #we never get into this condition
                    if i3[1].lower().strip() != const.PORT and pStat == setState:
                        tmpCol[i3[1]] = pVal
                elif setState == const.MODIFY and allAtrFlag: # this is to get all the attribute from the collection
                     if (i1[1][1] == const.SERVICE and i3[1].lower().strip() == const.IP):
                        tmpCol[const.IPADDRESS] = pVal
                     elif i1[1][1] == const.SERVICEGROUP:
                        if i3[1].lower().strip() != const.PORT:
                            tmpCol[i3[1]] = pVal
                        #if port state is modify or create, add it into the column, otherwise, don't add port
                        elif (pStat == const.MODIFY or pStat == const.CREATE):
                            tmpCol[i3[1]] = pVal
                     else:
                        tmpCol[i3[1]] = pVal
                elif setState == const.MODIFY and pStat == const.MODIFY:
                    if (i1[1][1] == const.SERVICE and i3[1].lower().strip() == const.IP):
                        tmpCol[const.IPADDRESS] = pVal
                    else:
                        tmpCol[i3[1]] = pVal
                #relax the check here, if setState is MODIFY, parameter state could be CREAT in some cases
                elif setState == const.MODIFY and pStat == const.CREATE:
                    if (i1[1][1] == const.SERVICE and i3[1].lower().strip() == const.IP):
                        tmpCol[const.IPADDRESS] = pVal
                    else:
                        tmpCol[i3[1]] = pVal
                elif pStat == const.DELETE and setState == const.DELETE:
                        tmpCol[i3[1]] = True
        if len(tmpCol) > 0:
            objAtrCol = tmpCol
            #logger.debug('++++++++++ Tmp collection Object attribute collection = %s' % (objAtrCol))

    logger.debug('++++++++++ Set Object attribute collection = %s' % (objAtrCol))
    return objAtrCol
#
# Create generic object using NITRO APIs
#

def createConfigObjects(objKey, attrCol, url, devIp, sesId, logger):
        #self.logger.debug('+++++++++++++ Create Config objects ------- objectName = %s, attribute details = %s' %(objKey, attrCol))
        resCode = {}
        try:
            nsGenSerObj = genericNitro.NitroMapper(logger)
            resCode[objKey] = nsGenSerObj.addNitroObject(objKey, attrCol, url, devIp, sesId)
            #respDat = respDat.json()
            #resCode = respDat[self.ERRORCODE]
        except Exception, err:
            logger.error(traceback.format_exc())

        return resCode
#
# get the state of the object here params are at second level
#
def getStateForObject(objCol):
    objStat = -1
    for i1, j1 in objCol.iteritems():
        for i2, j2 in j1.iteritems():
            if i2 == const.STATE:
                return j2
        # if we reach here that means the object state couldn't be find
    return objStat
#
# get config objects
#
def getErrorCodeFromRespCol(objCol, logger):
    """
    This is to get error code from the response collection
    """
    for a1, b1 in objCol.iteritems():
        for a2, b2 in b1.iteritems():
            for a3, b3 in b2.iteritems():
                #logger.debug('Error code = %s, values = %s' % (a3, b3))
                if a3 == const.ERRORCODE:
                    return b3

    #if code reaches here it means not found
    return None

#
# get the object's state here the params are at root level
#
def getRootObjectState(objCol):
    objState = -1
    for i1, j1 in objCol.iteritems():
        if i1 == const.STATE:
            return j1

    # code should not reach here otherwise there is no state
    return objState

#
# get bind objects
#
def getBindObjectsForObject(objCol):
    """
    This is just to get the bindings for an object
    """
    #self.logger.debug('++++++++++++ get all bindings for this object = %s'% (objCol))
    bindObjCol = {}
    tmpState = 0 # state of NO change
    tmpVal = None
    for a1, b1 in objCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if a3[0] == const.FOLDER and a3[1].find(const.BINDING) != -1:
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems():
                                    #self.logger.debug('+++++++++++ A5 = %s,B5 = %s ' % (a5,b5))
                                    if a5[0] == const.MREL:
                                        for a6, b6 in b5.iteritems():
                                            if a6.lower().strip() == const.STATE:
                                                tmpState = b6
                                            if a6 == const.VALUE or a6 == const.TARGET:
                                                tmpVal = b6
                                        #self.logger.debug('++++++++ STATE = %s VALUES = %s ' % (tmpState, tmpal))
                                        # check for create state
                                        #if tmpState == const.CREATE:
                                        bindObjCol[(tmpState, a3[2], a5[1], a5[2])] = tmpVal
    #self.logger.debug('++++++++++++ returning  Object Bindings collections = %s' % (bindObjCol))
    return bindObjCol

#
# get all MRELs for an object
#
def getMRELsForObject (objCol):
    """
    This is to get all the MRELs for an object
    """

    #self.logger.debug('++++++ get all MRELs for an object = %s' % (objCol))
    mrelCol = {}

    for a1, b1 in objCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if a3[0] == const.MREL:
                        mrelCol[a3] = b3
                    # now look for the folder which is not Binding folder
                    elif a3[0] == const.FOLDER and a3[1].find(const.BINDING) == -1:
                        for a4, b4 in b3.iteritems():
                            #self.logger.debug('++++++++ A4 = %s, B4 = %s'% (str(a4),b4))
                            if a4 == const.VALUE or a4 == const.TARGET:
                                for a5, b5 in b4.iteritems():
                                    #self.logger.debug('++++++++ A5 = %s, B5 = %s' % (a5,b5))
                             # ignore the vEncapRel since this gets handled at EpAttach and this is not ref object
                                    if a5[0] == const.MREL and a5[1] != const.VENCAPREL:
                                        mrelCol[a5] = b5
    #self.logger.debug('++++++++ returning MREL Collection for an Object = %s' % (mrelCol))

    return mrelCol

#
# get object's identifier and its value
#
def getObjectIdentifierNValue(objCol):
    """
    This is to get the object's identifier and its value
    """
    objName = None
    objKey = None
    objVal = None
    retCol = {}
    for a1, b1 in objCol.iteritems():
        objName = a1[1]
        objVal = a1[2]
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if a3 == const.NAME:
                        retCol[objKey] = {a3 : objVal}
                        return retCol

    # if the code comes here that means there is no identifier
    return retCol

#
# Check for binding folder i.e. root folder has bind folder inside it
#
def checkBindFolderInsideFolder(fldObjCol):
    """
    This is to check if there is bind folder inside this collection
    """
    for m1, n1 in fldObjCol.iteritems():
        if m1 == const.VALUE:
            for m2, n2 in n1.iteritems():
                if m2[0] == const.FOLDER and m2[1].find(const.BINDING) != -1:
                    return True
    # if code comes here then it should be False
    return False
#
#
# Check for nesting folder i.e. folder inside folder
#
def checkFolderInsideFolder(fldObjCol):
    """
    This is to check if there is any folder inside this collection
    """
    if type(fldObjCol) is not dict:
        return False
    for m1, n1 in fldObjCol.iteritems():
        if m1 == const.VALUE:
            if type(n1) is not dict:
                continue
            for m2, n2 in n1.iteritems():
                if m2[0] == const.FOLDER and m2[1].find(const.BINDING) == -1:
                    return True
    # if code comes here then it should be False
    return False
#
# This is to get specific state's Objects.
#
def getStateSpecificObjectsFromConfig(objState, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get object list for a specific object state
    """
    logger.debug('+++++++++ State specific objects from config +++++++++')
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.FOLDER:
                        # this is to skip GLOBAL folder since it is only for binding purpose
                        if a3[1].strip().lower() == const.GLOBAL:
                            continue # skip this folder
                        # this is to skip PARTITION folder since we have handled it in creating a partition
                        if a3[1].strip().lower() == const.PARTITION:
                            continue # skip this folder
                        #if ((objState == getRootObjectState(b3)) or deviceAuditFlag):
                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a3, b3))
                            # make sure this is not a folder with set of folders inside it
                        if checkFolderInsideFolder(b3):
                            for a4, b4 in b3.iteritems():
                                if a4 == const.VALUE:
                                    for a5, b5 in b4.iteritems():
                                            #since there won't be more than two levels folder in folder scenario
                                        if a5[0] == const.FOLDER and a5[1].find(const.BINDING) == -1:
                                            if ((objState == getRootObjectState(b5)) or (deviceAuditFlag)):
                                                #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a5, b5))
                                                tmpTuple = (a1, a3)
                                                objCol[(tmpTuple,a5)] = b5
                        elif ((objState == getRootObjectState(b3)) or deviceAuditFlag):
                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a3, b3))
                            objCol[(a1,a3)] = b3

    return objCol

#
# This is to get specific state's Bind Objects.
#
def getStateSpecificBindObjectsFromConfig(objState, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get bind object list for a specific state
    """
    logger.debug('+++++++++ State specific Bind objects from config +++++++++')
    bindAtrCol = {}
    tmpCol = {}
    instVal = None
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.FOLDER:
                        # get the folder name for this object
			keyName = a3[1]
			keyAtrVal = getObjectKey(a3[1], logger)
                        # check if the keyAtrVal is None if it is None that means it is a folder defined in device model
                        if keyAtrVal is None:
                            # get the object from this folder
                            #logger.debug ('None object col = %s' % (b3))
                            for a4, b4 in b3.iteritems():
                                if a4 == const.VALUE:
                                    for a5, b5 in b4.iteritems():
                                    # get bind collection from b4
	                                tmpTuple = (a1, a3, a5)
                                        tmpCol = getBindCol(tmpTuple, objState, a5, b5, devCfg, logger, deviceAuditFlag)
                                        bindAtrCol = dict(tmpCol.items() + bindAtrCol.items())
                        else:
                            # pass b2 since getBindCol will need key attribute and instVal
                            #logger.debug('Non none key object col = %s ' % (b2))
	                    tmpTuple = (a1, a3)
                            tmpCol = getBindCol(tmpTuple, objState, a3, b3, devCfg, logger, deviceAuditFlag)
                            bindAtrCol = dict(tmpCol.items() + bindAtrCol.items())

    return bindAtrCol

#
# This is to get bind collection from the passed collection
#
def getBindCol(tmpKeyTuple, objState, bndObjKey, objBndCol, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get bind collection from the object's collection, this method works in conjunction with getStateSpecificBindObjectsFromConfig
    """
    logger.debug('Get Bind Col key = %s, col = %s' % (bndObjKey, objBndCol))
    objCol = {}
    instVal = None
    globalBindFlag = False
    instVal = None
    #for i1, j1 in objBndCol.iteritems():
    #    if i1 == const.VALUE:
    #        for i2, j2 in j1.iteritems():
    objName = bndObjKey[1]
    keyAtrVal = getObjectKey(objName, logger)
    if (keyAtrVal):
        globalBindFlag = False
    else:
        globalBindFlag = True

    #logger.debug('Object name = %s key attribute = %s' % (objName, keyAtrVal))
    #logger.debug('Bind object details atr = %s, key val = %s' % (i2[1], keyAtrVal))
    #if a3[1] == const.SSLVSERVER:
                        #    instVal = getParamAttributeValueFromCollection(const.VSERVERNAME, b3, logger)
                        #else:
	                # passing key attribute's first element
    # get the instance value if the binding is NOT global
    if globalBindFlag is False:
        instVal = getParamAttributeValueFromCollection(keyAtrVal[0], objBndCol, logger)



    #instVal = a3[2]
    # check object's state should be NOCHANGE
    tmpState = getRootObjectState(objBndCol)
    if ((tmpState != const.NOCHANGE) or deviceAuditFlag):
        #logger.debug('++++++++ New Object List Key = %s, Value = %s' % (a3, b3))
        # make sure this folder has bind folder inside it
        if checkBindFolderInsideFolder(objBndCol):
            for a4, b4 in objBndCol.iteritems():
                #logger.debug('++++++++ NEW Bind folder Object List Key = %s, Value = %s' % (a4, b4))
                if a4 == const.VALUE:
                    for a5, b5 in b4.iteritems():
                        #since there won't be more than two levels folder in folder scenario
                        if a5[0] == const.FOLDER and a5[1].find(const.BINDING) != -1:
                            tmpCol = {}
                            #logger.debug('++++++++  New BIND Object List Key = %s, Value = %s' % (a5, b5))
                            if ((objState == getRootObjectState(b5)) or deviceAuditFlag):
                                #logger.debug('++++++++ BIND Object List Key = %s, Value = %s' % (a5, b5))
                                # get all the binding attributes in the tmp collection
                                for a6, b6 in b5.iteritems():
                                    if a6 == const.VALUE:
                                        for a7, b7 in b6.iteritems():
                                            for a8, b8 in b7.iteritems():
                                                #logger.debug('+++++ A8 = %s B8 = %s' % (a8,b8))
                                                if a8 == const.VALUE or a8 == const.TARGET:
                                                    if a7[0] == const.MREL:
                                                        if a7[1] == const.CERTKEYNAME:
                                                            atrVal = getKeyAttrValForObjectFromConfig(b8, devCfg, logger)
                                                            tmpCol[a7[1]] = atrVal
                                                        else:
                                                                                # check if the target is MREL with '/' i.e. policy/responderpolicy
                                                            if b8.find('/') != -1:
                                                                prntObj = b8[:b8.find('/')]
                                                                chldObj = b8[b8.find('/')+1:]
                                                                #logger.debug('++++++++ MREL Object Value parent = %s, child = %s' % (prntObj, chldObj))
                                                                atrVal =  getAttrValFromParentNChildObjectFromConfig(prntObj, chldObj, devCfg, logger)
                                                                tmpCol[a7[1]] = atrVal
                                                            else:
                                                                #logger.debug('++++++++ MREL Object Value = %s' % (b8))
                                                                atrVal = getKeyAttrValForObjectFromConfig(b8, devCfg, logger)
                                                                tmpCol[a7[1]] = atrVal
                                                    else:
                                                        tmpCol[a7[1]] = b8
                                                        #logger.debug('++++++++++ TEMP collection afer MREL n getKeyAttrVal  = %s'% (tmpCol))
                                            # if the binding doesn't starts with VLAN or SSL cert bind then add name
                                if not ((a5[1].startswith(const.VLAN_BIND)) or (a5[1].startswith(const.SSL_CERT_BIND)) or (a5[1].strip().lower() == const.SSLSERVICEGROUP)):
                                    if (instVal): # since global binding will be None
                                        tmpCol[keyAtrVal[0]] = instVal
                                elif (a5[1].startswith(const.SSL_CERT_BIND)):
                                    if (instVal): # since global binding will be None
                                        tmpCol[const.VSERVERNAME] = instVal
                                    #logger.debug('++++++++++ TEMP Bind collection = %s' % (tmpCol))
                                    # add the key and value or instance name for the uniqueness
                                objCol[(tmpKeyTuple, a5[1], a5[2], objName)] = tmpCol
    logger.debug('++++++++++ get Bind collection = %s'% (objCol))

    return objCol
#
# This is to load object from the file for the config order creation
#
def loadObjectListFromFile(flName):
    """
    This is to load the object list from file to a list
    """
    objectList = []
    flData = open(flName, 'r')
    for i in flData:
        objectList.append(i.strip().lower())

    return objectList

#
# get the connector's service groups from the function definition
#
def getObjectForConnector(conName, objType, cnfg, logger):
    logger.debug('+++++++++ getting the service group for a connector = %s' % (conName))
    fgCol = {}
    sgCol = {}
    lbList = []
    sgAtrCol = {}
    sgPortCol = {}
    for k1, v1 in cnfg.iteritems(): # iterating over device level
        #print "K1 = ", k1, v1
        for k2, v2 in v1.iteritems(): # iterating over device value dict
            #print "K2 = ", k2, v2
            #check for any device level configuration i.e. nsip
            if k2 == const.VALUE: # check for 'value':
                for k3, v3 in v2.iteritems(): # This is for global configuration
                    # check the function group
                    if k3[0] == const.FUNCTIONGROUP:
                        # check if the connector is part of this function group
                        for k4, v4 in v3.iteritems():
                            #logger.debug('++++ k4 = %s, V4 = %s' %(k4, v4))
                            if k4 == const.VALUE:
                                for k5, v5 in v4.iteritems():
                                    for k6, v6 in v5.iteritems():
                                        # we should be at function level
                                        #logger.debug('---- K6 = %s, V6 = %s '% (k6,v6))
                                        if k6 == const.VALUE:
                                            for k7,v7 in v6.iteritems():
                                                #logger.debug('K7 Keys =========== %s, Value = %s ' % (k7, v7))
                                                # check if the key is of type connector and the value is the same as param
                                                if k7[1] == objType:
                                                    #logger.debug(' Service = %s Connector = %s' % (k7,v7))
                                                    conFound = False
                                                    tmpCol = {}
                                                    for k8, v8 in v7.iteritems():
                                                        if k8 == const.CONNECTOR and v8 == conName:
                                                            conFound = True
                                                        if k8 == const.VALUE:
                                                            tmpCol = v8
                                                    if (conFound):
                                                        for k10, v10 in tmpCol.iteritems():
                                                            for k11, v11 in v10.iteritems():
                                                                if k11 == const.TARGET or k11 == const.VALUE:
                                                                    sgCol[k10] = v11
                                                                    #logger.debug('Adding target to SG List = %s' % (sgCol))

    return sgCol
#
# get the connector's service groups from the function definition
#
def getSGPortCollectionForConnector(conName, cnfg, logger):
    logger.debug('+++++++++ getting the service group for a connector = %s' % (conName))
    fgCol = {}
    lbList = []
    sgAtrCol = {}
    sgPortCol = {}
    for k1, v1 in cnfg.iteritems(): # iterating over device level
        #print "K1 = ", k1, v1
        for k2, v2 in v1.iteritems(): # iterating over device value dict
            #print "K2 = ", k2, v2
            #check for any device level configuration i.e. nsip
            if k2 == const.VALUE: # check for 'value':
                for k3, v3 in v2.iteritems(): # This is for global configuration
                    # check the function group
                    if k3[0] == const.FUNCTIONGROUP:
                        # check if the connector is part of this function group
                        for k4, v4 in v3.iteritems():
                            #logger.debug('++++ k4 = %s, V4 = %s' %(k4, v4))
                            if k4 == const.VALUE:
                                for k5, v5 in v4.iteritems():
                                    for k6, v6 in v5.iteritems():
                                        # we should be at function level
                                        #logger.debug('---- K6 = %s, V6 = %s '% (k6,v6))
                                        if k6 == const.VALUE:
                                            for k7 in v6.keys():
                                                #logger.debug('K7 Keys =========== %s ' % (str(k7)))
                                                # check if the key is of type connector and the value is the same as param
                                                if k7[0] == const.CONNECTION and k7[2] == conName:
                                                    fgCol[k5] = v6
    #logger.debug('+++++++++++ function level collection = %s' %(fgCol))
    # get the lbvserver
    for i1, j1 in fgCol.iteritems():
        for i2, j2 in j1.iteritems():
            #logger.debug('i2 ==== %s, j2 ====== %s' % (i2, j2))
            if i2[1] == const.LBVSERVER:
                for i3, j3 in j2.iteritems():
                    if i3 == const.VALUE:
                        for i4, j4 in j3.iteritems():
                            for i5, j5 in j4.iteritems():
                                #logger.debug('++++++++ i5 = %s, j5 = %s' % (i5,j5))
                                if i5 == const.TARGET or i5 == const.VALUE:
                                    lbList.append(j5)
    #logger.debug('+++++++++ lbvserver list = %s' % (lbList))
    sgPortCol = getSGForLbVservers(lbList, cnfg, logger)

    logger.debug('+++++++++ service group port collection = %s' % (sgPortCol))

    return sgPortCol

#
# Get lbvserver for service or service group
#
def getLBVServerBasedOnObject(bindingType, objName, cnfg, logger):
    """
    This is to get list of lbvservers based on serivce or service group
    """
    respCol = {}
    for k1, v1 in cnfg.iteritems(): # iterating over device level
        #print "K1 = ", k1, v1
        for k2, v2 in v1.iteritems(): # iterating over device value dict
            #print "K2 = ", k2, v2
            #check for any device level configuration i.e. nsip
            if k2 == const.VALUE: # check for 'value':
                for k3, v3 in v2.iteritems(): # This is for global configuration
                    # check for lbvserver folder and its service or servicegroup
                    lbName = None
                    tmpCol = {}
                    if k3[0] == const.FOLDER and k3[1] == const.LBVSERVER:
                        #logger.debug('Key = %s , Value = %s' % (k3, v3))
                        for k4, v4 in v3.iteritems():
                            if k4 == const.VALUE:
                                for k5, v5 in v4.iteritems():
                                    if k5[0] == const.PARAM and k5[1] == const.NAME:
                                        for j1, h1 in v5.iteritems():
                                            if j1 == const.VALUE:
                                                lbName = h1
                                        #logger.debug('LBVServer instance name = %s' % (lbName))
                                    if k5[0] == const.FOLDER and k5[1] == bindingType: # e.g. lbvserver_service_binding
                                        tmpCol = v5
                                # check if the service binding matches
                                for k6, v6 in tmpCol.iteritems():
                                    if k6 == const.VALUE:
                                        for k7, v7 in v6.iteritems():
                                            for k8, v8 in v7.iteritems():
                                                #logger.debug('K7 = %s V7 = %s' % (k7,v7))
                                                if k8 == const.VALUE and v8 == objName:
                                                    respCol[lbName] = v8
                                                    #logger.debug('Service binding details key = %s and value = %s' % (lbName, v8))



    return respCol



#
# Get the service group from LBVServers for a connector
#
def getSGForLbVservers(lbList, cfg, logger):
    #logger.debug('+++++++++++++ get ServiceGroups from LB Vservers = %s' % (lbList))
    lbCol = {}
    tmpLBCol = {}
    sgList = []
    sgCol = {}
    sgPortCol = {}
    for lbObj in lbList:
        lbCol[lbObj] = getCompleteObjectFromConfig(lbObj, cfg)

    #logger.debug('+++++++ Lb collection for CSVServers from config = %s' % (lbCol))

    # get the service groups from the temp LB collection
    for k1, l1 in lbCol.iteritems():
       for k2, l2 in l1.iteritems():
            for k3, l3 in l2.iteritems():
                if k3 == const.VALUE:
                    for k4, l4 in l3.iteritems():
                        #logger.debug('K4 ===== %s, L4 ====== %s' % (k4, l4))
                        if k4[0] == const.FOLDER and k4[1].find(const.SERVICEGROUP) != -1: # this should be service group from binding
                            for k5, l5 in l4.iteritems():
                                #logger.debug('K5 ===== %s, L5 ====== %s' % (k5,l5))
                                if k5 == const.VALUE:
                                    for k6, l6 in l5.iteritems():
                                        #logger.debug('K6 ===== %s, L6 ====== %s' % (k6,l6))
                                        if k6[1] == const.SERVICEGROUPNAME:
                                            for k7, l7 in l6.iteritems():
                                                #logger.debug('K7 ===== %s, L7 ====== %s' % (k7,l7))
                                                if k7 == const.VALUE or k7 == const.TARGET:
                                                    sgList.append(l7)

    #logger.debug('+++++++++ Service Group List from LBVServer for Connector = %s' % (sgList))
    # now get the service group object from config
    for sgObj in sgList:
        sgCol[sgObj] = getCompleteObjectFromConfig(sgObj, cfg)
    # create service group and port collection
    for o1, p1 in sgCol.iteritems():
        for o2, p2 in p1.iteritems():
            for o3, p3 in p2.iteritems():
                if o3 == const.VALUE:
                    # get the attributes from object params
                    for o4, p4 in p3.iteritems():
                        if o4[1] == const.PORT:
                            for o5, p5 in p4.iteritems():
                                if o5 == const.VALUE:
                                    sgPortCol[o1] = p5

    logger.debug('+++++++++++ Service group port collection = %s' % (sgPortCol))
    return sgPortCol

#
# get key and port collection
#
def getServiceGroupKeyPortCollection(sgObj, cnfg, logger):
    """
    This is to get the service group's key and port collection
    """
    sgCol = {}
    atrVal = None
    sgPortCol = {}
    sgCol[sgObj] = getCompleteObjectFromConfig(sgObj, cnfg)
    # get the key attribute for this object
    atrVal = getKeyAttrValForObjectFromConfig(sgObj, cnfg, logger)
    #logger.debug('++++++++++ Object attribute value  = %s' % (atrVal))
    # create service group and port collection
    for o1, p1 in sgCol.iteritems():
        for o2, p2 in p1.iteritems():
            for o3, p3 in p2.iteritems():
                if o3 == const.VALUE:
                    # get the attributes from object params
                    for o4, p4 in p3.iteritems():
                        if o4[1] == const.PORT:
                            for o5, p5 in p4.iteritems():
                                if o5 == const.VALUE:
                                    sgPortCol[atrVal] = p5

    logger.debug('+++++++++++ Service group port collection = %s' % (sgPortCol))
    return sgPortCol


#
# This is to handle VLAN/VXLAN and VIF network specific objects
#
def getStateSpecificNetworkObjects(objState, devCfg, logger):
    """
    This is to get VLAN/VXLAN and VIF network objects from the config
    """
    logger.debug('++++++++++ get state specific network VLAN/VXLAN object from the config +++++++')
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.IFCTAG or a3[0] == const.VIF:
                        if objState == getRootObjectState(b3):
                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a3, b3))
                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a3, b3))
                            objCol[a3] = b3

    return objCol

#
# get VIF value e.g. 1/1 or 1/2 based on Node name
#
def getStateSpecificNodeVIFsFromConfig(objState, nodeName, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get VIFs value based on node name
    """
    logger.debug('+++++++++ get Node Specific Tag from Config ++++++++++')
    vifObjCol = {}
    encapCol = {}
    vifObjName = None
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get the VIF or ifnum from the config for the particular node
                    if a3[0] == const.VIF:
                        #logger.debug('State details objState = %s, deviceAuditFlag = %s' % (getRootObjectState(b3), deviceAuditFlag))
                        #if ((objState == getRootObjectState(b3)) or deviceAuditFlag):
                        if ((const.NOCHANGE != getRootObjectState(b3)) or deviceAuditFlag):
                            for a4, b4 in b3.iteritems():
                                if a4.strip().lower() == const.CIFS:
                                    for a5, b5 in b4.iteritems():
                                        if a5 == nodeName:
                                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a5, b5))
                                            #logger.debug('++++++++ A1 Key = %s, A3 Key = %s, A4 Key=%s' % (a1, a3, a4))
                                            #vifObjCol[a5] = b5
                                            vifObjName = a3[2]
					    tmpTuple = ()
				            tmpTuple = (a1, a3)
                                            vifObjCol[(tmpTuple,vifObjName)] = b4
    return vifObjCol
#
# get VIF value e.g. 1/1 or 1/2 based on Node name
#
def getNodeVIFsFromConfig(nodeName, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get VIFs value based on node name
    """
    logger.debug('+++++++++ get Node Specific Tag from Config ++++++++++')
    vifObjCol = {}
    encapCol = {}
    vifObjName = None
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get the VIF or ifnum from the config for the particular node
                    if a3[0] == const.VIF:
                        for a4, b4 in b3.iteritems():
                            if a4.strip().lower() == const.CIFS:
                                for a5, b5 in b4.iteritems():
                                    if a5 == nodeName:
                                        #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a5, b5))
                                        #vifObjCol[a5] = b5
                                        vifObjName = a3[2]
                                        tmpTuple = (a1, a3, a5)
                                        vifObjCol[(tmpTuple,vifObjName)] = b4
    return vifObjCol
#
# get the encapass relation object based on VIF object name
#
def getStateSpecificVIFEncapassFromConfig(objState, vifObjName, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get encap based on VIF's object name
    """
    logger.debug('++++++++++ get encap based on VIF object name ++++++')
    encapCol = {}
    #get the encapassociation for the vifObjName
    if (vifObjName):
         for c1, d1 in devCfg.iteritems():
             for c2, d2 in d1.iteritems():
                 if c2 == const.VALUE:
                     for c3, d3 in d2.iteritems():
                         if c3[0] == const.VENCAPASS:
                             #if ((objState == getRootObjectState(d3)) or deviceAuditFlag):
                             if ((const.NOCHANGE != getRootObjectState(d3)) or deviceAuditFlag):
                                 for c4, d4 in d3.iteritems():
                                     if c4.strip().lower() == const.VIF_NAME and d4 == vifObjName:
                                         #logger.debug('++++++++ VEnCapass List Key = %s, Value = %s' % (c3, d3))
                                         encapCol[c3] = d3


    return encapCol

#
# get tags based on encap object name
#
def getStateSpecificEncapTagFromConfig(objState, encapObjName, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get tags based on encap object name
    """
    logger.debug('+++++++++ get state specific encap tag from config +++++++++++ encapObjName = %s' % (encapObjName))
    tagCol = {}
    if (encapObjName):
         for a1, b1 in devCfg.iteritems():
             for a2, b2 in b1.iteritems():
                 if a2 == const.VALUE:
                     for a3, b3 in b2.iteritems():
		         #logger.debug('++++++ Encap Tag A3 = %s B3 = %s' % (a3,b3))
                         if a3[0] == const.IFCTAG and a3[2] == encapObjName:
                             encapStat = -1
                             tagVal = -1
                             tagType = -1
                             for a4, b4 in b3.iteritems():
                                 if a4 == const.STATE:
                                     encapStat = b4
                                 elif a4 == const.TAG:
                                     tagVal = b4
                                 elif a4 == const.TYPE:
                                     tagType = b4
                             #logger.debug('+++++++ Values from the collection State = %s, tag = %s, tagType = %s' % (encapStat, tagVal, tagType))
                             if ((encapStat == objState) or deviceAuditFlag):
		                 tmpTuple = (a1, a3)
                                 tagCol[(tmpTuple, encapObjName, tagType)] = tagVal
                             #logger.debug('+++++++++++ Tag object collection value = %s' % (tagCol))

    return tagCol

#
# This is to handle the VENCAPASS since this is binding between VLAN/VXLAN and interface
#
def getStateSpecificVEncapassObjects(objState, devCfg, logger):
    """
    This is to get encap association objects from the config
    """
    logger.debug('++++++++++ get State speific Encapass object from the config +++++++')
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.VENCAPASS:
                        if objState == getRootObjectState(b3):
                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a3, b3))
                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a3, b3))
                            objCol[a3] = b3

    return objCol
#
# This is to get interface by node
#
def getInterfaceByNode(infCol, logger):
    """
    This is to get interface for given node from config
    """
    logger.debug('++++++++++ get all interfaces name from the payload +++++++')
    retList = []
    for a1, b1 in infCol.iteritems():
        # interfaces are in this format {(11, '', '10_1'): {'state': 0, 'label': ''}
        if (a1[2]) : # this is to make sure interface name in not null
            retList.append(a1[2])

    #logger.debug('++++++++ Interface List  = %s' % (retList))
    # return only unique interfaces
    tmpSet = set(retList)
    retList = list(tmpSet)
    logger.debug('++++ Interface list = %s' % (retList))

    return retList

#
# This is to get  the VENCAPASS
#
def getVEncapassObjects(devCfg, logger):
    """
    This is to get encap association objects from the config
    """
    #logger.debug('++++++++++ get State speific Encapass object from the config +++++++')
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.VENCAPASS:
                        objCol[a3] = b3

    return objCol


#
# This is to get state specific VLAN IDs from config
#
def getStateSpecificVLANFromConfig(objState, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get VLAN IDs/tags from config
    """
    logger.debug('+++++ getStateSpecific VLANs from Config ++++++')
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # check the folder type 7 for VLAN/tags
                    if a3[0] == const.IFCTAG:
                        tmpTag = None
                        tmpState = None
                        tmpType = None
                        for a4, b4 in b3.iteritems():
                            if a4 == const.STATE:
                                tmpState = b4
                            elif a4.strip().lower() == const.TAG:
                                tmpTag = b4
                            elif a4.strip().lower() == const.TYPE:
                                tmpType = b4
                        if tmpType == 1: # this is the VLAN type ID
                            if ((objState == tmpState) or deviceAuditFlag):
                                objCol[a3] = tmpTag
    return objCol

#
# This is to get add/mod state VLAN IDs from config
#
def getAddModStateVLANFromConfig(devCfg, logger, deviceAuditFlag=False):
    """
    This is to get VLAN IDs/tags from config
    """
    logger.debug('+++++ getStateSpecific VLANs from Config ++++++')
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # check the folder type 7 for VLAN/tags
                    if a3[0] == const.IFCTAG:
                        tmpTag = None
                        tmpState = None
                        tmpType = None
                        for a4, b4 in b3.iteritems():
                            if a4 == const.STATE:
                                tmpState = b4
                            elif a4.strip().lower() == const.TAG:
                                tmpTag = b4
                            elif a4.strip().lower() == const.TYPE:
                                tmpType = b4
                        if tmpType == 1: # this is the VLAN type ID
                            if ((tmpState == const.CREATE) or (tmpState == const.MODIFY)):
                                objCol[a3] = tmpTag
    return objCol

#
# This is to get monitoring stat from NetScaler
#
def getMonitoringStat(objName, objVal, url, devIp, sesId, logger):
    """
    This is to collect periodical stat from the NetScaler for its config objects
    """

    logger.debug('++++++++++ get Monitoring stat call for objName = %s instance name = %s' % (objName, objVal))
    respCode = {}

    respCode = nitro.getStats(objName, objVal, url, devIp, sesId, logger)

    return respCode

#
# This is to get the device name from the config
#
def getClusterColFromConfig(deviceObj, logger):
    """
    This is to get the device name from the config
    """
    #logger.debug('++++++++ get Device Name from Config +++++++++++')
    devCol = {}
    hostVal = None
    portVal = 0
    credVal = {}
    clusCol = {}
    devName = None
    for a1, b1 in deviceObj.iteritems():
        if type(a1) is str and a1.strip().lower() == const.DEVS:
            devCol = b1
    #logger.debug('+++++++ Device details ++++++ = %s' % (devCol))
    # now get the cluster details from the device collection
    for a2, b2 in devCol.iteritems():
        if type(a2) is not tuple and a2.strip().lower() == const.HOST:
            hostVal = b2
        elif type(a2) is not tuple and a2.strip().lower() == const.PORT:
            portVal = b2
        elif type(a2) is not tuple and a2.strip().lower() == const.CREDS:
            credVal = b2
        elif type(a2) is not tuple and a2.strip().lower() == const.NAME:
            devName = b2
        else: # this will be cluster
            clusCol[a2] = b2

    logger.debug('+++++++ Device details ++++++ port = %s, host = %s, name = %s' % (portVal, hostVal, devName))

    return clusCol
#
# This is to get login object from the NSLogin
#
def getLoginObj(devUrl, devIp, cred, logger):
    """
    This is to get login object
    """
    credCol = {}
    credCol["userName"] = cred["username"]
    credCol["password"] = cred["password"]
    #url = "http://" + devIp + "/nitro/v1/config/login"
    url = devUrl + "login"
    credCol['url'] = url
    #logger.debug('++++++++++ login object URL = %s' % (url))
    nsLoginObj = NSLogin.NSLogin(credCol, logger)

    return nsLoginObj


#
# This is to get the atributeValue from the dictionary
#
def getParamAttributeValueFromCollection(atrName, atrCol, logger):
    """
    This is to get the attribute value from the collectio
    """
    #logger.debug('+++++ Param Attribute col = %s' % (atrCol))
    for a1, b1 in atrCol.iteritems():
        if a1 == const.VALUE:
            for a2, b2 in b1.iteritems():
                # keys will be in this format (5, 'port', '')
		#logger.debug('++++++ Param Key = %s and Value = %s' % (a2, b2))
                if a2[0] == const.PARAM and a2[1].strip().lower() == atrName.strip().lower():
	            #print 'Attr -2  name and Value- 2 ========= ', a1, b1
                    for a3, b3 in b2.iteritems():
	                  #print 'Attr name and Value =', a2, b2
                        if a3 == const.VALUE:
                            return b3
    # if the code reached here that means attribute not found
    return None

#
# This is to get network and connector for each function
#
def getNetworkNConnectorFromConfig(conType, cnfg, logger):
    """
    This is to get network and connector for each function based on direction
    """
    respCol = {}
    funCfg = {}
    for k1, v1 in cnfg.iteritems(): # iterating over device level
        #print "K1 = ", k1, v1
        for k2, v2 in v1.iteritems(): # iterating over device value dict
            #print "K2 = ", k2, v2
            #check for any device level configuration i.e. nsip
            if k2 == const.VALUE: # check for 'value':
                for k3, v3 in v2.iteritems(): # This is for global configuration
                    # check the function group
                    if k3[0] == const.FUNCTIONGROUP:
                        # check if the connector is part of this function group
                        for k4, v4 in v3.iteritems():
                            #logger.debug('++++ k4 = %s, V4 = %s' %(k4, v4))
                            if k4 == const.VALUE:
                                for k5, v5 in v4.iteritems():
                                    # check for the function details such as key and name
                                    if k5[0] == const.FUNCTION:
                                        netCol = {}
                                        netVal = None
                                        funName = k5[1]
				        # get the function config collection since connector's value needs to be extracted from this config
			                funCfg = v5
	                                tmpKeyTuple = ()
                                        for k6, v6 in v5.iteritems():
                                            #conKey = None
                                            #conVal = None
                                            # we should be at function level
                                            #logger.debug('---- K6 = %s, V6 = %s '% (k6,v6))
                                            if k6 == const.VALUE:
                                                for k7, v7 in v6.iteritems():
                                                    # check for network
                                                    if k7[0] == const.FOLDER and k7[1] == conType + '_' + const.NETWORK:
                                                        conVal = None
                                                        netConStat = -1
                                                        tmpCol = {}
                                                        netKey = (k7[1], k7[2])
                                                        for k12, v12 in v7.iteritems():
                                                            #logger.debug(' K12 = %s , V12 = %s' % (k12, v12))
                                                            if k12.strip().lower() == const.CONNECTOR.strip().lower():
                                                                conVal = v12
                                                            elif k12 == const.VALUE:
                                                                tmpCol = v12
                                                            elif k12 == const.STATE: #commented out from Joan's solution
                                                                netConStat = v12
							# get the connector's value from the function config
							conValStr = getConnectorValueFromFunConfig(conVal, funCfg, logger)
                                                        encapStr = getEncapValueFromConfig(conValStr[1], cnfg, logger)
                                                        tagStr = getTagValueFromConfig(encapStr, cnfg, logger)
						        # if the NSIP state is 0 then check for Encap Association's state
                                                        if netConStat == const.NOCHANGE:
                                                            netConStat = getEncapStateFromConfig(conValStr[1], cnfg, logger)
                                                        for k13, v13 in tmpCol.iteritems():
                                                            for k14, v14 in v13.iteritems():
                                                                #logger.debug(' K14 = %s , V14 = %s' % (k14, v14))
                                                                if k14 == const.VALUE or k14 == const.TARGET:
                                                                    netVal = v14
                                                        #logger.debug('Net val = %s, conVal = %s State = %s EncapRel = %s' % (netVal, conVal, netConStat, conValStr))
					 		tmpKeyTuple = (k1, k3, k5, conValStr[0])
                                                        #logger.debug(' Encap Tag value = %s, Tag = %s , TmpKeyTuple = %s' % (encapStr, tagStr,tmpKeyTuple))
                                                        netCol[(netVal, netConStat)] = tagStr
                                        respCol[tmpKeyTuple] = netCol
                                        #logger.debug('++++  details network = %s ' % (respCol))
                                                # check if the key is of type connector and the value is the same as param
                                                #if k7[0] == const.CONNECTION and k7[2] == conName:
                                                #    fgCol[k5]

    return respCol

#
# This is to get connector's details from function and device config
#
def getConnectorValueFromFunConfig(conVal, funCfg,logger):
    """
    This is to get connector details from its name, the relationhsip flows name -> encapRel -> Tag -> VLAN/VXLAN
    """

    # get Connection name from function Config
    #logger.debug('function config = %s' % (funCfg))
    for i1,j1 in funCfg.iteritems():
        if i1 == const.VALUE:
            for i2, j2 in j1.iteritems():
                if i2[0] == const.CONNECTION and i2[2] == conVal:
                    for i3, j3 in j2.iteritems():
                        if i3 == const.VALUE:
                            for i4, j4 in j3.iteritems():
                                for i5, j5 in j4.iteritems():
                                    #logger.debug('++++ Connector ENCAPREL i5 =  %s, j5 = %s' % (i5, j5))
                                    if i5 == const.TARGET or i5 == const.VALUE:
                                        return (i2,j5)
    # if the execution flow reaches that means no encapRel found

    return None

#
# This is to get Tag values from EnCapRel
#
def getEncapValueFromConfig(encapRel, cnfg, logger):
    """
    This is to get the tag values from the config using encapRel
    """

    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.VENCAPASS and a3[2] == encapRel:
                        for a4, b4 in b3.iteritems():
                            #logger.debug('ENCAP Ass Values a4 = %s, b4 = %s' %(a4,b4))
                            if a4 ==  const.ENCAP:
                                return  b4
    # if the execution flow reaches that means no encapRel found
    return None
#
# This is to get Encap state from EnCapRel
#
def getEncapStateFromConfig(encapRel, cnfg, logger):
    """
    This is to get the tag values from the config using encapRel
    """

    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.VENCAPASS and a3[2] == encapRel:
                        for a4, b4 in b3.iteritems():
                            #logger.debug('ENCAP Ass Values a4 = %s, b4 = %s' %(a4,b4))
                            if a4 ==  const.STATE:
                                return  b4
    # if the execution flow reaches that means no encapRel found
    return None


#
# This is to get Tag values from EnCapRel
#
def getTagValueFromConfig(tagVal, cnfg, logger):
    """
    This is to get the tag values from the config using encapRel
    """

    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get all the object which has matching state
                    if a3[0] == const.IFCTAG and a3[2] == tagVal:
                        for a4, b4 in b3.iteritems():
                            #logger.debug('Values a4 = %s, b4 = %s' %(a4,b4))
                            if a4 ==  const.TAG:
                                return  b4
    # if the execution flow reaches that means no encapRel found
    return None

#
# This is to get attribute specific value
#
def getKeyAttrValForObjectFromConfig(objName, cnfg, logger):
    """
    This is to get attribute specific value for object
    """

    objCol = getCompleteObjectFromConfig(objName, cnfg)
    #logger.debug('Object Collection for getKeyAttrVal  = %s' % (objCol))
    keyObj = None
    for a1, b1 in objCol.iteritems():
	keyObj = a1[1]
	break
    logger.debug('Object key for Object = %s from getKeyAttrValForObject = %s' % (objName, keyObj))
    if (keyObj is None):
        return None
    # get the key attribute for this object
    atrName = getObjectKey(keyObj,logger)
    # get the first element of the tuple
    atrName = atrName[0]
    logger.debug('Object key Attribute Name  = %s' % (atrName))
    atrCol = getAttributeCollectionForObject(objCol, cnfg, logger)

    logger.debug(' +++++ Attribute Collection from getKeyAttrValForObject = %s' % (atrCol))
    for a1, b1 in atrCol.iteritems():
        for a2, b2 in b1.iteritems():
            #logger.debug('Values A1 = %s, B1 = %s, AttrName = %s' % (a1,b1, atrName))
            if a2 == atrName:
                return b2

    # if the code comes here that means the attribute not found
    return None
#
# This is to get service group members with IP and port
#
def getServiceGroupMemCol(sgName, cnfg, logger):
    """
    This is to get service group member's IP and port collection for serviceGroup
    """
    retCol = {}
    objCol = getCompleteObjectFromConfig(sgName, cnfg)
    #objAtrCol = getAttributeCollectionForObject(objCol, cnfg, logger)

    for k1,v1 in objCol.iteritems():
        for k2, v2 in v1.iteritems():
            if k2 == const.VALUE:
                for k3, v3 in v2.iteritems():
                    tmpCol = {}
                    if k3[0] == const.FOLDER and k3[1] == const.SVCGROUP_SGMEM_BIND:
                        for k4, v4 in v3.iteritems():
                            if k4 == const.VALUE:
                                for k5, v5 in v4.iteritems():
                                    if k5[0] == const.PARAM and k5[1].strip().lower() == const.IP:
                                        for k6, v6, in v5.iteritems():
                                            if k6 == const.VALUE:
                                                tmpCol[k5[1]] = v6
                                    elif k5[0] ==const.PARAM and k5[1].strip().lower() == const.PORT:
                                        for k7, v7 in v5.iteritems():
                                            if k7 == const.VALUE:
                                                tmpCol[k5[1]] = v7
                        retCol[k3] = tmpCol
        #logger.debug('++++ Service Group Member collection' % (retCol))
    return retCol

#
# This is to get parent object and from their get child object's attribute specific value
#
def getAttrValFromParentNChildObjectFromConfig(prntobjName, chldObjName, cnfg, logger):
    """
    This is to get attribute specific value for child's object, first get the parent, then find child
    and finally get the attribute
    """
    objKeyName = None
    objCol = getCompleteObjectFromConfig(prntobjName, cnfg)
    if len(objCol) == 0:
        return None
    #logger.debug('Prent object collection = %s' % (objCol))
    chldCol = getChildObjectFromParentCol(chldObjName, objCol, cnfg, logger)
    if len(chldCol) == 0:
        return None
    #logger.debug('Child object collection = %s' % (chldCol))
    for o1, p1 in chldCol.iteritems():
	# object key
	objKeyName = o1[1]
	break

    # get the key for this Object
    keyAtr = getObjectKey(objKeyName, logger)
    # we need to revisit for composite key plus keyAtr must Not be None
    if keyAtr is not None:
        keyAtr = keyAtr[0]
    #logger.debug('Child object name = %s keyAtr  = %s' % (objKeyName, keyAtr))
    atrCol = getAttributeCollectionForObject(chldCol, cnfg, logger)

    for a1, b1 in atrCol.iteritems():
        for a2, b2 in b1.iteritems():
            #logger.debug('Values A1 = %s, B1 = %s' % (a1,b1))
            if a2 == keyAtr:
                return b2

    # if the code comes here that means the attribute not found
    return None

#
# This is to get child object from parent object collection
#
def getChildObjectFromParentCol(chldObj, prntCol, cnfg, logger):
    """
    This is to get child object from parent's object collection
    """
    respCol = {}
    for a1, b1 in prntCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if a3[2] == chldObj:
                        respCol[a3] = b3

    return respCol

#
# This is the get object's key from the objectKey collection
#
def getObjectKey(objName, logger):
    """
    This is to get obect's key from the object collection
    """
    keyList = constKey.objOrder
    for i in keyList:
        keyTup = i
        if objName == keyTup[0]:
            return keyTup[1]

    # if the flow is here then not found
    return None
#
# This is the get object's modifiable attributes from setArgs
#
def getModObjTup(objName, logger):
    """
    This is to get obect's modifiable object's list as tuple
    """
    modList = setArgs.setArgs
    for i in modList:
        modTup = i
        if objName == modTup[0]:
            return modTup[1]

    # if the flow is here then not found
    return None
#
# This is to get Object Order List from objectOrderNKey
#
def getObjectOrderList(logger):
    """
    This is to get object's list in order from the objectOrderkey module
    """
    objRetList = []
    objList = constKey.objOrder
    for i in objList:
        objRetList.append(i[0])

    return objRetList

#
# This is to get MREL's key attribute
#
def getKeyForMREL(mrelVal, cnfg, logger):
    """
    This is to get key attribute for MRELs
    """
    objCol = getCompleteObjectFromConfig(mrelVal, cnfg)
    keyVal = None
    # from the object collection get the object key
    for i1, j1 in objCol.iteritems():
	keyVal = i1[1]
	break
    # now get the object key
    keyAttr = getObjectKey(keyVal, logger)
    # get the first element of the tuple
    keyAttr = keyAttr[0]
    return keyAttr

#
# This is to get config order collection
#
def getConfigOrderCol(cnfgCol, logger):
    """
    This is to get an order list of objects based on creation sequence
    """
    configOrderCol = {}
    orderObjList = getObjectOrderList(logger)    #const.OBJECTLIST
    for a1, b1 in cnfgCol.iteritems():
        tmpName = a1[1]
        # remove _cfg from the key
        #tmpName = tmpName[:tmpName.find('_cfg')]
        #logger.debug('+++++++++ Searching for  object details = %s' % (tmpName.upper()))
        for i in orderObjList:
            if i.strip().lower() == tmpName.strip().lower():
                # this will store only one value since others will get overwritten
                configOrderCol[orderObjList.index(i)] = tmpName.strip().lower()
                #logger.debug('+++++++++ Create object details = %s' % (tmpName.upper()))
                break

    return configOrderCol

#
# get the interface list from the interface collection
#
def getInterfaceAttrFromCol(inCol, logger):
    """
    This is to get interface attribute collection from interface
    """
    #logger.debug('+++++++++ get Interface attr list ++++++++++')
    ifAtrList = []
    encapCol = {}
    vifObjName = None
    for a1, b1 in inCol.iteritems():
        if a1[0] == const.INFTYPE:
            tmpInterface = a1[2]
            tmpInterface = tmpInterface.replace('_', '/')
	    tmpTuple = (a1[0], a1[1],a1[2],tmpInterface)
            ifAtrList.append(tmpTuple)
            #logger.debug('interface values = %s' % (tmpInterface))
    return ifAtrList
#
# This is to get connector's key from the function definition
#
def getConnectorObjectKeyFromFunction(cnName, funCol, logger):
    """
    This is to get connector's detail from the same function
    """
    for i1, j1 in funCol.iteritems():
        # look for the connection of type 2
        if i1[0] == const.CONNECTION and i1[2] == cnName:
            return i1

    # if the flow reaches here that not found

    return None


#
# This is to get connector and target vservers from collection
#
def getConnectorNTargetVserver(cnCol, funCfgCol, logger):
    """
    This is to get connector and target server from the collection
    """
    cnName = None
    cnKey = None
    tmpCol = {}
    cnObjKey = None
    tgtVser = None
    for a1, b1 in cnCol.iteritems():
        if a1 == const.CONNECTOR:
            cnKey = a1
            cnName = b1
            cnObjKey = getConnectorObjectKeyFromFunction(cnName, funCfgCol, logger)
        elif a1 == const.VALUE:
            tmpCol = b1
    # check if the cnName is not None then get target otherwise return
    if (cnName):
        for c1, d1 in tmpCol.iteritems():
            for c2, d2 in d1.iteritems():
                if c2 == const.TARGET or c2 == const.VALUE:
                  tgtVser = d2
    # create the connector and targetVserver dict
    retCol = {}
    # this is just for safety this shouldn't be the case
    if (tgtVser):
        retCol[(cnObjKey, cnKey,cnName)] = tgtVser

    return retCol
#
# This is to get vservers and its connectors from the config
#
def getVserverNConnectorsFromConfig(cnfg, logger):
    """
    This is to get vsersers and its connectors for each function from the config
    """
    retCol = {}
    for i1, j1 in cnfg.iteritems():
        for i2, j2 in j1.iteritems():
            if i2 == const.VALUE:
                for i3, j3 in j2.iteritems():
                    # look for function group id = 1 (GROUP)
                    if i3[0] == const.FUNCTIONGROUP:
                        # now look for function
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                for i5, j5 in j4.iteritems():
                                    # now look for funtion id = 3
                                    if i5[0] == const.FUNCTION:
                                        for i6, j6 in j5.iteritems():
                                            if i6 == const.VALUE:
                                                for i7, j7 in j6.iteritems():
                                                    # check for folder type 4 and key has 'vserver' in it
                                                    if i7[0] == 4 and i7[1].find(const.VSERVER) != -1:
                                                        # get the connector and target details from this vserver j6 is for function config details
                                                        tmpCnCol = getConnectorNTargetVserver(j7, j6, logger)
		 					tmpInTuple = None
                                                        for x1, y1 in tmpCnCol.iteritems():
                                                            tmpInTuple = (i1, i3, i5, x1[0], i7[1])
                                                        retCol[tmpInTuple] = tmpCnCol
                                                        #logger.debug('+++++ Connector N Target VServer = %s' % (retCol))
    return retCol

#
# This is to get target vservers from collection
#
def getTargetVserverRService(cnCol, logger):
    """
    This is to get target server from the collection
    """
    tgtVser = None
    for a1, b1 in cnCol.iteritems():
        if a1 == const.VALUE:
            for a2, b2 in b1.iteritems():
                for a3, b3 in b2.iteritems():
                    if a3 == const.TARGET or a3 == const.VALUE:
                        tgtVser = b3
    return tgtVser

#
# This is to get vservers for each function
#
def getVserverFromFunctionCol(funCfg, logger):
    """
    This is to get vsersers foreach function
    """
    retCol = {}
    #logger.debug('++++++++++++ Function Config = %s' %  (funCfg))
    for i1, j1 in funCfg.iteritems():
        if i1 == const.VALUE:
            for i2, j2 in j1.iteritems():
                if i2[0] == const.FOLDER and i2[1].find(const.VSERVER) != -1:
                    tmpSer = getTargetVserverRService(j2, logger)
                    retCol[i2] = tmpSer

    #logger.debug('+++++ vServerName N Target VServer = %s' % (retCol))
    return retCol

#
#
#
def getServiceNServiceGroupFromFunctionCol(funCol, logger):
    """
    This is to get unbind service or service group from the Function collection
    """
    retCol = {}
    for i1, j1 in funCol.iteritems():
        if i1 == const.VALUE:
            for i2, j2 in j1.iteritems():
                if (i2[0] == const.FOLDER and (i2[1].find(const.SERVICE) != -1 or
                                              i2[1].find(const.SERVICEGROUP) != -1)):
                    tmpSer = getTargetVserverRService(j2, logger)
                    retCol[i2] = tmpSer
    #logger.debug('++++++++++ service N serviceGroup from function collection = %s' % (retCol))
    return retCol
#
# get Service or service group for a given function
#
def getServiceNServiceGroupForFunction(fTuple, cnfg, logger):
    """
    This is to get service or services which are not bound to vServer but present in function definition
    """

    retCol = {}
    for i1, j1 in cnfg.iteritems():
        for i2, j2 in j1.iteritems():
            if i2 == const.VALUE:
                for i3, j3 in j2.iteritems():
                    if i3[0] == const.FUNCTIONGROUP:
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                for i5, j5 in j4.iteritems():
                                    # compare the function tuple i.e. (4, 'LoadBalancing','Node1)
                                    if i5 == fTuple:
                                        for i6, j6 in j5.iteritems():
                                            if i6 == const.VALUE:
                                                for i7, j7 in j6.iteritems():
                                                    if i7[0] == const.FOLDER and (i7[1].find(const.SERVICE) != -1 or i7[1].find(const.SERVICEGROUP) != -1):
                                                        tmpSer = getTargetVserverRService(j7, logger)
                                                        retCol[i1, i3, i5, i7] = tmpSer
    #logger.debug('++++++++++ service list from function = %s, services = %s' % (fTuple, retCol))

    return retCol

#
# This is to get list of functions from the config
#
def getFunctionsFromConfig(cnfg, logger):
    """
    This is to get list of functions from the config
    """

    retCol = {}
    for i1, j1 in cnfg.iteritems():
        for i2, j2 in j1.iteritems():
            if i2 == const.VALUE:
                for i3, j3 in j2.iteritems():
                    if i3[0] == const.FUNCTIONGROUP:
                        for i4, j4, in j3.iteritems():
                            if i4 == const.VALUE:
                                for i5, j5 in j4.iteritems():
                                    if i5[0] == const.FUNCTION:
                                        retCol[i1, i3, i5] = j5
    #logger.debug('++++++++++ function list from config = %s' % (retCol))

    return retCol

#
# This is to get Service or serviceGroup for a vServer
#
def getServiceNServiceGroupForVServer(vObj, cnfg, logger):
    """
    This is to get vServer's servcie or service group
    """
    retCol = {}
    #logger.debug('+++++++++ get service or service group collection for = %s' % (str(vObj)))
    for i1, j1 in cnfg.iteritems():
        for i2, j2 in j1.iteritems():
            if i2 == const.VALUE:
                for i3, j3 in j2.iteritems():
                    if i3[0] == const.FOLDER and i3[1] == vObj[1] and i3[2] == vObj[2]:
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                for i5, j5 in j4.iteritems():
                                    #logger.debug('+++++++++ getServiceNServiceGroup collection i5 = %s, j5 = %s' % (i5, j5))
                                    # now look for folder with service_binding or servicegroup_binding
                                    if (i5[0] == const.FOLDER and (i5[1].find(const.SERVICE_BINDING) != -1
                                                                      or i5[1].find(const.SERVICEGROUP_BINDING) != -1)):
                                            for i6, j6 in j5.iteritems():
                                                #logger.debug('+++++++++ getServiceNServiceGroup collection i6 = %s, j6 = %s' % (i6, j6))
                                                if i6 == const.VALUE:
                                                    for i7, j7 in j6.iteritems():
                                                        if i7[0] == const.MREL and i7[1] == const.SERVICE_BIND_KEY:
                                                            for i8, j8 in j7.iteritems():
                                                                if i8 == const.VALUE or i8 == const.TARGET:
                                                                    retCol[(i1, i3, i5, i7)] = j8
    logger.debug('+++++++++ getServiceNServiceGroup collection = %s' % (retCol))
    return retCol

#
# This is to generate faults based on response
#
def getFaults(rootKey, respCol, logger):
    """
    This is to parse service modify's reponse and generate faults based on error code
    """
    resFaults = []
    ignoreRange = range(200, 299)
    logger.debug('+++++ Faults respCol   = %s' % (respCol))
    for a1, b1 in respCol.iteritems():
        if type(b1) is not dict:
            continue
        #logger.debug('+++++ Faults Key A1 = %s B1 Value = %s' % (a1,b1))
        for a2, b2 in b1.iteritems():
            #logger.debug('+++++ Faults Key = %s Value = %s' % (a2,b2))
            erCode = None
            erMsg = None
            svrVal = None
            statusCode = None
            oprName = None
            if type(b2) is not dict:
                continue
            for a3, b3 in b2.iteritems():
                if a3.strip().lower() == const.ERRORCODE and b3 != 0:
	            erCode = b3
		elif a3.strip().lower() == const.MESSAGE:
	            erMsg = str(b3)
	        elif a3.strip().lower() == const.SEVERITY:
		    svrVal = b3
                elif a3 == const.STATUS_CODE:
                    statusCode = b3
                elif a3 == const.OPR_NAME:
                    oprName = b3
            # append this as faults
            logger.debug('Fault details oprName = %s, erMsg = %s, statusCode = %s' % (oprName, erMsg, oprName))
            if (erCode and erCode != 0):
                # do not generate fault if operation is Monitor to get stats 'MONITOR_OP'
                #if (oprName == const.MONITOR_OP):
                #    continue
                # Do not generate Fault if statusCode is 409
                if statusCode == 409 or (erCode in ignoreRange and erMsg.find('No such resource [backupVServer') == -1):
                    # do not ignore vlan_nsip_binding based on Cisco Bug CSCuu05130 & CSCut90128
                    if a2 != const.VLAN_NSIP_BINDING:
                        #logger.debug('Ignore this error VLAN NSIP Binding A2 = %s B2 = %s' % (str(a2), str(b2)))
                        continue
                # do not generate fault if operation is Delete 'DELETE_OP' and statusCode is 404
                if (oprName == const.DELETE_OP and statusCode == 404):
                    continue
                if (oprName == const.DELETE_OP and a2 == const.VLAN_INTERFACE_BIND_NAME and erMsg.find('Interface/channel not a member of given vlan') != -1):
                    continue
                if (oprName == const.BIND_OP and erMsg in const.IGNORE_OPTIONS):
                    #logger.debug('Ignoring BIND op details = %s' % (erMsg))
                    continue
                #elif (oprName == const.MOD_OP and erMsg.find('Too few arguments') != -1 ):
                #    continue
                #fltMsg = const.ERRORCODE.upper() + ':' + str(erCode) + ' ' + const.MESSAGE.upper() + ':' + erMsg + ' ' + const.SEVERITY.upper() + ':' + str(svrVal)
                fltMsg = erMsg + ' ' + const.SEVERITY.upper() + ':' + str(svrVal)
	        tmpList = []
                for i in a1:
                    if type(i) is tuple:  # this is to ignore object name in Fault list
                        # just check this is not nested tuple
                        tupFlag = True
                        for j in i:
                            if type(j) is tuple:
                                tmpList.append(j)
                                tupFlag = False
                        if (tupFlag):
                            tmpList.append(i)
                #logger.debug('+++++ Faults Key tmpList = %s a1 = %s' % (tmpList,a1))
	        # following Fault format
                if len(tmpList) > 0:
                    path = tmpList
                else:
                    tmpList.append(rootKey)
                    path = tmpList # this is to avoid empty path
	        code = int(erCode)
	        message = str(fltMsg)
                tmpTuple = (path, code, message)
                resFaults.append(tmpTuple)

    return resFaults

#
# This is to handle Param objects from the config
# the methods set /unset Param objects in NetScaler
#
def handleParamObjects(cnfg, url, devIp, sesId, logger, deviceAuditFlag=False):
    """
    This is to handle Param objects since these are just set operation
    """
    #logger.debug('++++++++++ Handling Param objects +++++++++++++')
    # look for Param folder in the config
    paramCol = {}
    paramKey = None
    retCol = {}
    paramTuple = ()
    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    #logger.debug('Param collection key = %s, Value = %s' % (a1, b1))
                    if a3[1].strip().lower() == const.PARAMOBJ:
			paramTuple = (a1,a3)
                        paramCol = b3
                        #logger.debug('Param collection A3 = %s B3 = %s' % (a3, b3))
                        paramKey = a3
                # this is to remove param object from device config
                if paramKey:
                    del b2[paramKey]
    # end of the for loop here

    # Apply param objects in NetScaler
    retCol[paramTuple] = applyParamObjects(paramTuple, paramCol, url, devIp, sesId, logger, deviceAuditFlag)

    #logger.debug('Removed Param Collection = %s' % (cnfg))

    # remove Param references from Functions as well
    for c1, d1 in cnfg.iteritems():
        for c2, d2 in d1.iteritems():
            if c2 == const.VALUE:
                for c3, d3 in d2.iteritems():
                    #logger.debug('C3 = %s D3 = %s' % (c3,d3))
                    # c3 must be of type function
                    if c3[0] == const.FUNCTIONGROUP:
                        for c4, d4 in d3.iteritems():
                            if c4 == const.VALUE:
                                for c5, d5 in d4.iteritems():
                                    if c5[0] == const.FUNCTION:
                                        for c6, d6 in d5.iteritems():
                                            if c6 == const.VALUE:
                                                paramKey = None
                                                for c7, d7 in d6.iteritems():
                                                    if c7[0] == const.FOLDER and c7[1].strip().lower() == const.PARAMOBJ:
                                                        paramKey = c7
                                                        #logger.debug('ParamKey = %s' % (str(paramKey)))
                                                # This is to remove param reference from function for further processing
                                                if (paramKey):
                                                    del d6[paramKey]
    #logger.debug('Final Param Collection = %s' % (cnfg))

    return retCol

#
# Set or unset Param values from the collection
#
def applyParamObjects(keyTuple, prCol, url, devIp, sesId, logger, deviceAuditFlag):
    """
    This is to handle set or unset values for Param objects
    """
    #logger.debug('++++++++ Applying Param Values ++++++')
    objName = None
    retCol = {}
    objState = None
    #logger.debug('Param Objects = %s' % (prCol))
    for	a1, b1 in prCol.iteritems():
        if a1 == const.VALUE:
            objName = None
            objState = None
            for a2, b2 in b1.iteritems():
                #logger.debug('A2 = %s B2 = %s' % (a2,b2))
                objName = a2[1]
                for a3, b3 in b2.iteritems():
                    if a3 == const.STATE:
                        objState = b3
                    elif a3 == const.VALUE:
                        objCol = b3
                        # get param attribute collection
                paramCol = getParamAttributeCollection(objCol, logger)
                #logger.debug('++++++++ Applying Param Collection state = %s collection = %s' % (objState, paramCol))
                # if the request is coming from deviceAudit then just set the values
                if deviceAuditFlag:
                    tmpTuple = keyTuple + a2
                    retCol[tmpTuple] = nitro.setConfigObjects(objName, paramCol, url, devIp, sesId, logger)
                elif objState == const.CREATE or objState == const.MODIFY:
	            tmpTuple = keyTuple + a2
                    retCol[tmpTuple] = nitro.setConfigObjects(objName, paramCol, url, devIp, sesId, logger)
                elif objState == const.DELETE:
	            tmpTuple = keyTuple + a2
                    unSetCol = unSetCallToSetTrueValue(paramCol, logger)
                    retCol[tmpTuple] = nitro.unsetConfigObjects(objName, unSetCol, url, devIp, sesId, logger)
    return retCol


#
# Get attribute collection for Param objects
#
def getParamAttributeCollection(objCol, logger):
    """
    This is to get Param attribute collection
    """
    tmpCol = {}
    for a1, b1 in objCol.iteritems():
        atrName = a1[1]
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                tmpCol[atrName] = b2
    return tmpCol

#
# UnSet col to make all values true
#
def unSetCallToSetTrueValue(objCol, logger):
    """
    This is to unset the call and make the values true
    """
    retCol = {}
    for a1, b1 in objCol.iteritems():
        retCol[a1] = const.TRUE

    return retCol
#
# Get Device level tuple for an object
#
def getDeviceConfig(url, devIp, sesId, logger):
    """
    This is to get configuration from device
    """
    cnfgCol = {}
    objList = constKey.objOrder

    for tmpObj in objList:
        tmpTuple = tmpObj
	objName	= tmpTuple[0]
	objKeyTuple = tmpTuple[1]
        tmpResp = nitro.getObjectsConfigFromDevice(objName, url, devIp, sesId, logger)
        if tmpResp[objName]:
            cnfgCol[objName] = tmpResp[objName]
        #logger.debug('++++++++ Config Object Details = %s' % (tmpResp))
        #logger.debug('++++++++ Config Object Details = %s' % (cnfgCol))
        #logger.debug('++++++++ Config Object Details = %s' % (tmpResp[objName]))
        # just add Not Null objects
        #if tmpResp[objName]:
        #    cnfgCol[(objName, objKeyTuple)] = tmpResp[objName]
    #logger.debug('++++++++ Config Object Details = %s' % (cnfgCol))
    return cnfgCol

#
# Clear the device config
#
def clearNSConfigFromDevice(url, devIp, cfgLevel, sesId, logger):
    """
    This is to clear configuration from device
    """
    cnfgCol = {}
    objList = constKey.objOrder

    cnfgCol[devIp] = nitro.clearConfigFromDevice(url, devIp, cfgLevel, sesId, logger)

    return cnfgCol

#
# get the cluster specific details
#
def getClusterNodeFromDeviceCol(clusCol, logger):
    """
    This is to get node details from cluster collection
    """
    #logger.debug('++++++++ get ClusterNode from device collection  ++++++++')
    nodeCol = {}
    haCol = {}
    hostVal = None
    portVal = 0
    credVal = {}
    devName = None
    for a1, b1 in clusCol.iteritems():
        #logger.debug('+++ a1 = %s, b1 = %s' % (a1,b1))
        if type(a1) is str and a1.strip().lower() == const.DEVS:
            devCol = b1
    #logger.debug('+++++++ Device details ++++++ = %s' % (devCol[const.HOST]))
    # now get the cluster details from the device collection
    for a2, b2 in devCol.iteritems():
        #logger.debug('+++++ get node details a2 = %s, b2 = %s'%(a2,b2))
        if type(a2) is not tuple and a2.strip().lower() == const.HOST:
            hostVal = b2
        elif type(a2) is not tuple and a2.strip().lower() == const.PORT:
            portVal = b2
        elif type(a2) is not tuple and a2.strip().lower() == const.CREDS:
            credVal = b2
        elif type(a2) is not tuple and a2.strip().lower() == const.NAME:
            devName = b2
        elif type(a2) is tuple and a2[1].strip().lower() == 'highavailability':
            haCol = b2
        else:    # this will be cluster
            nodeCol[a2] = b2
    #logger.debug('++++ cluster collection = %s' % (nodeCol))
    return nodeCol

#
# get the cluster node name
#
def getClusterNodeNameFromDeviceCol(clusCol, logger):
    """
    This is to get node Name from cluster collection
    """
    #logger.debug('++++++++ get ClusterNode Name from device collection  ++++++++')
    devName = []
    for a1, b1 in clusCol.iteritems():
        #logger.debug('+++ a1 = %s, b1 = %s' % (a1,b1))
        if type(a1) is str and a1.strip().lower() == const.DEVS:
            for a2, b2 in b1.iteritems():
                devName.append(a2)

    # this is just to be safe
    tmpSet = set(devName)
    devName = list(tmpSet)
    #logger.debug('+++++++ Cluster node name  ++++++ = %s' % (devName))
    return devName

#
# get the objects of type devObj the collection
#
def getObjColFromDevModCnfg_list(devCol, devObj, logger):
    """
    This is to get object specific collection from device modify config collection
    This will collect all the object-attrs of type devObj and puts them in list
    ex: for multiple ntpserver in devCol below is returned
    [{'servername': 'yy', 'minpoll': '8', 'key': '79'}, {'minpoll': '7', 'serverip': '1.2.3.4', 'key': '77'}]
    """
    instList = [];
    for i1, j1 in devCol.iteritems():
        if i1[1] == devObj:
            retCol = {}
            for i2, j2 in j1.iteritems():
                if i2 == const.VALUE:
                    for i3, j3 in j2.iteritems():
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                retCol[i3[1]] = j4
            if len(retCol) > 0:
                instList.append(retCol)
    return instList


#
# get deviceModify params from the collection
#
def getObjColFromDevModCnfg(devCol, devObj, logger):
    """
    This is to get object specific collection from device modify config collection
    """
    retCol = {}
    for i1, j1 in devCol.iteritems():
        if i1[1] == devObj:
            for i2, j2 in j1.iteritems():
                if i2 == const.VALUE:
                    for i3, j3 in j2.iteritems():
                        for i4, j4 in j3.iteritems():
                            if i4 == const.VALUE:
                                retCol[i3[1]] = j4

    return retCol
#
# get state of an object's instance value from device config
#
def getStaeOfInstanceObject(objName, instVal, url, devIp, sesId, logger):
    """
    This is to get the state of an object's instance for HA
    """
    tmRespCol = {}
    tmpRespCol = nitro.getInstanceConfigFromDevice(objName, instVal, url, devIp, sesId, logger)
    #logger.debug('+++ HA Node instance details = %s' % (tmpRespCol))
    haInstList = []
    # this is to avoid any accidental issue where data may not be present
    if tmpRespCol is None:
        return None
    for f1, g1 in tmpRespCol.iteritems():
        if f1.strip().lower() == const.HANODE:
            haInstList = g1
            break
    nodeState = None
    for i in haInstList:
        for j1, q1 in i.iteritems():
            if j1 == const.STATE:
                return q1 # this is the state of the object

    # if the execution reach here then no state
    return None

#
# get the state of the NetScaler based on its IP
#
def getHAStateOfDevice(objName, url, devIp, sesId, logger):
    """
    This is to find out if the device is primary or secondary
    """
    tmmRespCol = {}
    tmpRespCol = nitro.getObjectsConfigFromDevice(objName, url, devIp, sesId, logger)
    #logger.debug('+++ HA State of device details = %s' % (tmpRespCol))
    haInstList = []
    tmpCol = {}
    tmpCol = tmpRespCol[const.HANODE]
    for a1, b1 in tmpCol.iteritems():
        if a1.strip().lower() == const.HANODE:
            haInstList = b1
            break
    tmpState = None
    tmpIp = None
    for i in haInstList:
	#logger.debug(' HA Instance value = %s' % (i))
        for c1, d1 in i.iteritems():
                if c1 == const.STATE:
                    tmpState = d1
                elif c1 == const.IPADDRESS:
                    tmpIp = d1
	# commenting out this will get fixed with HA config
        #if tmpIp == devIp:
        #    return tmpState

    # if the execution reached that means no state
    return tmpState

#
# get the HA node of NetScaler
#
def getPeerHANodeOfDevice(objName, url, devIp, sesId, logger):
    """
    This is to find out HA Node for the device (primary or secondary)
    """
    tmmRespCol = {}
    tmpRespCol = nitro.getObjectsConfigFromDevice(objName, url, devIp, sesId, logger)
    #logger.debug('+++ HA Node of device details = %s' % (tmpRespCol))
    haInstList = []
    # this is to get HA payload from the response
    for a1, b1 in tmpRespCol[objName].iteritems():
        if a1.strip().lower() == const.HANODE:
            haInstList = b1
            break
    if haInstList is None:
	return None
    tmpId = None
    tmpIp = None
    #logger.debug('+++ HA inst list of device = %s' % (haInstList))
    for i in haInstList:
        for c1, d1 in i.iteritems():
                if c1 == const.ID:
                    tmpId = d1
                elif c1 == const.IPADDRESS:
                    tmpIp = d1
	# if the IPs don't match that means HA node Id of the peer
        if tmpIp != devIp:
            return tmpId

    # if the execution reached here that means no ID
    return None

#
#
# this is get collection of feature key and value, this is being used in clusterAudit
#
def getDeviceFeatureCollection(objCol, colOption, featureOptions,logger, auditFlag=False):
    """
    This is to get object collection for enable feature
    """
    #logger.debug('++++++ get Feature/Mode collection +++++++')
    retObjCol = {}
    featureList = []
    for a1, b1 in objCol.iteritems():
        if a1[1] == colOption:
            tmpState = None
            tmpVal = {}
            for a2, b2 in b1.iteritems():
            #logger.debug('+++ tmpState = %s, tmpVal = %s' % (a2, b2))
                if a2 == const.STATE:
                    tmpState = b2
                elif a2 == const.VALUE:
                    tmpVal = b2
            #logger.debug('+++ tmpState = %s, tmpVal = %s' % (tmpState, tmpVal))
            if tmpState != const.NOCHANGE or auditFlag:
                atrState = None
                atrVal = None
                for a3, b3 in tmpVal.iteritems():
                #logger.debug('+++ a3 = %s, b3 = %s ' % (a3,b3))
                    for a4, b4 in b3.iteritems():
                        if a4 == const.STATE:
                            atrState = b4
                        elif a4 == const.VALUE:
                            atrVal = b4
                #logger.debug('+++ a4 = %s, b4 = %s ' % (atrState,atrVal))
                    if ((atrState != const.NOCHANGE or auditFlag) and (atrVal in featureOptions)):
                        retObjCol[a3[1]]= atrVal
                        featureList.append(a3[1])

                    if ((atrVal not in const.ENABLE_OPTIONS) and (atrVal not in const.DISABLE_OPTIONS)):
                        logger.error('Invalid value for feature/mode (%s,%s)' % (a3[1], atrVal))

    return featureList

#
# Run RHI config using looping mechanism
#
def execRHIConfig(device, sesId,  logger):
    """
    This is to execute RHI config in loop wating for 3 seconds with each time
    """
    feaCol = {}
    credCol = {}
    retCol = {}
    rhiFlag = False
    credCol = device[const.CREDS]
    nsObj = NSServer.NSServer(logger)
    devUrl = None
    for i in range(3):
        devUrl = getURL(device[const.PORT], device[const.HOST],logger)
        feaCol= nsObj.getNSFeature(devUrl, sesId)
        for m1, n1 in feaCol.iteritems():
            if m1.strip().lower() == const.OSPF.strip().lower() and n1 == True:
                #rhconf.rhiNetworkConfig(device[const.HOST], credCol[const.USERNAME], credCol[const.PASSWORD], logger)
                rhiFlag = True
                logger.debug('RHI Configuration Successfully applied in NetScaler')
        if (rhiFlag):
            break
        else:
            time.sleep(3)
    if rhiFlag is False:
        logger.error('RHI configuration Failed')
        #retCol = {}
        #retCol[const.ERRORCODE] = 1001
        #retCol[const.MESSAGE] = 'RHI Configuration Failed in NetScaler'
        #retCol[const.STATE] = const.TRANSIENT
        #retCol[const.SEVERITY] = "ERROR"
        return retCol

    return retCol

#
# get the NITRO URL based on port
#
def getURL(port, devIp, logger):
    """
    This is to get URL based on port value 80 or 443 otherwise raise exception
    """
    #logger.debug('Port = %s and devIp = %s' % (port, devIp))
    url = None
    if port == 80:
        url = "http://" + devIp + "/nitro/v1/config/"
    elif port == 443:
        url = "https://" + devIp + "/nitro/v1/config/"
    else:
        raise Exception("Unsupported port on Device")
    #logger.debug('Returning URL = %s' % (url))

    return url

#
# get the root key of the configuration
#
def getRootKey(cnfg, logger):
    """
    This is to get the root key from the key configuration
    """
    rootKey = None
    for a1, b1 in cnfg.iteritems():
        rootKey = a1
        break

    #logger.debug('++++++ Root key for the configuration is = %s' % (str(rootKey)))

    return rootKey
#
# get instance object from the response
#
def getObjectInstanceFromResponse(objType, respCol, logger):
    """
    This is to get object from response
    """
    objResp = {}
    #logger.debug(' get Objects Instance from Response = %s' % (respCol))
    tmpError = None
    for a1, b1 in respCol.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.ERRORCODE:
                tmpError = b2
            elif a2 == objType:
                #logger.debug('B2 -------- = %s' % (b2))
                if type(b2) is list and len(b2) > 0:
                    objResp[objType] = b2[0] # since most of the time objects will be in list
    if tmpError == 0:
        return objResp
    else:
        return []

#
# compare APIC & Device Objects
#
def compareAPICNDeviceObjects(apicAtrCol, devAtrCol, logger):
    """
    This is to compare two objects between APIC & NetScaler device
    """
    logger.debug('+++ compare two objects using attribute collection ++++')
    logger.debug('... APIC Attr COl = %s' % (apicAtrCol))
    logger.debug('....Device Attr Col = %s' % (devAtrCol))
    retCol = {}

    for i in apicAtrCol.keys():
        if i in devAtrCol.keys():
            # compare the values
            # first get the type from device
            devVal = devAtrCol[i]
            apicVal = apicAtrCol[i]
            # since device is retunring type in unicode
            if type(devVal) is unicode:
                devVal = devVal.encode('UTF-8')
            valType = type(devVal)
            #logger.debug('++++ Value Type from Device  = %s, value = %s' % (valType, devVal))
            if valType is str:
                if valType(devVal).strip().lower() != valType(apicVal).strip().lower():
                    #logger.debug('......... STRING mismatch values from compare  APIC = %s, Device = %s'% (apicVal, devVal))
                    return False
            else:
                if valType(devVal) != valType(apicVal):
                    #logger.debug('......... Non-string mismatch values from compare APIC = %s, Device = %s'% (apicVal, devVal))
                    return False
            #devAtrType = str # ype(devVal) # this is to avoid string integer comparison
            #logger.debug('++++++ DevAtr Type = %s' % (devAtrType))
            #if devAtrType is str:
            #    logger.debug('......... string comapre---- APIC = %s, Device = %s' % (apicAtrCol[i], devAtrCol[i]))
            #    if devAtrType(apicAtrCol[i]).strip().lower() != devAtrCol[i].strip().lower():
                    # values mismatch
           #         logger.debug('......... mismatch values from compare APIC N Device Objects APIC = %s, Device = %s'% (apicAtrCol[i], devAtrCol[i]))
           #         return False
           # else:
           #     logger.debug('......... Non string comapre---- APIC = %s, Device = %s' % (apicAtrCol[i], devAtrCol[i]))
           #     if devAtrType(apicAtrCol[i]) != devAtrCol[i]:
                    # values mismatch
           #         logger.debug('......... mismatch values from compare APIC N Device Objects APIC = %s, Device = %s'% (apicAtrCol[i], devAtrCol[i]))
           #         return False
    # if execution reaches here then return True
    return True
#
# convert nested tuples to list of tuples
#
def getTupleList(tupVal, logger):
    """
    This is to get flat list of tuples and avoid any nesting within tuple
    """
    tupList = []
    tmpList = []
    #logger.debug('Tuple Value = %s' % (str(tupVal)))
    for i in tupVal:
        checkFlag = False
        checkFlag = checkTupleInsideTuple(i, logger)
        if checkFlag:
           tmpList =  getTupleList(i, logger)
           #logger.debug('After recusrion list = %s, i = %s' % (tmpList, i))
        else:
            tupList.append(i)
    return tmpList + tupList

#
# check if there tuple inside tuple
#
def checkTupleInsideTuple(tupVal, logger):
    """
    Check if there is tuple inside tuple
    """
    # this is for safety purpose in case value is primitive
    if type(tupVal) is not tuple:
        return False
    for i in tupVal:
        if type(i) is tuple:
            return True
        else:
            return False

    # just for safety purpose
    return False

#
# This is to get cluster specific state's Objects.
#
def getClusterStateSpecificObjectsFromConfig(objState, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get object list for a specific object state
    """
    #logger.debug('+++++++++ State specific objects from config  = %s +++++++++' % (objState))
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        atrCol = {}
        paramCol = {}
        tmpState = 0
        for a2, b2 in b1.iteritems():
            if a2 == const.STATE:
                tmpState = b2
            #logger.debug('++++++++ Object  Key A2 = %s, Value B2 = %s' % (a2, b2))
            if a2 == const.VALUE:
                paramCol[a1] = b2
        #logger.debug('objstate = %s paramCol = %s' % (tmpState, paramCol))
        if tmpState == objState or deviceAuditFlag:
            for a3, b3 in paramCol.iteritems():
                for a4, b4 in b3.iteritems():
                    #logger.debug('obj A4  = %s col B4 = %s' % (a4,b4))
                    for a5, b5 in b4.iteritems():
                        if a5 == const.VALUE:
                            atrCol[a4[1]] = b5

        #logger.debug('++++++++ Object Collection  Key = %s, Value = %s' % (a1[1], atrCol))
        if len(atrCol) > 0: # this is to avoid empty collection
            #logger.debug('++++++++ Object Collection  Key = %s, Value = %s' % (a1[1], atrCol))
            objCol[a1] = atrCol

    return objCol

#
# This is to get cluster specific state's Objects.
#
def getClusterModifyObjectAtrsFromConfig(objState, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get object list for a specific object state
    """
    #logger.debug('+++++++++ Modify State specific objects from config  = %s +++++++++' % (objState))
    objCol = {}
    for a1, b1 in devCfg.iteritems():
        atrCol = {}
        paramCol = {}
        tmpState = 0
        for a2, b2 in b1.iteritems():
            if a2 == const.STATE:
                tmpState = b2
            #logger.debug('++++++++ Object  Key A2 = %s, Value B2 = %s' % (a2, b2))
            if a2 == const.VALUE:
                paramCol[a1] = b2
        #logger.debug('objstate = %s paramCol = %s' % (tmpState, paramCol))
        if tmpState == objState or deviceAuditFlag:
            for a3, b3 in paramCol.iteritems():
                for a4, b4 in b3.iteritems():
                    #logger.debug('obj A4  = %s col B4 = %s' % (a4,b4))
                    tmpState = None
                    tmpVal = None
                    for a5, b5 in b4.iteritems():
                        if a5 == const.STATE:
                            tmpState = b5
                        elif a5 == const.VALUE:
                            tmpVal = b5
                    # add state with each attribute
                    atrCol[a4[1]] = (tmpState, tmpVal)

        #logger.debug('++++++++ Object Collection  Key = %s, Value = %s' % (a1[1], atrCol))
        if len(atrCol) > 0: # this is to avoid empty collection
            #logger.debug('++++++++ Object Collection  Key = %s, Value = %s' % (a1[1], atrCol))
            objCol[a1] = atrCol

    return objCol

#
# This is to get modify attributes for cluster config
#
def getAtrForClusteriModifyObj(objState, objCol, devCfg, logger, allAtrFlag=False):
    """
    This is to attribute collection for cluster modify state
    """
    respCol = {}
    for a1, b1 in objCol.iteritems():
        atrCol = {}
        for a2, b2 in b1.iteritems():
            # here a1 is attribute name and b2 is attribute value {(4, 'snmpmanager', 'snmpmanager_1'): {'ipaddress': (1, '10.102.37.222')}}
            if (b2[0] == objState or allAtrFlag):
                atrCol[a2] = b2[1] # b2 is tuple (state, value)

        respCol[a1] = atrCol

    return respCol

#
# get VIF value e.g. 1/1 or 1/2 based on Node name
#
def getNodeVIFsFromConfigForState(objState, nodeName, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get VIFs value based on node name
    """
    #logger.debug('+++++++++ get Node Specific Tag from Config for modify state++++++++++')
    vifObjCol = {}
    encapCol = {}
    vifObjName = None
    for a1, b1 in devCfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    # get the VIF or ifnum from the config for the particular node
                    if a3[0] == const.VIF:
                        #logger.debug('State details objState = %s, deviceAuditFlag = %s' % (getRootObjectState(b3), deviceAuditFlag))
                        if ((objState == getRootObjectState(b3)) or deviceAuditFlag):
                            for a4, b4 in b3.iteritems():
                                if a4.strip().lower() == const.CIFS:
                                    for a5, b5 in b4.iteritems():
                                        if a5 == nodeName:
                                            #logger.debug('++++++++ Object List Key = %s, Value = %s' % (a5, b5))
                                            #logger.debug('++++++++ A1 Key = %s, A3 Key = %s, A4 Key=%s' % (a1, a3, a4))
                                            #vifObjCol[a5] = b5
                                            vifObjName = a3[2]
					    tmpTuple = ()
				            tmpTuple = (a1, a3)
                                            vifObjCol[(tmpTuple,vifObjName)] = b4
    return vifObjCol

#
# get the encapass relation object based on VIF object name and MODIFY state
#
def getVIFEncapassFromConfigNState(vifObjName, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get encap based on VIF's object name and its state
    """
    #logger.debug('++++++++++ get encap based on VIF object name for modify state ++++++')
    encapCol = {}
    #get the encapassociation for the vifObjName
    if (vifObjName):
         for c1, d1 in devCfg.iteritems():
             for c2, d2 in d1.iteritems():
                 if c2 == const.VALUE:
                     for c3, d3 in d2.iteritems():
                         if c3[0] == const.VENCAPASS:
                             tmpState = None
                             vifFlag = False
                             encapVal = None
                             tmpState = getRootObjectState(d3)
                             for c4, d4 in d3.iteritems():
                                 if c4.strip().lower() == const.VIF_NAME and d4 == vifObjName:
                                     vifFlag = True
                                 elif c4.strip().lower() == const.ENCAP:
                                     encapVal = d4
                             #logger.debug('++++++++ VEnCapass flag  = %s, encap = %s' % (vifFlag, encapVal))
                             if (vifFlag):
                                 encapCol[(c3, tmpState)] = encapVal


    return encapCol
#
# get tags and its state based on encap object name
#
def getEncapTagNStateFromConfig(encapObjName, devCfg, logger, deviceAuditFlag=False):
    """
    This is to get tags and its state based on encap object name
    """
    #logger.debug('+++++++++ get encap tag and state from config +++++++++++ encapObjName = %s' % (encapObjName))
    tagCol = {}
    if (encapObjName):
         for a1, b1 in devCfg.iteritems():
             for a2, b2 in b1.iteritems():
                 if a2 == const.VALUE:
                     for a3, b3 in b2.iteritems():
		         #logger.debug('++++++ Encap Tag A3 = %s B3 = %s' % (a3,b3))
                         if a3[0] == const.IFCTAG and a3[2] == encapObjName:
                             encapStat = -1
                             tagVal = -1
                             tagType = -1
                             for a4, b4 in b3.iteritems():
                                 if a4 == const.STATE:
                                     encapStat = b4
                                 elif a4 == const.TAG:
                                     tagVal = b4
                                 elif a4 == const.TYPE:
                                     tagType = b4
                             #logger.debug('+++++++ Values from the collection State = %s, tag = %s, tagType = %s' % (encapStat, tagVal, tagType))
		             tmpTuple = (a1, a3)
                             if tagType == 1: # this is for VLAN
                                 tagCol[(tmpTuple, encapObjName, tagType, encapStat)] = tagVal
                                 #logger.debug('+++++++++++ Tag object collection value = %s' % (tagCol))

    return tagCol

#
# replace token keys with actual key i.e. aaa_radiuspolicy_binding with authenticationvserver_authenticationradiuspolicy_binding
#
def replaceTokenName(tokenStr, replStr, cnfg, logger):
    """
    This is to replace token string with real object name in the dictionary
    """
    #logger.debug('+++++ This is to replace token string with replacement string ++++++')
    retCol = {}
    tmpCol = {}
    oldkey = None
    for a1, b1 in cnfg.iteritems():
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems():
                    if a3[1] == const.AUTHENTICATION_SERVER:
                        for a4, b4 in b3.iteritems():
                            tmpCol = {}
                            tmpTuple = ()
                            oldkey = None
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems():
                                    #logger.debug('++++ A5 = %s, b5 = %s' % (a5,b5))
                                    tmpStr = a5[1]
                                    if ((tmpStr.find(tokenStr) != -1) and (tmpStr.find('_binding') != -1)):
                                        #logger.debug('++++ found the object name to be replaced obj = %s' % (tmpStr))
                                        tmpStr = tmpStr.replace(tokenStr, replStr)
                                        #logger.debug('++++ replace string = %s' % (replStr))
                                        tmpTuple = (a5[0], tmpStr, a5[2])
                                        #logger.debug('++++ new tuple = %s' % str(tmpTuple))
                                        tmpCol = b5
                                        oldkey = a5
                                # replace the old key with new key and its value
                                if (oldkey is not None and len(tmpCol) != 0):
                                    b4[tmpTuple] = tmpCol
                                    #logger.debug('+++++ new Key = %s, collection = %s' % (tmpTuple, tmpCol))
                                    del b4[oldkey]
                                    #logger.debug('new col B4 = %s' % (b4))

    return

#
# This is to get arg entry in setArgs
def getSetArg(objName, logger):
    """
    This is to get arg entry in setArgs
    """
    argList = setArgs.setArgs
    for i in argList:
        argTup = i
        if objName == argTup[0]:
            return argTup

    return None

#
# This is to check if add is available in a particular argTup entry
def getObjAdd(argTup, logger):
    """
    This is to check if add is available in a particular argTup entry
    """
    if argTup is None:
        return True

    return argTup[2]['ADDOP']

#
# This is to get the setonly param from arg tuple
def getParamSetOnly(argTup, paramName, logger):
    """
    This is to get the setonly param from arg tuple
    """
    if argTup is None:
        return None

    if 'SETONLY_args' in argTup[2]:
        setOnlyArgTup = argTup[2]['SETONLY_args']
        for argName in setOnlyArgTup:
            if paramName == argName:
                if 'SETUID_REQD_args' in argTup[2]:
                    return argTup[2]['SETUID_REQD_args']
                else:
                    return ()

    return None


#
# Get connector and IP collection from service audit payload
#
def getIPNConForAttach(cnfg, logger):
    """
    This is to get Connector and IP collection for attach event
    """
    logger.debug('+++++++ get IP and Connector collection from Config with type 22 for attach & detach event ++++++')
    tmpList = []
    tmpCol = {}
    for a1, b1 in cnfg.iteritems(): # Device level - 0
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems(): # Function Group  config - 1
                    if a3[0] == const.FUNCTIONGROUP:
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems(): # -- Function level - 3
                                    if a5[0] == const.FUNCTION:
                                        for a6, b6 in b5.iteritems():
                                            if a6 == const.VALUE:
                                                #logger.debug('----- A6 = %s B6 = %s ' % (a6,b6))
                                                for a7, b7 in b6.iteritems():
                                                    tmpList = []
                                                    if a7[0] == const.CONNECTION: # -- Connectors
                                                        tmpConName = a7[2]
                                                        for a8, b8 in b7.iteritems():
                                                            #logger.debug('----- A8 = %s B8 = %s' % (a8,b8))
                                                            if a8 == const.VALUE:
                                                                for a9, b9 in b8.iteritems():
                                                                    if a9[0] == const.ATTACHIP:
                                                                        #logger.debug('----- A9 = %s B9 = %s ' % (a9,b9))
                                                                        tmpAddr = a9[2]
                                                                         # this is to remove masking from the IP
                                                                        if tmpAddr.find('/') > 0:
                                                                            tmpAddr = tmpAddr[:tmpAddr.find('/')]
                                                                        tmpList.append((a9[0], a9[1], tmpAddr))
                                                                        #logger.debug('----- tmpCol connector with IP Col = %s' % (tmpCol))
                                                                #tmpList.append(tmpCol)
                                                    if len(tmpList) > 0:
                                                        tmpCol[a1,a3,a5,a7] = tmpList
    logger.debug('----- connector with IP List = %s' % (tmpCol))
    return tmpCol

#
# get service group based on function group, function & connector details
#
def getSGForAttachIPConnector(con, cnfg, logger):
    """
    This is to get service group on the passed connector
    """
    logger.debug('+++++++ get service group IP and Connector collection from Config with type 22 for attach & detach event ++++++')
    tmpList = []
    tmpCol = {}
    # con is in collection of 3 tuples
    funGrp = con[1]
    funName = con[2]
    conName = con[3]
    sgTarget = None
    for a1, b1 in cnfg.iteritems(): # Device level - 0
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems(): # Function Group  config - 1
                    #logger.debug(' --- A3 = %s B3 = %s funGrp Name = %s' %(a3, b3, funGrp[1]))
                    if a3[1] == funGrp[1]: # compare function Group name
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems(): # -- Function level - 3
                                    #logger.debug(' --- A5 = %s B5 = %s fun Name = %s' %(a5, b5, funName[1]))
                                    if a5[1] == funName[1]: # compare function names
                                        for a6, b6 in b5.iteritems():
                                            if a6 == const.VALUE:
                                                #logger.debug('----- A6 = %s B6 = %s ' % (a6,b6))
                                                for a7, b7 in b6.iteritems():
                                                    #logger.debug('----- A7 = %s B7 = %s ' % (a7,b7))
                                                    if a7[0] == const.FOLDER and a7[1] == const.MFCNGSERVICEGROUP: # find service group
                                                        conFound = False
                                                        tmpValCol = {}
                                                        for a8, b8 in b7.iteritems():
                                                            if a8 == const.CONNECTOR and b8 == conName[2]:
                                                                conFound = True
                                                            if a8 == const.VALUE:
                                                                tmpValCol = b8
                                                        if conFound:
                                                            for x1,y1 in tmpValCol.iteritems():
                                                                for x2, y2 in y1.iteritems():
                                                                    if x2 == const.TARGET:
                                                                        sgTarget = y2
                                                                        logger.debug(' --- service group target = %s' % (sgTarget))
    # now get the object from config
    sgrpName = None
    portVal = None
    tmpObjCol = {}
    if sgTarget :
        tmpObjCol = getCompleteObjectFromConfig(sgTarget, cnfg)
    for d1, e1 in tmpObjCol.iteritems():
        for d2, e2 in e1.iteritems():
            if d2 == const.VALUE:
                for d3, e3 in e2.iteritems():
                    #logger.debug('--- D3 = %s E3 = %s' % (d3, e3))
                    if d3[1] == const.SERVICEGROUPNAME:
                        for d4, e4 in e3.iteritems():
                            if d4 == const.VALUE:
                                sgrpName = e4
                    elif d3[1] == const.PORT:
                        for g1, h1 in e3.iteritems():
                            if g1 == const.VALUE:
                                portVal = h1
                                #logger.debug('++++ service group name = %s  for con = %s' % (sgrpName, con[3]))

    logger.debug('++++ Serivce group name = %s port = %s for Connector = %s' % (sgrpName, portVal, con[3]))
    return (sgrpName, portVal)
#
# get mfcngservice group and related attach IPs
#
def getMFSGNAttachIps(mfSgCngName, cnfg, logger):
    """
    This is to get mfcng service group based on service group's instance name and related attach IPs
    """
    respCol = {}
    for a1, b1 in cnfg.iteritems(): # Device level - 0
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems(): # Function Group  config - 1
                     #logger.debug(' --- A3 = %s B3 = %s funGrp Name = %s' %(a3, b3, funGrp[1]))
                    #logger.debug('----- A3 = %s B3 = %s ' % (a3,b3))
                    if a3[0] == const.FUNCTIONGROUP: # compare service group folder config
                        #logger.debug('----- A3 = %s B3 = %s ' % (a3,b3))
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems(): # -- Function level - 3
                                    #logger.debug(' --- A5 = %s B5 = %s' %(a5, b5))
                                    tmpFunCol = {}
                                    tmpConName = None
                                    if a5[0] == const.FUNCTION: # compare function names
                                        for a6, b6 in b5.iteritems():
                                            if a6 == const.VALUE:
                                                #logger.debug('----- A6 = %s B6 = %s ' % (a6,b6))
                                                for a7, b7 in b6.iteritems():
                                                    #logger.debug('----- A7 = %s B7 = %s ' % (a7,b7))
                                                    if a7[0] == const.FOLDER and a7[1] == const.MFCNGSERVICEGROUP: # find service group
                                                        tmpCol = {}
                                                        for a8, b8 in b7.iteritems():
                                                            if a8 == const.VALUE:
                                                                tmpFunCol = b8
                                                            elif a8 == const.CONNECTOR:
                                                                tmpConName = b8
                                                        #logger.debug('+++++ TmpCol = %s tmpConName = %s' % (tmpFunCol, tmpConName))
                                                        if len(tmpFunCol) > 0:
                                                            for a9, b9 in tmpFunCol.iteritems():
                                                                for a10, b10 in b9.iteritems():
                                                                    if a10 == const.TARGET and b10 == mfSgCngName:
                                                                        # get the complete connector object from APIC config
                                                                        respCol = getConnectorNAttachIPFromConfig(tmpConName, cnfg, logger)
    logger.debug('++++ connector collection for matching sg = %s' % (respCol))
    return respCol
#
# get connector from the config
#
def getConnectorNAttachIPFromConfig(conName, cnfg, logger):
    """
    This is to get connector from config and its associated IP
    """
    respCol = {}
    for a1, b1 in cnfg.iteritems(): # Device level - 0
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems(): # Function Group  config - 1
                    if a3[0] == const.FUNCTIONGROUP:
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems(): # -- Function level - 3
                                    if a5[0] == const.FUNCTION:
                                        for a6, b6 in b5.iteritems():
                                            if a6 == const.VALUE:
                                                #logger.debug('----- A6 = %s B6 = %s ' % (a6,b6))
                                                for a7, b7 in b6.iteritems():
                                                    tmpList = []
                                                    if a7[0] == const.CONNECTION and a7[2] == conName: # -- Connectors
                                                        #tmpConName = a7[2]
                                                        for a8, b8 in b7.iteritems():
                                                            #logger.debug('----- A8 = %s B8 = %s' % (a8,b8))
                                                            if a8 == const.VALUE:
                                                                for a9, b9 in b8.iteritems():
                                                                    if a9[0] == const.ATTACHIP:
                                                                        #logger.debug('----- A9 = %s B9 = %s ' % (a9,b9))
                                                                        tmpAddr = a9[2]
                                                                         # this is to remove masking from the IP
                                                                        if tmpAddr.find('/') > 0:
                                                                            tmpAddr = tmpAddr[:tmpAddr.find('/')]
                                                                        tmpList.append((a9[0], a9[1], tmpAddr))
                                                                        #logger.debug('----- tmpCol connector with IP Col = %s' % (tmpCol))
                                                                #tmpList.append(tmpCol)

                                                    if len(tmpList) > 0:
                                                        respCol[a1,a3,a5,a7] = tmpList
    logger.debug('----- connector with IP List = %s' % (respCol))
    return respCol

#
# get the service group & service group member binding from the APIC config
#
def getSGObjectNMemberBinding(sgName, cnfg, logger):
    """
    This is to get service group & service group member binding from APIC config
    """
    respCol = {}
    for a1, b1 in cnfg.iteritems(): # Device level - 0
        for a2, b2 in b1.iteritems():
            if a2 == const.VALUE:
                for a3, b3 in b2.iteritems(): # Device Config  Group  config - 1
                    sgInstName = None
                    tmpSgName = None
                    bindCol = {}
                    #logger.debug(' --- A3 = %s B3 = %s funGrp Name = %s' %(a3, b3, funGrp[1]))
                    if a3[0] == const.FOLDER and a3[1] == const.SERVICEGROUP:
                        sgInstName = a3[2]
                        for a4, b4 in b3.iteritems():
                            if a4 == const.VALUE:
                                for a5, b5 in b4.iteritems():
                                    if a5[0] == const.PARAM and a5[1] == const.SERVICEGROUPNAME:
                                        for s1, t1 in b5.iteritems():
                                            if s1 == const.VALUE:
                                                tmpSgName = t1
                                    elif a5[0] == const.PARAM and a5[1] == const.PORT:
                                        for x1, y1 in b5.iteritems():
                                            if x1 == const.VALUE:
                                                tmpPortVal = y1
                                    elif a5[0] == const.FOLDER and a5[1] == const.SVCGROUP_SGMEM_BIND:
                                        tmpBindPort = None
                                        tmpBindIp = None
                                        for u1, v1 in b5.iteritems():
                                            if u1 == const.VALUE:
                                                for u2, v2 in v1.iteritems():
                                                    if u2[0] == const.PARAM and u2[1] == const.PORT:
                                                        for j1, h1 in v2.iteritems():
                                                            if j1 == const.VALUE:
                                                                tmpBindPort = h1
                                                    elif u2[0] ==const.PARAM and u2[1] == const.IP:
                                                        for j5, h5 in v2.iteritems():
                                                            if j5 == const.VALUE:
                                                                tmpBindIp = h5
                                        if tmpBindPort and tmpBindIp:
                                            bindCol[a5] = (tmpBindIp,tmpBindPort)
                        if tmpSgName:
                            logger.debug('+++ Service group name = %s bind Col = %s' % (tmpSgName, bindCol))
                            if tmpSgName.lower().strip() == sgName.lower().strip():
                                # if the service group is the same then get Attach IP from its connector
                                tmpConCol = {}
                                tmpConCol = getMFSGNAttachIps(sgInstName, cnfg, logger)
                                respCol[sgName] = bindCol
                                respCol =  dict(respCol.items() + tmpConCol.items())


    return respCol

