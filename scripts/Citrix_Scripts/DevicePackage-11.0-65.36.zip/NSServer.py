#
# Copyright (c) 2008-2015 Citrix Systems, Inc.
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

import json
import requests
import re

from util import scriptConst as const

class NSServer(object):
    """
    This is to configure and update NetScaler 
    """
    def __init__(self, logName, udevice=None, uversion=None):
        self.device= udevice
        self.version = uversion
        self.logger = logName
#
# device URL will be in this format 
# "http://" + devIp + "/nitro/v1/config/"
#
    def validate(self, modelVersion, sessionId, devUrl):
        headers = {'Cookie': "sessionid=" + sessionId}
        url = devUrl + "nsversion"
        self.logger.debug("Device URL = %s"% url)
        response = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
        respJson = response.json()
        versDict = respJson["nsversion"]
        versionStr = versDict["version"]
        # get the NetScaler version from the complete version string 'NetScaler NS10.1: Build 124.1.nc, Date: Jan 21 2014, 04:45:38'
        tmpVer = versionStr[versionStr.find('NS')+2:versionStr.find(':')]
        # now make sure there is no '.e' otherwise remove it as well
        if tmpVer.find('.e') > 0:
            tmpVer = tmpVer[:tmpVer.find('.e')]

        #self.logger.debug(" ==== Validate Response   = %s"%versDict["version"])
        #This is to append 'NS' in version string
        #deviceVersion = 'NS' + deviceVersion
        self.logger.debug(" Version String from device = %s search string = %s float Version Number = %s" % (versionStr, modelVersion, tmpVer))
        # the model version in this format 10.1.52.22 where first two digits are part of version details i.e. 10.1 and next digits are build number i.e. 52.22
        tmpModVer = str(modelVersion).split('.')
        mdFloatVal = tmpModVer[0] # major version i.e. 10
        dvFloatVal = float(tmpVer)
        minorModelVer = tmpModVer[1] # minor version i.e. 1 (mdFloatVal - int(mdFloatVal))*10
        tmpStrVer = str(dvFloatVal) #- int(dvFloatVal))*10
        tmpStrVer = tmpStrVer.split('.')
        minorDeviceVer = tmpStrVer[1] # ignore the first value 10.1 <-- 10 from here
        self.logger.debug(" Version details from device major = %s minor = %s " % (int(dvFloatVal), int(minorDeviceVer)))
        self.logger.debug(" Model Version details from major = %s minor = %s " % (mdFloatVal, minorModelVer))
        # device validation logic major version must be the same 
        if (int(mdFloatVal) == int(dvFloatVal) and int(minorDeviceVer) >= int(minorModelVer)): # re.search(deviceVersion, versionStr):
            return True
        elif (int(dvFloatVal) > int(mdFloatVal)):
            return True
        else:
            return False

    def clearNSConfig(self, sessionId, devUrl):
        self.logger.debug("++++++++ This is to clear NS config  ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"clear"},
                       "sessionid":sessionId, 
                       "nsconfig": { "force": "true", "level": "basic"}
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        #self.logger.debug( " Clear config Payload = %s"%payload)
        response = requests.post(devUrl, timeout=const.TIMEOUT, data=payload, headers=headers, verify=False)
        self.logger.debug(" Clear config Response = %s"%response)
        
        return response.json()
#
# Enable NetScaler's feature
#
    def enableFeatures(self, featureList, sessionId, devUrl):
        self.logger.debug("++++++++ This is to enable Feature on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
	#ftList = self.getNSFeatureList(sessionId, deviceIp)
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"enable"},
                       "sessionid":sessionId, 
                       "nsfeature": { "feature": featureList }
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        #self.logger.debug(" Feature ENABLE Payload = %s"%payload)
        response = requests.post(devUrl, data=payload, timeout=const.TIMEOUT,  headers=headers, verify=False)
        #self.logger.debug(" Feature ENABLE Response = %s"%response.text)
        
        return response.json()

#
# Disable NetScaler's Feature
#
    def disableFeatures(self, featureList, sesId, devUrl):
        """
        This is to disable Features in NetScaler 
        """
        self.logger.debug("++++++++ This is to disable Feature on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        payload = {"params":{"action":"disable"},
                       "sessionid":sesId,
                       "nsfeature": { "feature": featureList }
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug(" [NITRO] - Feature DISABLE Payload = %s"%payload)
        response = requests.post(devUrl, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
        self.logger.debug(" Feature DISABLE Response = %s"%response.text)

        return response.json()

#
# disable rest of the fearure from Device
#
    def disableRemainigFeature(self, ferList, sesId, devUrl):
        """
        This is to disable rest of the feature in device
        """
        devFerList = self.getNSFeatureList(sesId, devUrl)
        disFerList = []
        for i in devFerList:
            if i.lower() not in [ferName.lower() for ferName in ferList]:
                disFerList.append(i)
        self.logger.debug('+++++ disabling rest of the feature = %s' % (disFerList))
        resp = self.disableFeatures(disFerList, sesId, devUrl)
        return resp
#
# Enable Mode in NetScaler
#
    def enableNSMode(self, modeList, mode, sesId, url, devIp):
        """
        This is to enable NSMODE USNIP
        """
        self.logger.debug('+++++ This is to perform NSMODE operation at device level ++++')
        headers = {'Cookie': "sessionid=" + sesId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + devIp + "/nitro/v1/config/"
        payload = {"params":{"action": mode },
                           "sessionid":sesId,
                       "nsmode": { "mode": modeList }
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug(" [NITRO]--- ENABLE NSMODE Payload = %s"%payload)
        response = requests.post(url, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
        self.logger.debug(" ENABLE NSMODE responseUSNIP = %s"%response.text)

        return response.json()
#
# Enable LB Feature
#
    def enableLBFeature(self, sessionId, devUrl):
        self.logger.debug("++++++++ This is enable LB Feature on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"enable"},
                       "sessionid":sessionId, 
                       "nsfeature": { "feature": "lb"}
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug( "[NITRO]---  ENABLE Payload = %s"%payload)
        response = requests.post(devUrl, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
        self.logger.debug(" ENABLE Response = %s"%response)

        return response.json()
#
# Disable LB Feature
#
    def disableLBFeature(self, sessionId, devUrl):
        """ 
         This is to disable lb feature from the NetScaler 
         """
        self.logger.debug("++++++++ This is disable LB Feature on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"disable"},
                       "sessionid":sessionId,
                       "nsfeature": { "feature": "lb"}
                      }
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug( " [NITRO]--- DISABLE Payload = %s"%payload)
        response = requests.post(devUrl, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
        self.logger.debug(" DISABLE Response = %s"%response)

        return response.json()
#
# Enable CS Feature
# 
    def enableCSFeature(self, sessionId, devUrl):
        """
        This is enable CS Feature from NetScaler 
        """
        self.logger.debug( "++++++++ This is enable CS Feature on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"enable"},
                       "sessionid":sessionId,
                       "nsfeature": { "feature": "cs"}
                   }
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug(" CS ENABLE Payload = %s"%payload)
        response = requests.post(devUrl, data=payload, timeout= 0.1, headers=headers, verify=False)
        self.logger.debug(" CS ENABLE Response = %s"%response)

        return response.json()

#
# Disable CS Feature
#
    def disableCSFeature(self, sessionId, devUrl):
        """
        This is to disable lb feature from the NetScaler                                                         
        """
        self.logger.debug( "++++++++ This is disable CS Feature on NS ++++++++++")
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        #url = "http://" + deviceIp + "/nitro/v1/config/"
        payload = {"params":{"action":"disable"},
                       "sessionid":sessionId,
                       "nsfeature": { "feature": "cs"}
                      }
        payload = json.dumps(payload)
        payload = "object=" + payload
        self.logger.debug(" CS DISABLE Payload = %s"%payload)
        response = requests.post(devUrl, data=payload, timeout=const.TIMEOUT, headers=headers, verify=False)
        self.logger.debug(" CS DISABLE Response = %s"%response)

        return response.json()
#
# Get Feature List
#
    def getNSFeatureList(self, sessionId, devUrl):
        """
        This is to get all the NS feature present in the device
        """
        feaList = []

        self.logger.debug('++++++++++ Getting all the NS features from the device +++++++++')
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        url = devUrl + "nsfeature"
        resp = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
        #self.logger.debug('++++ Response = %s statusCode = %s' % (resp, resp.status_code))
        #self.logger.debug('+++++++ Json response = %s' % (resp.json()))
        erCode = 0
        tmpDict = {}
        respDict = resp.json()
        for a1, b1 in respDict.iteritems():
            if a1 == 'errorcode':
                erCode = b1
            elif a1 == 'nsfeature':
                tmpDict = b1
        self.logger.debug('Feature Response = %s' % (tmpDict)) 
        if erCode == 0:
            for i in tmpDict.keys():
                if i != 'feature':  # this check is required since there is redundant dataset for feature
                    feaList.append(i)
           
        return feaList
#
# This is get all the NS mode from device
#                         
    def getNSModeList(self, sessionId, devUrl):
        """
        This is to get all the NS mode from the device
        """
        modeList = []

        self.logger.debug('++++++++++ Getting all the NS Modes from the device +++++++++')
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        url = devUrl + "nsmode"
        resp = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
        #self.logger.debug('++++ Response = %s statusCode = %s' % (resp, resp.status_code))
        #self.logger.debug('+++++++ Json response = %s' % (resp.json()))
        erCode = 0
        tmpDict = {}
        respDict = resp.json()
        for a1, b1 in respDict.iteritems():
            if a1 == 'errorcode':
                erCode = b1
            elif a1 == 'nsmode':
                tmpDict = b1
        #self.logger.debug('Mode  Response = %s' % (tmpDict)) 
        if erCode == 0:
            for i in tmpDict.keys():
                if i != 'mode':  # this check is required since there is redundant dataset for feature
                    modeList.append(i)
           
        return modeList
#
# This is to get NS Feature
#
    def getNSFeature(self, devUrl, sessionId):
        """
        This is to get all the NS feature present in the device
        """
        feaList = []
        retCol = {}
        self.logger.debug('++++++++++ Getting all the NS features from the device +++++++++')
        headers = {'Cookie': "sessionid=" + sessionId, 'Content-Type': "application/x-www-form-urlencoded"}
        url = devUrl + "nsfeature"
        resp = requests.get(url, timeout=const.TIMEOUT, headers=headers, verify=False)
        #self.logger.debug('++++ Response = %s statusCode = %s' % (resp, resp.status_code))
        #self.logger.debug('+++++++ Json response = %s' % (resp.json()))
        erCode = 0
        tmpDict = {}
        respDict = resp.json()
        for a1, b1 in respDict.iteritems():
            if a1 == 'errorcode':
                erCode = b1
            elif a1 == 'nsfeature':
                retCol = b1
        self.logger.debug('Feature Response = %s' % (retCol)) 
           
        return retCol
                         
#
# This is to get list of enabled NS Feature
#
    def getNSEnableFeature(self, devUrl, sessionId):
        """
        This is to get all the NS enabled feature present in the device
        """
        enableFeaList = []
        feaCol= self.getNSFeature(devUrl, sessionId)
        if "feature" in feaCol:
            enableFeaList = feaCol["feature"]
        
        return enableFeaList
